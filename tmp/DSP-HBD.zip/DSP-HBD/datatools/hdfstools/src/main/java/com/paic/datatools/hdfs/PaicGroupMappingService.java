package com.paic.datatools.hdfs;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.security.GroupMappingServiceProvider;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

/**
 * create table GROUP_MAPPING (user varchar(50),groups varchar(200), primary key(user));
 * <p>
 * hadoop.security.group.mapping
 * <p>
 * HADOOP_CLASSPATH=$HADOOP_CLASSPATH:/home/cloudera/var/group/hadoopgroup.jar
 */
public class PaicGroupMappingService implements GroupMappingServiceProvider {
  private static final Log LOG = LogFactory.getLog(PaicGroupMappingService.class);

  public static final String GROUP_MAPPING_DB = "jdbc:mysql://stsz030133/sentry";
  public static final String GROUP_MAPPING_USERNAME = "sentry";
  public static final String GROUP_MAPPING_PASSWORD = "Sentry@123";

  private static ConcurrentHashMap<String, List<String>> groups = null;
  private static Thread groupMappingLoader;

  public PaicGroupMappingService() {
    groupMappingLoader = new Thread(new Runnable() {
      @Override
      public void run() {
        while (true) {
          loadGroupMapping();
          try {
            Thread.currentThread().sleep(3 * 60 * 1000);
          } catch (InterruptedException e) {
            LOG.error("groupMappingLoader thread interrupted!", e);
          }
        }
      }
    });
    groupMappingLoader.start();
  }

  private static synchronized void loadGroupMapping() {
    ConcurrentHashMap<String, List<String>> newGroups = new ConcurrentHashMap<>();
    try (Connection conn = DriverManager
        .getConnection(GROUP_MAPPING_DB, GROUP_MAPPING_USERNAME, GROUP_MAPPING_PASSWORD);

         Statement stmt = conn.createStatement();

         ResultSet rs = stmt.executeQuery("select * from GROUP_MAPPING ")) {
      while (rs.next()) {
        String user = rs.getString(1);
        String groups = Objects.requireNonNull(rs.getString(2));
        List<String> list = Arrays.asList(groups.split(","));
        newGroups.put(user, list);
      }
      groups = newGroups;
    } catch (SQLException e) {
      LOG.error("Get hadoop group mapping error!", e);
    }
  }

  @Override
  public List<String> getGroups(String user) throws IOException {
    if (groups == null) {
      loadGroupMapping();
    }

    List<String> groupList = groups.get(user);

    // 如果找不到组配置，返回一个和用户名一样的组名称
    if (groupList == null) {
      groupList = new ArrayList<>();
      groupList.add(user);
      LOG.error("CAN'T NOT FIND GROUPS FOR USER " + user);
    }

    return groupList;
  }

  @Override
  public void cacheGroupsRefresh() throws IOException {
    loadGroupMapping();  // 什么时候刷新？？
  }

  @Override
  public void cacheGroupsAdd(List<String> groups) throws IOException {
    // does nothing in this provider of user to groups mapping
  }

}
