package com.paic.datatools.hdfs;

import org.apache.commons.httpclient.util.DateUtil;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * java -cp $(hadoop classpath):lib/*:hdfstools-1.0.jar  com.paic.datatools.hdfs.DuTools 5
 */
public class DuTools extends Configured implements Tool {

    private static final Logger logger = LoggerFactory.getLogger(DuTools.class);

    public static final Path ROOT = new Path("hdfs://pasc/");
    public static final Map<Path, Long> consumedMap = new HashMap<>();
    public static final Map<Path, Path> pathTree = new HashMap<>();

    private static int MAX_DEPTH = 5;
    private static Long FILTER_FILE_LENGTH = 1024 * 1024 * 1024 * 10L;
    private static boolean SAVE_DB = true;

    public static FileSystem fs;

    public static void main(String[] args) throws Exception {
        ToolRunner.run(new DuTools(), args);
    }

    @Override
    public int run(String[] args) throws Exception {
        if (args.length == 1) {
            MAX_DEPTH = Integer.parseInt(args[0]);
        } else if (args.length == 2) {
            MAX_DEPTH = Integer.parseInt(args[0]);
            FILTER_FILE_LENGTH = Long.parseLong(args[1]);
        } else if (args.length == 3) {
            MAX_DEPTH = Integer.parseInt(args[0]);
            FILTER_FILE_LENGTH = Long.parseLong(args[1]);
            SAVE_DB = Boolean.parseBoolean(args[2]);
        }

        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm00");
        String frequence = sdf.format(new Date());
        logger.info("start hdfs used check. frequence=" + frequence);

        Configuration conf = new Configuration();
        System.setProperty("HADOOP_USER_NAME", "hdfs");
        fs = FileSystem.get(conf);
        consumedMap.put(ROOT, fs.getContentSummary(ROOT).getSpaceConsumed());
        traverseDirectory(ROOT, 1);
        fs.close();

        if (SAVE_DB) {
            saveValue(frequence);
        } else {
            for (Map.Entry<Path, Long> en : consumedMap.entrySet()) {
                System.out.println(en.getKey() + " : " + en.getValue());
            }
        }
        logger.info("end hdfs used check. frequence=" + frequence);
        return 0;
    }

    private static void traverseDirectory(final Path parent, final int depth) throws IOException {
        try {
            FileStatus[] fileStatuses = fs.listStatus(parent);
            for (FileStatus fileStatus : fileStatuses) {

                Path cpath = fileStatus.getPath();
                Long len;
                if (!fileStatus.isDirectory())
                    len = fileStatus.getLen();
                else
                    len = fs.getContentSummary(cpath).getSpaceConsumed();

                if (len > FILTER_FILE_LENGTH) {
                    consumedMap.put(cpath, len);
                    pathTree.put(cpath, parent);

                    // 遍历子目录
                    if (fileStatus.isDirectory() && depth < MAX_DEPTH)
                        traverseDirectory(cpath, depth + 1);
                }
            }
        } catch (FileNotFoundException e) {
        }
    }

    public static boolean saveValue(String frequence) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = DriverManager.getConnection(Constant.JDBC_URL, Constant.JDBC_USERNAME, Constant.JDBC_PASSWORD);
            conn.setAutoCommit(false);

            String sql = "INSERT INTO hdfs_used VALUES (SEQ_HDFS_USED.nextval ,? ,? ,? ,? )";
            pstmt = conn.prepareStatement(sql);
            for (Map.Entry<Path, Long> en : consumedMap.entrySet()) {
                String path = en.getKey().toString();
                Long size = en.getValue();
                Path parentPath = pathTree.get(en.getKey());
                String parentPathStr = parentPath == null ? null : parentPath.toString();
                logger.info(path + " : " + size + " , parentPath : " + parentPath);
                pstmt.setString(1, frequence);
                pstmt.setString(2, path);
                pstmt.setLong(3, size);
                pstmt.setString(4, parentPathStr);
                pstmt.executeUpdate();
            }
            conn.commit();
            return true;
        } catch (Exception e) {
            logger.error("save to db error!", e);
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.rollback();
                }
            } catch (SQLException e1) {
                logger.error("save to db error!", e);
            }
            return false;
        } finally {
            try {
                if (pstmt != null)
                    pstmt.close();
            } catch (SQLException e) {
                logger.error("save to db error!", e);
            }

            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException e) {

            }

        }
    }

}
