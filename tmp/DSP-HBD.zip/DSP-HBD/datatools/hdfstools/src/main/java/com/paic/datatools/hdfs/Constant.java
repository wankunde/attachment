package com.paic.datatools.hdfs;

public class Constant {
    public static final String JDBC_URL = "jdbc:oracle:thin:@172.16.54.35:1528:dsprt";

    public static final String JDBC_USERNAME = "dspsdg";

    public static final String JDBC_PASSWORD = "kiop0987";
}
