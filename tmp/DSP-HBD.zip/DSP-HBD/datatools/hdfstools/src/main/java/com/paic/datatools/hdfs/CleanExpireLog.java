package com.paic.datatools.hdfs;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

import java.io.IOException;

/**
 * hadoop jar hdfstools-1.0.jar com.paic.datatools.hdfs.CleanExpireLog /metadata/logs/spark_stdalone/eventlog 7
 */
public class CleanExpireLog {

  public static FileSystem fs;

  public static void main(String[] args) throws IOException {
    if (args.length != 2) {
      System.out.println("Usage : CleanExpireLog [logDir] [keepDays]");
    }

    Path logDir = new Path(args[0]);
    Integer keepDays = Integer.parseInt(args[1]);
    Long expireTs = System.currentTimeMillis() - 86400 * 1000 * keepDays;

    Configuration conf = new Configuration();
    System.setProperty("HADOOP_USER_NAME", "hdfs");

    fs = FileSystem.get(conf);
    FileStatus[] fileStatuses = fs.listStatus(logDir);
    for (FileStatus fileStatus : fileStatuses) {
      Long mt = fileStatus.getModificationTime();
      if (mt < expireTs) {
        System.out.println(fileStatus.toString() + " with mt " + mt + " will be deleted!");
        fs.delete(fileStatus.getPath(), true);
      }
    }
  }
}
