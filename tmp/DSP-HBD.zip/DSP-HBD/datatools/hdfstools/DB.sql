-- Create table
create table hdfs_used
(
  id        number,
  frequence varchar2(16),
  path      varchar2(2000),
  length      number,
  parent    varchar2(2000)
)
;
-- Create/Recreate indexes
create index IDX_hdfs_used on hdfs_used (frequence, path);
-- Create/Recreate primary, unique and foreign key constraints
alter table hdfs_used
  add constraint PK_hdfs_used primary key (ID);


-- Create sequence
create sequence SEQ_HDFS_USED
minvalue 1
maxvalue 9999999999999999999999999999
start with 1
increment by 1
cache 1000;