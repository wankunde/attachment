public class DataFrame {

  Schema schema;
  List<Row> rows;

}
