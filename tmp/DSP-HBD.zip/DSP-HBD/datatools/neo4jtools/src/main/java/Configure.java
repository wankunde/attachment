import java.util.Properties;

public class Configure {

  public String NEO4J_URI;
  public String NEO4J_USERNAME;
  public String NEO4J_PASSWORD;

  public Integer WORKER_POOL_SIZE;
  public Integer WORKER_BATCH_SIZE;

  public String[] JOB_DATA_FILES;
  public String JOB_DATA_DELIMITER;
  public ImportType JOB_IMPORT_TYPE;
  public String JOB_NODE_LABEL;
  public String JOB_NODE_KEY;
  public Integer JOB_NODE_COL;
  public String[] JOB_PROPERTIES_KEYS;
  public Integer[] JOB_PROPERTIES_INDICES;

  public String JOB_REL_CYPHER;
  public String JOB_REL_FROMLABEL;
  public String JOB_REL_FROMKEY;
  public String JOB_NODE_FROMCOL;
  public String JOB_REL_TOLABEL;
  public String JOB_REL_TOKEY;
  public String JOB_NODE_TOCOL;
  public String JOB_REL_RELATION;


  public Configure(Properties prop) {
    NEO4J_URI = parseStringProperty(prop, "neo4j.uri", "bolt://localhost:7687");
    NEO4J_USERNAME = parseStringProperty(prop, "neo4j.username", "neo4j");
    NEO4J_PASSWORD = parseStringProperty(prop, "neo4j.password", "neo4j");

    WORKER_POOL_SIZE = parseIntProperty(prop, "worker.pool_size", 100);
    WORKER_BATCH_SIZE = parseIntProperty(prop, "worker.batch_size", 100);

    JOB_DATA_FILES = parseStringsProperty(prop, "job.data_files", new String[]{});
    JOB_DATA_DELIMITER = parseStringProperty(prop, "job.data_delimiter", ",");

    JOB_IMPORT_TYPE = ImportType.valueOf(prop.getProperty("job.import_type"));
    if (JOB_IMPORT_TYPE == ImportType.NODE_CREATE) {
      JOB_NODE_LABEL = parseStringProperty(prop, "job.node_label", "");
    } else if (JOB_IMPORT_TYPE == ImportType.NODE_MERGE) {
      JOB_NODE_LABEL = parseStringProperty(prop, "job.node_label", "");
      String nodeMergeKey = parseStringProperty(prop, "job.node_key", "");
      JOB_NODE_KEY = nodeMergeKey.split(":")[0];
      JOB_NODE_COL = Integer.parseInt(nodeMergeKey.split(":")[1]);
    } else if (JOB_IMPORT_TYPE == ImportType.RELATION_MERGE) {
      JOB_REL_CYPHER = parseStringProperty(prop, "job.rel_cypher", "");
      JOB_REL_FROMLABEL = parseStringProperty(prop, "job.node_fromlabel", "");
      String nodeMergeKey = parseStringProperty(prop, "job.node_fromkey", "");
      JOB_NODE_KEY = nodeMergeKey.split(":")[0];
      JOB_NODE_COL = Integer.parseInt(nodeMergeKey.split(":")[1]);
    }

    // NODE_CREATE NODE_MERGE
    String[] jobProperties = parseStringsProperty(prop, "job.properties", new String[]{});
    int jpLength = jobProperties.length;
    JOB_PROPERTIES_KEYS = new String[jpLength];
    JOB_PROPERTIES_INDICES = new Integer[jpLength];
    for (int i = 0; i < jpLength; i++) {
      JOB_PROPERTIES_KEYS[i] = jobProperties[i].split(":")[0];
      JOB_PROPERTIES_INDICES[i] = Integer.parseInt(jobProperties[i].split(":")[1]);
    }
  }

  private static String parseStringProperty(Properties prop, String key, String defaultValue) {
    String value = prop.getProperty(key);
    return value != null ? value : defaultValue;
  }

  private static String[] parseStringsProperty(Properties prop, String key, String[] defaultValue) {
    String value = prop.getProperty(key);
    return value != null ? value.split(",") : defaultValue;
  }

  private static Integer parseIntProperty(Properties prop, String key, Integer defaultValue) {
    String value = prop.getProperty(key);
    return value != null ? Integer.parseInt(value) : defaultValue;
  }

  private static Long parseLongProperty(Properties prop, String key, Long defaultValue) {
    String value = prop.getProperty(key);
    return value != null ? Long.parseLong(value) : defaultValue;
  }

  private static Boolean parseBooleanProperty(Properties prop, String key, Boolean defaultValue) {
    String value = prop.getProperty(key);
    return value != null ? Boolean.parseBoolean(value) : defaultValue;
  }


  public static void main(String[] args) {
    System.out.println(ImportType.valueOf("NODE_CREATE"));
  }
}
