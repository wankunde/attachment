import org.apache.commons.io.FileUtils;
import org.apache.commons.io.LineIterator;
import org.neo4j.driver.v1.AuthTokens;
import org.neo4j.driver.v1.Driver;
import org.neo4j.driver.v1.GraphDatabase;
import org.neo4j.driver.v1.Transaction;
import org.neo4j.driver.v1.Value;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static org.neo4j.driver.v1.Values.parameters;
import static org.neo4j.driver.v1.Values.value;

/**
 * cd ../neo4j && java -cp neo4jtools-1.0.jar:lib/* DataImporter -c conf/node_merge.properties
 */
public class DataImporter implements AutoCloseable {

  private Configure conf;

  private Driver driver;
  private Map<Integer, CompletableFuture> workerMap;
  private ExecutorService threadPool;

  public DataImporter(Properties prop) {
    conf = new Configure(prop);
    driver = GraphDatabase.driver(conf.NEO4J_URI, AuthTokens.basic(conf.NEO4J_USERNAME, conf.NEO4J_PASSWORD));
    workerMap = new ConcurrentHashMap<>();
    threadPool = Executors.newFixedThreadPool(conf.WORKER_POOL_SIZE);
  }

  @Override
  public void close() {
    driver.close();

    try {
      threadPool.shutdown();
      if (!threadPool.awaitTermination(60, TimeUnit.SECONDS)) {
        // 超时的时候向线程池中所有的线程发出中断(interrupted)。
        threadPool.shutdownNow();
      }
    } catch (InterruptedException e) {
      // awaitTermination方法被中断的时候也中止线程池中全部的线程的执行。
      System.out.println("awaitTermination interrupted: " + e);
      threadPool.shutdownNow();
    }
  }

  public static void main(String... args) throws Exception {
    // load default config
    ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
    Properties prop = new Properties();
//    InputStream is = classLoader.getResourceAsStream("node_merge.properties");
//    prop.load(is);

    // load user config
    for (int i = 0; i < args.length; i++) {
      if (args[i].startsWith("-")) {
        if (args[i].equals("-c") || args[i].equals("--config")) {
          prop.load(new FileInputStream(args[++i]));
        } else if (args[i].startsWith("--")) {
          prop.setProperty(args[i].substring(2), args[++i]);
        }
      }
    }

    try (DataImporter importer = new DataImporter(prop)) {
      importer.doImport();
    }
  }

  public Integer asyncImport(final String cypher, final Value nodes) {
    Long ts = System.currentTimeMillis();

    driver.session().beginTransactionAsync()
        .thenCompose(tx ->
            tx.runAsync(cypher, nodes)
                .exceptionally(e -> {
                  e.printStackTrace();
                  return null;
                })
                .thenApply(ignore -> tx)
        ).thenCompose(Transaction::commitAsync);

    System.out.println("Thread : " + Thread.currentThread().getName() + "\t" + (System.currentTimeMillis() - ts));
    return 0;
  }


  public void submitJob(final String cypher, final Value batch, final Integer offset) {
    CompletableFuture future = CompletableFuture.supplyAsync(() -> asyncImport(cypher, batch), threadPool)
        .whenComplete((s, e) -> {
          if (e != null)
            System.out.println("ImportWorker error : " + e);

          workerMap.remove(offset);
        });
    workerMap.put(offset, future);
  }


  public String generateCypher() {
    String label;
    String key;
    String fromLabel;
    String fromKey;
    String toLabel;
    String toKey;
    String relation;

    String cypher = null;
    switch (conf.JOB_IMPORT_TYPE) {
      case NODE_CREATE:
        label = conf.JOB_NODE_LABEL;
        cypher = "UNWIND {batch} as row CREATE (n:" + label + ") SET n = row";
        break;
      case NODE_MERGE:
        label = conf.JOB_NODE_LABEL;
        key = conf.JOB_NODE_KEY;
        cypher = "UNWIND {batch} as row MERGE (n:" + label + " {" + key + ":row." + key + " }) SET n = row.properties";
        break;
      case RELATION_CREATE:
        cypher = "MERGE (n:Mobile {mobile:$mobile}) SET n:Mobile SET n = $data RETURN id(n)";
        break;
      case RELATION_MERGE:
        fromLabel = conf.JOB_REL_FROMLABEL;
        fromKey = conf.JOB_REL_FROMKEY;
        toLabel = conf.JOB_REL_TOLABEL;
        toKey = conf.JOB_REL_TOKEY;
        relation = conf.JOB_REL_RELATION;
        cypher = "UNWIND {batch} as row " +
            "MATCH (from:" + fromLabel + " {" + fromKey + ":row." + fromKey + "}) " +
            "MATCH (to:" + toLabel + " {" + toKey + ":row." + toKey + "}) " +
            "MERGE (from)-[rel:" + relation + "]->(to) set rel = row.properties";
        break;
    }

    return cypher;
  }

  public void doImport() throws IOException {
    Long ts = System.currentTimeMillis();

    HashMap<String, String> row = new HashMap<>((int) (conf.JOB_PROPERTIES_KEYS.length / 0.75F + 1), 0.75F);
    Value[] batchRows = new Value[conf.WORKER_BATCH_SIZE];

    for (String dataFile : conf.JOB_DATA_FILES) {
      try (LineIterator it = FileUtils.lineIterator(new File(dataFile), "UTF-8")) {
        String cypher = generateCypher();
        int offset = 0;
        int pos = 0;

        while (it.hasNext()) {
          String[] cols = it.nextLine().split(conf.JOB_DATA_DELIMITER);

          row.clear();
          for (int idx = 0; idx < conf.JOB_PROPERTIES_KEYS.length; idx++) {
            row.put(conf.JOB_PROPERTIES_KEYS[idx], cols[conf.JOB_PROPERTIES_INDICES[idx]]);
          }

          switch (conf.JOB_IMPORT_TYPE) {
            case NODE_CREATE:
              batchRows[pos++] = value(row);
              break;
            case NODE_MERGE:
              batchRows[pos++] = parameters(conf.JOB_NODE_KEY, cols[conf.JOB_NODE_COL], "properties", row);
              break;
          }

          if (pos == conf.WORKER_BATCH_SIZE) {
            Value batch = parameters("batch", batchRows);
            submitJob(cypher, batch, offset);
            batchRows = new Value[conf.WORKER_BATCH_SIZE];
            pos = 0;
          }

          offset++;
        }

        if (pos > 0) {
          Value[] leftBatchRows = new Value[pos];
          System.arraycopy(batchRows, 0, leftBatchRows, 0, pos);
          Value batch = parameters("batch", leftBatchRows);
          submitJob(cypher, batch, offset);
        }

        System.out.println("test 1..");
        Collection<CompletableFuture> futures = workerMap.values();
        CompletableFuture.allOf(futures.toArray(new CompletableFuture[futures.size()])).join();
        System.out.println("test 2..");
      }
    }
    System.out.println("total time cost : " + (System.currentTimeMillis() - ts));
  }
}