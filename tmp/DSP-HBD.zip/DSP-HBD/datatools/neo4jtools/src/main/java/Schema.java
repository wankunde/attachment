public class Schema {

  String[] colNames;
  String[] colTypes;

  public Schema(String[] colNames, String[] colTypes) {
    this.colNames = colNames;
    this.colTypes = colTypes;
  }
}
