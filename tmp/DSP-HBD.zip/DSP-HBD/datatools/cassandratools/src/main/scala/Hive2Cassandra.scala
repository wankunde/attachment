import com.datastax.driver.core.ConsistencyLevel
import com.datastax.spark.connector._
import com.datastax.spark.connector.cql.CassandraConnector
import org.apache.spark.SparkConf
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.internal.Logging
import org.apache.spark.sql.SparkSession

/**
  * Created by WANKUN603 on 2018-08-14.
  *
  */
object Hive2Cassandra extends Logging {

  def main(args: Array[String]): Unit = {
    lazy val usage =
      raw"""Usage :
           |    --cassandraHost
           |    --keyspace
           |    --table
           |    --hiveSql
           |    --truncateTable
           |    --partitionKeyColumns
           |    --clusteringKeyColumns
           |    """.stripMargin

    val Array(cassandraHost: String,
    keyspace: String,
    table: String,
    hiveSql: String,
    truncateTable: Option[Boolean],
    partitionKeyColumns: Option[String],
    clusteringKeyColumns: Option[String]) = {

      val parseArgs: Array[Any] = new Array(7)
      for (namedArg <- args.grouped(2)) {
        if (namedArg(0).equals("--cassandraHost"))
          parseArgs(0) = namedArg(1)
        else if (namedArg(0).equals("--keyspace"))
          parseArgs(1) = namedArg(1).toLowerCase
        else if (namedArg(0).equals("--table"))
          parseArgs(2) = namedArg(1).toLowerCase
        else if (namedArg(0).equals("--hiveSql"))
          parseArgs(3) = namedArg(1)
        else if (namedArg(0).equals("--truncateTable"))
          parseArgs(4) = Some(namedArg(1).toBoolean)
        else if (namedArg(0).equals("--partitionKeyColumns"))
          parseArgs(5) = Some(namedArg(1).toLowerCase)
        else if (namedArg(0).equals("--clusteringKeyColumns"))
          parseArgs(6) = Some(namedArg(1).toLowerCase)
      }
      for (i <- 0 to 6) {
        if (i < 4 && parseArgs(i) == null) {
          log.info("parameters error!\n" + usage)
          System.exit(1)
        } else if (i >= 4 && parseArgs(i) == null) {
          parseArgs(i) = None
        }
      }
      parseArgs
    }

    val spark = SparkSession
      .builder()
      .appName("Spark to Cassandra")
      .config("spark.sql.warehouse.dir", "hdfs:///user/hive/warehouse")
      .config("spark.cassandra.connection.host", cassandraHost)
      .config("spark.cassandra.connection.port", 9042)
//      .config("spark.cassandra.output.consistency.level", "ALL")
      .config("spark.cleaner.ttl", "3600")
      .enableHiveSupport()
      .getOrCreate()

    import spark.sql
    sql("set spark.sql.caseSensitive=false")
    val sqlDF = sql(hiveSql)

    CassandraConnector(spark.sparkContext.getConf).withSessionDo { session =>
      val rs = session.execute(s"SELECT table_name FROM system_schema.tables WHERE keyspace_name='${keyspace}' and table_name='${table}'")
      if (rs.all().size() == 0) {
        sqlDF.createCassandraTable(
          keyspace,
          table,
          if (partitionKeyColumns == None) None else Some(partitionKeyColumns.get.split(",")),
          if (clusteringKeyColumns == None) None else Some(clusteringKeyColumns.get.split(","))
        )
        session.execute(s""" ALTER TABLE ${keyspace}.${table} WITH compaction = { 'class' :  'LeveledCompactionStrategy'  } """)
      } else
        log.debug(s"Cassandra table ${keyspace}.${table} already exists!")

      if (truncateTable.getOrElse(false))
        session.execute(s" TRUNCATE TABLE ${keyspace}.${table} ")
    }

    val columnsBroadcast: Broadcast[Array[String]] = spark.sparkContext.broadcast(sqlDF.columns)
    val confBroadcast: Broadcast[SparkConf] = spark.sparkContext.broadcast(spark.sparkContext.getConf)

    sqlDF.foreachPartition(iterator => {
      val columns = columnsBroadcast.value
      val columnsStr = columns.mkString(",")
      val placeholder = columns.map(_ => "?").mkString(",")

      val pKeys = if (partitionKeyColumns == None) Array[String]() else partitionKeyColumns.get.split(",")
      val cKeys = if (clusteringKeyColumns == None) Array[String]() else clusteringKeyColumns.get.split(",")
      val conditionCols = (pKeys ++ cKeys)
      log.info("partitionKeyColumns : " + partitionKeyColumns.mkString(","))
      log.info("clusteringKeyColumns : " + clusteringKeyColumns.mkString(","))
      log.info("pKeys : " + pKeys.mkString(","))
      log.info("cKeys : " + cKeys.mkString(","))
      log.info("conditionCols : " + conditionCols.mkString(","))
      val idx = conditionCols.map(col => columns.indexOf(col))
      val condition = conditionCols.map(col => col + " = ?").mkString(" AND ")
      val delSql = s"""DELETE FROM ${keyspace}.${table} WHERE ${condition}"""
      val insertSql = s"""INSERT INTO ${keyspace}.${table}(${columnsStr}) VALUES(${placeholder})"""

      CassandraConnector(confBroadcast.value).withSessionDo { session =>
        val delPstmt = if (conditionCols.size > 0) Some(session.prepare(delSql)) else None
        val insertPstmt = session.prepare(insertSql)
        while (iterator.hasNext) {
          val seq = iterator.next().toSeq.asInstanceOf[Seq[AnyRef]]
          //            log.debug("params :" + seq)

          //            delPstmt match {
          //              case Some(stmt: Statement) => {
          //                val delValues = idx.foldLeft(ListBuffer[AnyRef]())((delValues: ListBuffer[AnyRef], i: Int) => {
          //                  delValues.append(seq(i))
          //                  delValues
          //                })
          //                session.executeAsync(stmt.bind(delValues: _*))
          //              }
          //              case None =>
          //            }

          session.execute(insertPstmt.bind(seq: _*))
        }
      }
    })

    spark.stop()
  }
}
