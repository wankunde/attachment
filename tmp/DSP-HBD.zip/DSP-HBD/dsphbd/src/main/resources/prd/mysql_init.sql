create database dsphbd default character set utf8 collate utf8_general_ci;

create user dsphbd@'localhost' identified by 'kiop0987';

grant all privileges on dsphbd.* to dsphbd;