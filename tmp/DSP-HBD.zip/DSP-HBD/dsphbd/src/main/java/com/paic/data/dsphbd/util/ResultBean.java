package com.paic.data.dsphbd.util;

/**
 * Created by wankun603 on 2018-06-21.
 */
public class ResultBean {
  public static final Integer OK = 0;
  public static final Integer CREATEED = 0;
  public static final Integer NOT_MODIFY = 0;
  public static final Integer UNAUTHORIZED = 401;
  public static final Integer UNAUTHORIZED_NOTOKEN = 997;//4011;
  public static final Integer UNAUTHORIZED_ERROR = 998;
  public static final Integer UNAUTHORIZED_EXPIRE = 4013;
  public static final Integer UNAUTHORIZED_NO_CONSIST = 4014;
  public static final Integer UNAUTHORIZED_SIGN_ERROR = 4015;
  public static final Integer UNAUTHORIZED_SERVER_ERROR = 999;
  public static final Integer FORBIDDEN = 403;
  public static final Integer NOT_FOUND = 404;
  public static final Integer INVALID_REQUST = 422;
  public static final Integer SYS_ERROR = 500;

  public static final ResultBean SUCCESS_OK = new ResultBean(null, OK,"success");


  //@XStreamAlias("data")
  private Object data;

  //@XStreamAlias("err")
  private Integer err;

  //@XStreamAlias("msg")
  private String msg;

  private String errmsg;

  private Integer status;

  public ResultBean() { }

  public ResultBean(Object data, ResultMsgBean msgBean) {
    this.data = data;
    this.status = this.err = msgBean.err;
    this.msg= msgBean.msg;
  }

  public ResultBean(Object data, Integer err, String msg) {
    this.data = data;
    this.err = err;
    this.msg = msg;

    this.errmsg = msg;

    this.status= err;

    if(status == 0){
      this.status = 1;
    }
  }

  public Object getData() {
    return data;
  }
  public void setData(Object data) {
    this.data = data;
  }
  public Integer getErr() {
    return err;
  }
  public void setErr(Integer err) {
    this.err = err;
    this.status= err;

    if(status == 0){
      this.status = 1;
    }
  }

  public String getMsg() {
    return msg;
  }

  public void setMsg(String msg) {
    this.msg = msg;
    this.errmsg = msg;
  }

  public String getErrmsg() {
    return errmsg;
  }

  public void setErrmsg(String errmsg) {
    this.errmsg = errmsg;
  }

  public Integer getStatus() {
    return status;
  }

  public void setStatus(Integer status) {
    this.status = status;
  }

  @Override
  public String toString() {
    return "ResultBean [data=" + data + ", err=" + err + ", msg=" + msg + ", errmsg=" + errmsg + ", status="
            + status + "]";
  }
}
