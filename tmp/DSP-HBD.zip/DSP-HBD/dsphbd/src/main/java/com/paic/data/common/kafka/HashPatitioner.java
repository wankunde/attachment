package com.paic.data.common.kafka;

import kafka.producer.Partitioner;
import kafka.utils.VerifiableProperties;

/**
 * Created by WANKUN603 on 2018-07-10.
 */
public class HashPatitioner<T> implements Partitioner {

  public HashPatitioner(VerifiableProperties props) {

  }

  @Override
  public int partition(Object key, int numPartitions) {
    return Math.abs(key.hashCode() % numPartitions);
  }
}
