package com.paic.data.common.hive;

import org.apache.hive.jdbc.HiveStatement;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
import java.util.concurrent.Callable;

/**
 * Created by WANKUN603 on 2018-08-09.
 */
public class HiveRunner implements Callable {

  private String queryId;
  private String server2Url;
  private String server2UserName;
  private String server2Password;

  private String sqlText;
  private Map<String, String> configuration;

  private String server2Logdir;

  public HiveRunner(String queryId, String server2Url, String server2UserName, String server2Password,
                    String sqlText, Map<String, String> configuration, String server2Logdir) {
    this.queryId = queryId;
    this.server2Url = server2Url;
    this.server2UserName = server2UserName;
    this.server2Password = server2Password;
    this.sqlText = sqlText;
    this.configuration = configuration;
    this.server2Logdir = server2Logdir;
  }

  @Override
  public Object call() throws Exception {
    try (Connection con = DriverManager.getConnection(server2Url, server2UserName, server2Password)) {
      try (Statement stmt = con.createStatement()) {
        Thread logThread = new Thread(new LogRunnable((HiveStatement) stmt, queryId, server2Logdir));
        logThread.setDaemon(true);
        logThread.start();
        for (Map.Entry<String, String> en : configuration.entrySet()) {
          stmt.execute("set " + en.getKey() + "=" + en.getValue() + ";");
        }
        return stmt.executeQuery(sqlText);
      }
    }
  }

  //进度信息的轮询线程实现
  static class LogRunnable implements Runnable {
    private final HiveStatement stmt;
    private final String queryId;
    private final String server2Logdir;
    private final BufferedWriter logWriter;

    LogRunnable(HiveStatement hiveStatement, String queryId, String server2Logdir) throws IOException {
      this.stmt = hiveStatement;
      this.queryId = queryId;
      this.server2Logdir = server2Logdir;
      logWriter = Files.newBufferedWriter(Paths.get(server2Logdir, queryId));
    }

    private void updateQueryLog() {
      List<String> queryLogs = null;
      try {
        queryLogs = stmt.getQueryLog();
      } catch (SQLException e) {
        e.printStackTrace();
      }
      for (String log : queryLogs) {
        System.out.println("进度信息-->" + log);
      }
    }

    @Override
    public void run() {
      try {
        while (stmt.hasMoreLogs()) {
          updateQueryLog();
          Thread.sleep(1000);
        }
      } catch (InterruptedException e) {
        e.getStackTrace();
      } finally {
        if (logWriter != null) {
          try {
            logWriter.close();
          } catch (IOException e) {

          }
        }
      }
    }
  }
}
