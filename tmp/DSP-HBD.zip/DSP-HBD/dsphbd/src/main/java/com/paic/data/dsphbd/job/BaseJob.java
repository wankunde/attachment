package com.paic.data.dsphbd.job;

/**
 * Created by WANKUN603 on 2016-05-11.
 */

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.framework.imps.CuratorFrameworkState;
import org.apache.curator.framework.recipes.leader.LeaderLatch;
import org.apache.curator.framework.recipes.leader.LeaderLatch.State;
import org.apache.curator.retry.ExponentialBackoffRetry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import java.util.concurrent.TimeUnit;

public abstract class BaseJob {
    protected Logger logger = LoggerFactory.getLogger(this.getClass());
    protected
    @Value("${dsphbd.zookeeper.connection}")
    String VAST_ZOOKEEPER_CONNECTION;
    protected
    @Value("${dsphbd.zookeeper.root}")
    String VAST_ZOOKEEPER_ROOT;
    protected
    @Value("${dsphbd.zookeeper.session.timeout.ms:60000}")
    String DEFAULT_SESSION_TIMEOUT;
    protected
    @Value("${dsphbd.zookeeper.connection.timeout.ms:15000}")
    String DEFAULT_CONNECTION_TIMEOUT;
    protected
    @Value("${dsphbd.zookeeper.job.disable}")
    String VAST_ZOOKEEPER_JOB_DISABLE;
    protected
    @Value("${dsphbd.job.forcerun}")
    String VAST_JOB_FORCERUN;
    private volatile CuratorFramework client;
    private String path;
    private LeaderLatch latch;

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    protected boolean isStop = false;

    protected boolean isRun() {
        if (isStop()) return false;
        if ("true".equalsIgnoreCase(VAST_ZOOKEEPER_JOB_DISABLE)) {
            if ("true".equalsIgnoreCase(VAST_JOB_FORCERUN)) {
                return true;
            }
        } else {
            return isLeader();
        }
        return false;
    }

    protected CuratorFramework getCuratorFramework() {
        if (client == null) {
            synchronized (BaseJob.class) {
                if (client == null) {
                    client = CuratorFrameworkFactory.newClient(VAST_ZOOKEEPER_CONNECTION, Integer.parseInt(DEFAULT_SESSION_TIMEOUT),
                            Integer.parseInt(DEFAULT_CONNECTION_TIMEOUT), new ExponentialBackoffRetry(1000, 3));
                    client.start();
                }
            }
        }
        if (client.getState().equals(CuratorFrameworkState.STOPPED)) client.start();
        return client;
    }

    protected boolean isLeader() {
        this.path = VAST_ZOOKEEPER_ROOT + "/" + getClass().getSimpleName();

        if (latch == null) {
            latch = new LeaderLatch(getCuratorFramework(), path);
            try {
                latch.start();
            } catch (Exception e) {
                logger.error("", e);
            }
        }
        try {
            if (latch.hasLeadership()) {
                return true;
            }
            if (latch.getState().equals(State.CLOSED)) latch.start();
            return latch.await(3, TimeUnit.SECONDS);
        } catch (Exception e) {
            logger.error("", e);
        }
        return false;
    }

    public boolean isStop() {
        synchronized (BaseJob.class) {
            return isStop;
        }
    }

    public void setStop(boolean isStop) {
        synchronized (BaseJob.class) {
            this.isStop = isStop;
        }
    }
}
