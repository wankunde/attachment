package com.paic.data.dsphbd.service.impl;

import com.paic.data.dsphbd.service.HiveService;
import org.apache.hadoop.hive.conf.HiveConf;
import org.apache.hadoop.hive.metastore.MetaStoreUtils;
import org.apache.hadoop.hive.ql.Context;
import org.apache.hadoop.hive.ql.ErrorMsg;
import org.apache.hadoop.hive.ql.QueryPlan;
import org.apache.hadoop.hive.ql.exec.FetchTask;
import org.apache.hadoop.hive.ql.exec.TaskFactory;
import org.apache.hadoop.hive.ql.hooks.HookUtils;
import org.apache.hadoop.hive.ql.lockmgr.HiveTxnManager;
import org.apache.hadoop.hive.ql.lockmgr.TxnManagerFactory;
import org.apache.hadoop.hive.ql.log.PerfLogger;
import org.apache.hadoop.hive.ql.metadata.AuthorizationException;
import org.apache.hadoop.hive.ql.parse.*;
import org.apache.hadoop.hive.ql.plan.TableDesc;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.GnuParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.io.FileUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hive.cli.CliDriver;
import org.apache.hadoop.hive.cli.CliSessionState;
import org.apache.hadoop.hive.common.LogUtils;
import org.apache.hadoop.hive.common.LogUtils.LogInitializationException;
import org.apache.hadoop.hive.common.io.CachingPrintStream;
import org.apache.hadoop.hive.conf.HiveConf;
import org.apache.hadoop.hive.metastore.api.FieldSchema;
import org.apache.hadoop.hive.metastore.api.Schema;
import org.apache.hadoop.hive.ql.Driver;
import org.apache.hadoop.hive.ql.processors.CommandProcessor;
import org.apache.hadoop.hive.ql.processors.CommandProcessorFactory;
import org.apache.hadoop.hive.ql.session.SessionState;

import java.sql.*;
import java.util.List;
import java.util.Map;

/**
 * Created by wankun603 on 2018-06-26.
 */
@Service
public class HiveServiceImpl implements HiveService {

  private static final Logger LOG = LoggerFactory.getLogger(HiveServiceImpl.class);

  private Context ctx;

  private static final HiveConf hiveConf = new HiveConf();

  @Value("#{configProperties['hive.server2.url']}")
  private String server2Url;

  @Value("#{configProperties['hive.server2.username']}")
  private String server2UserName;

  @Value("#{configProperties['hive.server2.password']}")
  private String server2Password;

  @Override
  public List<FieldSchema> parseHiveSql(String hql) throws Exception {
    BaseSemanticAnalyzer sem = compile(hql, hiveConf);
    Schema schema = getSchema(sem, hiveConf);

    return schema.getFieldSchemas();
  }

  /**
   * Compile a new query, but potentially reset taskID counter.  Not resetting task counter
   * is useful for generating re-entrant QL queries.
   *
   * @param command The HiveQL query to compile
   * @param conf
   * @return 0 for ok
   */
  public BaseSemanticAnalyzer compile(String command, HiveConf conf) throws Exception {
    TaskFactory.resetId();
    SessionState.setCurrentSessionState(CliSessionState.start(conf));
    SessionState.get().initTxnMgr(conf);

    // generate new query id
    String queryId = QueryPlan.makeQueryId();
    conf.setVar(HiveConf.ConfVars.HIVEQUERYID, queryId);

    try {
      command = new VariableSubstitution().substitute(conf, command);
      ctx = new Context(conf);
      ctx.setCmd(command);
      ctx.setHDFSCleanup(true);

      ParseDriver pd = new ParseDriver();
      ASTNode tree = pd.parse(command);
      tree = ParseUtils.findRootNonNullToken(tree);

      BaseSemanticAnalyzer sem = SemanticAnalyzerFactory.get(conf, tree);
      sem.analyze(tree, ctx);

      return sem;
    } catch (Exception e) {
      ErrorMsg error = ErrorMsg.getErrorMsg(e.getMessage());
      String errorMessage = "FAILED: " + e.getClass().getSimpleName();
      if (error != ErrorMsg.GENERIC_ERROR) {
        errorMessage += " [Error " + error.getErrorCode() + "]:";
      }

      // HIVE-4889
      if ((e instanceof IllegalArgumentException) && e.getMessage() == null && e.getCause() != null) {
        errorMessage += " " + e.getCause().getMessage();
      } else {
        errorMessage += " " + e.getMessage();
      }

      throw new Exception(errorMessage + "\n"
              + org.apache.hadoop.util.StringUtils.stringifyException(e));
    }
  }

  /**
   * Get a Schema with fields represented with native Hive types
   */
  public static Schema getSchema(BaseSemanticAnalyzer sem, HiveConf conf) {
    Schema schema = null;

    // If we have a plan, prefer its logical result schema if it's
    // available; otherwise, try digging out a fetch task; failing that,
    // give up.
    if (sem == null) {
      // can't get any info without a plan
    } else if (sem.getResultSchema() != null) {
      List<FieldSchema> lst = sem.getResultSchema();
      schema = new Schema(lst, null);
    } else if (sem.getFetchTask() != null) {
      FetchTask ft = sem.getFetchTask();
      TableDesc td = ft.getTblDesc();
      // partitioned tables don't have tableDesc set on the FetchTask. Instead
      // they have a list of PartitionDesc objects, each with a table desc.
      // Let's
      // try to fetch the desc for the first partition and use it's
      // deserializer.
      if (td == null && ft.getWork() != null && ft.getWork().getPartDesc() != null) {
        if (ft.getWork().getPartDesc().size() > 0) {
          td = ft.getWork().getPartDesc().get(0).getTableDesc();
        }
      }

      if (td == null) {
        LOG.info("No returning schema.");
      } else {
        String tableName = "result";
        List<FieldSchema> lst = null;
        try {
          lst = MetaStoreUtils.getFieldsFromDeserializer(tableName, td.getDeserializer(conf));
        } catch (Exception e) {
          LOG.warn("Error getting schema: "
                  + org.apache.hadoop.util.StringUtils.stringifyException(e));
        }
        if (lst != null) {
          schema = new Schema(lst, null);
        }
      }
    }
    if (schema == null) {
      schema = new Schema();
    }
    LOG.info("Returning Hive schema: " + schema);
    return schema;
  }



  @Override
  public boolean submit(String sqlText, Map<String, String> configuration) throws SQLException {
    Connection con = DriverManager.getConnection(server2Url, server2UserName, server2Password);
    Statement stmt = con.createStatement();
    for (Map.Entry<String, String> en : configuration.entrySet()) {
      stmt.execute("set " + en.getKey() + "=" + en.getValue() + ";");
    }
    return stmt.execute(sqlText);
  }

  @Override
  public ResultSet executeQuery(String sqlText, Map<String, String> configuration) throws SQLException {
    Connection con = DriverManager.getConnection(server2Url, server2UserName, server2Password);
    Statement stmt = con.createStatement();
    for (Map.Entry<String, String> en : configuration.entrySet()) {
      stmt.execute("set " + en.getKey() + "=" + en.getValue() + ";");
    }
    return stmt.executeQuery(sqlText);
  }
}
