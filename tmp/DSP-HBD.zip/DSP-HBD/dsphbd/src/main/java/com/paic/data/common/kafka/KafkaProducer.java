package com.paic.data.common.kafka;

import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;
import java.util.Random;

/**
 * Created by WANKUN603 on 2018-07-10.
 */
public class KafkaProducer {

  private static final Logger logger = LoggerFactory.getLogger(KafkaProducer.class);


  private final ProducerConfig config;
  private Producer<String, byte[]> producer;
  private Random random = new Random();

  public KafkaProducer(String brokerList) {
    this(brokerList, null, null, null);
  }

  public KafkaProducer(String brokerList, String type, String acks, String batch) {
    Properties props = new Properties();
    props.put("metadata.broker.list", brokerList);
    props.put("key.serializer.class", "kafka.serializer.StringEncoder");
//        props.put("producer.type", type != null ? type : "async");
    props.put("request.required.acks", acks != null ? acks : "1");
    props.put("partitioner.class", "com.paic.data.kafka.HashPatitioner");
    props.put("producer.type", "sync");
    if (batch != null) props.put("batch.num.messages", batch);

    config = new ProducerConfig(props);
    producer = null;
  }

  public KafkaProducer(Properties props) {
    this(new ProducerConfig(props));
  }

  public KafkaProducer(ProducerConfig config) {
    this.config = config;
    producer = null;
  }

  public synchronized void start() {
    if (producer == null) {
      producer = new Producer<String, byte[]>(config);
      logger.info("===> Kafka producer start!");
    }
  }

  public synchronized void stop() {
    if (producer != null) {
      producer.close();
      producer = null;
      logger.info("===> Kafka producer stop!");
    }
  }

  public void send(String topic, byte[] data) {
    if (producer != null) {
      producer.send(new KeyedMessage<String, byte[]>(topic,String.valueOf(random.nextInt(7)), data));
    }
  }

  public static void main(String[] args) throws InterruptedException {
    KafkaProducer producer = new KafkaProducer("10.25.164.45:9092,10.25.164.46:9092,10.25.164.47:9092,10.25.164.48:9092");
    producer.start();
    for (int i = 0; i < 10; i++) {
      producer.send("Test", ("hello:" + i).getBytes());
      Thread.sleep(10000);
    }
    producer.stop();
  }
}
