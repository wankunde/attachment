package com.paic.data.dsphbd.service;

import org.apache.hadoop.hive.metastore.api.FieldSchema;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

/**
 * Created by wankun603 on 2018-06-26.
 */
public interface HiveService {

  List<FieldSchema> parseHiveSql(String hql) throws Exception;

  boolean submit(String sqlText, Map<String, String> configuration) throws SQLException;

  ResultSet executeQuery(String sqlText, Map<String, String> configuration) throws SQLException;
}
