package com.paic.data.dsphbd.entity;

/**
 * Created by wankun603 on 2018-06-26.
 */
public class QueryRule {
  private String sparkTableName;
  private String createTime;
  private String modifyTime;
  private String resultTable;
  private String keepDays;
  private String isEnable;

  public String getSparkTableName() {
    return sparkTableName;
  }

  public void setSparkTableName(String sparkTableName) {
    this.sparkTableName = sparkTableName;
  }

  public String getCreateTime() {
    return createTime;
  }

  public void setCreateTime(String createTime) {
    this.createTime = createTime;
  }

  public String getModifyTime() {
    return modifyTime;
  }

  public void setModifyTime(String modifyTime) {
    this.modifyTime = modifyTime;
  }

  public String getResultTable() {
    return resultTable;
  }

  public void setResultTable(String resultTable) {
    this.resultTable = resultTable;
  }

  public String getKeepDays() {
    return keepDays;
  }

  public void setKeepDays(String keepDays) {
    this.keepDays = keepDays;
  }

  public String getIsEnable() {
    return isEnable;
  }

  public void setIsEnable(String isEnable) {
    this.isEnable = isEnable;
  }
}
