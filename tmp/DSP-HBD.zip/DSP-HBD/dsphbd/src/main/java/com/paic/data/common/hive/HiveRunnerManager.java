package com.paic.data.common.hive;

import org.springframework.stereotype.Service;

/**
 * Created by WANKUN603 on 2018-08-10.
 */
@Service
public class HiveRunnerManager {

}
