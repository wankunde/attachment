package com.paic.data.dsphbd.util;

import org.apache.commons.lang3.StringUtils;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

public class CookieUtils {
    /**
     * 添加Cookie
     * 
     * @param response
     * @param name   Cookie的名字
     * @param value  Cookie的值
     * @param maxAge Cookie的存活时间，单位秒
     */
    public static void addCookie(HttpServletRequest request, HttpServletResponse response, String name, String value, int maxAge) {
        
        Cookie cookie = new Cookie(name, value);
        //解决nginx中获取cookie的问题,cookie只能放在根下
        String path = "/";//request.getContextPath();
        if (StringUtils.isEmpty(path)){
            path = "/";
        }
        cookie.setPath(path);
        if (maxAge > 0)
            cookie.setMaxAge(maxAge);
        // 添加到客户端
        response.addCookie(cookie);
    }

    /**
     * 取出所有的Cookie
     * 
     * @param request
     * @return
     */
    public static Map<String, Cookie> getAllCookies(HttpServletRequest request) {
        Map<String, Cookie> cookie_map = new HashMap<String, Cookie>();
        Cookie[] cookies = request.getCookies();
        // 如果存在cookie,就存入Map
        if (cookies != null) {
            for (int i = 0; i < cookies.length; i++) {
                cookie_map.put(cookies[i].getName(), cookies[i]);
            }
        }
        return cookie_map;
    }

    /**
     * 在Cookie中通过Cookie名称获得Session中的SessionId
     * 
     * @param request
     * @param name
     * @return
     */
    public static String getCookieVal(HttpServletRequest request, String name) {
        Map<String, Cookie> cookie_map = getAllCookies(request);
        if (cookie_map.containsKey(name)) {
            Cookie cookie = cookie_map.get(name);
            return cookie.getValue();
        }
        return null;
    }
    
    /**
     * 删除cookie
     * @param name
     */
    public static void deleteCookie(HttpServletRequest request, HttpServletResponse response, String name){
        Cookie cookie = new Cookie(name, null);
        //解决nginx中获取cookie的问题,cookie只能放在根下
        String path = "/";//request.getContextPath();
        if (StringUtils.isEmpty(path)){
            path = "/";
        }       
        cookie.setPath(path);
        cookie.setMaxAge(0);
        response.addCookie(cookie);
    }
    
    public static void deleteAllCookie(HttpServletRequest request, HttpServletResponse response){
        Cookie[] cookies = request.getCookies();
        // 如果存在cookie,就存入Map
        if (cookies != null) {
            for (int i = 0; i < cookies.length; i++) {
                Cookie cookie = cookies[i];
                if (cookie.getPath()==null){
                    cookie.setPath("/");
                }
                cookie.setMaxAge(0);
                response.addCookie(cookie);
            }
        }
    }
}
