package com.paic.data.dsphbd.util;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.util.Map;

public class MyJdbcTemplate extends JdbcTemplate {

    protected RowMapper<Map<String, Object>> getColumnMapRowMapper() {
        return new MyColumnMapRowMapper();
    }
}
