package com.paic.data.dsphbd.util;

import java.util.List;

public class PaginationBean<T> {
    private Integer total;
    private Integer pageSize;
    private Integer pageCount;
    private Integer currentPage;

    private List<T> data;

    private Integer err;

    private String msg;

    public PaginationBean(Integer total, Integer pageSize, Integer pageCount, Integer currentPage, List<T> data) {
        super();
        this.total = total;
        this.pageSize = pageSize;
        this.pageCount = pageCount;
        this.currentPage = currentPage;
        this.data = data;
    }

    public PaginationBean(List<T> data, Integer err, String msg) {
        super();
        this.data = data;
        this.err = err;
        this.msg = msg;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getPageCount() {
        return pageCount;
    }

    public void setPageCount(Integer pageCount) {
        this.pageCount = pageCount;
    }

    public Integer getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(Integer currentPage) {
        this.currentPage = currentPage;
    }

    public List<T> getData() {
        return data;
    }

    public void setData(List<T> data) {
        this.data = data;
    }

    public Integer getErr() {
        return err;
    }

    public void setErr(Integer err) {
        this.err = err;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}