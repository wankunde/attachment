package com.paic.data.dsphbd.entity;

/**
 * Created by wankun603 on 2018-06-26.
 */
public class CustomEvent {
  private String ruleId;
  private String eventTypeId;
  private String createTime;
  private String createUser;
  private String modifyTime;
  private String modifyUser;
  private String eventType;

  public String getRuleId() {
    return ruleId;
  }

  public void setRuleId(String ruleId) {
    this.ruleId = ruleId;
  }

  public String getEventTypeId() {
    return eventTypeId;
  }

  public void setEventTypeId(String eventTypeId) {
    this.eventTypeId = eventTypeId;
  }

  public String getCreateTime() {
    return createTime;
  }

  public void setCreateTime(String createTime) {
    this.createTime = createTime;
  }

  public String getCreateUser() {
    return createUser;
  }

  public void setCreateUser(String createUser) {
    this.createUser = createUser;
  }

  public String getModifyTime() {
    return modifyTime;
  }

  public void setModifyTime(String modifyTime) {
    this.modifyTime = modifyTime;
  }

  public String getModifyUser() {
    return modifyUser;
  }

  public void setModifyUser(String modifyUser) {
    this.modifyUser = modifyUser;
  }

  public String getEventType() {
    return eventType;
  }

  public void setEventType(String eventType) {
    this.eventType = eventType;
  }
}
