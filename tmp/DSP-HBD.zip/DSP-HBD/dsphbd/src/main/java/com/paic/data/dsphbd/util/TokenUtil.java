package com.paic.data.dsphbd.util;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Date;

public class TokenUtil {
    public static final int EXPIRED_SECONDS = 1800;
    private static final String HEX_CHARS = "0123456789abcdef";
    /**
     * 令牌校验
     * @param token 令牌
     * @return  校验通过返回UM账号
     */
    public static String validateToken(String token) {
        try {
            if (token==null || token.trim().equals("")) {
                return null;
            }
            String user = getUser(token);
            token = removeUser(token);
            String time = getTime(token);
            if (System.currentTimeMillis() >= Long.valueOf(time)) {
                return null;
            }
            String rest = removeTime(token);
            for (int i = 0; i < user.length(); i++) {
                for (int j = 0; j < user.length(); j++) {
                    String v = shift(user, j);
                    String nt = generateToken(v, i, -1);
                    String nr = removeTime(removeUser(nt));
                    if (nr.equals(rest)) {
                        return v;
                    }
                }
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public static String generateTokenTimeout(String user, int timeoutSeconds) {
        int n = (int) (user.length() * Math.random());
        return generateToken(user, n, timeoutSeconds);
    }

    public static String generateToken(String user, int n, int timeoutSeconds) {
        String seed = shift(user, n);
        String md5 = md5Hex(seed);
        seed = shift(md5, n);
        seed = parseByte2HexStr(seed);
        return insertUser(insertTime(seed, timeoutSeconds), user);
    }

    private static String removeTime(String str) {
        return removeString(str, 13, 5);

    }

    private static String removeString(String str, int len, int x) {
        StringBuilder sb = new StringBuilder(str);
        for (int i = 0; i < len; i++) {
            int p = i * x - i;
            sb.deleteCharAt(p);
        }
        return sb.toString();
    }

    private static String getTime(String str) {
        return getString(str, 13, 5);

    }

    private static String getString(String str, int len, int x) {
        char[] cs = new char[len];
        char[] ss = str.toCharArray();
        for (int i = 0; i < len; i++) {
            int p = i * x;
            cs[i] = ss[p];
        }
        return new String(cs);
    }

    private static String removeUser(String str) {
        return removeString(str, 20, 4);
    }

    private static String getUser(String str) {
        return getString(str, 20, 4).replaceAll("[.]", "");
    }

    private static String insertUser(String str, String user) {
        int n = (int) (Math.random() * user.length());
        String v = fill(shift(user, n), 20, ".");
        return insertString(str, v, 4);
    }

    private static String fill(String str, int len, String f) {
        if (str.length() >= len) {
            return str;
        }
        StringBuilder sb = new StringBuilder(str);
        while (sb.length() != len) {
            sb.insert((int) (sb.length() * Math.random()), f);
        }
        return sb.toString();
    }

    private static String insertTime(String str, int timeoutSeconds) {
        int x = timeoutSeconds == -1 ? EXPIRED_SECONDS : timeoutSeconds;
        String time = String.valueOf(System.currentTimeMillis() + x * 1000);
        return insertString(str, time, 5);
    }

    private static String insertString(String origin, String inserts, int x) {
        StringBuilder sb = new StringBuilder(origin);
        char[] cs = inserts.toCharArray();
        for (int i = 0; i < cs.length; i++) {
            int p = i * x;
            sb.insert(p, cs[i]);
        }
        return sb.toString();
    }

    private static String shift(String user, int n) {
        char[] ss = user.toCharArray();
        char[] cs = new char[user.length()];
        for (int i = 0; i < cs.length; i++) {
            cs[i] = ss[(i + n) % cs.length];
        }
        for (int i = 0; i < cs.length / 2; i++) {
            char x = cs[i];
            cs[i] = cs[cs.length - i - 1];
            cs[cs.length - i - 1] = x;
        }
        return String.valueOf(cs);
    }

    
    /**
     * Converts a byte array to hex string.
     * 
     * @param b -
     *            the input byte array
     * @return hex string representation of b.
     */
    
    public static String toHexString(byte[] b) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < b.length; i++) {
            sb.append(HEX_CHARS.charAt(b[i] >>> 4 & 0x0F));
            sb.append(HEX_CHARS.charAt(b[i] & 0x0F));
        }
        return sb.toString();
    }

    /**
     * Converts a hex string into a byte array.
     * 
     * @param s -
     *            string to be converted
     * @return byte array converted from s
     */
    public static byte[] toByteArray(String s) {
        byte[] buf = new byte[s.length() / 2];
        int j = 0;
        for (int i = 0; i < buf.length; i++) {
            buf[i] = (byte) ((Character.digit(s.charAt(j++), 16) << 4) | Character
                    .digit(s.charAt(j++), 16));
        }
        return buf;
    }

    static MessageDigest getDigest() {
        try {
            return MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Calculates the MD5 digest and returns the value as a 16 element
     * <code>byte[]</code>.
     * 
     * @param data
     *            Data to digest
     * @return MD5 digest
     */
    public static byte[] md5(byte[] data) {
        return getDigest().digest(data);
    }

    /**
     * Calculates the MD5 digest and returns the value as a 16 element
     * <code>byte[]</code>.
     * 
     * @param data
     *            Data to digest
     * @return MD5 digest
     */
    public static byte[] md5(String data) {
        return md5(data.getBytes());
    }

    /**
     * Calculates the MD5 digest and returns the value as a 32 character hex
     * string.
     * 
     * @param data
     *            Data to digest
     * @return MD5 digest as a hex string
     */
    public static String md5Hex(byte[] data) {
        return toHexString(md5(data));
    }

    /**
     * Calculates the MD5 digest and returns the value as a 32 character hex
     * string.
     * 
     * @param data
     *            Data to digest
     * @return MD5 digest as a hex string
     */
    public static String md5Hex(String data) {
        return toHexString(md5(data));
    }
    private static int KEY_LENGTH = 16; // 指定key的字节长度，少的衄1�7�多的裁剄1�7
    private static String KEY_STR = "pingankey";// 密钥
    private static String CHARSETNAME = "UTF-8";// 编码
    private static final String KEY_ALGORITHM = "AES";
    private static final String CIPHER_ALGORITHM ="AES/ECB/PKCS5Padding"; // 指定填充方式

    private static SecretKeySpec generateKey(byte[] password) throws Exception {
        if (password.length == KEY_LENGTH) {
            return new SecretKeySpec(password, KEY_ALGORITHM);
        } else if (password.length < KEY_LENGTH) {
            byte[] pwd = new byte[KEY_LENGTH];
            for (int i = 0; i < password.length; i ++) {
                pwd[i] = password[i];
            }
            for (int i = password.length; i < KEY_LENGTH; i ++) {
                pwd[i] = 0;
            }
            return new SecretKeySpec(pwd, KEY_ALGORITHM);
        } else {
            byte[] pwd = new byte[KEY_LENGTH];
            for (int i = 0; i < KEY_LENGTH; i ++) {
                pwd[i] = password[i];
            }
            return new SecretKeySpec(pwd, KEY_ALGORITHM);
        }
    }

    public static byte[] encrypt(byte[] content, byte[] password) throws Exception {
        Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, generateKey(password));
        return cipher.doFinal(content);
    }

    public static byte[] decrypt(byte[] content, byte[] password) throws Exception {
        Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, generateKey(password));
        return cipher.doFinal(content);
    }

    /**
     * 原始加密
     * 
     * @param content
     *            霄1�7要加密的内容
     * @return
     */
    private static byte[] encrypt(String content) {
        try {
            byte[] byteContent = content.getBytes(CHARSETNAME);
            byte[] password = KEY_STR.getBytes(CHARSETNAME);
            return encrypt(byteContent, password); // 加密
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 原始解密
     * 
     * @param content
     *            待解密内宄1�7
     * @return
     */
    public static String decrypt(String content) {
        try {
            byte[] decryptFrom = parseHexStr2Byte(content);
            byte[] password = KEY_STR.getBytes(CHARSETNAME);
            byte[] result = decrypt(decryptFrom, password);
            return new String(result); // 加密
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 将二进制转换戄1�7进制
     * 
     * @param buf
     * @return
     */
    public static String parseByte2HexStr(String content) {
        byte[] encryptResult = encrypt(content);
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < encryptResult.length; i++) {
            String hex = Integer.toHexString(encryptResult[i] & 0xFF);
            if (hex.length() == 1) {
                hex = '0' + hex;
            }
            sb.append(hex.toUpperCase());
        }
        return sb.toString();
    }

    /**
     * 射1�7进制转换为二进制
     * 
     * @param hexStr
     * @return
     */
    private static byte[] parseHexStr2Byte(String hexStr) {
        if (hexStr.length() < 1)
            return null;
        byte[] result = new byte[hexStr.length() / 2];
        for (int i = 0; i < hexStr.length() / 2; i++) {
            int high = Integer.parseInt(hexStr.substring(i * 2, i * 2 + 1), 16);
            int low = Integer.parseInt(hexStr.substring(i * 2 + 1, i * 2 + 2),
                    16);
            result[i] = (byte) (high * 16 + low);
        }
        return result;
    }
    public static void main(String[] args) {
        System.out.println(new Date());
        String key = "LIUSHENGRI668569";
        String token = generateTokenTimeout(key, 1800000);
        System.out.println(token);
        System.out.println(validateToken(".1A283C46BB0606EIECAR05CGB20N67BEA1D.730H258S270UBDCI26BL49399D3.B88.3BD62795D50668F2E150DFEEDCD46166049A01E9B929555790EE6E29C7F2"));
    }

}
