package com.paic.data.dsphbd.job;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.apache.http.*;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ConnectionKeepAliveStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicHeaderElementIterator;
import org.apache.http.protocol.HTTP;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.io.IOException;
import java.net.URI;
import java.util.Properties;
import java.util.Random;

import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;

@Component
public class HdfsMetricsJob extends BaseJob {

  private static final Logger logger = LoggerFactory.getLogger(HdfsMetricsJob.class);

  private static final String DEFAULT_CHARSET = "UTF-8";

  @Value("#{configProperties['hadoop.metrics.hdfs.url']}")
  private String hadoopHdfsMetricsUrl;

  @Value("#{configProperties['metadata.broker.list']}")
  private String brokerList;

  @Value("#{configProperties['producer.type']}")
  private String producerType;

  @Value("#{configProperties['key.serializer.class']}")
  private String keySerializer;

  @Value("#{configProperties['serializer.class']}")
  private String serializer;

  @Value("#{configProperties['batch.num.messages']}")
  private String batchNumMessages;

  @Value("#{configProperties['topic.detector.metrics']}")
  private String detectorMetrics;

  private Producer<String, String> producer;
  private Random random = new Random();

  @PostConstruct
  public void initKafka() {
    assert brokerList != null;
    Properties props = new Properties();
    props.put("metadata.broker.list", brokerList);
    props.put("producer.type", producerType != null ? producerType : "sync");
    props.put("key.serializer.class", keySerializer != null ? keySerializer : "kafka.serializer.StringEncoder");
    props.put("serializer.class", keySerializer != null ? keySerializer : "kafka.serializer.StringEncoder");
    props.put("partitioner.class", "com.paic.data.common.kafka.HashPatitioner");
    props.put("batch.num.messages", batchNumMessages != null ? batchNumMessages : 100);
    ProducerConfig producerConfig = new ProducerConfig(props);
    if(producer!=null)
      producer.close();
    producer = new Producer<>(producerConfig);
    logger.info("===> Kafka producer start!");
  }

  @PreDestroy
  public void closeKafka() {
    if (producer != null)
      producer.close();
    logger.info("===> Kafka producer stop!");
  }

  @Scheduled(cron = "0 * * * * ?")
  public void doJob() {
    if (isRun()) {
      URI uri = URI.create(hadoopHdfsMetricsUrl);

      HttpGet request = new HttpGet(uri);
      CloseableHttpResponse response = null;
      try {
        CloseableHttpClient httpClient = getClient();

        response = httpClient.execute(request);
        HttpEntity entity = response.getEntity();
        String entityStr = null;

        int status = response.getStatusLine().getStatusCode();
        if (null != entity) {
          entityStr = EntityUtils.toString(entity, DEFAULT_CHARSET);
        }

        // Remove BOM
        if (entityStr.charAt(0) == '\uFEFF')
          entityStr = entityStr.substring(1);

        if (status == HttpStatus.SC_OK) {
          JSONObject json = JSON.parseObject(entityStr);
          JSONArray beans = json.getJSONArray("beans");
          Double RpcProcessingTimeAvgTime = null;
          Long CallQueueLength = null;

          Long TotalFiles = null;
          Double CapacityTotalGB = null;
          Double CapacityUsedGB = null;
          Double CapacityRemainingGB = null;
          Long TotalLoad = null;
          Long BlocksTotal = null;
          Long MissingBlocks = null;
          Long CorruptBlocks = null;

          Long NumLiveDataNodes = null;
          Long NumDeadDataNodes = null;
          Long VolumeFailuresTotal = null;

          for (int i = 0; i < beans.size(); i++) {
            JSONObject bean = beans.getJSONObject(i);
            String name = bean.getString("name");
            if (name != null) {
              if ("Hadoop:service=NameNode,name=FSNamesystem".equals(name)) {
                TotalFiles = bean.getLong("TotalFiles");
                CapacityTotalGB = bean.getDouble("CapacityTotalGB");
                CapacityUsedGB = bean.getDouble("CapacityUsedGB");
                CapacityRemainingGB = bean.getDouble("CapacityRemainingGB");
                TotalLoad = bean.getLong("TotalLoad");
                BlocksTotal = bean.getLong("BlocksTotal");
                MissingBlocks = bean.getLong("MissingBlocks");
                CorruptBlocks = bean.getLong("CorruptBlocks");
              } else if ("Hadoop:service=NameNode,name=RpcActivityForPort8020".equals(name)) {
                RpcProcessingTimeAvgTime = bean.getDouble("RpcProcessingTimeAvgTime");
                CallQueueLength = bean.getLong("CallQueueLength");
              } else if ("Hadoop:service=NameNode,name=FSNamesystemState".equals(name)) {
                NumLiveDataNodes = bean.getLong("NumLiveDataNodes");
                NumDeadDataNodes = bean.getLong("NumDeadDataNodes");
                VolumeFailuresTotal = bean.getLong("VolumeFailuresTotal");
              }
            }
          }
          StringBuilder dataBody = new StringBuilder();
          dataBody.append("hadoop_hdfs_metrics,type=hdfs_system ");
          dataBody.append("RpcProcessingTimeAvgTime=" + RpcProcessingTimeAvgTime);
          dataBody.append(",CallQueueLength=" + CallQueueLength);
          dataBody.append(",TotalFiles=" + TotalFiles);
          dataBody.append(",CapacityTotalGB=" + CapacityTotalGB);
          dataBody.append(",CapacityUsedGB=" + CapacityUsedGB);
          dataBody.append(",CapacityRemainingGB=" + CapacityRemainingGB);
          dataBody.append(",TotalLoad=" + TotalLoad);
          dataBody.append(",BlocksTotal=" + BlocksTotal);
          dataBody.append(",MissingBlocks=" + MissingBlocks);
          dataBody.append(",CorruptBlocks=" + CorruptBlocks);
          dataBody.append(",NumLiveDataNodes=" + NumLiveDataNodes);
          dataBody.append(",NumDeadDataNodes=" + NumDeadDataNodes);
          dataBody.append(",VolumeFailuresTotal=" + VolumeFailuresTotal);
          dataBody.append(" " + System.nanoTime());
          JSONObject jmx = new JSONObject();
          jmx.put("comp_name", "hadoop_metrics");
          jmx.put("comp_name", "hadoop_hdfs_metrics");
          jmx.put("data_type", "inf");
          jmx.put("data_body", dataBody.toString());
          String jxmString = jmx.toString();

          producer.send(new KeyedMessage<>(detectorMetrics, "" + random.nextInt(10), jxmString));
          System.out.println(jxmString);

        }
      } catch (Exception e) {
        logger.error("write hdfs metrics to kafka error! url={}", uri.toString(), e);
      } finally {
        request.abort();
        if (response != null)
          try {
            response.close();
          } catch (IOException e) {
          }
      }

    }
  }

  private CloseableHttpClient getClient() {
    return HttpClients.custom().setKeepAliveStrategy(KEEP_ALIVE_STRATEGY).build();
  }

  private final ConnectionKeepAliveStrategy KEEP_ALIVE_STRATEGY = new ConnectionKeepAliveStrategy() {
    public long getKeepAliveDuration(HttpResponse response, HttpContext context) {
      // Honor 'keep-alive' header
      HeaderElementIterator it = new BasicHeaderElementIterator(
              response.headerIterator(HTTP.CONN_KEEP_ALIVE));
      while (it.hasNext()) {
        HeaderElement he = it.nextElement();
        String param = he.getName();
        String value = he.getValue();
        if (value != null && param.equalsIgnoreCase("timeout")) {
          try {
            return Long.parseLong(value) * 1000;
          } catch (NumberFormatException ignore) {
          }
        }
      }

      return 30 * 1000;
    }
  };

}