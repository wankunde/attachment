package com.paic.data.dsphbd.entity;

import java.util.Map;

/**
 * Created by wankun603 on 2018-06-26.
 */
public class HiveParserRequest {

  private long id;
  private long jobId;
  private long jobLogId;
  private long jobFrequency;
  private String tableSpace;
  private String tableName;
  private String sqlText;
  private Map<String, String> configuration;
  private String submitUser;
  private String ip;
  private String createBy;
  private Long createdTime;
  private String updateBy;
  private Long updatedTime;
  private Map<String,Object> hiveAttributes;

  public long getId() {
    return id;
  }

  public void setId(long id) {
    this.id = id;
  }

  public long getJobId() {
    return jobId;
  }

  public void setJobId(long jobId) {
    this.jobId = jobId;
  }

  public long getJobLogId() {
    return jobLogId;
  }

  public void setJobLogId(long jobLogId) {
    this.jobLogId = jobLogId;
  }

  public long getJobFrequency() {
    return jobFrequency;
  }

  public void setJobFrequency(long jobFrequency) {
    this.jobFrequency = jobFrequency;
  }

  public String getTableSpace() {
    return tableSpace;
  }

  public void setTableSpace(String tableSpace) {
    this.tableSpace = tableSpace;
  }

  public String getTableName() {
    return tableName;
  }

  public void setTableName(String tableName) {
    this.tableName = tableName;
  }

  public String getSqlText() {
    return sqlText;
  }

  public void setSqlText(String sqlText) {
    this.sqlText = sqlText;
  }

  public Map<String, String> getConfiguration() {
    return configuration;
  }

  public void setConfiguration(Map<String, String> configuration) {
    this.configuration = configuration;
  }

  public String getSubmitUser() {
    return submitUser;
  }

  public void setSubmitUser(String submitUser) {
    this.submitUser = submitUser;
  }

  public String getIp() {
    return ip;
  }

  public void setIp(String ip) {
    this.ip = ip;
  }

  public String getCreateBy() {
    return createBy;
  }

  public void setCreateBy(String createBy) {
    this.createBy = createBy;
  }

  public Long getCreatedTime() {
    return createdTime;
  }

  public void setCreatedTime(Long createdTime) {
    this.createdTime = createdTime;
  }

  public String getUpdateBy() {
    return updateBy;
  }

  public void setUpdateBy(String updateBy) {
    this.updateBy = updateBy;
  }

  public Long getUpdatedTime() {
    return updatedTime;
  }

  public void setUpdatedTime(Long updatedTime) {
    this.updatedTime = updatedTime;
  }

  public Map<String, Object> getHiveAttributes() {
    return hiveAttributes;
  }

  public void setHiveAttributes(Map<String, Object> hiveAttributes) {
    this.hiveAttributes = hiveAttributes;
  }
}
