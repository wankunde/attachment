package com.paic.data.dsphbd.util;

/**
 * Created by wankun603 on 2018-06-26.
 */
public enum ResultMsgBean {
  Success(0, "成功"),
  CodeException(500, "服务器错误"),
  ParameterError(422, "参数错误"),
  FieldError(3, "非法字段"),
  UnSupportRequestMethod(4, "请求方式不支持"),
  SERVER_BUSY(5, "服务器繁忙"),
  UnSafeChar(6, "非法字符"),
  SQLError(7, "SQL语法错误"),
  NotExist(8, "数据不存在"),
  NoPermission(9, "无权限");

  public final int err;

  public final String msg;

  ResultMsgBean(int err, String msg) {
    this.err = err;
    this.msg = msg;
  }

}
