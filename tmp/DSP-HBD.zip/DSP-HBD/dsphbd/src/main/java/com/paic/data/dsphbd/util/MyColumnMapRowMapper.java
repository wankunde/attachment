package com.paic.data.dsphbd.util;

import org.springframework.jdbc.core.ColumnMapRowMapper;

public class MyColumnMapRowMapper extends ColumnMapRowMapper{

    protected String getColumnKey(String columnName) {
        return columnName.toLowerCase();
    }
}
