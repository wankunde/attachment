package com.paic.data.dsphbd.view;

import com.paic.data.dsphbd.entity.HiveParserRequest;
import com.paic.data.dsphbd.service.HiveService;
import com.paic.data.dsphbd.util.ResultMsgBean;
import com.paic.data.dsphbd.util.ResultBean;
import com.paic.data.dsphbd.util.StringUtil;
import org.apache.hadoop.hive.metastore.api.FieldSchema;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * Created by wankun603 on 2018-06-26.
 */
@Controller
@RequestMapping("/hive")
public class HiveApi {

  private static final Logger logger = LoggerFactory.getLogger(HiveApi.class);

  @Autowired
  private HiveService hiveService;

  @RequestMapping(value = "/hiveparser", method = RequestMethod.POST)
  @ResponseBody
  public Object hiveparser(HttpServletRequest request,
                           @RequestBody HiveParserRequest hiveParserRequest) throws Exception {
    if (hiveParserRequest == null || StringUtil.isBlank(hiveParserRequest.getSqlText())) {
      return new ResultBean(null, ResultMsgBean.ParameterError);
    }
    List<FieldSchema> fieldSchemas = hiveService.parseHiveSql(hiveParserRequest.getSqlText());
    return new ResultBean(fieldSchemas, ResultMsgBean.Success);
  }

  @RequestMapping(value = "/runQuery", method = RequestMethod.POST)
  @ResponseBody
  public Object submit(HttpServletRequest request,
                       @RequestBody HiveParserRequest hiveParserRequest) throws Exception {
    if (hiveParserRequest == null
            || StringUtil.isBlank(hiveParserRequest.getSqlText())
            || hiveParserRequest.getConfiguration() == null) {
      return new ResultBean(null, ResultMsgBean.ParameterError);
    }
    boolean res = hiveService.submit(hiveParserRequest.getSqlText(),hiveParserRequest.getConfiguration());
    return new ResultBean(true, ResultMsgBean.Success);
  }
}
