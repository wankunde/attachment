package com.paic.data.dsphbd.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public final class DateUtil {

    private static final Logger logger = LoggerFactory.getLogger(DateUtil.class);
    public static final String DEFULT_FORMAT = "yyyy-MM-dd HH:mm:ss";
    public static final String DEFULT_CONNECTION_FORMAT = "yyyyMMddHHmmss";
    public static final String DATE_CONNECTION_FORMAT = "yyMMdd";
    public static final String DATE_YEARMONTHDDAY_FORMAT = "yyyyMMdd";
    public static final String DATE_YEARMONTH_FORMAT = "yyyyMM";
    public static final String DATE_YEAR_FORMAT = "yyyy";
    public static final String DATE_SHORT_FORMAT = "yyyy-MM-dd";
    public static final String DATE_START_TIME = " 00:00:00";
    public static final String DATE_END_TIME = " 23:59:59";

    private DateUtil() {

    }
    
    public static SimpleDateFormat getCompactFormat(){
    	return new SimpleDateFormat("yyyyMMddHHmmss");
    }

    public static String getDateTime() {
        Date date = new Date();
        SimpleDateFormat defultFormat = new SimpleDateFormat(DEFULT_FORMAT);
        return defultFormat.format(date);
    }

    public static String getDateTime(Date date) {
        SimpleDateFormat defultFormat = new SimpleDateFormat(DEFULT_FORMAT);
        return defultFormat.format(date);
    }

    public static Date getDateTime(String dateStr) {
        if (StringUtil.isNotBlank(dateStr)) {
            try {
                SimpleDateFormat defultFormat = new SimpleDateFormat(DEFULT_FORMAT);
                return defultFormat.parse(dateStr);
            } catch (ParseException e) {
            }
        }
        return null;
    }

    public static String getDateTime(Date date, String formatStr) {
        SimpleDateFormat format = new SimpleDateFormat(formatStr);// 等价于
        return format.format(date);
    }

    public static long getTime() {
        return System.currentTimeMillis();
    }

    public static String getDate(Date date) {
        SimpleDateFormat connectionFormat = new SimpleDateFormat(DEFULT_CONNECTION_FORMAT);
        return connectionFormat.format(date);
    }

    public static Date getDate(long timeStamp) {
        return new Date(timeStamp);
    }

    public static String getDate() {
        Date date = new Date();
        SimpleDateFormat connectionFormat = new SimpleDateFormat(DEFULT_CONNECTION_FORMAT);
        return connectionFormat.format(date);
    }

    public static Date parseDate(String dateStr) {
        try {
            SimpleDateFormat defultFormat = new SimpleDateFormat(DEFULT_FORMAT);
            return defultFormat.parse(dateStr);
        } catch (ParseException e) {
            logger.error(e.getMessage(), e);
        }
        return null;
    }

    public static Date getDayOfMonth(Date paramdate, boolean flag) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(paramdate);
        String time = "";
        if (flag) {
            cal.set(Calendar.DAY_OF_MONTH, 1);
        } else {
            cal.roll(Calendar.DAY_OF_MONTH, -1);
        }
        SimpleDateFormat shortFormat = new SimpleDateFormat(DATE_SHORT_FORMAT);
        time = shortFormat.format(cal.getTime());
        Date date = parseDate(time + DATE_START_TIME);
        return date;
    }

    /**
     * 获取xx天前的日期
     *
     * @param day
     * @return
     */
    public static Date getSomeDayAgo(int day) {

        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, day);
        Date servenDay = c.getTime();
        return servenDay;
    }

    /**
     * 判断当前时间是否在区间中(高峰) 如: 18:00-21:00
     *
     * @return boolean
     */
    public static boolean getOurMinute(String start, String end) {
        if (StringUtil.isNotBlank(start) && StringUtil.isNotBlank(end)) {
            long now_time = System.currentTimeMillis();
            Date date = new Date();
            SimpleDateFormat shortFormat = new SimpleDateFormat(DATE_SHORT_FORMAT);
            String now_str = shortFormat.format(date);
            start = start + ":00";
            end = end + ":00";
            String das = now_str + " " + start;
            String dae = now_str + " " + end;
            Date start_date = DateUtil.parseDate(das);
            Date end_date = DateUtil.parseDate(dae);
            if (start_date.getTime() <= now_time && now_time <= end_date.getTime()) {
                return true;
            }
        }
        return false;
    }

    public static Date getDateTimeStamp(String time) throws ParseException {
        SimpleDateFormat connectionFormat = new SimpleDateFormat(DEFULT_CONNECTION_FORMAT);
        return connectionFormat.parse(time);
    }

    public static Date getTodayShortTime(boolean flag, int hours) throws ParseException {
        Calendar cal = Calendar.getInstance();
        if (flag) {
            cal.add(Calendar.HOUR_OF_DAY, hours);
            return cal.getTime();
        }
        cal.add(Calendar.HOUR_OF_DAY, -hours);
        return cal.getTime();
    }

    /**
     * 获取xx天的开始时间
     *
     * @param date
     * @return
     */
    public static Date getStartTime(Date date) {
        String dateTime = getDateTime(date, DATE_SHORT_FORMAT);
        return parseDate(dateTime + DATE_START_TIME);
    }

    /**
     * 获取xx天的结束时间
     *
     * @param date
     * @return
     */
    public static Date getEndTime(Date date) {
        String dateTime = getDateTime(date, DATE_SHORT_FORMAT);
        return parseDate(dateTime + DATE_END_TIME);
    }

    /**
     * 获取当前时间所在年的周数
     *
     * @param date
     * @return
     */
    public static int getWeekOfYear() {
        Date date = new Date();
        Calendar c = new GregorianCalendar();
        c.setFirstDayOfWeek(Calendar.MONDAY);
        c.setMinimalDaysInFirstWeek(7);
        c.setTime(date);
        return c.get(Calendar.WEEK_OF_YEAR);
    }

    /**
     * 获取当前月第一天
     *
     * @return
     * @throws ParseException
     */
    public static Date getMonthStartTime(Date date) throws ParseException {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.set(Calendar.DATE, 1);
        SimpleDateFormat shortFormat = new SimpleDateFormat(DATE_SHORT_FORMAT);
        Date now = shortFormat.parse(shortFormat.format(c.getTime()));
        return now;
    }

    /**
     * 获取当前月最后一天
     *
     * @return
     * @throws ParseException
     */
    public static Date getMonthEndTime(Date date) throws ParseException {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.set(Calendar.DAY_OF_MONTH, c.getActualMaximum(Calendar.DAY_OF_MONTH));
        SimpleDateFormat shortFormat = new SimpleDateFormat(DATE_SHORT_FORMAT);
        String last = shortFormat.format(c.getTime());
        return getDateTime(last + DATE_END_TIME);
    }

    /**
     * 获取当前周的第一天
     *
     * @return
     */
    public static Date getWeekFirstDay(Date date) {
        Calendar c = new GregorianCalendar();
        c.setFirstDayOfWeek(Calendar.MONDAY);
        c.setTime(date);
        c.set(Calendar.DAY_OF_WEEK, c.getFirstDayOfWeek()); // Monday
        SimpleDateFormat shortFormat = new SimpleDateFormat(DATE_SHORT_FORMAT);
        String last = shortFormat.format(c.getTime());
        return getDateTime(last + DATE_START_TIME);

    }

    /**
     * 获取当前周的最后一天
     *
     * @return
     */
    public static Date getWeekLastDay(Date date) {
        Calendar c = new GregorianCalendar();
        c.setFirstDayOfWeek(Calendar.SUNDAY);
        c.setTime(date);
        c.set(Calendar.DAY_OF_WEEK, c.getFirstDayOfWeek() + 6); // Sunday
        c.add(Calendar.DAY_OF_YEAR, 1);
        SimpleDateFormat shortFormat = new SimpleDateFormat(DATE_SHORT_FORMAT);
        String last = shortFormat.format(c.getTime());
        return getDateTime(last + DATE_END_TIME);
    }

    /**
     * 获取某年第一天日期
     *
     * @param year
     *            年份
     * @return Date
     */
    public static Date getYearFirst(int year) {
        Calendar calendar = Calendar.getInstance();
        calendar.clear();
        calendar.set(Calendar.YEAR, year);
        Date currYearFirst = calendar.getTime();
        return currYearFirst;
    }

    /**
     * 获取某年最后一天日期
     *
     * @param year
     *            年份
     * @return Date
     */
    public static Date getYearLast(int year) {
        Calendar calendar = Calendar.getInstance();
        calendar.clear();
        calendar.set(Calendar.YEAR, year);
        calendar.roll(Calendar.DAY_OF_YEAR, -1);
        Date currYearLast = calendar.getTime();

        return currYearLast;
    }

    /**
     * 获取年份
     *
     * @param date
     * @return
     */
    public static int getYear(Date date) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DATE_YEAR_FORMAT);
        String year = simpleDateFormat.format(new Date());
        return Integer.valueOf(year);
    }

}
