package com.paic.data.dsphbd.job;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

/**
 * Created by wankun603 on 2018-06-27.
 */
//@ContextConfiguration("classpath:applicationContext.xml")
public class HdfsMetricsJobTest extends AbstractJUnit4SpringContextTests {

  @Autowired
  private HdfsMetricsJob hdfsMetricsJob;

  @Test
  public void hdfsMetricsJob() throws Exception {
    hdfsMetricsJob.doJob();
  }

}