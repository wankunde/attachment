/**
  * Created by wankun603 on 2018-03-02.
  */
trait Constant {
  val REST_URL_EVENT_ALL:String ="http://172.16.50.43:8080/vast/event/list"

  val JDBC_URL = "jdbc:oracle:thin:@172.16.50.21:1537:dspdata"
  val JDBC_USERNAME = "dspvast"
  val JDBC_PASSWORD = "kiop0987"

  val KAFKA_BROKERS = "26.6.1.89:9092,26.6.1.90:9092,26.6.1.91:9092"

  // bin/kafka-topics.sh --zookeeper 26.6.0.24:2181,26.6.0.25:2181,26.6.0.26:2181,26.6.0.27:2181,26.6.0.31:2181/kafka/prdbigdata_kafka08 --create --topic vast_result --partitions 5 --replication-factor 2
  val RESULT_KAFKA_TOPIC = "vast_result"
  val RESULT_VAST_ALERT_DETAIL_TOPIC = "vast_alert_detail"
  val RESULT_WEB_ALERT_DETAIL_TOPIC = "web_alert_detail"
  val RESULT_KAFKA_BROKERS = "172.16.50.43:9092,172.16.50.44:9092,172.16.50.110:9092,172.16.50.111:9092"
  val RESULT_KAFKA_ZOOKEEPER = "26.6.0.24:2181,26.6.0.25:2181,26.6.0.26:2181,26.6.0.27:2181,26.6.0.31:2181/kafka/prdsf"
}
