/**
  * Created by wankun603 on 2018-03-02.
  */
case class AppEvent(
                     app_version: String,
                     device_model: String,
                     os_name: String,
                     os_version: String,
                     app_key: String,
                     app_type: String,
                     device_id: String,
                     partner_id: String,
                     net_status: String,
                     local_ip: String,
                     session_id: String,
                     index: Int,
                     start: Long,
                     ts: Long,
                     ip: String,
                     name: String,
                     label: String,
                     parameters: Map[String, String],
                     end: Long,
                     duration: Long
                   )