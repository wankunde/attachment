import java.lang.management.ManagementFactory

import org.apache.spark.internal.Logging

/**
  * Created by WANKUN603 on 2018-09-14.
  */
object Tx1 extends Logging{

  def main(args: Array[String]): Unit = {
    log.info(s"Started daemon with process name: ${ManagementFactory.getRuntimeMXBean().getName()}")
  }
}
