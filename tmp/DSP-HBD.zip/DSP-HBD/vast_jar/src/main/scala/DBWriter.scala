import java.sql.{Connection, DriverManager, PreparedStatement}
import java.text.SimpleDateFormat
import java.util.{Date, Properties}

import kafka.consumer.{Consumer, ConsumerConfig, ConsumerIterator, KafkaStream}
import kafka.message.MessageAndMetadata
import kafka.serializer.StringEncoder
import org.apache.kafka.common.serialization.StringDeserializer
import org.slf4j.LoggerFactory

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

// java -cp jar-1.0.jar:$(echo ./lib/*.jar | tr ' ' ':') DBWriter &
object DBWriter extends Constant {

  val log = LoggerFactory.getLogger("DBWriter")

  def main(args: Array[String]): Unit = {
    val TOPIC = RESULT_KAFKA_TOPIC
    val props = new Properties()
    //    props.setProperty("bootstrap.servers", RESULT_KAFKA_BROKERS)
    props.setProperty("key.deserializer", classOf[StringDeserializer].getName)
    props.setProperty("value.deserializer", classOf[StringDeserializer].getName)
    //    props.setProperty("partition.assignment.strategy", "range")
    //    props.setProperty("group.id", "DBWriter")

    props.setProperty("zookeeper.connect", RESULT_KAFKA_ZOOKEEPER)
    props.setProperty("group.id", "DBWriter")
    props.setProperty("zookeeper.session.timeout.ms", "4000")
    props.setProperty("zookeeper.sync.time.ms", "200")
    props.setProperty("auto.commit.interval.ms", "1000")
    //    props.setProperty("auto.offset.reset", "smallest")
    props.setProperty("serializer.class", classOf[StringEncoder].getName)

    val connector = Consumer.create(new ConsumerConfig(props))

    val streams = connector.createMessageStreams(Map(TOPIC -> 10)) // ,StringDeserializer,

    var futureIndex = 0
    for (stream <- streams.get(TOPIC).get) {
      processStream(futureIndex, stream)
      futureIndex = futureIndex + 1
    }
  }

  case class StructField(name: String, dataType: String)

  def processStream(futureIndex: Int,
                    stream: KafkaStream[Array[Byte], Array[Byte]]): Future[Unit] = Future {
    val tableName = "VAST_RESULT_CUSTOM_EVENT"
    val schema = List(StructField("event", "StringType"),
      StructField("label", "StringType"),
      StructField("dim", "StringType"),
      StructField("uv", "IntegerType"),
      StructField("pv", "IntegerType"),
      StructField("fail_num", "IntegerType"),
      StructField("du_avg", "DoubleType"),
      StructField("du_300", "IntegerType"),
      StructField("du_500", "IntegerType"),
      StructField("du_1000", "IntegerType"),
      StructField("du_3000", "IntegerType"),
      StructField("du_5000", "IntegerType"),
      StructField("du_10000", "IntegerType"),
      StructField("du_10001", "IntegerType"),
      StructField("du_120000", "IntegerType"),
      StructField("overtime_num", "IntegerType"))

    val conn: Connection = DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD)
    val placeholder = schema.map(f => '?').mkString(",")
    val sql =
      s"""INSERT INTO ${tableName} VALUES (
          | SEQ_${tableName}.nextval,
          | ?,
          | sysdate,
          | ${placeholder})
             """.stripMargin
    val pstmt: PreparedStatement = conn.prepareStatement(sql)

//    var rowCount = 0
//    val batchSize = 100
    val formatter: SimpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss")

    val it: ConsumerIterator[Array[Byte], Array[Byte]] = stream.iterator()
    try {
      while (it.hasNext) {
        val data: MessageAndMetadata[Array[Byte], Array[Byte]] = it.next()
        val timestamp = new String(data.key).stripPrefix("[").stripSuffix("]").split("_")(1).toLong
        val frequence = formatter.format(new Date(timestamp))
        pstmt.setLong(1, frequence.toLong)

        val fields = new String(data.message()).stripPrefix("[").stripSuffix("]").split(",")
        var j = 0
        while (j < fields.length) {

          try {
            schema(j).dataType match {
              case "IntegerType" => pstmt.setInt(j + 2, fields(j).toInt)
              case "LongType" => pstmt.setLong(j + 2, fields(j).toLong)
              case "DoubleType" => pstmt.setDouble(j + 2, fields(j).toDouble)
              case "FloatType" => pstmt.setFloat(j + 2, fields(j).toFloat)
              case "StringType" => pstmt.setString(j + 2, fields(j))
            }
          }
          catch {
            case e: Exception =>
              println(e)
          }
          j = j + 1
        }

        pstmt.executeUpdate()
//        pstmt.addBatch()
//        rowCount = rowCount + 1
//        if (rowCount % batchSize == 0) {
//          pstmt.executeBatch()
//          rowCount = 0
//        }
//        println("futureNumer->[" + futureIndex + "],  key->[" + new String(data.key) + "],  message->[" + new String(data.message) + "],  partition->[" +
//          data.partition + "],  offset->[" + data.offset + "]")
      }

//      if (rowCount > 0)
//        pstmt.executeBatch()
    } catch {
      case e: Exception => println(e)
    } finally {
      if (pstmt != null)
        try {
          pstmt.close()
        } catch {
          case e: Exception => println(e)
        }

      if (conn != null)
        try {
          conn.close()
        } catch {
          case e: Exception => println(e)
        }
    }
  }

}
