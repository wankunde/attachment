import java.util.Properties

import kafka.serializer.StringDecoder
import org.apache.kafka.common.serialization.StringSerializer
import org.apache.spark.SparkConf
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.types._
import org.apache.spark.sql.{Encoders, SparkSession}
import org.apache.spark.streaming.kafka.KafkaUtils
import org.apache.spark.streaming.{Minutes, StreamingContext}

// spark-submit --jars $(echo ./lib/*.jar | tr ' ' ',') --master spark://cnsz035617:7077  --deploy-mode client --total-executor-cores 10 --executor-cores 2 --executor-memory 4g --conf spark.ui.port=4050 --class AppLoginMonitor jar-1.0.jar >/appcom/log/jobs/AppLoginMonitor.log 2>&1 &
/**
  * Created by wankun603 on 2018-06-20.
  */
object AppLoginMonitor extends Constant {

  val topicsSet = Set("vast.app_event")

  def main(args: Array[String]) {
    val sparkConf = new SparkConf().setAppName("app login monitor")
    val ssc = new StreamingContext(sparkConf, Minutes(1))

    val kafkaParams = Map[String, String]("metadata.broker.list" -> KAFKA_BROKERS)
    val messages = KafkaUtils.createDirectStream[String, String, StringDecoder, StringDecoder](
      ssc, kafkaParams, topicsSet)

    var eventSchema: StructType = null

    val kafkaProducer: Broadcast[KafkaSink[String, String]] = {
      val kafkaProducerConfig = {
        val props = new Properties()
        props.setProperty("bootstrap.servers", RESULT_KAFKA_BROKERS)
        props.setProperty("key.serializer", classOf[StringSerializer].getName)
        props.setProperty("value.serializer", classOf[StringSerializer].getName)
        props.setProperty("partitioner.class", classOf[HashPartitioner].getName)
        props.setProperty("producer.type", "sync")
        props.setProperty("batch.num.messages", "50")

        props
      }
      ssc.sparkContext.broadcast(KafkaSink[String, String](kafkaProducerConfig))

      //      val message1 = new KeyedMessage[String, String](topic, "1", "test 0");
      //      producer.send(message1);
      // https://www.cnblogs.com/AK47Sonic/p/7260577.html
    }

    messages.map(_._2).foreachRDD((rdd, time) => {
      val spark = SparkSession.builder.config(sparkConf).getOrCreate()

      val dataset = if (eventSchema != null)
        spark.read.schema(eventSchema).json(spark.createDataset(rdd)(Encoders.STRING))
      else
        spark.read.json(spark.createDataset(rdd)(Encoders.STRING))
      eventSchema = dataset.schema

      dataset.createOrReplaceTempView("app_event")

      spark.conf.set("spark.sql.shuffle.partitions", "10")

      val result = spark.sql(
        raw"""select sum(case when (t.login = t.press_button) and (t.login>=1) then 1 else 0 end) as login_cnt,
              |    sum(case when t.press_button>=1 then 1 else 0 end) as button_cnt,
              |    t.app_version, t.app_type as os_name,
              |    sum(case when t.login_timeout>=1 then 1 else 0 end) as timeout_cnt,
              |    sum(case when t.net_0>=1 then 1 else 0 end) as net0_cnt
              |  from (
              |    select sum(case when label like '%|200' then 1 else 0 end) as login,
              |      sum(case when label like '%|200' and (duration <=0 and duration>=10000) then 1 else 0 end) as login_timeout,
              |      sum(case when (name = 'okbutton' and label = 'stockland') or (label='land' and name='login') then 1 else 0 end) as press_button,
              |      sum(case when ((name = 'okbutton' and label = 'stockland') or (label='land' and name='login')) and (net_status<='0') then 1 else 0 end) as net_0,
              |      app_type, app_version, device_id
              |    from app_event
              |    where (split(app_version,'\\.')[0]>6 or (split(app_version,'\\.')[0]=6 and split(app_version,'\\.')[1]>=6))
              |    and start>(unix_timestamp()-360*60*1000)
              |    and  (name in ('okbutton','login') and label in ('stockland','land') or label like '%|200')
              |    group by app_type, app_version, device_id
              |  ) t
              |  group by app_type,app_version
              |  having sum(case when t.press_button>=1 then 1 else 0 end) > 10
         """.stripMargin)
      result.foreach(row => kafkaProducer.value.send(RESULT_KAFKA_TOPIC, "appLoginMonitor_" + time.milliseconds, row.toString()))
    }
    )
    ssc.start()
    ssc.awaitTermination()
  }
}