import java.util.Properties
import java.util.regex.{Matcher, Pattern}

import kafka.serializer.StringDecoder
import org.apache.commons.lang.StringUtils
import org.apache.kafka.common.serialization.StringSerializer
import org.apache.spark.SparkConf
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.catalyst.expressions.GenericRowWithSchema
import org.apache.spark.sql.types._
import org.apache.spark.sql.{Encoders, SparkSession}
import org.apache.spark.streaming.kafka.KafkaUtils
import org.apache.spark.streaming.{Minutes, StreamingContext}

import scala.util.parsing.json.JSON

// spark-submit --jars $(echo ./lib/*.jar | tr ' ' ',') --master spark://cnsz035617:7077  --deploy-mode client --total-executor-cores 20 --executor-cores 2 --executor-memory 10g --conf spark.ui.port=4042  --class CustomEvent jar-1.0.jar >/appcom/log/jobs/CustomEvent.log &
object CustomEvent extends Constant {

  val topicsSet = Set("vast.app_event")

  case class RestResultBean()

  def main(args: Array[String]) {
    val sparkConf = new SparkConf().setAppName("custom event")
    val ssc = new StreamingContext(sparkConf, Minutes(1))

    val kafkaParams = Map[String, String]("metadata.broker.list" -> KAFKA_BROKERS)
    val messages = KafkaUtils.createDirectStream[String, String, StringDecoder, StringDecoder](
      ssc, kafkaParams, topicsSet)

    var eventSchema: StructType = null

    val kafkaProducer: Broadcast[KafkaSink[String, String]] = {
      val kafkaProducerConfig = {
        val props = new Properties()
        props.setProperty("bootstrap.servers", RESULT_KAFKA_BROKERS)
        props.setProperty("key.serializer", classOf[StringSerializer].getName)
        props.setProperty("value.serializer", classOf[StringSerializer].getName)
        props.setProperty("partitioner.class", classOf[HashPartitioner].getName)
        props.setProperty("producer.type", "sync")
        props.setProperty("batch.num.messages", "50")

        props
      }
      ssc.sparkContext.broadcast(KafkaSink[String, String](kafkaProducerConfig))
    }

    val eventMap: Broadcast[Map[(String, String), String]] = {
      val json = JSON.parseFull(scala.io.Source.fromURL(REST_URL_EVENT_ALL)("UTF-8").mkString)
      val dataList = json.getOrElse(None)
        .asInstanceOf[Map[String, Any]].get("data").getOrElse(None)
        .asInstanceOf[List[Map[String, String]]]
      val map = dataList.map(bean => ((bean.get("name").get, bean.get("label").get) -> bean.get("label").get)).toMap
      ssc.sparkContext.broadcast(map)
    }

    val eventDimensions: Broadcast[Map[(String, String), String]] = {
      val json = JSON.parseFull(scala.io.Source.fromURL(REST_URL_EVENT_ALL)("UTF-8").mkString)
      val dataList = json.getOrElse(None)
        .asInstanceOf[Map[String, Any]].get("data").getOrElse(None)
        .asInstanceOf[List[Map[String, String]]]
      val map = dataList.map(bean => ((bean.get("name").get, bean.get("label").get) -> bean.get("dimensions").get)).toMap
      ssc.sparkContext.broadcast(map)
    }

    val p = ssc.sparkContext.broadcast(
      Pattern.compile("[^//]*?\\.(com.cn|com|cn|net|org|biz|info|cc|tv)(.+)", Pattern.CASE_INSENSITIVE))


    messages.map(_._2).foreachRDD((rdd, time) => {
      val spark = SparkSession.builder.config(sparkConf).getOrCreate()

      val dataset = if (eventSchema != null)
        spark.read.schema(eventSchema).json(spark.createDataset(rdd)(Encoders.STRING))
      else
        spark.read.json(spark.createDataset(rdd)(Encoders.STRING))
      eventSchema = dataset.schema

      dataset.createOrReplaceTempView("app_event")

      spark.conf.set("spark.sql.shuffle.partitions", "20")

      spark.udf.register("event_label", (name: String, label: String) => {
        val rex_label = if (name.equals("restIO")) {
          val matcher: Matcher = p.value.matcher(label.split('?')(0))
          if (matcher.find) matcher.group(2) else label
        } else if (name.equals("networkIO")) {
          if (label.startsWith("DZH")) {
            label.replace("DZH", "")
          } else label
        } else label
        eventMap.value.getOrElse((name, rex_label), "")
      }: String)

      spark.udf.register("event_dimensions", (name: String,
                                              label: String,
                                              app_version: String,
                                              device_model: String,
                                              os_name: String,
                                              os_version: String,
                                              app_key: String,
                                              app_type: String,
                                              partner_id: String,
                                              net_status: String,
                                              parameters: GenericRowWithSchema) => {
        val rex_label2 = if (name.equals("restIO")) {
          val matcher: Matcher = p.value.matcher(label.split('?')(0))
          if (matcher.find) matcher.group(2) else label
        } else if (name.equals("networkIO")) {
          if (label.startsWith("DZH")) {
            label.replace("DZH", "")
          } else label
        } else label

        val dimensions = eventDimensions.value.getOrElse((name, rex_label2), "")
        if (StringUtils.isBlank(dimensions))
          ""
        else {
          val dims: Array[String] = dimensions.split('|').map(_.trim)
          var res: String = new String()
          dims.foreach(d => {
            d match {
              case "app_version" => res += app_version + "|"
              case "device_model" => res += device_model + "|"
              case "os_name" => res += os_name + "|"
              case "os_version" => res += os_version + "|"
              case "app_key" => res += app_key + "|"
              case "app_type" => res += app_type + "|"
              case "partner_id" => res += partner_id + "|"
              case "net_status" => res += net_status + "|"
              case _ if (d.startsWith("parameters")) => {
                val pcode = d.substring("parameters".length).stripPrefix("[").stripSuffix("]")
                res += parameters.getAs[String](pcode) + "|"
              }
              case _ =>
            }
          }
          )
          res.stripSuffix("|")
        }
      }: String)

      val result = spark.sql(
        raw"""SELECT name, label, dim,
              |       COUNT(DISTINCT device_id) AS uv,
              |       SUM(IF(net_status != 0 , 1, 0)) AS pv,
              |       SUM(IF(((name='networkIO' and net_returnCode<>0) or (name='restIO' and ((app_type='iOS' and rest_result<>1) or (app_type='android' and rest_status not in (1,200))))) and duration <> -1,1,0)) AS fail_num,
              |       AVG(IF(duration>0 and duration<120000,duration,0)) AS du_avg,
              |       SUM(IF(duration < 300 and duration >0, 1, 0)) AS du_300,
              |       SUM(IF(duration < 500 and duration >= 300, 1, 0)) AS du_500,
              |       SUM(IF(duration < 1000 and duration >= 500, 1, 0)) AS du_1000,
              |       SUM(IF(duration < 1500 and duration >= 1000, 1, 0)) AS du_1500,
              |       SUM(IF(duration < 3000 and duration >= 1500, 1, 0)) AS du_3000,
              |       SUM(IF(duration < 5000 and duration >= 3000, 1, 0)) AS du_5000,
              |       SUM(IF(duration < 10000 and duration >= 5000, 1, 0)) AS du_10000,
              |       SUM(IF(duration >= 10000 and duration<120000, 1, 0)) AS du_10001,
              |       SUM(IF(duration >= 120000, 1, 0)) AS du_120000,
              |       SUM(IF(duration = -1 and net_status != 0 , 1, 0)) AS overtime_num,
              |       SUM(IF(net_status = 0 , 1, 0)) AS no_net
              |FROM (SELECT name,event_label(name,label) AS label,
              |             event_dimensions(name,label,app_version,device_model,os_name,os_version,app_key,app_type,partner_id,net_status,parameters) AS dim,
              |             device_id, duration,parameters.returnCode AS net_returnCode,parameters.status AS rest_status,parameters.result AS rest_result,app_type, net_status
              |      FROM app_event
              |      WHERE event_label(name,label) != ''
              |      AND  (split(app_version,'\\.')[0]>5 or (split(app_version,'\\.')[0]=5 and split(app_version,'\\.')[1]>=10))
              |      AND app_key='993F95713DA740373EF0A0EE7BBBCC32') t
              |GROUP BY name, label, dim
                 """.stripMargin)

      result.foreach(row => kafkaProducer.value.send(RESULT_KAFKA_TOPIC, "CustomEvent_" + time.milliseconds, row.toString()))
    }
    )
    ssc.start()
    ssc.awaitTermination()
  }
}