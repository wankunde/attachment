import java.util.Properties

import kafka.serializer.StringDecoder
import org.apache.kafka.common.serialization.StringSerializer
import org.apache.spark.SparkConf
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.types._
import org.apache.spark.sql.{Encoders, Row, SparkSession}
import org.apache.spark.streaming.kafka.KafkaUtils
import org.apache.spark.streaming.{Minutes, StreamingContext}

// spark-submit --jars $(echo ./lib/*.jar | tr ' ' ',') --master spark://cnsz035617:7077  --deploy-mode client --total-executor-cores 10 --executor-cores 2 --executor-memory 3g --conf spark.ui.port=4051 --class WebPerf jar-1.0.jar >/appcom/log/jobs/WebPerf.log &
object WebPerf extends Constant {

  def main(args: Array[String]) {
    val sparkConf = new SparkConf().setAppName("WebPerf")
    val ssc = new StreamingContext(sparkConf, Minutes(1))

    val kafkaParams = Map[String, String]("metadata.broker.list" -> KAFKA_BROKERS)
    val webPerfMessages = KafkaUtils.createDirectStream[String, String, StringDecoder, StringDecoder](
      ssc, kafkaParams, Set("vast.webperf"))
    val webDataMessages = KafkaUtils.createDirectStream[String, String, StringDecoder, StringDecoder](
      ssc, kafkaParams, Set("vast.webdata"))

    var webPerfSchema: StructType = null
    var webDataSchema: StructType = null

    val kafkaProducer: Broadcast[KafkaSink[String, String]] = {
      val kafkaProducerConfig = {
        val props = new Properties()
        props.setProperty("bootstrap.servers", RESULT_KAFKA_BROKERS)
        props.setProperty("key.serializer", classOf[StringSerializer].getName)
        props.setProperty("value.serializer", classOf[StringSerializer].getName)
        props.setProperty("partitioner.class", classOf[HashPartitioner].getName)
        props.setProperty("producer.type", "sync")
        props.setProperty("batch.num.messages", "50")

        props
      }
      ssc.sparkContext.broadcast(KafkaSink[String, String](kafkaProducerConfig))
    }

    val sparkBC: Broadcast[SparkSession] = {
      val spark = SparkSession.builder.config(sparkConf).getOrCreate()
      ssc.sparkContext.broadcast(spark)
    }

    val res1 = webPerfMessages.transform((rdd, time) => {
      val spark = sparkBC.value

      val dataset = if (webPerfSchema != null)
        spark.read.schema(webPerfSchema).json(spark.createDataset(rdd.values)(Encoders.STRING))
      else
        spark.read.json(spark.createDataset(rdd.values)(Encoders.STRING))
      webPerfSchema = dataset.schema

      dataset.createOrReplaceTempView("webperf")

      spark.conf.set("spark.sql.shuffle.partitions", "10")

      val result = spark.sql(
        raw"""
             |select COALESCE(if(action like 'EMIMP_NW%','EMIMP_NW',null),
             |           if(action like 'CHANCE_%','CHANCE',null),
             |           if(action like 'INS_%','INS',null),
             |           if(action like 'EMIMP_NS%','EMIMP%',null),
             |           if(action like 'REPORT_%','REPORT',null),
             |           if(action is null or action='','_',null),
             |                action) as action,
             |  SUM(IF(total < 300 and total >0, 1, 0)) AS du_300,
             |  SUM(IF(total < 500 and total >= 300, 1, 0)) AS du_500,
             |  SUM(IF(total < 1000 and total >= 500, 1, 0)) AS du_1000,
             |  SUM(IF(total < 2000 and total >= 1000, 1, 0)) AS du_2000,
             |  SUM(IF(total < 5000 and total >= 2000, 1, 0)) AS du_5000,
             |  SUM(IF(total < 10000 and total >= 5000, 1, 0)) AS du_10000,
             |  SUM(IF(total < 20000 and total >= 10000, 1, 0)) AS du_20000,
             |  SUM(IF(total >= 20000, 1, 0)) AS timeout,
             |  SUM(IF(total<0, 1, 0)) AS local_error
             |from webperf
             |group by COALESCE(if(action like 'EMIMP_NW%','EMIMP_NW',null),
             |           if(action like 'CHANCE_%','CHANCE',null),
             |           if(action like 'INS_%','INS',null),
             |           if(action like 'EMIMP_NS%','EMIMP%',null),
             |           if(action like 'REPORT_%','REPORT',null),
             |           if(action is null or action='','_',null),
             |                action)
             |having count(1)>10
             | """.stripMargin)

      result.rdd.map(row => (row.getString(0), row))
    })

    val res2 = webDataMessages.transform((rdd, time) => {
      val spark = sparkBC.value

      val dataset = if (webDataSchema != null)
        spark.read.schema(webDataSchema).json(spark.createDataset(rdd.values)(Encoders.STRING))
      else
        spark.read.json(spark.createDataset(rdd.values)(Encoders.STRING))
      webDataSchema = dataset.schema

      dataset.createOrReplaceTempView("webdata")

      spark.conf.set("spark.sql.shuffle.partitions", "10")

      val result = spark.sql(
        raw"""
             |select COALESCE(if(action like 'EMIMP_NW%','EMIMP_NW',null),
             |          if(action like 'CHANCE_%','CHANCE',null),
             |          if(action like 'INS_%','INS',null),
             |          if(action like 'EMIMP_NS%','EMIMP%',null),
             |          if(action like 'REPORT_%','REPORT',null),
             |          if(action is null or action='','_',null),
             |               action) as action,
             |     sum(if(info["info"]='接口调用失败',1,0)) rpc_error
             |from webdata
             |group by COALESCE(if(action like 'EMIMP_NW%','EMIMP_NW',null),
             |          if(action like 'CHANCE_%','CHANCE',null),
             |          if(action like 'INS_%','INS',null),
             |          if(action like 'EMIMP_NS%','EMIMP%',null),
             |          if(action like 'REPORT_%','REPORT',null),
             |          if(action is null or action='','_',null),
             |               action)
             |""".stripMargin)

      result.rdd.map(row => (row.getString(0), row))
    })

    res1.leftOuterJoin(res2).foreachRDD((rdd, time) => {
      // Save to Kafka
      rdd.foreach((kv: (String, (Row, Option[Row]))) => {
        val r1 = kv._2._1
        val r2 = kv._2._2.getOrElse(Row("", 0))
        kafkaProducer.value.send(RESULT_KAFKA_TOPIC, "webperf_" + time.milliseconds, s"[${(r1.toSeq ++ Seq(r2.get(1))).mkString(",")}]" )
      })
    })

    ssc.start()
    ssc.awaitTermination()
  }
}