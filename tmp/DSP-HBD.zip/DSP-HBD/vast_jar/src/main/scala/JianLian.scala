import java.util.Properties

import kafka.serializer.StringDecoder
import org.apache.kafka.common.serialization.StringSerializer
import org.apache.spark.SparkConf
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.types._
import org.apache.spark.sql.{Encoders, SparkSession}
import org.apache.spark.streaming.kafka.KafkaUtils
import org.apache.spark.streaming.{Minutes, StreamingContext}

// spark-submit --jars $(echo ./lib/*.jar | tr ' ' ',') --master spark://cnsz035617:7077  --deploy-mode client --total-executor-cores 20 --executor-cores 2 --executor-memory 10g --conf spark.ui.port=4041 --class JianLian2 jar-1.0.jar >/appcom/log/jobs/JianLian2.log &
object JianLian extends Constant {

  val topicsSet = Set("vast.app_event")

  def main(args: Array[String]) {
    val sparkConf = new SparkConf().setAppName("jianlian")
    val ssc = new StreamingContext(sparkConf, Minutes(1))

    val kafkaParams = Map[String, String]("metadata.broker.list" -> KAFKA_BROKERS)
    val messages = KafkaUtils.createDirectStream[String, String, StringDecoder, StringDecoder](
      ssc, kafkaParams, topicsSet)

    var eventSchema: StructType = null

    val kafkaProducer: Broadcast[KafkaSink[String, String]] = {
      val kafkaProducerConfig = {
        val props = new Properties()
        props.setProperty("bootstrap.servers", RESULT_KAFKA_BROKERS)
        props.setProperty("key.serializer", classOf[StringSerializer].getName)
        props.setProperty("value.serializer", classOf[StringSerializer].getName)
        props.setProperty("partitioner.class", classOf[HashPartitioner].getName)
        props.setProperty("producer.type", "sync")
        props.setProperty("batch.num.messages", "50")

        props
      }
      ssc.sparkContext.broadcast(KafkaSink[String, String](kafkaProducerConfig))

      //      val message1 = new KeyedMessage[String, String](topic, "1", "test 0");
      //      producer.send(message1);
      // https://www.cnblogs.com/AK47Sonic/p/7260577.html
    }

    messages.map(_._2).foreachRDD((rdd, time) => {
      val spark = SparkSession.builder.config(sparkConf).getOrCreate()

      val dataset = if (eventSchema != null)
        spark.read.schema(eventSchema).json(spark.createDataset(rdd)(Encoders.STRING))
      else
        spark.read.json(spark.createDataset(rdd)(Encoders.STRING))
      eventSchema = dataset.schema

      dataset.createOrReplaceTempView("app_event")

      spark.conf.set("spark.sql.shuffle.partitions", "20")

      val result = spark.sql(
        raw"""
         SELECT name, label, dim,
         COUNT(DISTINCT device_id) AS uv,
         SUM(IF((ConnectTimes<0 and (errorCode=0 or errorCode is null)) or ConnectTimes > 0 ,1,0)) AS pv,
         SUM(IF(ConnectTimes<0 and (errorCode=0 or errorCode is null) ,1,0)) AS fail_num,
         AVG(IF(ConnectTimes>0 and ConnectTimes<120000,ConnectTimes,0)) AS du_avg,
         SUM(IF(ConnectTimes < 300 and ConnectTimes >0, 1, 0)) AS du_300,
         SUM(IF(ConnectTimes < 500 and ConnectTimes >= 300, 1, 0)) AS du_500,
         SUM(IF(ConnectTimes < 1000 and ConnectTimes >= 500, 1, 0)) AS du_1000,
         SUM(IF(ConnectTimes < 1500 and ConnectTimes >= 1000, 1, 0)) AS du_1500,
         SUM(IF(ConnectTimes < 3000 and ConnectTimes >= 1500, 1, 0)) AS du_3000,
         SUM(IF(ConnectTimes < 5000 and ConnectTimes >= 3000, 1, 0)) AS du_5000,
         SUM(IF(ConnectTimes < 10000 and ConnectTimes >= 5000, 1, 0)) AS du_10000,
         SUM(IF(ConnectTimes >= 10000 and ConnectTimes<120000, 1, 0)) AS du_10001,
         SUM(IF(ConnectTimes >= 120000, 1, 0)) AS du_120000,
         SUM(IF(ConnectTimes > 5000, 1, 0)) AS overtime_num,
         SUM(IF(net_status = 0 , 1, 0)) AS no_net
           FROM (SELECT name,label,
           concat(concat(net_status,'|'),app_version) AS dim,
           device_id, parameters.ConnectTime AS ConnectTimes,parameters.returnCode AS net_returnCode,
           parameters.errorCode AS errorCode,app_type, net_status
           FROM app_event
           WHERE name='networkIO' and label in ('networkConnectInfo','marketConnectInfo','gatewayConnectInfo')
       AND  (split(app_version,'\\.')[0]>5 or (split(app_version,'\\.')[0]=5 and split(app_version,'\\.')[1]>=10))
       AND app_key='993F95713DA740373EF0A0EE7BBBCC32'
       AND net_status != 0
       AND parameters.ConnectTime is not null) t
       GROUP BY name, label, dim
                 """)

      // Save to DB Mode
      //      result.write.mode(SaveMode.Append).jdbc(jdbcUrl,"vast_result_custom_event2",prop)

      //      val rsSchema = result.schema
      //      val tableName = "VAST_RESULT_CUSTOM_EVENT"
      //      result.foreachPartition(iterator => OJDBCUtil.savePartition(tableName,rsSchema, iterator, time.milliseconds,JDBC_URL,JDBC_USERNAME,JDBC_PASSWORD))

      // Save to Kafka
      result.foreach(row => kafkaProducer.value.send(RESULT_KAFKA_TOPIC, "jianlian_" + time.milliseconds, row.toString()))
    }
    )
    ssc.start()
    ssc.awaitTermination()
  }
}