import java.sql.{Connection, DriverManager, PreparedStatement}
import java.text.SimpleDateFormat
import java.util.Date

import org.apache.spark.internal.Logging
import org.apache.spark.sql.Row
import org.apache.spark.sql.jdbc.JdbcDialects
import org.apache.spark.sql.types._

/**
  * Created by wankun603 on 2018-03-02.
  */
object OJDBCUtil extends Logging {
  type JDBCValueSetter = (PreparedStatement, Row, Int) => Unit

  def makeSetter(dataType: DataType): JDBCValueSetter = {
    dataType match {
      case IntegerType =>
        (stmt: PreparedStatement, row: Row, pos: Int) =>
          stmt.setInt(pos + 1, row.getInt(pos))

      case LongType =>
        (stmt: PreparedStatement, row: Row, pos: Int) =>
          stmt.setLong(pos + 1, row.getLong(pos))

      case DoubleType =>
        (stmt: PreparedStatement, row: Row, pos: Int) =>
          stmt.setDouble(pos + 1, row.getDouble(pos))

      case FloatType =>
        (stmt: PreparedStatement, row: Row, pos: Int) =>
          stmt.setFloat(pos + 1, row.getFloat(pos))

      case ShortType =>
        (stmt: PreparedStatement, row: Row, pos: Int) =>
          stmt.setInt(pos + 1, row.getShort(pos))

      case ByteType =>
        (stmt: PreparedStatement, row: Row, pos: Int) =>
          stmt.setInt(pos + 1, row.getByte(pos))

      case BooleanType =>
        (stmt: PreparedStatement, row: Row, pos: Int) =>
          stmt.setBoolean(pos + 1, row.getBoolean(pos))

      case StringType =>
        (stmt: PreparedStatement, row: Row, pos: Int) =>
          stmt.setString(pos + 1, row.getString(pos))

      case BinaryType =>
        (stmt: PreparedStatement, row: Row, pos: Int) =>
          stmt.setBytes(pos + 1, row.getAs[Array[Byte]](pos))

      case TimestampType =>
        (stmt: PreparedStatement, row: Row, pos: Int) =>
          stmt.setTimestamp(pos + 1, row.getAs[java.sql.Timestamp](pos))

      case DateType =>
        (stmt: PreparedStatement, row: Row, pos: Int) =>
          stmt.setDate(pos + 1, row.getAs[java.sql.Date](pos))

      case t: DecimalType =>
        (stmt: PreparedStatement, row: Row, pos: Int) =>
          stmt.setBigDecimal(pos + 1, row.getDecimal(pos))

      case _ =>
        (_: PreparedStatement, _: Row, pos: Int) =>
          throw new IllegalArgumentException(
            s"Can't translate non-null value for field $pos")
    }
  }

  def isCascadingTruncateTable(url: String): Option[Boolean] = {
    JdbcDialects.get(url).isCascadingTruncateTable()
  }

  def savePartition(tableName: String,
                    schema: StructType,
                    iterator: Iterator[Row],
                    time: Long,
                    JDBC_URL: String,
                    JDBC_USERNAME: String,
                    JDBC_PASSWORD: String): Unit = {

    val setters = schema.fields.map(f => makeSetter(f.dataType))
    val numFields = schema.fields.length
    val formatter: SimpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss")
    val frequence = formatter.format(new Date(time))
    val placeholder = schema.map(f => '?').mkString(",")

    val conn: Connection = DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD)
    conn.setAutoCommit(false);

    val sql =
      s"""INSERT INTO ${tableName} VALUES (
          | SEQ_${tableName}.nextval,
          | ${frequence} ,
          | sysdate,
          | ${placeholder})
             """.stripMargin

    val pstmt: PreparedStatement = conn.prepareStatement(sql)

    try {
      while (iterator.hasNext) {
        val row = iterator.next()
        var i = 0
        while (i < numFields) {
          if (!row.isNullAt(i)) {
            setters(i).apply(pstmt, row, i)
          }
          i = i + 1
        }
        pstmt.addBatch()
      }

      pstmt.executeBatch()
    } finally {
      if (pstmt != null)
        try {
          pstmt.close()
        } catch {
          case e: Exception => log.error("pstmt close failed", e)
        }

      if (conn != null)
        try {
          conn.close()
        } catch {
          case e: Exception => log.error("conn close failed", e)
        }
    }
  }
}