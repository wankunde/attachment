import kafka.serializer.StringDecoder
import org.apache.spark.SparkConf
import org.apache.spark.sql.types._
import org.apache.spark.sql.{Encoders, SparkSession}
import org.apache.spark.streaming.kafka.KafkaUtils
import org.apache.spark.streaming.{Minutes, StreamingContext}

// spark-submit --jars $(echo ./lib/*.jar | tr ' ' ',') --master spark://cnsz035617:7077  --deploy-mode client --total-executor-cores 10 --executor-cores 2 --executor-memory 4g --conf spark.ui.port=4044 --class AppUV jar-1.0.jar >/appcom/log/jobs/AppUV.log 2>&1 &

object AppUV extends Constant {

  val topicsSet = Set("vast.app_event")

  def main(args: Array[String]) {
    val sparkConf = new SparkConf().setAppName("app uv")
    val ssc = new StreamingContext(sparkConf, Minutes(1))

    val kafkaParams = Map[String, String]("metadata.broker.list" -> KAFKA_BROKERS)
    val messages = KafkaUtils.createDirectStream[String, String, StringDecoder, StringDecoder](
      ssc, kafkaParams, topicsSet)

    var eventSchema: StructType = null
    messages.map(_._2).foreachRDD((rdd, time) => {
      val spark = SparkSession.builder.config(sparkConf).getOrCreate()

      val dataset = if (eventSchema != null)
        spark.read.schema(eventSchema).json(spark.createDataset(rdd)(Encoders.STRING))
      else
        spark.read.json(spark.createDataset(rdd)(Encoders.STRING))
      eventSchema = dataset.schema

      dataset.createOrReplaceTempView("app_event")

      spark.conf.set("spark.sql.shuffle.partitions", "10")

      val result = spark.sql(
        raw"""SELECT count(distinct device_id)
              |FROM app_event
              |WHERE (split(app_version,'\\.')[0]>5 or (split(app_version,'\\.')[0]=5 and split(app_version,'\\.')[1]>=10))
              |AND app_key='993F95713DA740373EF0A0EE7BBBCC32'
         """.stripMargin)

      val rsSchema = result.schema
      val tableName = "VAST_RESULT_APP_UV"
      result.foreachPartition(iterator => OJDBCUtil.savePartition(tableName, rsSchema, iterator, time.milliseconds, JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD))
    }
    )
    ssc.start()
    ssc.awaitTermination()
  }
}