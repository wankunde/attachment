#!/bin/bash

spark-submit --jars $(echo ./lib/*.jar | tr ' ' ',') --master spark://cnsz035617:7077  --deploy-mode client --total-executor-cores 20 --executor-cores 2 --executor-memory 10g --conf spark.ui.port=4041 --class JianLian2 jar-1.0.jar >/appcom/log/jobs/JianLian2.log &
spark-submit --jars $(echo ./lib/*.jar | tr ' ' ',') --master spark://cnsz035617:7077  --deploy-mode client --total-executor-cores 20 --executor-cores 2 --executor-memory 10g --conf spark.ui.port=4042  --class CustomEvent jar-1.0.jar >/appcom/log/jobs/CustomEvent.log &
spark-submit --jars $(echo ./lib/*.jar | tr ' ' ',') --master spark://cnsz035617:7077  --deploy-mode client --total-executor-cores 10 --executor-cores 2 --executor-memory 4g --conf spark.ui.port=4043  --class AppPV jar-1.0.jar >/appcom/log/jobs/AppPV.log 2>&1 &
spark-submit --jars $(echo ./lib/*.jar | tr ' ' ',') --master spark://cnsz035617:7077  --deploy-mode client --total-executor-cores 10 --executor-cores 2 --executor-memory 4g --conf spark.ui.port=4044 --class AppUV jar-1.0.jar >/appcom/log/jobs/AppUV.log 2>&1 &
spark-submit --jars $(echo ./lib/*.jar | tr ' ' ',') --master spark://cnsz035617:7077  --deploy-mode client --total-executor-cores 10 --executor-cores 2 --executor-memory 4g --conf spark.ui.port=4047 --class AppStart jar-1.0.jar >/appcom/log/jobs/AppStart.log 2>&1 &
spark-submit --jars $(echo ./lib/*.jar | tr ' ' ',') --master spark://cnsz035617:7077  --deploy-mode client --total-executor-cores 10 --executor-cores 2 --executor-memory 4g  --conf spark.ui.port=4046 --class NewUser jar-1.0.jar >/appcom/log/jobs/NewUser.log 2>&1 &
spark-submit --jars $(echo ./lib/*.jar | tr ' ' ',') --master spark://cnsz035617:7077  --deploy-mode client --total-executor-cores 10 --executor-cores 2 --executor-memory 4g --conf spark.ui.port=4048  --class AppCrash jar-1.0.jar >/appcom/log/jobs/AppCrash.log 2>&1 &
spark-submit --jars $(echo ./lib/*.jar | tr ' ' ',') --master spark://cnsz035617:7077  --deploy-mode client --total-executor-cores 10 --executor-cores 2 --executor-memory 4g --conf spark.ui.port=4049  --class AppLogin jar-1.0.jar >/appcom/log/jobs/AppLogin.log 2>&1 &

