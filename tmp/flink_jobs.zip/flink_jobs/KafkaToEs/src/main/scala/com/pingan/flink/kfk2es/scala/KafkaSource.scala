package com.pingan.flink.kfk2es.scala

import java.util.Properties

import org.apache.flink.api.common.serialization.SimpleStringSchema
import org.apache.flink.api.java.utils.ParameterTool
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer08

/**
  * Created by WANGYI422 on 2018/7/24.
  */
class KafkaSource(params: ParameterTool) {
  val kafkaProp = new Properties()
  kafkaProp.setProperty("bootstrap.servers",params.getRequired("source.bootstrap.servers"))
  kafkaProp.setProperty("zookeeper.connect",params.getRequired("source.zookeeper.connect"))
  kafkaProp.setProperty("group.id",params.getRequired("source.group.id"))
  kafkaProp.setProperty("auto.offset.reset",params.get("source.auto.offset.reset","latest"))
  kafkaProp.setProperty("auto.commit.enable",params.getBoolean("source.auto.commit.enable",true).toString)
  val topic = params.getRequired("source.topic")

  def getSource = {
    new FlinkKafkaConsumer08(topic, new SimpleStringSchema(), kafkaProp)
  }
}
