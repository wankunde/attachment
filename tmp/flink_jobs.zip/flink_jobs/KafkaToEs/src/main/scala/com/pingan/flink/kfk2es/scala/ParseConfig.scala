package com.pingan.flink.kfk2es.scala

import org.apache.flink.api.common.ExecutionConfig
import org.apache.flink.api.common.restartstrategy.RestartStrategies
import org.apache.flink.api.java.utils.ParameterTool
import org.apache.flink.streaming.api.TimeCharacteristic
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
/**
  * Created by WANGYI422 on 2018/7/24.
  */
object ParseConfig {
  def checkArgs(args: Array[String]): Boolean = {
    if (args.length != 1) {
      false
    } else true
  }
}

class ParseConfig(val configFile: String) {
  val params = ParameterTool.fromPropertiesFile(configFile)

  def getExecEnv: StreamExecutionEnvironment = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    val config: ExecutionConfig = env.getConfig
    config.setRestartStrategy(RestartStrategies.fixedDelayRestart(3, 20000))
    env.enableCheckpointing(60000)
    config.setParallelism(params.getInt("flink.Parallelism",1))
    env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime)
    config.setGlobalJobParameters(params)
    env
  }
}
