package com.pingan.flink.kfk2es.scala

import org.apache.flink.api.scala._
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment

/**
  * Created by WANGYI422 on 2018/7/24.
  */
object Main {
  def main(args: Array[String]): Unit = {
    if (!ParseConfig.checkArgs(args)) throw new RuntimeException("Missing parameters!\n" + "Usage: flink run <Jar.file> <properties>")
    val parseConfig = new ParseConfig(args(0))
    val env: StreamExecutionEnvironment = parseConfig.getExecEnv
    val params = parseConfig.params

    val source = new KafkaSource(params)
    val sink = new EsSink(params)

    env.addSource(source.getSource).addSink(sink.getSink)
    env.execute(s"""${params.getRequired("source.topic")} to Es""")
  }
}
