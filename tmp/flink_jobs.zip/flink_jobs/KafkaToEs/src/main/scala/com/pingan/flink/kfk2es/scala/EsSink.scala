package com.pingan.flink.kfk2es.scala

import java.net.{InetAddress, InetSocketAddress}
import java.util

import scala.collection.JavaConverters._
import com.alibaba.fastjson.{JSON, JSONObject}
import org.apache.flink.api.common.functions.RuntimeContext
import org.apache.flink.api.java.utils.ParameterTool
import org.apache.flink.streaming.connectors.elasticsearch.{ElasticsearchSinkFunction, RequestIndexer}
import org.apache.flink.streaming.connectors.elasticsearch2.ElasticsearchSink
import org.elasticsearch.action.index.IndexRequest
import org.elasticsearch.client.Requests

object EsSink {
  case class EsSinkFunction(index: String, type_name: String, fields: String) extends ElasticsearchSinkFunction[String] {
    override def process(t: String, runtimeContext: RuntimeContext, requestIndexer: RequestIndexer): Unit = requestIndexer.add(createIndexRequest(t))

    def createIndexRequest(element: String): IndexRequest = {
      val jsonObject = JSON.parseObject(element)
      if (fields.toLowerCase().equals("all")) {
        Requests.indexRequest()
          .index(index)
          .`type`(type_name)
          .source(new util.HashMap[String, Object](jsonObject))
      } else {
        val json = new util.HashMap[String, Object](jsonObject.size())
        fields.split(",").foreach( k => json.put(k, jsonObject.get(k)))
        Requests.indexRequest()
          .index(index)
          .`type`(type_name)
          .source(json)
      }
    }
  }
}

/**
  * Created by WANGYI422 on 2018/7/24.
  */
class EsSink(params: ParameterTool) {
  import com.pingan.flink.kfk2es.scala.EsSink._
  val esProp = new util.HashMap[String, String]()
  esProp.put("cluster.name", params.getRequired("sink.cluster.name"))
  esProp.put("client.transport.sniff", params.get("sink.client.transport.sniff","true"))
  esProp.put("bulk.flush.max.size.mb", params.get("sink.bulk.flush.max.size.mb","2097152"))
  esProp.put("bulk.flush.interval.ms", params.get("sink.bulk.flush.interval.ms","200"))
  esProp.put("bulk.flush.backoff.enable", params.get("sink.bulk.flush.backoff.enable","true"))
  esProp.put("bulk.flush.backoff.retries", params.get("sink.bulk.flush.backoff.retries","3"))

  val transportAddresses = new util.ArrayList[InetSocketAddress]()
  transportAddresses.add(new InetSocketAddress(InetAddress.getByName(params.getRequired("sink.es.host.1")), 9300))
  transportAddresses.add(new InetSocketAddress(InetAddress.getByName(params.getRequired("sink.es.host.2")), 9300))
  transportAddresses.add(new InetSocketAddress(InetAddress.getByName(params.getRequired("sink.es.host.3")), 9300))

  def getSink: ElasticsearchSink[String] = {
    new ElasticsearchSink(esProp, transportAddresses, EsSinkFunction(
      params.getRequired("sink.es.index.name"),
      params.getRequired("sink.es.type.name"),
      params.get("sink.es.fields", "all")))
  }

}
