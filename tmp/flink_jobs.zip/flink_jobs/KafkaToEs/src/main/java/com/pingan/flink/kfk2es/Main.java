package com.pingan.flink.kfk2es;

import org.apache.flink.api.common.functions.RuntimeContext;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.elasticsearch.ElasticsearchSinkFunction;
import org.apache.flink.streaming.connectors.elasticsearch.RequestIndexer;
import org.apache.flink.streaming.connectors.elasticsearch2.ElasticsearchSink;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer08;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.client.Requests;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by WANGYI422 on 2018/7/26.
 */
public class Main {
    public static void main(String[] args) throws Exception {
        Map<String, String> esProp = new HashMap<String, String>();
        List<InetSocketAddress> transportAddresses = new ArrayList<InetSocketAddress>();

        if (!ParseConfig.checkArgs(args))
            throw new RuntimeException("Missing parameters!\n" + "Usage: flink run <Jar.file> <properties>");

        ParseConfig parseConfig = new ParseConfig(args[0]);
        StreamExecutionEnvironment env = parseConfig.getExecEnv();
        ParameterTool params = parseConfig.params;

        FlinkKafkaConsumer08<String> source = new KafkaSource(params).getSource();
        ElasticsearchSink<String> sink = new EsSink(params).getSink();

        env.addSource(source).addSink(sink);
        env.execute(params.getRequired("source.topic") + " to Es");
    }
}
