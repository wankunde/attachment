package com.pingan.flink.kfk2es;

import org.apache.flink.api.common.functions.RuntimeContext;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.connectors.elasticsearch.ElasticsearchSinkFunction;
import org.apache.flink.streaming.connectors.elasticsearch.RequestIndexer;
import org.apache.flink.streaming.connectors.elasticsearch2.ElasticsearchSink;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.client.Requests;

import java.io.Serializable;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by WANGYI422 on 2018/7/26.
 */
public class EsSink {
    public ParameterTool params;
    private Map<String, String> esProp = new HashMap<String, String>();
    private List<InetSocketAddress> transportAddresses = new ArrayList<InetSocketAddress>();

    public EsSink(ParameterTool params) {
        this.params = params;
    }

    public ElasticsearchSink<String> getSink() {
        esProp.put("cluster.name", params.getRequired("sink.cluster.name"));
        esProp.put("client.transport.sniff", params.get("sink.client.transport.sniff","true"));
        esProp.put("bulk.flush.max.size.mb", params.get("sink.bulk.flush.max.size.mb","2097152"));
        esProp.put("bulk.flush.interval.ms", params.get("sink.bulk.flush.interval.ms","200"));
        esProp.put("bulk.flush.backoff.enable", params.get("sink.bulk.flush.backoff.enable","true"));
        esProp.put("bulk.flush.backoff.retries", params.get("sink.bulk.flush.backoff.retries","3"));

        try {
            transportAddresses.add(new InetSocketAddress(InetAddress.getByName(params.getRequired("sink.es.host.1")), 9300));
            transportAddresses.add(new InetSocketAddress(InetAddress.getByName(params.getRequired("sink.es.host.2")), 9300));
            transportAddresses.add(new InetSocketAddress(InetAddress.getByName(params.getRequired("sink.es.host.3")), 9300));
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }

        EsSinkFunction<String> func = new EsSinkFunction<String>(params);

        return new ElasticsearchSink<String>(esProp, transportAddresses, func);
    }
}
