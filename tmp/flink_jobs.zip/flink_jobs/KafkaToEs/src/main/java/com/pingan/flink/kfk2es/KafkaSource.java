package com.pingan.flink.kfk2es;

import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer08;

import java.util.Properties;

/**
 * Created by WANGYI422 on 2018/7/26.
 */
public class KafkaSource {
    public ParameterTool params;
    private Properties kafkaProp = new Properties();

    public KafkaSource(ParameterTool params) {
        this.params = params;
    }

    public FlinkKafkaConsumer08<String> getSource() {
        String topic = params.getRequired("source.topic");
        kafkaProp.setProperty("bootstrap.servers",params.getRequired("source.bootstrap.servers"));
        kafkaProp.setProperty("zookeeper.connect",params.getRequired("source.zookeeper.connect"));
        kafkaProp.setProperty("group.id",params.getRequired("source.group.id"));
        kafkaProp.setProperty("auto.offset.reset",params.get("source.auto.offset.reset","latest"));
        kafkaProp.setProperty("auto.commit.enable", params.get("source.auto.commit.enable", "true").toLowerCase());
        return new FlinkKafkaConsumer08<String>(topic, new SimpleStringSchema(), kafkaProp);
    }
}
