package com.pingan.flink.kfk2es;

import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

import java.io.File;
import java.io.IOException;

/**
 * Created by WANGYI422 on 2018/7/26.
 */
public class ParseConfig {
    public ParameterTool params;
    public String configFile;

    public static boolean checkArgs(String[] args) {
        if (args.length != 1) {
            return false;
        } else return true;
    }

    public ParseConfig(String configFile) {
        this.configFile = configFile;
    }

    public StreamExecutionEnvironment getExecEnv() throws IOException {
        params = ParameterTool.fromPropertiesFile(new File(configFile));
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.getConfig().setRestartStrategy(RestartStrategies.fixedDelayRestart(3, 20000));
        env.enableCheckpointing(60000);
        env.getConfig().setParallelism(params.getInt("flink.Parallelism", 1));
        env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);
        env.getConfig().setGlobalJobParameters(params);
        return env;
    }
}
