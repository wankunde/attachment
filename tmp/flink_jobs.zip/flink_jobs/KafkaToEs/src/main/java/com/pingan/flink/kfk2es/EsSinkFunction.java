package com.pingan.flink.kfk2es;

import org.apache.flink.api.common.functions.RuntimeContext;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.connectors.elasticsearch.ElasticsearchSinkFunction;
import org.apache.flink.streaming.connectors.elasticsearch.RequestIndexer;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.client.Requests;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by WANGYI422 on 2018/7/26.
 */
public class EsSinkFunction<T> implements ElasticsearchSinkFunction<T>, Serializable {
    private String index;
    private String type;
    private String fields;

    public EsSinkFunction() {
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setFields(String fields) {
        this.fields = fields;
    }

    public String getIndex() {
        return index;
    }

    public String getType() {
        return type;
    }

    public String getFields() {
        return fields;
    }

    public EsSinkFunction(String index, String type, String fields) {
        this.index = index;
        this.type = type;
        this.fields = fields;
    }

    public EsSinkFunction(ParameterTool params) {
        this.index = params.getRequired("sink.es.index.name");
        this.type = params.getRequired("sink.es.type.name");
        this.fields = params.getRequired("sink.es.fields");
    }

    public IndexRequest createIndexRequest(T element) {
        Map<String, String> json = new HashMap<String, String>();
        json.put("data", "This is a test");
        return Requests.indexRequest()
                .index(this.index)
                .type(this.type)
                .source(json);
    }

    @Override
    public void process(T t, RuntimeContext runtimeContext, RequestIndexer requestIndexer) {
        requestIndexer.add(createIndexRequest(t));
    }
}
