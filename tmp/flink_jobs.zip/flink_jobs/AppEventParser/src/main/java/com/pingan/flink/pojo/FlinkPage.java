package com.pingan.flink.pojo;

import com.paic.app.tracking.Page;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by WANGYI422 on 2018/1/19.
 */
public class FlinkPage {
    public String app_version;
    public String device_model;
    public String os_name;
    public String os_version;
    public String app_key;
    public String app_type;
    public String device_id;
    public String partner_id;
    public String net_status;
    public String local_ip;
    public String session_id;
    public int index;
    public long start;
    public long ts;
    public String ip;
    public String name;
    public String refer;
    public int level;
    public Map<String, String> parameters;
    public long end;
    public long duration;

    public FlinkPage() {
    }

    public FlinkPage(Page page) {
        this.app_version = (String)page.getAppVersion();
        this.device_model = (String)page.getDeviceModel();
        this.os_name = (String)page.getOsName();
        this.os_version = (String)page.getOsVersion();
        this.app_key = (String)page.getAppKey();
        this.app_type = (String)page.getAppType();
        this.device_id = (String)page.getDeviceId();
        this.partner_id = (String)page.getPartnerId();
        this.net_status = (String)page.getNetStatus();
        this.local_ip = (String)page.getLocalIp();
        this.session_id = (String)page.getSessionId();
        this.index = page.getIndex();
        this.start = page.getStart();
        this.ts = page.getTs();
        this.ip = (String)page.getIp();
        this.name = (String)page.getName();
        this.refer = (String)page.getRefer();
        this.level = page.getLevel();
        this.parameters = (HashMap<String,String>)(Map)page.getParameters();
        this.end = page.getEnd();
        this.duration = page.getDuration();
    }

    public String getApp_version() {
        return app_version;
    }

    public String getDevice_model() {
        return device_model;
    }

    public String getOs_name() {
        return os_name;
    }

    public String getOs_version() {
        return os_version;
    }

    public String getApp_key() {
        return app_key;
    }

    public String getApp_type() {
        return app_type;
    }

    public String getDevice_id() {
        return device_id;
    }

    public String getPartner_id() {
        return partner_id;
    }

    public String getNet_status() {
        return net_status;
    }

    public String getLocal_ip() {
        return local_ip;
    }

    public String getSession_id() {
        return session_id;
    }

    public int getIndex() {
        return index;
    }

    public long getStart() {
        return start;
    }

    public long getTs() {
        return ts;
    }

    public String getIp() {
        return ip;
    }

    public String getName() {
        return name;
    }

    public String getRefer() {
        return refer;
    }

    public int getLevel() {
        return level;
    }

    public Map<String, String> getParameters() {
        return parameters;
    }

    public long getEnd() {
        return end;
    }

    public long getDuration() {
        return duration;
    }

    public void setApp_version(String app_version) {
        this.app_version = app_version;
    }

    public void setDevice_model(String device_model) {
        this.device_model = device_model;
    }

    public void setOs_name(String os_name) {
        this.os_name = os_name;
    }

    public void setOs_version(String os_version) {
        this.os_version = os_version;
    }

    public void setApp_key(String app_key) {
        this.app_key = app_key;
    }

    public void setApp_type(String app_type) {
        this.app_type = app_type;
    }

    public void setDevice_id(String device_id) {
        this.device_id = device_id;
    }

    public void setPartner_id(String partner_id) {
        this.partner_id = partner_id;
    }

    public void setNet_status(String net_status) {
        this.net_status = net_status;
    }

    public void setLocal_ip(String local_ip) {
        this.local_ip = local_ip;
    }

    public void setSession_id(String session_id) {
        this.session_id = session_id;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public void setStart(long start) {
        this.start = start;
    }

    public void setTs(long ts) {
        this.ts = ts;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setRefer(String refer) {
        this.refer = refer;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public void setParameters(Map<String, String> parameters) {
        this.parameters = parameters;
    }

    public void setEnd(long end) {
        this.end = end;
    }

    public void setDuration(long duration) {
        this.duration = duration;
    }
}
