package com.pingan.flink.pojo;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by WANGYI422 on 2018/4/13.
 */
public class AppSimplifyLog {
    public String device_id = null;
    public String userid = null;
    public String cust_code = null;
    public String session_id = null;
    public String ip = null;
    public String local_ip = null;
    public String app_type = null;
    public String app_version = null;
    public String os_version = null;
    public String model = null;
    public String label = null;
    public String name = null;
    public String click_time = null;
    public String receive_time = null;
    public String end_time = null;
    public long duration = 0;
    public String aid = null;
    public String sid = null;
    public String ouid = null;
    public String partner_id = null;
    public String app_key = null;
    public int index = 0;
    public String net_status = null;
    public Map<String, String> parameters = new HashMap<>();
    public String source = "native";

    public AppSimplifyLog() {
    }

    public AppSimplifyLog(String device_id, String userid, String cust_code, String session_id, String ip, String local_ip, String app_type, String app_version, String os_version, String model, String label, String name, String click_time, String receive_time, String end_time, long duration, String aid, String sid, String ouid, String partner_id, String app_key, int index, String net_status, Map<String, String> parameters, String source) {
        this.device_id = device_id;
        this.userid = userid;
        this.cust_code = cust_code;
        this.session_id = session_id;
        this.ip = ip;
        this.local_ip = local_ip;
        this.app_type = app_type;
        this.app_version = app_version;
        this.os_version = os_version;
        this.model = model;
        this.label = label;
        this.name = name;
        this.click_time = click_time;
        this.receive_time = receive_time;
        this.end_time = end_time;
        this.duration = duration;
        this.aid = aid;
        this.sid = sid;
        this.ouid = ouid;
        this.partner_id = partner_id;
        this.app_key = app_key;
        this.index = index;
        this.net_status = net_status;
        this.parameters = parameters;
        this.source = source;

    }

    public String getDevice_id() {
        return device_id;
    }

    public String getUserid() {
        return userid;
    }

    public String getCust_code() {
        return cust_code;
    }

    public String getSession_id() {
        return session_id;
    }

    public String getIp() {
        return ip;
    }

    public String getLocal_ip() {
        return local_ip;
    }

    public String getApp_type() {
        return app_type;
    }

    public String getApp_version() {
        return app_version;
    }

    public String getOs_version() {
        return os_version;
    }

    public String getModel() {
        return model;
    }

    public String getLabel() {
        return label;
    }

    public String getName() {
        return name;
    }

    public String getClick_time() {
        return click_time;
    }

    public String getReceive_time() {
        return receive_time;
    }

    public String getEnd_time() {
        return end_time;
    }

    public long getDuration() {
        return duration;
    }

    public String getAid() {
        return aid;
    }

    public String getSid() {
        return sid;
    }

    public String getOuid() {
        return ouid;
    }

    public String getPartner_id() {
        return partner_id;
    }

    public String getApp_key() {
        return app_key;
    }

    public int getIndex() {
        return index;
    }

    public String getNet_status() {
        return net_status;
    }

    public Map<String, String> getParameters() {
        return parameters;
    }

    public String getSource() {
        return source;
    }


    public void setDevice_id(String device_id) {
        this.device_id = device_id;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public void setCust_code(String cust_code) {
        this.cust_code = cust_code;
    }

    public void setSession_id(String session_id) {
        this.session_id = session_id;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public void setLocal_ip(String local_ip) {
        this.local_ip = local_ip;
    }

    public void setApp_type(String app_type) {
        this.app_type = app_type;
    }

    public void setApp_version(String app_version) {
        this.app_version = app_version;
    }

    public void setOs_version(String os_version) {
        this.os_version = os_version;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setClick_time(String click_time) {
        this.click_time = click_time;
    }

    public void setReceive_time(String receive_time) {
        this.receive_time = receive_time;
    }

    public void setEnd_time(String end_time) {
        this.end_time = end_time;
    }

    public void setDuration(long duration) {
        this.duration = duration;
    }

    public void setAid(String aid) {
        this.aid = aid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    public void setOuid(String ouid) {
        this.ouid = ouid;
    }

    public void setPartner_id(String partner_id) {
        this.partner_id = partner_id;
    }

    public void setApp_key(String app_key) {
        this.app_key = app_key;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public void setNet_status(String net_status) {
        this.net_status = net_status;
    }

    public void setParameters(Map<String, String> parameters) {
        this.parameters = parameters;
    }

    public void setSource(String source) {
        this.source = source;
    }

}
