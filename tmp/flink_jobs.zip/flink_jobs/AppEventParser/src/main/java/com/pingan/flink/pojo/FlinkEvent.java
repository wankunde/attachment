package com.pingan.flink.pojo;

import com.paic.app.tracking.Event;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by WANGYI422 on 2018/1/17.
 */
public class FlinkEvent {
    public String app_version;
    public String device_model;
    public String os_name;
    public String os_version;
    public String app_key;
    public String app_type;
    public String device_id;
    public String partner_id;
    public String net_status;
    public String local_ip;
    public String session_id;
    public int index;
    public long start;
    public long ts;
    public String ip;
    public String name;
    public String label;
    public Map<String,String> parameters;
    public long end;
    public long duration;

    public FlinkEvent(){}

    public FlinkEvent(Event event){
        this.app_version = (String) event.getAppVersion();
        this.device_model = (String) event.getDeviceModel();
        this.os_name = (String) event.getOsName();
        this.os_version = (String) event.getOsVersion();
        this.app_key = (String) event.getAppKey();
        this.app_type = (String) event.getAppType();
        this.device_id = (String) event.getDeviceId();
        this.partner_id = (String) event.getPartnerId();
        this.net_status = (String) event.getNetStatus();
        this.local_ip = (String) event.getLocalIp();
        this.session_id = (String) event.getSessionId();
        this.index = event.getIndex();
        this.start = event.getStart();
        this.ts = event.getTs();
        this.ip = (String) event.getIp();
        this.name = (String) event.getName();
        this.label = (String) event.getLabel();
//        this.parameters = event.getParameters().toString();
        this.parameters = (HashMap<String, String>)(Map)event.getParameters();
        this.end = event.getEnd();
        this.duration = event.getDuration();
    }

    public String toString(){
        String SEP = ",";
        return app_version+SEP+device_model+SEP+os_name+SEP+os_version+SEP+app_key+SEP+
                app_type+SEP+device_id+SEP+partner_id+SEP+net_status+SEP+local_ip+SEP+
                session_id+SEP+index+SEP+start+SEP+ts+SEP+ip+SEP+name+SEP+label+SEP+
                parameters.toString()+SEP+end+SEP+duration+"\n";
    }

    public String getApp_version() {
        return app_version;
    }

    public String getDevice_model() {
        return device_model;
    }

    public String getOs_name() {
        return os_name;
    }

    public String getOs_version() {
        return os_version;
    }

    public String getApp_key() {
        return app_key;
    }

    public String getApp_type() {
        return app_type;
    }

    public String getDevice_id() {
        return device_id;
    }

    public String getPartner_id() {
        return partner_id;
    }

    public String getNet_status() {
        return net_status;
    }

    public String getLocal_ip() {
        return local_ip;
    }

    public String getSession_id() {
        return session_id;
    }

    public int getIndex() {
        return index;
    }

    public long getStart() {
        return start;
    }

    public long getTs() {
        return ts;
    }

    public String getIp() {
        return ip;
    }

    public String getName() {
        return name;
    }

    public String getLabel() {
        return label;
    }

    public Map<String, String> getParameters() {
        return parameters;
    }

    public long getEnd() {
        return end;
    }

    public long getDuration() {
        return duration;
    }

    public void setApp_version(String app_version) {
        this.app_version = app_version;
    }

    public void setDevice_model(String device_model) {
        this.device_model = device_model;
    }

    public void setOs_name(String os_name) {
        this.os_name = os_name;
    }

    public void setOs_version(String os_version) {
        this.os_version = os_version;
    }

    public void setApp_key(String app_key) {
        this.app_key = app_key;
    }

    public void setApp_type(String app_type) {
        this.app_type = app_type;
    }

    public void setDevice_id(String device_id) {
        this.device_id = device_id;
    }

    public void setPartner_id(String partner_id) {
        this.partner_id = partner_id;
    }

    public void setNet_status(String net_status) {
        this.net_status = net_status;
    }

    public void setLocal_ip(String local_ip) {
        this.local_ip = local_ip;
    }

    public void setSession_id(String session_id) {
        this.session_id = session_id;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public void setStart(long start) {
        this.start = start;
    }

    public void setTs(long ts) {
        this.ts = ts;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public void setParameters(Map<String, String> parameters) {
        this.parameters = parameters;
    }

    public void setEnd(long end) {
        this.end = end;
    }

    public void setDuration(long duration) {
        this.duration = duration;
    }
}
