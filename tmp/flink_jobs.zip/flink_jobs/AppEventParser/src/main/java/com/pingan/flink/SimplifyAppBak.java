package com.pingan.flink;

import com.pingan.flink.pojo.FlinkEvent;
import com.pingan.flink.pojo.SimplifyLog;
import org.slf4j.Logger;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by WANGYI422 on 2018/4/13.
 */
public class SimplifyAppBak {

    public static SimplifyLog simplify(FlinkEvent flinkEvent){
        String userid ;
        String usercode ;
        String device_id ;
        String ip ;
        String app_type ;
        String app_version ;
        String os_version ;
        String model ;
        String label ;
        String name ;
        String referer = null;
        String click_time ;
        long duration ;
        String wt_sr = null;
        String source = "native";
        String sd_sid = null;
        String visitorid = null;
        String visitid = null;
        String channel = null;

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        userid = flinkEvent.getParameters().getOrDefault("userId", null);
        usercode = flinkEvent.getParameters().getOrDefault("userCode", null);
        device_id = flinkEvent.getDevice_id();
        ip = flinkEvent.getIp();
        app_type = flinkEvent.getApp_type();
        app_version = flinkEvent.getApp_version();
        os_version = flinkEvent.getOs_version();
        model = flinkEvent.getDevice_model();
        label = flinkEvent.getLabel();
        name = flinkEvent.getName();
        click_time = sdf.format(new Date(flinkEvent.getStart()));
        duration = flinkEvent.getDuration();

        return new SimplifyLog(userid, usercode, device_id, ip, app_type, app_version, os_version, model, label, name, referer, click_time, duration, wt_sr, source, sd_sid, visitorid, visitid, channel);
    }

    public static List<String> readFilter(String localFile, Logger logger) throws IOException {
        File local = new File(localFile);
        List<String> filter = new ArrayList<String>();

        if (!local.exists()) {
            logger.error("Local file {} does not exists!", localFile);
            return null;
        }

        BufferedReader bufferedReader = new BufferedReader(new FileReader(local));
        String line = null;
        while ((line = bufferedReader.readLine()) != null) {
            filter.add(line);
        }
        return filter;
    }
}
