package com.pingan.flink;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.paic.app.tracking.*;
import com.paic.data.log.reader.HttpByteLogReader;
import com.paic.data.log.reader.HttpRequestParser;
import com.paic.data.log.tools.EventParser;
import com.paic.data.log.tools.EventType;
import com.paic.data.log.tools.SDConfusionParser;
import com.paic.data.utils.Base64Utils;
import com.paic.data.utils.EasyCodecUtils;
import com.paic.data.utils.GZipUtils;
import com.paic.data.utils.QueryStringDecoder;

import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by WANGYI422 on 2018/1/17.
 */
public class parsedUtils {
    public static final int DEFAULT_SEED = 0x9747b28c;
    private final byte[] KEY = Base64Utils.decrypt("UGluZ0FuRWFzeUNvZGVjS2V5");
    private HttpRequestParser parser = new HttpRequestParser(HttpRequestParser.AppHeaderFields);
    private static final Charset CHARSET = Charset.forName("UTF-8");
    private static String CHARSET_STR = "charset=";
    private static int CHARSET_STR_LEN = CHARSET_STR.length();
    List<Event> app_event_records = new LinkedList<>();
    List<Install> app_install_records = new LinkedList<>();
    List<Start> app_start_records = new LinkedList<>();
    List<Crash> app_crash_records = new LinkedList<>();
    List<Close> app_close_records = new LinkedList<>();
    List<Session> app_session_records = new LinkedList<>();
    List<Page> app_page_records = new LinkedList<>();

    public void parseKafka( byte[] event) {

        try {
            HttpByteLogReader.Request request = parser.parse(event);
            QueryStringDecoder queryString = new QueryStringDecoder(request.uri, CHARSET);
            String appKey = queryString.get("appKey");
            String appType = queryString.get("appType");
            String contentType = request.headers.get("Content-Type");
            if (request.method.equals(HttpByteLogReader.HttpMethod.POST)) {
                if ((!EventParser.hasEmptyString(new String[]{appKey, appType, contentType})) && (request.content != null) && (request.content.length >= 10))
                    ;
            } else {
                return;
            }
            JSONObject report = null;
            if (contentType.contains("application/json")) {
                report = JSONObject.parseObject(new String(request.content, getCharset(contentType)));
            } else {
                byte[] data = EasyCodecUtils.decrypt(request.content, KEY);
                if ((data[0] != 123) && (data[1] != 34)) {
                    data = GZipUtils.uncompress(data);
                }
                report = JSONObject.parseObject(new String(data, CHARSET));
            }

            EventParser.Common common = EventParser.parseCommon(appKey, appType, report);
            common.ts = request.time;
            common.ip = request.ip;
            if (!common.valid()) {
                return;
            }

            JSONArray events = (JSONArray) SDConfusionParser.get(report, "events");
            for (Iterator i$ = events.iterator(); i$.hasNext(); ) {
                Object e = i$.next();
                JSONObject object = (JSONObject) e;
                Integer type = SDConfusionParser.getInt(object, "type");
                try {
                    if (type == null)
                        continue;
                    if (type.intValue() == EventType.Event.id) {
                        Event record = EventParser.parseEvent(common, object);

                        if (record != null && record.getTs() > 1496332800000l) //2017-6-2日之后。
                            app_event_records.add(record);
                    } else if (type.intValue() == EventType.Install.id) {
                        Install record = EventParser.parseInstall(common, object);

                        if (record != null) {
                            app_install_records.add(record);
                        }
                    } else if (type.intValue() == EventType.Start.id){
                        Start record = EventParser.parseStart(common, object);

                        if (record != null) {
                            app_start_records.add(record);
                        }
                    } else if (type.intValue() == EventType.Crash.id) {
                        Crash record = EventParser.parseCrash(common, object);

                        if (record != null) {
                            app_crash_records.add(record);
                        }
                    } else if (type.intValue() == EventType.Close.id){
                        Close record = EventParser.parseClose(common, object);

                        if (record != null) {
                            app_close_records.add(record);
                        }
                    } else if (type.intValue() == EventType.Session.id) {
                        Session record = EventParser.parseSession(common, object);

                        if (record != null) {
                            app_session_records.add(record);
                        }
                    } else if (type.intValue() == EventType.Page.id) {
                        Page record = EventParser.parsePage(common, object);

                        if (record != null) {
                            app_page_records.add(record);
                        }
                    } else {
                        continue;
                    }

                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static Charset getCharset(String content_type) {
        int length = content_type != null ? content_type.length() : 0;
        if (length < CHARSET_STR_LEN) {
            return CHARSET;
        }
        int pos = content_type.indexOf(CHARSET_STR);
        if (pos < 0) {
            return CHARSET;
        }
        String charset = content_type.substring(pos + CHARSET_STR_LEN);
        try {
            return Charset.forName(charset);
        } catch (Exception e) {
        }
        return CHARSET;
    }

    public List<Event> getAppEventRecords() {
        return app_event_records;
    }

    public List<Install> getAppInstallRecords() {
        return app_install_records;
    }

    public List<Start> getAppStartRecords() {
        return app_start_records;
    }

    public List<Crash> getAppCrashRecords() {
        return app_crash_records;
    }

    public List<Close> getAppCloseRecords() {
        return app_close_records;
    }

    public List<Session> getAppSessionRecords() {
        return app_session_records;
    }

    public List<Page> getAppPageRecords() {
        return app_page_records;
    }
}
