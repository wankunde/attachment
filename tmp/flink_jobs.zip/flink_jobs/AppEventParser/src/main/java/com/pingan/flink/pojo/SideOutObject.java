package com.pingan.flink.pojo;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by WANGYI422 on 2018/4/16.
 */
public class SideOutObject {
    public String ct;
    public String t;
    public String id;
    public Map<String, String> v;

    public SideOutObject(String ct, String t, String id, Map<String, String> v) {
        this.ct = ct;
        this.t = t;
        this.id = id;
        this.v = v;
    }

    public SideOutObject() {
    }

    public SideOutObject(String ct, String t, String id, SimplifyLog simplifyLog) {
        this.ct = ct;
        this.t = t;
        this.id = id;
        Map<String, String> map = new LinkedHashMap<>(19);
        map.put("userid", simplifyLog.userid);
        map.put("usercode", simplifyLog.usercode);
        map.put("device_id", simplifyLog.device_id);
        map.put("ip", simplifyLog.ip);
        map.put("app_type", simplifyLog.app_type);
        map.put("app_version", simplifyLog.app_version);
        map.put("os_version", simplifyLog.os_version);
        map.put("model", simplifyLog.model);
        map.put("label", simplifyLog.label);
        map.put("name", simplifyLog.name);
        map.put("referer", simplifyLog.referer);
        map.put("click_time", simplifyLog.click_time);
        map.put("duration", String.valueOf(simplifyLog.duration));
        map.put("wt_sr", simplifyLog.wt_sr);
        map.put("source", simplifyLog.source);
        map.put("sd_sid", simplifyLog.sd_sid);
        map.put("visitorid", simplifyLog.visitorid);
        map.put("visitid", simplifyLog.visitid);
        map.put("channel", simplifyLog.channel);
        this.v = map;
    }

    public String getCt() {
        return ct;
    }

    public String getT() {
        return t;
    }

    public String getId() {
        return id;
    }

    public Map<String, String> getV() {
        return v;
    }

    public void setCt(String ct) {
        this.ct = ct;
    }

    public void setT(String t) {
        this.t = t;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setV(Map<String, String> v) {
        this.v = v;
    }
}

