package com.pingan.flink.pojo;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by WANGYI422 on 2018/4/16.
 */
public class AppInternalSideOutObject {
    public String ct;
    public String t;
    public String id;
    public Map<String, Object> v;

    public AppInternalSideOutObject() {
    }

    public AppInternalSideOutObject(String ct, String t, String id, Map<String, Object> v) {
        this.ct = ct;
        this.t = t;
        this.id = id;
        this.v = v;
    }

    public AppInternalSideOutObject(String ct, String t, String id, AppSimplifyLog simplifyLog) {
        this.ct = ct;
        this.t = t;
        this.id = id;
        Map<String, Object> map = new LinkedHashMap<>(30);
        map.put("device_id", simplifyLog.device_id);
        map.put("userid", simplifyLog.userid);
        map.put("cust_code", simplifyLog.cust_code);
        map.put("session_id", simplifyLog.session_id);
        map.put("ip", simplifyLog.ip);
        map.put("local_ip", simplifyLog.local_ip);
        map.put("app_type", simplifyLog.app_type);
        map.put("app_version", simplifyLog.app_version);
        map.put("os_version", simplifyLog.os_version);
        map.put("model", simplifyLog.model);
        map.put("label", simplifyLog.label);
        map.put("name", simplifyLog.name);
        map.put("click_time", simplifyLog.click_time);
        map.put("receive_time", simplifyLog.receive_time);
        map.put("end_time", simplifyLog.end_time);
        map.put("duration", String.valueOf(simplifyLog.duration));
        map.put("aid", simplifyLog.aid);
        map.put("sid", simplifyLog.sid);
        map.put("ouid", simplifyLog.ouid);
        map.put("partner_id", simplifyLog.partner_id);
        map.put("app_key", simplifyLog.app_key);
        map.put("index", String.valueOf(simplifyLog.index));
        map.put("net_status", simplifyLog.net_status);
        map.put("source", simplifyLog.source);

        if (simplifyLog.receive_time != null && simplifyLog.receive_time.length() == 24) {
            map.put("day", simplifyLog.receive_time.substring(0, 10));
            map.put("hour", simplifyLog.receive_time.substring(0, 13));
            map.put("minute", simplifyLog.receive_time.substring(0, 16));
        }
        map.put("pv", "1");

        this.v = map;
    }

    public String getCt() {
        return ct;
    }

    public String getT() {
        return t;
    }

    public String getId() {
        return id;
    }

    public Map<String, Object> getV() {
        return v;
    }

    public void setCt(String ct) {
        this.ct = ct;
    }

    public void setT(String t) {
        this.t = t;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setV(Map<String, Object> v) {
        this.v = v;
    }
}

