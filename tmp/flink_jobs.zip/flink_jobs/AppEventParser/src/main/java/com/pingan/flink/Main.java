package com.pingan.flink;

/**
 * Created by WANGYI422 on 2018/1/16.
 */
import com.paic.app.tracking.*;
import com.paic.data.log.tools.EventType;
import com.pingan.flink.pojo.*;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.common.state.MapState;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.typeinfo.BasicTypeInfo;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.collector.selector.OutputSelector;
import org.apache.flink.streaming.api.datastream.BroadcastStream;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.datastream.SplitStream;
import org.apache.flink.streaming.api.environment.CheckpointConfig;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer08;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaProducer08;
import org.apache.flink.streaming.connectors.kafka.partitioner.FlinkKafkaPartitioner;
import org.apache.flink.util.Collector;
import com.alibaba.fastjson.JSON;
import org.apache.flink.util.OutputTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.*;


public class Main {
    public static void main(String[] args) throws Exception {
//        final Logger logger = LoggerFactory.getLogger(Main.class);

        if (args.length != 1) {
            System.out.println("Missing parameters!\n" +
                    "Usage: flink run <Jar.file> <properties>");
            return;
        }
        final ParameterTool parameterTool = ParameterTool.fromPropertiesFile(new File(args[0]));
        /*if (parameterTool.getNumberOfParameters() < 5) {
            System.out.println("Missing parameters!\n" +
                    "Usage: flink run <Jar.file> --input-topic <topic> " +
                    "--bootstrap.servers <kafka brokers>" +
                    "--zookeeper.connect <zk quorum> --group.id <some id>" +
                    "--auto.offset.reset <largest>");
            return;
        }*/

        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
//        env.getConfig().disableSysoutLogging();
        env.getConfig().setRestartStrategy(RestartStrategies.fixedDelayRestart(3, 20000));
        env.enableCheckpointing(60000);
//        env.getCheckpointConfig().enableExternalizedCheckpoints(CheckpointConfig.ExternalizedCheckpointCleanup.DELETE_ON_CANCELLATION);

        env.getConfig().setParallelism(parameterTool.getInt("flink.Parallelism"));
        env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);
        env.registerCachedFile(parameterTool.getRequired("name_label.filter.file"), "filter_file");

        env.getConfig().setGlobalJobParameters(parameterTool);


        DataStream<byte[]> input = env.addSource(new FlinkKafkaConsumer08<byte[]>(parameterTool.getRequired("input-topic"),
                new AppEventSchema(),
                parameterTool.getProperties()));

        SplitStream<FlinkAppObject> ParsedInput = input.flatMap(new FlatMapFunction<byte[], FlinkAppObject>() {
            @Override
            public void flatMap(byte[] bytes, Collector<FlinkAppObject> collector) throws Exception {
                parsedUtils parser = new parsedUtils();
                parser.parseKafka(bytes);
                for (Event event:
                        parser.app_event_records) {
                    try {
                        collector.collect(new FlinkAppObject(EventType.Event.id,(String)event.getDeviceId(),JSON.toJSONString(new FlinkEvent(event))));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                for (Install install:
                        parser.app_install_records) {
                    try {
                        collector.collect(new FlinkAppObject(EventType.Install.id,(String)install.getDeviceId(),JSON.toJSONString(new FlinkInstall(install))));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                for (Start start :
                        parser.app_start_records) {
                    try {
                        collector.collect(new FlinkAppObject(EventType.Start.id, (String) start.getDeviceId(), JSON.toJSONString(new FlinkStart(start))));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                for (Crash crash :
                        parser.app_crash_records) {
                    try {
                        collector.collect(new FlinkAppObject(EventType.Crash.id, (String) crash.getDeviceId(), JSON.toJSONString(new FlinkCrash(crash))));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                for (Close close:
                        parser.app_close_records) {
                    try {
                        collector.collect(new FlinkAppObject(EventType.Close.id, (String) close.getDeviceId(), JSON.toJSONString(new FlinkClose(close))));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                for (Session session:
                        parser.app_session_records) {
                    try {
                        collector.collect(new FlinkAppObject(EventType.Session.id, (String) session.getDeviceId(), JSON.toJSONString(new FlinkSession(session))));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                for (Page page :
                        parser.app_page_records) {
                    try {
                        collector.collect(new FlinkAppObject(EventType.Page.id, (String) page.getDeviceId(), JSON.toJSONString(new FlinkPage(page))));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }).split(new OutputSelector<FlinkAppObject>() {
            @Override
            public Iterable<String> select(FlinkAppObject flinkAppObject) {
                List<String> output = new ArrayList<String>();
                switch (flinkAppObject.id) {
                    case 0:
                        output.add("Install");
                        break;
                    case 1:
                        output.add("Start");
                        break;
                    case 2:
                        output.add("Close");
                        break;
                    case 3:
                        output.add("Session");
                        break;
                    case 4:
                        output.add("Page");
                        break;
                    case 5:
                        output.add("Event");
                        break;
                    case 6:
                        output.add("Crash");
                        break;
                    default:
                        output.add("Other");
                }
                return output;
            }
        });

        Properties properties = new Properties();
        properties.setProperty("bootstrap.servers", parameterTool.getRequired("dest.brokerList"));
        properties.setProperty("acks", parameterTool.getRequired("dest.acks"));
        properties.setProperty("compression.type", parameterTool.getRequired("dest.compression.type"));
        properties.setProperty("retries", parameterTool.getRequired("dest.retries"));
        properties.setProperty("metadata.fetch.timeout.ms", parameterTool.getRequired("dest.metadata.fetch.timeout.ms"));
        properties.setProperty("buffer.memory", parameterTool.getRequired("dest.buffer.memory"));
        properties.setProperty("batch.size", parameterTool.getRequired("dest.batch.size"));
        properties.setProperty("max.request.size", parameterTool.getRequired("dest.max.request.size"));
        properties.setProperty("linger.ms", parameterTool.getRequired("dest.linger.ms"));
//        properties.setProperty("out.ct.format", parameterTool.getRequired("out.ct.format"));
//        properties.setProperty("out.t", parameterTool.getRequired("out.t"));
//        properties.setProperty("out.id", parameterTool.getRequired("out.id"));


        DataStream<String> InstallDS = new AppWriteToKafka<FlinkAppObject>().run(
                ParsedInput, "Install",
                "vast.app_install",
                properties);

        DataStream<String> StartDS = new AppWriteToKafka<FlinkAppObject>().run(
                ParsedInput, "Start",
                "vast.app_start",
                properties);

        DataStream<String> CloseDS = new AppWriteToKafka<FlinkAppObject>().run(
                ParsedInput, "Close",
                "vast.app_close",
                properties);

        DataStream<String> SessionDS = new AppWriteToKafka<FlinkAppObject>().run(
                ParsedInput, "Session",
                "vast.app_session",
                properties);

        DataStream<String> PageDS = new AppWriteToKafka<FlinkAppObject>().run(
                ParsedInput, "Page",
                "vast.app_page",
                properties);

       /* DataStream<String> EventDS = new AppWriteToKafka<FlinkAppObject>().run(
                ParsedInput, "Event",
                "vast.app_event",
                properties);*/

        DataStream<String> CrashDS = new AppWriteToKafka<FlinkAppObject>().run(
                ParsedInput, "Crash",
                "vast.app_crash",
                properties);

       /* SingleOutputStreamOperator<String> EventDS = ParsedInput.select("Event").keyBy("device_id").process(new ProcessFunction<FlinkAppObject, String>() {
            @Override
            public void processElement(FlinkAppObject flinkAppObject, Context context, Collector<String> collector) throws Exception {
                collector.collect(flinkAppObject.json);
                FlinkEvent flinkEvent = null;
                try {
                    flinkEvent = JSON.parseObject(flinkAppObject.json, FlinkEvent.class);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (flinkEvent.name != null && !flinkEvent.name.equals("restIO") && !flinkEvent.name.equals("networkIO")) {
                    SideOutObject sideOutObject = null;
                    try {
                        SimplifyLog simplifyLog = SimplifyApp.simplify(flinkEvent);
                        sideOutObject = new SideOutObject(parameterTool.getRequired("out.ct"), parameterTool.getRequired("out.t"),
                                parameterTool.getRequired("out.id"), simplifyLog);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    context.output(outputTag, JSON.toJSONString(sideOutObject));
                }
//                context.output(outputTag,JSON.parseObject(flinkAppObject.json,FlinkEvent.class));
            }
        });*/
        OutputTag<String> outputTag = new OutputTag<String>("AppEvent_side_output"){};
        OutputTag<String> internalOutputTag = new OutputTag<String>("Internal_AppEvent_side_output"){};
        SingleOutputStreamOperator<String> EventDS = ParsedInput.select("Event").
                process(new SimplifyAppFunction());

        EventDS.addSink(new FlinkKafkaProducer08<String>(
                "vast.app_event", new SimpleStringSchema(), properties)).name("vast.app_event");

        if (parameterTool.getRequired("sideout.flag").toLowerCase().equals("true")) {
            DataStream<String> SideDS = EventDS.getSideOutput(outputTag);

            Properties sideoutPro = (Properties) properties.clone();
            sideoutPro.setProperty("bootstrap.servers", parameterTool.getRequired("sideout.dest.brokerList"));
            sideoutPro.setProperty("acks", parameterTool.getRequired("dest.acks"));
            sideoutPro.setProperty("compression.type", parameterTool.getRequired("dest.compression.type"));
            sideoutPro.setProperty("retries", parameterTool.getRequired("dest.retries"));
            sideoutPro.setProperty("metadata.fetch.timeout.ms", parameterTool.getRequired("dest.metadata.fetch.timeout.ms"));
            sideoutPro.setProperty("buffer.memory", parameterTool.getRequired("dest.buffer.memory"));
            sideoutPro.setProperty("batch.size", parameterTool.getRequired("dest.batch.size"));
            sideoutPro.setProperty("max.request.size", parameterTool.getRequired("dest.max.request.size"));
            sideoutPro.setProperty("linger.ms", parameterTool.getRequired("dest.linger.ms"));

            SideDS.addSink(new FlinkKafkaProducer08<String>(
                    parameterTool.getRequired("sideout.topic"), new SimpleStringSchema(), sideoutPro)).name("outer.vast.SimplifiedLogAppEvent");
        }

        //send to BigData's kafka
        if (parameterTool.getRequired("internal.sideout.flag").toLowerCase().equals("true")) {
            DataStream<String> internalSideDS = EventDS.getSideOutput(internalOutputTag);
            Properties internalSideoutPro = (Properties) properties.clone();
            internalSideoutPro.setProperty("bootstrap.servers", parameterTool.getRequired("dest.brokerList"));
            internalSideoutPro.setProperty("acks", "0");
            internalSideoutPro.setProperty("compression.type", parameterTool.getRequired("dest.compression.type"));
            internalSideoutPro.setProperty("metadata.fetch.timeout.ms", parameterTool.getRequired("dest.metadata.fetch.timeout.ms"));
            internalSideoutPro.setProperty("buffer.memory", parameterTool.getRequired("dest.buffer.memory"));
            internalSideoutPro.setProperty("batch.size", parameterTool.getRequired("dest.batch.size"));
            internalSideoutPro.setProperty("max.request.size", parameterTool.getRequired("dest.max.request.size"));
            internalSideoutPro.setProperty("linger.ms", parameterTool.getRequired("dest.linger.ms"));

            internalSideDS.addSink(new FlinkKafkaProducer08<String>(
                    parameterTool.getRequired("internal.sideout.topic"), new SimpleStringSchema(), internalSideoutPro)).name("internal.vast.SimplifiedLogAppEvent");
        }

        env.execute("Flink Kafka vast.App");
    }
}
