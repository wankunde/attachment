package com.pingan.flink;

import com.pingan.flink.pojo.FlinkAppObject;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SplitStream;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaProducer08;
import org.apache.flink.streaming.connectors.kafka.partitioner.FlinkKafkaPartitioner;

import java.util.Properties;

/**
 * Created by WANGYI422 on 2018/1/19.
 */
public class AppWriteToKafka<T extends FlinkAppObject> {
    public AppWriteToKafka() {
    }

    public DataStream<String> run(SplitStream<T> ParsedInput, String selectName,  String topicId, Properties properties ) {
        DataStream<T> dataStream = ParsedInput.select(selectName);
        FlinkKafkaProducer08<String> producer011 = new FlinkKafkaProducer08<String>(
                topicId, new SimpleStringSchema(), properties );
//        producer011.setWriteTimestampToKafka(true);
        DataStream<String> output = dataStream.map(new MapFunction<T, String>() {
            @Override
            public String map(T t) throws Exception {
                return t.json;
            }
        });
        output.addSink(producer011).name(selectName);
        return output;
    }
}
