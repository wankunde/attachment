package com.pingan.flink.pojo;

/**
 * Created by WANGYI422 on 2018/1/19.
 */
public class FlinkAppObject {
    public int id;
    public String device_id;
    public String json;

    public FlinkAppObject() {
    }

    public FlinkAppObject(int id, String device_id, String json) {
        this.id = id;
        this.device_id = device_id;
        this.json = json;
    }

}
