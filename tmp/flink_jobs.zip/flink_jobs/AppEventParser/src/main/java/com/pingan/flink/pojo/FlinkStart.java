package com.pingan.flink.pojo;

import com.paic.app.tracking.Start;

/**
 * Created by WANGYI422 on 2018/1/19.
 */
public class FlinkStart {
    public String app_version;
    public String device_model;
    public String os_name;
    public String os_version;
    public String app_key;
    public String app_type;
    public String device_id;
    public String partner_id;
    public String net_status;
    public String local_ip;
    public String session_id;
    public int index;
    public long start;
    public String device_name;
    public long ts;
    public String ip;

    public FlinkStart() {
    }

    public FlinkStart(Start start) {
        this.app_version = (String)start.getAppVersion();
        this.device_model = (String)start.getDeviceModel();
        this.os_name = (String)start.getOsName();
        this.os_version = (String)start.getOsVersion();
        this.app_key = (String)start.getAppKey();
        this.app_type = (String)start.getAppType();
        this.device_id = (String)start.getDeviceId();
        this.partner_id = (String)start.getPartnerId();
        this.net_status = (String)start.getNetStatus();
        this.local_ip = (String)start.getLocalIp();
        this.session_id = (String)start.getSessionId();
        this.index = start.getIndex();
        this.start = start.getStart();
        this.device_name = start.toString();
        this.ts = start.getTs();
        this.ip = (String)start.getIp();
    }

    public String getApp_version() {
        return app_version;
    }

    public String getDevice_model() {
        return device_model;
    }

    public String getOs_name() {
        return os_name;
    }

    public String getOs_version() {
        return os_version;
    }

    public String getApp_key() {
        return app_key;
    }

    public String getApp_type() {
        return app_type;
    }

    public String getDevice_id() {
        return device_id;
    }

    public String getPartner_id() {
        return partner_id;
    }

    public String getNet_status() {
        return net_status;
    }

    public String getLocal_ip() {
        return local_ip;
    }

    public String getSession_id() {
        return session_id;
    }

    public int getIndex() {
        return index;
    }

    public long getStart() {
        return start;
    }

    public String getDevice_name() {
        return device_name;
    }

    public long getTs() {
        return ts;
    }

    public String getIp() {
        return ip;
    }

    public void setApp_version(String app_version) {
        this.app_version = app_version;
    }

    public void setDevice_model(String device_model) {
        this.device_model = device_model;
    }

    public void setOs_name(String os_name) {
        this.os_name = os_name;
    }

    public void setOs_version(String os_version) {
        this.os_version = os_version;
    }

    public void setApp_key(String app_key) {
        this.app_key = app_key;
    }

    public void setApp_type(String app_type) {
        this.app_type = app_type;
    }

    public void setDevice_id(String device_id) {
        this.device_id = device_id;
    }

    public void setPartner_id(String partner_id) {
        this.partner_id = partner_id;
    }

    public void setNet_status(String net_status) {
        this.net_status = net_status;
    }

    public void setLocal_ip(String local_ip) {
        this.local_ip = local_ip;
    }

    public void setSession_id(String session_id) {
        this.session_id = session_id;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public void setStart(long start) {
        this.start = start;
    }

    public void setDevice_name(String device_name) {
        this.device_name = device_name;
    }

    public void setTs(long ts) {
        this.ts = ts;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }
}
