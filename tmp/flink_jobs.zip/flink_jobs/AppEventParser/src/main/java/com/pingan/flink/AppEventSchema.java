package com.pingan.flink;

import org.apache.flink.api.common.serialization.AbstractDeserializationSchema;

import java.io.IOException;

/**
 * Created by WANGYI422 on 2018/1/17.
 */
public class AppEventSchema<T> extends AbstractDeserializationSchema<byte[]> {
    @Override
    public byte[] deserialize(byte[] bytes) throws IOException {
        return bytes;
    }

}
