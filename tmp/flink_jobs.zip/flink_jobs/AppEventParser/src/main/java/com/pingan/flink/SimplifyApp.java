package com.pingan.flink;

import com.pingan.flink.pojo.AppSimplifyLog;
import com.pingan.flink.pojo.FlinkEvent;
import com.pingan.flink.pojo.SimplifyLog;
import org.slf4j.Logger;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by WANGYI422 on 2018/4/13.
 */
public class SimplifyApp {

    public static AppSimplifyLog simplify(FlinkEvent flinkEvent){
        String device_id = null;
        String userid = null;
        String cust_code = null;
        String session_id = null;
        String ip = null;
        String local_ip = null;
        String app_type = null;
        String app_version = null;
        String os_version = null;
        String model = null;
        String label = null;
        String name = null;
        String click_time = null;
        String receive_time = null;
        String end_time = null;
        long duration = 0;
        String aid = null;
        String sid = null;
        String ouid = null;
        String partner_id = null;
        String app_key = null;
        int index = 0;
        String net_status = null;
        Map<String, String> parameters = new HashMap<>();
        String source = "native";

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss+0800");

        device_id = flinkEvent.getDevice_id();
        userid = flinkEvent.getParameters().getOrDefault("userId", null);
        cust_code = flinkEvent.getParameters().getOrDefault("userCode", null);
        session_id = flinkEvent.getSession_id();
        ip = flinkEvent.getIp();
        local_ip = flinkEvent.getLocal_ip();
        app_type = flinkEvent.getApp_type().toLowerCase();
        app_version = flinkEvent.getApp_version();
        os_version = flinkEvent.getOs_version();
        model = flinkEvent.getDevice_model();
        label = flinkEvent.getLabel();
        name = flinkEvent.getName();
        click_time = sdf.format(new Date(flinkEvent.getStart()));
        receive_time = sdf.format(new Date(flinkEvent.getTs()));
        end_time = sdf.format(new Date(flinkEvent.getEnd()));
        duration = flinkEvent.getDuration();

        partner_id = flinkEvent.getPartner_id();
        String[] partners;
        if (partner_id.indexOf('-') != -1) {
            partners = partner_id.split("-");
            if (partners.length == 3) {
                aid = partners[0];
                sid = partners[1];
                ouid = partners[2];
            }
        } else {
            aid = partner_id;
            sid = null;
            ouid = null;
        }
        app_key = flinkEvent.getApp_key();
        index = flinkEvent.getIndex();
        net_status = flinkEvent.getNet_status();
        parameters = flinkEvent.getParameters();
        source = "native";

        return new AppSimplifyLog(device_id, userid, cust_code, session_id, ip, local_ip, app_type, app_version, os_version, model,
                label, name, click_time, receive_time, end_time, duration, aid, sid, ouid, partner_id, app_key, index, net_status,
                parameters, source);
    }

    public static List<String> readFilter(String localFile, Logger logger) throws IOException {
        File local = new File(localFile);
        List<String> filter = new ArrayList<String>();

        if (!local.exists()) {
            logger.error("Local file {} does not exists!", localFile);
            return null;
        }

        BufferedReader bufferedReader = new BufferedReader(new FileReader(local));
        String line = null;
        while ((line = bufferedReader.readLine()) != null) {
            filter.add(line);
        }
        return filter;
    }
}
