package com.pingan.flink.pojo;

/**
 * Created by WANGYI422 on 2018/4/13.
 */
public class SimplifyLog {
    public String userid ;
    public String usercode ;
    public String device_id ;
    public String ip ;
    public String app_type ;
    public String app_version ;
    public String os_version ;
    public String model ;
    public String label ;
    public String name ;
    public String referer ;
    public String click_time ;
    public long duration ;
    public String wt_sr ;
    public String source ;
    public String sd_sid ;
    public String visitorid ;
    public String visitid ;
    public String channel ;

    public SimplifyLog() {
    }

    public SimplifyLog(String userid, String usercode, String device_id, String ip, String app_type, String app_version, String os_version, String model, String label, String name, String referer, String click_time, long duration, String wt_sr, String source, String sd_sid, String visitorid, String visitid, String channel) {
        this.userid = userid;
        this.usercode = usercode;
        this.device_id = device_id;
        this.ip = ip;
        this.app_type = app_type;
        this.app_version = app_version;
        this.os_version = os_version;
        this.model = model;
        this.label = label;
        this.name = name;
        this.referer = referer;
        this.click_time = click_time;
        this.duration = duration;
        this.wt_sr = wt_sr;
        this.source = source;
        this.sd_sid = sd_sid;
        this.visitorid = visitorid;
        this.visitid = visitid;
        this.channel = channel;
    }

    public String getUserid() {
        return userid;
    }

    public String getUsercode() {
        return usercode;
    }

    public String getDevice_id() {
        return device_id;
    }

    public String getIp() {
        return ip;
    }

    public String getApp_type() {
        return app_type;
    }

    public String getApp_version() {
        return app_version;
    }

    public String getOs_version() {
        return os_version;
    }

    public String getModel() {
        return model;
    }

    public String getLabel() {
        return label;
    }

    public String getName() {
        return name;
    }

    public String getReferer() {
        return referer;
    }

    public String getClick_time() {
        return click_time;
    }

    public long getDuration() {
        return duration;
    }

    public String getWt_sr() {
        return wt_sr;
    }

    public String getSource() {
        return source;
    }

    public String getSd_sid() {
        return sd_sid;
    }

    public String getVisitorid() {
        return visitorid;
    }

    public String getVisitid() {
        return visitid;
    }

    public String getChannel() {
        return channel;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public void setUsercode(String usercode) {
        this.usercode = usercode;
    }

    public void setDevice_id(String device_id) {
        this.device_id = device_id;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public void setApp_type(String app_type) {
        this.app_type = app_type;
    }

    public void setApp_version(String app_version) {
        this.app_version = app_version;
    }

    public void setOs_version(String os_version) {
        this.os_version = os_version;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setReferer(String referer) {
        this.referer = referer;
    }

    public void setClick_time(String click_time) {
        this.click_time = click_time;
    }

    public void setDuration(long duration) {
        this.duration = duration;
    }

    public void setWt_sr(String wt_sr) {
        this.wt_sr = wt_sr;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public void setSd_sid(String sd_sid) {
        this.sd_sid = sd_sid;
    }

    public void setVisitorid(String visitorid) {
        this.visitorid = visitorid;
    }

    public void setVisitid(String visitid) {
        this.visitid = visitid;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }
}
