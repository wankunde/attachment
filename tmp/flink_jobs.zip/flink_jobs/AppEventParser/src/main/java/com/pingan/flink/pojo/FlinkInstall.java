package com.pingan.flink.pojo;

import com.paic.app.tracking.Install;

/**
 * Created by WANGYI422 on 2018/1/19.
 */
public class FlinkInstall {
    public String app_version;
    public String device_model;
    public String os_name;
    public String os_version;
    public String app_key;
    public String app_type;
    public String device_id;
    public String partner_id;
    public String net_status;
    public String local_ip;
    public String session_id;
    public int index;
    public long start;
    public long ts;
    public String ip;
    public String device_name;
    public String app_name;
    public boolean is_upgrade;
    public String package$;
    public String pixels;
    public String sdk_version;
    public Long cpu_cores;
    public Long cpu_frequency;
    public Long bus_frequency;
    public Long men_size;
    public Long disk_size;

    public FlinkInstall(){}

    public FlinkInstall(Install install) {
        this.app_version = (String)install.getAppVersion();
        this.device_model = (String)install.getDeviceModel();
        this.os_name = (String)install.getOsName();
        this.os_version = (String)install.getOsVersion();
        this.app_key = (String)install.getAppKey();
        this.app_type = (String)install.getAppType();
        this.device_id = (String)install.getDeviceId();
        this.partner_id = (String)install.getPartnerId();
        this.net_status = (String)install.getNetStatus();
        this.local_ip = (String)install.getLocalIp();
        this.session_id = (String)install.getSessionId();
        this.index = install.getIndex();
        this.start = install.getStart();
        this.ts = install.getTs();
        this.ip = (String)install.getIp();
        this.device_name = (String)install.getDeviceName();
        this.app_name = (String)install.getAppName();
        this.is_upgrade = install.getIsUpgrade();
        this.package$ = (String)install.getPackage$();
        this.pixels = (String)install.getPixels();
        this.sdk_version = (String)install.getSdkVersion();
        this.cpu_cores = install.getCpuCores();
        this.cpu_frequency = install.getCpuFrequency();
        this.bus_frequency = install.getBusFrequency();
        this.men_size = install.getMenSize();
        this.disk_size = install.getDiskSize();
    }

    public void setApp_version(String app_version) {
        this.app_version = app_version;
    }

    public void setDevice_model(String device_model) {
        this.device_model = device_model;
    }

    public void setOs_name(String os_name) {
        this.os_name = os_name;
    }

    public void setOs_version(String os_version) {
        this.os_version = os_version;
    }

    public void setApp_key(String app_key) {
        this.app_key = app_key;
    }

    public void setApp_type(String app_type) {
        this.app_type = app_type;
    }

    public void setDevice_id(String device_id) {
        this.device_id = device_id;
    }

    public void setPartner_id(String partner_id) {
        this.partner_id = partner_id;
    }

    public void setNet_status(String net_status) {
        this.net_status = net_status;
    }

    public void setLocal_ip(String local_ip) {
        this.local_ip = local_ip;
    }

    public void setSession_id(String session_id) {
        this.session_id = session_id;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public void setStart(long start) {
        this.start = start;
    }

    public void setTs(long ts) {
        this.ts = ts;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public void setDevice_name(String device_name) {
        this.device_name = device_name;
    }

    public void setApp_name(String app_name) {
        this.app_name = app_name;
    }

    public void setIs_upgrade(boolean is_upgrade) {
        this.is_upgrade = is_upgrade;
    }

    public void setPackage$(String package$) {
        this.package$ = package$;
    }

    public void setPixels(String pixels) {
        this.pixels = pixels;
    }

    public void setSdk_version(String sdk_version) {
        this.sdk_version = sdk_version;
    }

    public void setCpu_cores(Long cpu_cores) {
        this.cpu_cores = cpu_cores;
    }

    public void setCpu_frequency(Long cpu_frequency) {
        this.cpu_frequency = cpu_frequency;
    }

    public void setBus_frequency(Long bus_frequency) {
        this.bus_frequency = bus_frequency;
    }

    public void setMen_size(Long men_size) {
        this.men_size = men_size;
    }

    public void setDisk_size(Long disk_size) {
        this.disk_size = disk_size;
    }

    public String getApp_version() {
        return app_version;
    }

    public String getDevice_model() {
        return device_model;
    }

    public String getOs_name() {
        return os_name;
    }

    public String getOs_version() {
        return os_version;
    }

    public String getApp_key() {
        return app_key;
    }

    public String getApp_type() {
        return app_type;
    }

    public String getDevice_id() {
        return device_id;
    }

    public String getPartner_id() {
        return partner_id;
    }

    public String getNet_status() {
        return net_status;
    }

    public String getLocal_ip() {
        return local_ip;
    }

    public String getSession_id() {
        return session_id;
    }

    public int getIndex() {
        return index;
    }

    public long getStart() {
        return start;
    }

    public long getTs() {
        return ts;
    }

    public String getIp() {
        return ip;
    }

    public String getDevice_name() {
        return device_name;
    }

    public String getApp_name() {
        return app_name;
    }

    public boolean isIs_upgrade() {
        return is_upgrade;
    }

    public String getPackage$() {
        return package$;
    }

    public String getPixels() {
        return pixels;
    }

    public String getSdk_version() {
        return sdk_version;
    }

    public Long getCpu_cores() {
        return cpu_cores;
    }

    public Long getCpu_frequency() {
        return cpu_frequency;
    }

    public Long getBus_frequency() {
        return bus_frequency;
    }

    public Long getMen_size() {
        return men_size;
    }

    public Long getDisk_size() {
        return disk_size;
    }
}
