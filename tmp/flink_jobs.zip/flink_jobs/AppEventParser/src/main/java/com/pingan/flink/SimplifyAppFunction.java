package com.pingan.flink;

import com.alibaba.fastjson.JSON;
import com.pingan.flink.pojo.*;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;
import org.apache.flink.util.OutputTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by WANGYI422 on 2018/4/19.
 */
public class SimplifyAppFunction extends ProcessFunction<FlinkAppObject, String> {
    private Map<String, String> filter = new HashMap<>();
    private BufferedReader bufferedReader;
    private final Logger logger = LoggerFactory.getLogger(SimplifyAppFunction.class);
    private ParameterTool parameters;
    private OutputTag<String> outputTag = new OutputTag<String>("AppEvent_side_output"){};
    private OutputTag<String> internalOutputTag = new OutputTag<String>("Internal_AppEvent_side_output"){};
    private String flinkThreadHost;
    private Random random;
    private String threadName;
    private boolean dynamicConfigFlag = false;

    @Override
    public void open(Configuration parameters) throws Exception {
        flinkThreadHost = InetAddress.getLocalHost().getHostAddress().toString();
        random = new Random();
        threadName = String.valueOf(random.nextInt(Integer.MAX_VALUE));

        this.parameters = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
//        String localFile = parameters.getString("name_label.filter.file", "/tmp/simplifyApp.config");
        File local = getRuntimeContext().getDistributedCache().getFile("filter_file");

        if (!local.exists()) {
            logger.error("Local file {} does not exists!", local.getAbsolutePath());
            return ;
        }

        bufferedReader = new BufferedReader(new FileReader(local));
        String line = null;
        while ((line = bufferedReader.readLine()) != null) {
//            filter.add(line);
            if (line.indexOf(":") != -1) {
                String[] temp = line.split(":");
                filter.put(temp[0], temp[1]);
            }else {
                continue;
            }
        }
        bufferedReader.close();
    }

    @Override
    public void processElement(FlinkAppObject flinkAppObject, Context context, Collector<String> collector) throws Exception {
        String nameLabel = null;
        collector.collect(flinkAppObject.json);
        FlinkEvent flinkEvent = null;
        SimpleDateFormat sdf = new SimpleDateFormat(parameters.get("out.ct.format", "yyyyMMddHHmmss"));
        String ct = sdf.format(new Date());
        String t;

        if (ct.substring(ct.length() - 5, ct.length() - 2).equals("700") && !dynamicConfigFlag) {
            dynamicConfigFlag = true;
        }

        if (dynamicConfigFlag && !ct.substring(ct.length() - 5, ct.length() - 2).equals("700")) {
            dynamicConfigFlag = false;
            File configFile = new File(parameters.getRequired("name_label.filter.file"));

            if (!configFile.exists()) {
                logger.error("Local file {} does not exists!", configFile.getAbsolutePath());
            } else {
                bufferedReader = new BufferedReader(new FileReader(configFile));
                String line = null;
                while ((line = bufferedReader.readLine()) != null) {

                    if (line.indexOf(":") != -1) {
                        String[] temp = line.split(":");
                        filter.put(temp[0], temp[1]);
                    } else {
                        continue;
                    }
                }
                bufferedReader.close();
            }
        }


//        String t = parameters.get("out.t", "t");
//        String id = parameters.get("out.id", "id");
//        String id = UUID.randomUUID().toString();
        String id = flinkThreadHost + "_" + threadName +"_"+ System.currentTimeMillis() + "_"+random.nextInt(Integer.MAX_VALUE);

        try {
            flinkEvent = JSON.parseObject(flinkAppObject.json, FlinkEvent.class);
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            if (flinkEvent != null && flinkEvent.device_id != null && !flinkEvent.device_id.isEmpty() && flinkEvent.name != null && flinkEvent.label != null
                    && !flinkEvent.name.toLowerCase().equals("networkio") && !flinkEvent.name.toLowerCase().equals("restio")) {
                nameLabel = flinkEvent.name + "," + flinkEvent.label;

                t = filter.getOrDefault(nameLabel,"unknown");
                AppSideOutObject sideOutObject = null;
                AppInternalSideOutObject internalSideOutObject = null;

                try {
                    AppSimplifyLog simplifyLog = SimplifyApp.simplify(flinkEvent);
                    sideOutObject = new AppSideOutObject(ct, t, id, simplifyLog);
                    internalSideOutObject = new AppInternalSideOutObject(ct, t, id, simplifyLog);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (filter.containsKey("*,*") || filter.containsKey(nameLabel)) {
                    context.output(outputTag, JSON.toJSONString(sideOutObject));
                }
                context.output(internalOutputTag, JSON.toJSONString(internalSideOutObject));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

//                context.output(outputTag,JSON.parseObject(flinkAppObject.json,FlinkEvent.class));
    }
}
