package com.pingan.flink;

import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer08;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaProducer08;
import org.apache.flink.util.OutputTag;

import java.io.File;
import java.util.Properties;


/**
 * Created by WANGYI422 on 2018/2/5.
 */
public class Main {
    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            System.out.println("Missing parameters!\n" +
                    "Usage: flink run <Jar.file <properties>");
            return;
        }
        final ParameterTool parameterTool = ParameterTool.fromPropertiesFile(new File(args[0]));

        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.getConfig().setRestartStrategy(RestartStrategies.fixedDelayRestart(3, 10000));
        env.enableCheckpointing(10000);
        env.getConfig().setParallelism(parameterTool.getInt("flink.Parallelism"));
        env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);
        env.registerCachedFile(parameterTool.getRequired("name_label.filter.file"), "web_filter_file");

        env.getConfig().setGlobalJobParameters(parameterTool);


        DataStream<String> origin_webperf = env.addSource(new FlinkKafkaConsumer08<String>(parameterTool.getRequired("webperf-topic"),
                new SimpleStringSchema(),
                parameterTool.getProperties()));
        DataStream<String> origin_webtrends = env.addSource(new FlinkKafkaConsumer08<String>(parameterTool.getRequired("webtrends-topic"),
                new SimpleStringSchema(),
                parameterTool.getProperties()));
        DataStream<String> origin_webdata = env.addSource(new FlinkKafkaConsumer08<String>(parameterTool.getRequired("webdata-topic"),
                new SimpleStringSchema(),
                parameterTool.getProperties()));


        Properties properties = new Properties();
        properties.setProperty("bootstrap.servers", parameterTool.getRequired("dest.brokerList"));
        properties.setProperty("acks", parameterTool.getRequired("dest.acks"));
        properties.setProperty("compression.type", parameterTool.getRequired("dest.compression.type"));
        properties.setProperty("retries", parameterTool.getRequired("dest.retries"));
        properties.setProperty("metadata.fetch.timeout.ms", parameterTool.getRequired("dest.metadata.fetch.timeout.ms"));

//        properties.setProperty("out.ct.format", parameterTool.getRequired("out.ct.format"));
//        properties.setProperty("out.t", parameterTool.getRequired("out.t"));
//        properties.setProperty("out.id", parameterTool.getRequired("out.id"));


        FlinkKafkaProducer08<String> webperfSink = new FlinkKafkaProducer08<String>(
                parameterTool.getRequired("dest.webperf-topic"),
                new SimpleStringSchema(),
                properties
        );
        FlinkKafkaProducer08<String> webdataSink = new FlinkKafkaProducer08<String>(
                parameterTool.getRequired("dest.webdata-topic"),
                new SimpleStringSchema(),
                properties
        );
        FlinkKafkaProducer08<String> webtrendsSink = new FlinkKafkaProducer08<String>(
                parameterTool.getRequired("dest.webtrends-topic"),
                new SimpleStringSchema(),
                properties
        );

        OutputTag<String> outputTag = new OutputTag<String>("Web_side_output"){};
        SingleOutputStreamOperator<String> webtrendsDS = origin_webtrends.process(new SimplifyWebFunction());

        DataStream<String> SideDS = webtrendsDS.getSideOutput(outputTag);
        SideDS.addSink(new FlinkKafkaProducer08<String>(parameterTool.getRequired("sideout.topic")
                , new SimpleStringSchema(), properties)).
                name("vast.SimplifiedWebtrends");

        origin_webperf.addSink(webperfSink).name("webperf");
        webtrendsDS.addSink(webtrendsSink).name("webtrends");
        origin_webdata.addSink(webdataSink).name("webdata");

        env.execute("Flink Kafka vast.web");
    }
}
