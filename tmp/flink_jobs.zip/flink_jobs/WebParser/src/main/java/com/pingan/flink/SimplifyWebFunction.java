package com.pingan.flink;

import com.alibaba.fastjson.JSON;
import com.pingan.flink.pojo.*;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;
import org.apache.flink.util.OutputTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Created by WANGYI422 on 2018/4/19.
 */
public class SimplifyWebFunction extends ProcessFunction<String, String> {
    private Map<String, String> filter = new HashMap<>();
    private BufferedReader bufferedReader;
    private final Logger logger = LoggerFactory.getLogger(SimplifyWebFunction.class);
    private ParameterTool parameters;
    private OutputTag<String> outputTag = new OutputTag<String>("Web_side_output"){};

    @Override
    public void open(Configuration parameters) throws Exception {
        this.parameters = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
//        String localFile = parameters.getString("name_label.filter.file", "/tmp/simplifyApp.config");
        File local = getRuntimeContext().getDistributedCache().getFile("web_filter_file");

        if (!local.exists()) {
            logger.error("Local file {} does not exists!", local.getAbsolutePath());
            return ;
        }

        bufferedReader = new BufferedReader(new FileReader(local));
        String line = null;
        while ((line = bufferedReader.readLine()) != null) {
//            filter.add(line);
            filter.put(line,"v");
        }
        bufferedReader.close();
    }

    @Override
    public void processElement(String in, Context context, Collector<String> collector) throws Exception {
        String nameLabel = null;
        collector.collect(in);
        FlinkWebTrends flinkWebTrends = null;
        SimpleDateFormat sdf = new SimpleDateFormat(parameters.get("out.ct.format", "yyyyMMddHHmmss"));
        String ct = sdf.format(new Date());
        String t = parameters.get("out.t", "t");
//        String id = parameters.get("out.id", "id");
        String id = UUID.randomUUID().toString();

        try {
            flinkWebTrends = JSON.parseObject(in, FlinkWebTrends.class);
        } catch (Exception e) {
            System.err.println("1");
            e.printStackTrace();
        }

        try {
            if (flinkWebTrends != null && flinkWebTrends.app_device_id != null && !flinkWebTrends.app_device_id.isEmpty() &&
                    flinkWebTrends.wt_obj != null && flinkWebTrends.wt_ti != null) {

                nameLabel = flinkWebTrends.wt_obj + "," + flinkWebTrends.wt_ti;

                if (filter.containsKey("*,*") || filter.containsKey(nameLabel)) {
                    WebSideOutObject sideOutObject = null;
                    try {
                        WebSimplifyLog simplifyLog = SimplifyWeb.simplify(flinkWebTrends);
                        sideOutObject = new WebSideOutObject(ct, t, id, simplifyLog);
                    } catch (Exception e) {
                        System.err.println("2");
                        e.printStackTrace();
                    }
                    context.output(outputTag, JSON.toJSONString(sideOutObject));
                }
            }
        } catch (Exception e) {
            System.err.println("3");
            e.printStackTrace();
        }

//                context.output(outputTag,JSON.parseObject(flinkAppObject.json,FlinkEvent.class));
    }
}
