package com.pingan.flink;

import com.pingan.flink.pojo.FlinkWebTrends;

/**
 * Created by WANGYI422 on 2018/4/24.
 */
public interface Handler {
    String handle(FlinkWebTrends webTrends);
}
