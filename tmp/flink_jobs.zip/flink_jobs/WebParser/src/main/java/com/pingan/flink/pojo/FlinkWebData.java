package com.pingan.flink.pojo;

import java.util.Map;

/**
 * Created by WANGYI422 on 2018/2/5.
 */
public class FlinkWebData {
    public String wt_id;
    public String sd_uid;
    public String sd_sid;
    public String host;
    public String referer;
    public String user_agent;
    public String app_device_id;
    public String app_type;
    public String app_version;
    public String remote_ip;
    public long recv_time;
    public String module_name;
    public long local_time;
    public String log_level;
    public String action;
    public java.lang.Integer total;
    public java.util.Map<String,String> paramsIn;
    public java.util.Map<String,String> paramsOut;
    public java.util.Map<String,String> info;
    public String TuffyVersionIds;
    public java.util.Map<String,String> otherParams;

    public String getWt_id() {
        return wt_id;
    }

    public String getSd_uid() {
        return sd_uid;
    }

    public String getSd_sid() {
        return sd_sid;
    }

    public String getHost() {
        return host;
    }

    public String getReferer() {
        return referer;
    }

    public String getUser_agent() {
        return user_agent;
    }

    public String getApp_device_id() {
        return app_device_id;
    }

    public String getApp_type() {
        return app_type;
    }

    public String getApp_version() {
        return app_version;
    }

    public String getRemote_ip() {
        return remote_ip;
    }

    public long getRecv_time() {
        return recv_time;
    }

    public String getModule_name() {
        return module_name;
    }

    public long getLocal_time() {
        return local_time;
    }

    public String getLog_level() {
        return log_level;
    }

    public String getAction() {
        return action;
    }

    public Integer getTotal() {
        return total;
    }

    public Map<String, String> getParamsIn() {
        return paramsIn;
    }

    public Map<String, String> getParamsOut() {
        return paramsOut;
    }

    public Map<String, String> getInfo() {
        return info;
    }

    public String getTuffyVersionIds() {
        return TuffyVersionIds;
    }

    public Map<String, String> getOtherParams() {
        return otherParams;
    }

    public void setWt_id(String wt_id) {
        this.wt_id = wt_id;
    }

    public void setSd_uid(String sd_uid) {
        this.sd_uid = sd_uid;
    }

    public void setSd_sid(String sd_sid) {
        this.sd_sid = sd_sid;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public void setReferer(String referer) {
        this.referer = referer;
    }

    public void setUser_agent(String user_agent) {
        this.user_agent = user_agent;
    }

    public void setApp_device_id(String app_device_id) {
        this.app_device_id = app_device_id;
    }

    public void setApp_type(String app_type) {
        this.app_type = app_type;
    }

    public void setApp_version(String app_version) {
        this.app_version = app_version;
    }

    public void setRemote_ip(String remote_ip) {
        this.remote_ip = remote_ip;
    }

    public void setRecv_time(long recv_time) {
        this.recv_time = recv_time;
    }

    public void setModule_name(String module_name) {
        this.module_name = module_name;
    }

    public void setLocal_time(long local_time) {
        this.local_time = local_time;
    }

    public void setLog_level(String log_level) {
        this.log_level = log_level;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public void setParamsIn(Map<String, String> paramsIn) {
        this.paramsIn = paramsIn;
    }

    public void setParamsOut(Map<String, String> paramsOut) {
        this.paramsOut = paramsOut;
    }

    public void setInfo(Map<String, String> info) {
        this.info = info;
    }

    public void setTuffyVersionIds(String tuffyVersionIds) {
        TuffyVersionIds = tuffyVersionIds;
    }

    public void setOtherParams(Map<String, String> otherParams) {
        this.otherParams = otherParams;
    }
}
