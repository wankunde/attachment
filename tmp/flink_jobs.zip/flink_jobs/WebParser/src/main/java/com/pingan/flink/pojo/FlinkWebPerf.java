package com.pingan.flink.pojo;

import java.util.Map;

/**
 * Created by WANGYI422 on 2018/2/5.
 */
public class FlinkWebPerf {
    public String wt_id;
    public String sd_uid;
    public String sd_sid;
    public String host;
    public String referer;
    public String user_agent;
    public String app_device_id;
    public String app_type;
    public String app_version;
    public String remote_ip;
    public long recv_time;
    public String page;
    public String action;
    public String log_type;
    public int on_load;
    public int redirect;
    public int appcache;
    public int dns;
    public int tcp;
    public int request;
    public int response;
    public int processing;
    public int total;
    public String descr;
    public long start_time;
    public String TuffyVersionIds;
    public java.util.Map<String,String> otherParams;

    public FlinkWebPerf() {
    }

    public void setWt_id(String wt_id) {
        this.wt_id = wt_id;
    }

    public void setSd_uid(String sd_uid) {
        this.sd_uid = sd_uid;
    }

    public void setSd_sid(String sd_sid) {
        this.sd_sid = sd_sid;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public void setReferer(String referer) {
        this.referer = referer;
    }

    public void setUser_agent(String user_agent) {
        this.user_agent = user_agent;
    }

    public void setApp_device_id(String app_device_id) {
        this.app_device_id = app_device_id;
    }

    public void setApp_type(String app_type) {
        this.app_type = app_type;
    }

    public void setApp_version(String app_version) {
        this.app_version = app_version;
    }

    public void setRemote_ip(String remote_ip) {
        this.remote_ip = remote_ip;
    }

    public void setRecv_time(long recv_time) {
        this.recv_time = recv_time;
    }

    public void setPage(String page) {
        this.page = page;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public void setLog_type(String log_type) {
        this.log_type = log_type;
    }

    public void setOn_load(int on_load) {
        this.on_load = on_load;
    }

    public void setRedirect(int redirect) {
        this.redirect = redirect;
    }

    public void setAppcache(int appcache) {
        this.appcache = appcache;
    }

    public void setDns(int dns) {
        this.dns = dns;
    }

    public void setTcp(int tcp) {
        this.tcp = tcp;
    }

    public void setRequest(int request) {
        this.request = request;
    }

    public void setResponse(int response) {
        this.response = response;
    }

    public void setProcessing(int processing) {
        this.processing = processing;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public void setDescr(String descr) {
        this.descr = descr;
    }

    public void setStart_time(long start_time) {
        this.start_time = start_time;
    }

    public void setTuffyVersionIds(String tuffyVersionIds) {
        TuffyVersionIds = tuffyVersionIds;
    }

    public void setOtherParams(Map<String, String> otherParams) {
        this.otherParams = otherParams;
    }

    public String getWt_id() {
        return wt_id;
    }

    public String getSd_uid() {
        return sd_uid;
    }

    public String getSd_sid() {
        return sd_sid;
    }

    public String getHost() {
        return host;
    }

    public String getReferer() {
        return referer;
    }

    public String getUser_agent() {
        return user_agent;
    }

    public String getApp_device_id() {
        return app_device_id;
    }

    public String getApp_type() {
        return app_type;
    }

    public String getApp_version() {
        return app_version;
    }

    public String getRemote_ip() {
        return remote_ip;
    }

    public long getRecv_time() {
        return recv_time;
    }

    public String getPage() {
        return page;
    }

    public String getAction() {
        return action;
    }

    public String getLog_type() {
        return log_type;
    }

    public int getOn_load() {
        return on_load;
    }

    public int getRedirect() {
        return redirect;
    }

    public int getAppcache() {
        return appcache;
    }

    public int getDns() {
        return dns;
    }

    public int getTcp() {
        return tcp;
    }

    public int getRequest() {
        return request;
    }

    public int getResponse() {
        return response;
    }

    public int getProcessing() {
        return processing;
    }

    public int getTotal() {
        return total;
    }

    public String getDescr() {
        return descr;
    }

    public long getStart_time() {
        return start_time;
    }

    public String getTuffyVersionIds() {
        return TuffyVersionIds;
    }

    public Map<String, String> getOtherParams() {
        return otherParams;
    }
}
