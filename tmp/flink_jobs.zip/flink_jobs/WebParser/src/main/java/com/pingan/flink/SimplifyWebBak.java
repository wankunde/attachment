package com.pingan.flink;

import com.pingan.flink.pojo.FlinkWebTrends;
import com.pingan.flink.pojo.SimplifyLog;
import org.slf4j.Logger;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by WANGYI422 on 2018/4/13.
 */
public class SimplifyWebBak {

    public static SimplifyLog simplify(FlinkWebTrends flinkWebTrends){
        String userid = null;
        String usercode = null;
        String device_id ;
        String ip ;
        String app_type ;
        String app_version ;
        String os_version = null;
        String model = null;
        String label ;
        String name ;
        String referer ;
        String click_time ;
        long duration = 0 ;
        String wt_sr ;
        String source = "h5";
        String sd_sid ;
        String visitorid ;
        String visitid ;
        String channel = null;

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");

        String device_id_temp = flinkWebTrends.getApp_device_id();
        if (device_id_temp != null && device_id_temp.length() > 7) {
            device_id = device_id_temp.substring(0, device_id_temp.length() - 7);
        } else {
            device_id = device_id_temp;
        }
        ip = flinkWebTrends.getRemote_ip();
        app_type = flinkWebTrends.getApp_type();
        app_version = flinkWebTrends.getApp_version();
        String model_temp = flinkWebTrends.getUser_agent();
        if (model_temp != null && model_temp.contains("(iPhone;")) {
            model = "IPHONE";
        } else {
            if (model_temp != null && model_temp.indexOf("Build/") != -1) {
                model_temp = model_temp.substring(0, model_temp.indexOf("Build/"));
                if (model_temp.lastIndexOf(';') != -1) {
                    model = model_temp.substring(model_temp.lastIndexOf(';')+1).trim();
                }
            } else {
                model = model_temp;
            }
        }
        label = flinkWebTrends.getWt_ti();
        name = flinkWebTrends.getWt_obj();
        referer = flinkWebTrends.getReferer();
        click_time = sdf.format(new Date(flinkWebTrends.getRecv_time()));
        wt_sr = flinkWebTrends.getWt_sr();
        sd_sid = flinkWebTrends.getSd_sid();
        visitorid = flinkWebTrends.getOtherParams().getOrDefault("WT.vtid", null);
        visitid = dt.format(new Date()) + '_' + flinkWebTrends.getOtherParams().getOrDefault("WT.vtid", "") + '_' + flinkWebTrends.getWt_vt_num();

        Map<Integer, Handler> channelMap = channelMap();
        for (Map.Entry<Integer, Handler> entry :
                channelMap.entrySet()) {
            channel = entry.getValue().handle(flinkWebTrends);
            if (channel != null) {
                break;
            }
        }

        return new SimplifyLog(userid, usercode, device_id, ip, app_type, app_version, os_version, model, label, name, referer, click_time, duration, wt_sr, source, sd_sid, visitorid, visitid, channel);
    }

    public static Map<Integer, Handler> channelMap() {
        Map<Integer, Handler> result = new LinkedHashMap<>();
        int key = 1;

        result.put(key, new Handler() {
            @Override
            public String handle(FlinkWebTrends webTrends) {
                String obj = webTrends.getOtherParams().getOrDefault("sdcAgent", null);
                String res = null;
                if (obj != null && obj.toLowerCase().contains("aneapp")) {
                    res = "证券APP";
                }
                return res;
            }
        });
        key++;
        result.put(key, new Handler() {
            @Override
            public String handle(FlinkWebTrends webTrends) {
                String obj = webTrends.getOtherParams().getOrDefault("sdcAgent", null);
                String res = null;
                if (obj != null && obj.toLowerCase().contains("weixin")) {
                    res = "微信";
                }
                return res;
            }
        });
        key++;
        result.put(key, new Handler() {
            @Override
            public String handle(FlinkWebTrends webTrends) {
                String obj = webTrends.getOtherParams().getOrDefault("sdcSubagent", null);
                String res = null;
                if (obj != null && (obj.toLowerCase().contains("dazhihui") || obj.toLowerCase().contains("tdx-jiin") ||
                        obj.toLowerCase().contains("tdx-lccp") || obj.toLowerCase().contains("tdx-lcsc") ||
                        obj.toLowerCase().contains("rym") || obj.toLowerCase().contains("xyk") ||
                        obj.toLowerCase().contains("lujinsuo"))) {
                    res = "外部合作平台";
                }
                return res;
            }
        });
        key++;
        result.put(key, new Handler() {
            @Override
            public String handle(FlinkWebTrends webTrends) {
                String obj = webTrends.getOtherParams().getOrDefault("sdcPlatform", null);
                String res = null;
                if (obj != null && obj.toLowerCase().contains("pc")) {
                    res = "WEB";
                }
                return res;
            }
        });
        key++;
        result.put(key, new Handler() {
            @Override
            public String handle(FlinkWebTrends webTrends) {
                String obj = webTrends.getOtherParams().getOrDefault("sdcPlatform", null);
                String res = null;
                if (obj != null && (obj.toLowerCase().contains("android") || obj.toLowerCase().contains("ipad") || obj.toLowerCase().contains("iphone"))) {
                    res = "WAP";
                }
                return res;
            }
        });
        key++;
        result.put(key, new Handler() {
            @Override
            public String handle(FlinkWebTrends webTrends) {
                return "其他";
            }
        });

        return result;
    }

    public static List<String> readFilter(String localFile, Logger logger) throws IOException {
        File local = new File(localFile);
        List<String> filter = new ArrayList<String>();

        if (!local.exists()) {
            logger.error("Local file {} does not exists!", localFile);
            return null;
        }

        BufferedReader bufferedReader = new BufferedReader(new FileReader(local));
        String line = null;
        while ((line = bufferedReader.readLine()) != null) {
            filter.add(line);
        }
        return filter;
    }

    /*public static void main(String[] args) {
        FlinkWebTrends webTrends = new FlinkWebTrends();
        webTrends.setRecv_time(System.currentTimeMillis());
        Map<String, String> map = new HashMap<>();
        map.put("sdcAgent", "aneapp_6.9.1.0");
        webTrends.setOtherParams(map);
        System.out.println(simplify(webTrends).channel);

        String channel = null;

        Map<Integer, Handler> channelMap = channelMap();
        for (Map.Entry<Integer, Handler> entry :
                channelMap.entrySet()) {
            channel = entry.getValue().handle(webTrends);
            if (channel != null) {
                break;
            }
        }
        System.out.println(channel);

        map.put("sdcAgent", "weixin");
        webTrends.setOtherParams(map);
        for (Map.Entry<Integer, Handler> entry :
                channelMap.entrySet()) {
            channel = entry.getValue().handle(webTrends);
            if (channel != null) {
                break;
            }
        }
        System.out.println(channel);

        map.put("sdcAgent", "xxx");
        map.put("sdcSubagent", "app-grzx-lczc");
        webTrends.setOtherParams(map);
        for (Map.Entry<Integer, Handler> entry :
                channelMap.entrySet()) {
            channel = entry.getValue().handle(webTrends);
            if (channel != null) {
                break;
            }
        }
        System.out.println(channel);

        map.put("sdcAgent", "xxx");
        map.put("sdcSubagent", "lujinsuo");
        webTrends.setOtherParams(map);
        for (Map.Entry<Integer, Handler> entry :
                channelMap.entrySet()) {
            channel = entry.getValue().handle(webTrends);
            if (channel != null) {
                break;
            }
        }
        System.out.println(channel);

        map.put("sdcAgent", "xxx");
        map.put("sdcSubagent", "app-grzx-lczc");
        map.put("sdcPlatform", "pc");
        webTrends.setOtherParams(map);
        for (Map.Entry<Integer, Handler> entry :
                channelMap.entrySet()) {
            channel = entry.getValue().handle(webTrends);
            if (channel != null) {
                break;
            }
        }
        System.out.println(channel);

        map.put("sdcAgent", "xxx");
        map.put("sdcSubagent", "app-grzx-lczc");
        map.put("sdcPlatform", "android");
        webTrends.setOtherParams(map);
        for (Map.Entry<Integer, Handler> entry :
                channelMap.entrySet()) {
            channel = entry.getValue().handle(webTrends);
            if (channel != null) {
                break;
            }
        }
        System.out.println(channel);

    }*/
}
