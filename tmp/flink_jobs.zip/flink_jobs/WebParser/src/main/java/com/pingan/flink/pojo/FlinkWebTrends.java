package com.pingan.flink.pojo;

import java.util.Map;

/**
 * Created by WANGYI422 on 2018/2/5.
 */
public class FlinkWebTrends {
    public String wt_id;
    public String sd_uid;
    public String sd_sid;
    public String host;
    public String referer;
    public String user_agent;
    public String app_device_id;
    public String app_type;
    public String app_version;
    public String remote_ip;
    public long recv_time;
    public String SFSAgreement;
    public String dcsdat;
    public String dcsqry;
    public String dcsref;
    public String dcssip;
    public String dcsuri;
    public String hasMainThirdFlag;
    public String platform;
    public String wt_click;
    public String wt_bh;
    public String wt_bs;
    public String wt_cd;
    public String wt_ct;
    public String wt_dat;
    public String wt_dl;
    public String wt_es;
    public String wt_fv;
    public String wt_hp;
    public String wt_jo;
    public String wt_js;
    public String wt_jv;
    public String wt_le;
    public String wt_obj;
    public String wt_pa_cgn;
    public String wt_pa_cgs;
    public String wt_pa_dom;
    public String wt_pa_ref;
    public String wt_pagetitle;
    public String wt_pageurl;
    public String wt_pv_num;
    public String wt_re_cgn;
    public String wt_re_cgs;
    public String wt_slv;
    public String wt_sr;
    public String wt_ssl;
    public String wt_ti;
    public String wt_tz;
    public String wt_ul;
    public String wt_vt_f;
    public String wt_vt_f_a;
    public String wt_vt_num;
    public String wt_num;
    public String TuffyVersionIds;
    public java.util.Map<String,String> otherParams;
    public String wt_unionid;
    public String wt_data;
    public java.util.Map<String,String> cookie;

    public FlinkWebTrends(){}

    public String getWt_id() {
        return wt_id;
    }

    public String getSd_uid() {
        return sd_uid;
    }

    public String getSd_sid() {
        return sd_sid;
    }

    public String getHost() {
        return host;
    }

    public String getReferer() {
        return referer;
    }

    public String getUser_agent() {
        return user_agent;
    }

    public String getApp_device_id() {
        return app_device_id;
    }

    public String getApp_type() {
        return app_type;
    }

    public String getApp_version() {
        return app_version;
    }

    public String getRemote_ip() {
        return remote_ip;
    }

    public long getRecv_time() {
        return recv_time;
    }

    public String getSFSAgreement() {
        return SFSAgreement;
    }

    public String getDcsdat() {
        return dcsdat;
    }

    public String getDcsqry() {
        return dcsqry;
    }

    public String getDcsref() {
        return dcsref;
    }

    public String getDcssip() {
        return dcssip;
    }

    public String getDcsuri() {
        return dcsuri;
    }

    public String getHasMainThirdFlag() {
        return hasMainThirdFlag;
    }

    public String getPlatform() {
        return platform;
    }

    public String getWt_click() {
        return wt_click;
    }

    public String getWt_bh() {
        return wt_bh;
    }

    public String getWt_bs() {
        return wt_bs;
    }

    public String getWt_cd() {
        return wt_cd;
    }

    public String getWt_ct() {
        return wt_ct;
    }

    public String getWt_dat() {
        return wt_dat;
    }

    public String getWt_dl() {
        return wt_dl;
    }

    public String getWt_es() {
        return wt_es;
    }

    public String getWt_fv() {
        return wt_fv;
    }

    public String getWt_hp() {
        return wt_hp;
    }

    public String getWt_jo() {
        return wt_jo;
    }

    public String getWt_js() {
        return wt_js;
    }

    public String getWt_jv() {
        return wt_jv;
    }

    public String getWt_le() {
        return wt_le;
    }

    public String getWt_obj() {
        return wt_obj;
    }

    public String getWt_pa_cgn() {
        return wt_pa_cgn;
    }

    public String getWt_pa_cgs() {
        return wt_pa_cgs;
    }

    public String getWt_pa_dom() {
        return wt_pa_dom;
    }

    public String getWt_pa_ref() {
        return wt_pa_ref;
    }

    public String getWt_pagetitle() {
        return wt_pagetitle;
    }

    public String getWt_pageurl() {
        return wt_pageurl;
    }

    public String getWt_pv_num() {
        return wt_pv_num;
    }

    public String getWt_re_cgn() {
        return wt_re_cgn;
    }

    public String getWt_re_cgs() {
        return wt_re_cgs;
    }

    public String getWt_slv() {
        return wt_slv;
    }

    public String getWt_sr() {
        return wt_sr;
    }

    public String getWt_ssl() {
        return wt_ssl;
    }

    public String getWt_ti() {
        return wt_ti;
    }

    public String getWt_tz() {
        return wt_tz;
    }

    public String getWt_ul() {
        return wt_ul;
    }

    public String getWt_vt_f() {
        return wt_vt_f;
    }

    public String getWt_vt_f_a() {
        return wt_vt_f_a;
    }

    public String getWt_vt_num() {
        return wt_vt_num;
    }

    public String getWt_num() {
        return wt_num;
    }

    public String getTuffyVersionIds() {
        return TuffyVersionIds;
    }

    public Map<String, String> getOtherParams() {
        return otherParams;
    }

    public String getWt_unionid() {
        return wt_unionid;
    }

    public String getWt_data() {
        return wt_data;
    }

    public Map<String, String> getCookie() {
        return cookie;
    }

    public void setWt_id(String wt_id) {
        this.wt_id = wt_id;
    }

    public void setSd_uid(String sd_uid) {
        this.sd_uid = sd_uid;
    }

    public void setSd_sid(String sd_sid) {
        this.sd_sid = sd_sid;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public void setReferer(String referer) {
        this.referer = referer;
    }

    public void setUser_agent(String user_agent) {
        this.user_agent = user_agent;
    }

    public void setApp_device_id(String app_device_id) {
        this.app_device_id = app_device_id;
    }

    public void setApp_type(String app_type) {
        this.app_type = app_type;
    }

    public void setApp_version(String app_version) {
        this.app_version = app_version;
    }

    public void setRemote_ip(String remote_ip) {
        this.remote_ip = remote_ip;
    }

    public void setRecv_time(long recv_time) {
        this.recv_time = recv_time;
    }

    public void setSFSAgreement(String SFSAgreement) {
        this.SFSAgreement = SFSAgreement;
    }

    public void setDcsdat(String dcsdat) {
        this.dcsdat = dcsdat;
    }

    public void setDcsqry(String dcsqry) {
        this.dcsqry = dcsqry;
    }

    public void setDcsref(String dcsref) {
        this.dcsref = dcsref;
    }

    public void setDcssip(String dcssip) {
        this.dcssip = dcssip;
    }

    public void setDcsuri(String dcsuri) {
        this.dcsuri = dcsuri;
    }

    public void setHasMainThirdFlag(String hasMainThirdFlag) {
        this.hasMainThirdFlag = hasMainThirdFlag;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public void setWt_click(String wt_click) {
        this.wt_click = wt_click;
    }

    public void setWt_bh(String wt_bh) {
        this.wt_bh = wt_bh;
    }

    public void setWt_bs(String wt_bs) {
        this.wt_bs = wt_bs;
    }

    public void setWt_cd(String wt_cd) {
        this.wt_cd = wt_cd;
    }

    public void setWt_ct(String wt_ct) {
        this.wt_ct = wt_ct;
    }

    public void setWt_dat(String wt_dat) {
        this.wt_dat = wt_dat;
    }

    public void setWt_dl(String wt_dl) {
        this.wt_dl = wt_dl;
    }

    public void setWt_es(String wt_es) {
        this.wt_es = wt_es;
    }

    public void setWt_fv(String wt_fv) {
        this.wt_fv = wt_fv;
    }

    public void setWt_hp(String wt_hp) {
        this.wt_hp = wt_hp;
    }

    public void setWt_jo(String wt_jo) {
        this.wt_jo = wt_jo;
    }

    public void setWt_js(String wt_js) {
        this.wt_js = wt_js;
    }

    public void setWt_jv(String wt_jv) {
        this.wt_jv = wt_jv;
    }

    public void setWt_le(String wt_le) {
        this.wt_le = wt_le;
    }

    public void setWt_obj(String wt_obj) {
        this.wt_obj = wt_obj;
    }

    public void setWt_pa_cgn(String wt_pa_cgn) {
        this.wt_pa_cgn = wt_pa_cgn;
    }

    public void setWt_pa_cgs(String wt_pa_cgs) {
        this.wt_pa_cgs = wt_pa_cgs;
    }

    public void setWt_pa_dom(String wt_pa_dom) {
        this.wt_pa_dom = wt_pa_dom;
    }

    public void setWt_pa_ref(String wt_pa_ref) {
        this.wt_pa_ref = wt_pa_ref;
    }

    public void setWt_pagetitle(String wt_pagetitle) {
        this.wt_pagetitle = wt_pagetitle;
    }

    public void setWt_pageurl(String wt_pageurl) {
        this.wt_pageurl = wt_pageurl;
    }

    public void setWt_pv_num(String wt_pv_num) {
        this.wt_pv_num = wt_pv_num;
    }

    public void setWt_re_cgn(String wt_re_cgn) {
        this.wt_re_cgn = wt_re_cgn;
    }

    public void setWt_re_cgs(String wt_re_cgs) {
        this.wt_re_cgs = wt_re_cgs;
    }

    public void setWt_slv(String wt_slv) {
        this.wt_slv = wt_slv;
    }

    public void setWt_sr(String wt_sr) {
        this.wt_sr = wt_sr;
    }

    public void setWt_ssl(String wt_ssl) {
        this.wt_ssl = wt_ssl;
    }

    public void setWt_ti(String wt_ti) {
        this.wt_ti = wt_ti;
    }

    public void setWt_tz(String wt_tz) {
        this.wt_tz = wt_tz;
    }

    public void setWt_ul(String wt_ul) {
        this.wt_ul = wt_ul;
    }

    public void setWt_vt_f(String wt_vt_f) {
        this.wt_vt_f = wt_vt_f;
    }

    public void setWt_vt_f_a(String wt_vt_f_a) {
        this.wt_vt_f_a = wt_vt_f_a;
    }

    public void setWt_vt_num(String wt_vt_num) {
        this.wt_vt_num = wt_vt_num;
    }

    public void setWt_num(String wt_num) {
        this.wt_num = wt_num;
    }

    public void setTuffyVersionIds(String tuffyVersionIds) {
        TuffyVersionIds = tuffyVersionIds;
    }

    public void setOtherParams(Map<String, String> otherParams) {
        this.otherParams = otherParams;
    }

    public void setWt_unionid(String wt_unionid) {
        this.wt_unionid = wt_unionid;
    }

    public void setWt_data(String wt_data) {
        this.wt_data = wt_data;
    }

    public void setCookie(Map<String, String> cookie) {
        this.cookie = cookie;
    }
}
