package com.pingan.flink;

import com.pingan.flink.pojo.FlinkWebTrends;
import com.pingan.flink.pojo.WebSimplifyLog;
import org.slf4j.Logger;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by WANGYI422 on 2018/4/13.
 */
public class SimplifyWeb {

    public static WebSimplifyLog simplify(FlinkWebTrends flinkWebTrends){
        String device_id  = null;
        String wt_id = null;
        String sd_uid = null;
        String sd_sid = null;
        String visitorid = null;
        String wt_unionid = null;
        String omm_session_id = null;
        String ip = null;
        String app_type = null;
        String app_version = null;
        String model = null;
        String label = null;
        String name = null;
        String referer = null;
        String host = null;
        String page_url = null;
        String query_mcid = null;
        String query_inner_entry = null;
        String query_inner_media = null;
        String query_pid = null;
        String query_shid = null;
        String query_adid = null;
        String query_aid = null;
        String query_sid = null;
        String query_ouid = null;
        String query_id = null;
        String query_infid = null;
        String query_t = null;
        String query_innerchannel = null;
        String wt_sys = null;
        String dcsref = null;
        String dcshost = null;
        String keyword = null;
        String click_time = null;
        String recv_time = null;
        String channel = null;
        String platform = null;
        String user_agent = null;
        Map<String,String> otherparams = null;
        String wt_click = null;
        String wt_bh = null;
        String wt_bs = null;
        String wt_cd = null;
        String wt_ct = null;
        String wt_dat = null;
        String wt_dl = null;
        String wt_es = null;
        String wt_fv = null;
        String wt_hp = null;
        String wt_jo = null;
        String wt_js = null;
        String wt_jv = null;
        String wt_le = null;
        String wt_pa_cgn = null;
        String wt_pa_cgs = null;
        String wt_pa_dom = null;
        String wt_pa_ref = null;
        String wt_pagetitle = null;
        String wt_pageurl = null;
        String wt_pv_num = null;
        String wt_re_cgn = null;
        String wt_re_cgs = null;
        String wt_slv = null;
        String wt_sr = null;
        String wt_ssl = null;
        String wt_tz = null;
        String wt_ul = null;
        String wt_vt_f = null;
        String wt_vt_f_a = null;
        String wt_vt_num = null;
        String wt_num = null;
        String tuffyversionids = null;
        String source = "h5";

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");

        String device_id_temp = flinkWebTrends.getApp_device_id();
        if (device_id_temp != null && device_id_temp.length() > 7) {
            device_id = device_id_temp.substring(0, device_id_temp.length() - 7);
        } else {
            device_id = device_id_temp;
        }
        wt_id = flinkWebTrends.getWt_id();
        sd_uid = flinkWebTrends.getSd_uid();
        sd_sid = flinkWebTrends.getSd_sid();
        visitorid = flinkWebTrends.getOtherParams().getOrDefault("WT.vtid", null);
        wt_unionid = flinkWebTrends.getWt_unionid();
        omm_session_id = flinkWebTrends.getOtherParams().getOrDefault("PHONEX_OMM_INTF_ESB_TICKET", null);
        ip = flinkWebTrends.getRemote_ip();
        app_type = flinkWebTrends.getApp_type();
        app_version = flinkWebTrends.getApp_version();
        String model_temp = flinkWebTrends.getUser_agent();
        if (model_temp != null && model_temp.contains("(iPhone;")) {
            model = "IPHONE";
        } else {
            if (model_temp != null && model_temp.indexOf("Build/") != -1) {
                model_temp = model_temp.substring(0, model_temp.indexOf("Build/"));
                if (model_temp.lastIndexOf(';') != -1) {
                    model = model_temp.substring(model_temp.lastIndexOf(';')+1).trim();
                }
            } else {
                model = model_temp;
            }
        }
        label = flinkWebTrends.getWt_ti();
        name = flinkWebTrends.getWt_obj();
        referer = flinkWebTrends.getReferer();
        host = flinkWebTrends.getHost();
        page_url = coalesce(flinkWebTrends.getWt_es(), flinkWebTrends.getWt_pageurl());

        Map<String, String> refererQuery = ParseUrlQuery(referer);
        query_mcid = refererQuery.getOrDefault("WT.mc_id", null);
        query_inner_entry = refererQuery.getOrDefault("inner_entry", null);
        query_inner_media = refererQuery.getOrDefault("inner_media", null);
        query_pid = refererQuery.getOrDefault("pid", null);
        query_shid = refererQuery.getOrDefault("shid", null);
        query_adid = refererQuery.getOrDefault("adid", null);
        query_aid = refererQuery.getOrDefault("aid", null);
        query_sid = refererQuery.getOrDefault("sid", null);
        query_ouid = refererQuery.getOrDefault("ouid", null);
        query_id = refererQuery.getOrDefault("id", null);
        query_infid = refererQuery.getOrDefault("infid", null);
        query_t = refererQuery.getOrDefault("t", null);
        query_innerchannel = refererQuery.getOrDefault("innerChannel", null);

        if (page_url.contains("stock.pingan.com/omm/phonex")) {
            wt_sys = "理财";
        } else if (page_url.contains("stock.pingan.com/oas")) {
            wt_sys = "开户";
        } else if (page_url.contains("asset.stock.pingan.com/")) {
            wt_sys = "资产配置";
        } else if (page_url.contains("stock.pingan.com/invest/") || page_url.contains("stock.pingan.com/zuhe/")) {
            wt_sys = "投顾";
        } else {
            wt_sys = null;
        }
        dcsref = flinkWebTrends.getDcsref();
        Map<String, String> dcsrefQuery = ParseUrlQuery(dcsref);
        dcshost = ParseUrl(dcsref, "HOST");
        wt_pa_ref = flinkWebTrends.getWt_pa_ref();
        if (wt_pa_ref.equals("seo") || wt_pa_ref.equals("sem")) {
            keyword = coalesce(dcsrefQuery.getOrDefault("wd", null),
                    dcsrefQuery.getOrDefault("word", null),
                    dcsrefQuery.getOrDefault("query", null),
                    dcsrefQuery.getOrDefault("q", null));
        } else {
            keyword = null;
        }

        click_time = sdf.format(new Date(Long.parseLong(flinkWebTrends.getDcsdat())));
        recv_time = sdf.format(new Date(flinkWebTrends.getRecv_time()));
        Map<Integer, Handler> channelMap = channelMap();
        for (Map.Entry<Integer, Handler> entry :
                channelMap.entrySet()) {
            channel = entry.getValue().handle(flinkWebTrends);
            if (channel != null) {
                break;
            }
        }
        platform = flinkWebTrends.getPlatform();
        user_agent = flinkWebTrends.getUser_agent();
        otherparams = flinkWebTrends.getOtherParams();
        wt_click = flinkWebTrends.getWt_click();
        wt_bh = flinkWebTrends.getWt_bh();
        wt_bs = flinkWebTrends.getWt_bs();
        wt_cd = flinkWebTrends.getWt_cd();
        wt_ct = flinkWebTrends.getWt_ct();
        wt_dat = flinkWebTrends.getWt_dat();
        wt_dl = flinkWebTrends.getWt_dl();
        wt_es = flinkWebTrends.getWt_es();
        wt_fv = flinkWebTrends.getWt_fv();
        wt_hp = flinkWebTrends.getWt_hp();
        wt_jo = flinkWebTrends.getWt_jo();
        wt_js = flinkWebTrends.getWt_js();
        wt_jv = flinkWebTrends.getWt_jv();
        wt_le = flinkWebTrends.getWt_le();
        wt_pa_cgn = flinkWebTrends.getWt_pa_cgn();
        wt_pa_cgs = flinkWebTrends.getWt_pa_cgs();
        wt_pa_dom = flinkWebTrends.getWt_pa_dom();
        wt_pagetitle = flinkWebTrends.getWt_pagetitle();
        wt_pageurl = flinkWebTrends.getWt_pageurl();
        wt_pv_num = flinkWebTrends.getWt_pv_num();
        wt_re_cgn = flinkWebTrends.getWt_re_cgn();
        wt_re_cgs = flinkWebTrends.getWt_re_cgs();
        wt_slv = flinkWebTrends.getWt_slv();
        wt_sr = flinkWebTrends.getWt_sr();
        wt_ssl = flinkWebTrends.getWt_ssl();
        wt_tz = flinkWebTrends.getWt_tz();
        wt_ul = flinkWebTrends.getWt_ul();
        wt_vt_f = flinkWebTrends.getWt_vt_f();
        wt_vt_f_a = flinkWebTrends.getWt_vt_f_a();
        wt_vt_num = flinkWebTrends.getWt_vt_num();
        wt_num = flinkWebTrends.getWt_num();
        tuffyversionids = flinkWebTrends.getTuffyVersionIds();

        return new WebSimplifyLog(device_id, wt_id, sd_uid, sd_sid, visitorid, wt_unionid, omm_session_id, ip, app_type, app_version, model, label, name, referer, host, page_url, query_mcid,
                query_inner_entry, query_inner_media,query_pid,query_shid,query_adid,query_aid,query_sid,query_ouid,query_id,query_infid,query_t,query_innerchannel,wt_sys,
                dcsref,dcshost,keyword,click_time,recv_time,channel,platform,user_agent,otherparams,wt_click,wt_bh,wt_bs,wt_cd,wt_ct,wt_dat,wt_dl,wt_es,wt_fv,wt_hp,wt_jo,
                wt_js,wt_jv,wt_le,wt_pa_cgn,wt_pa_cgs,wt_pa_dom,wt_pa_ref,wt_pagetitle,wt_pageurl,wt_pv_num,wt_re_cgn,wt_re_cgs,wt_slv,wt_sr,wt_ssl,wt_tz,wt_ul,wt_vt_f,
                wt_vt_f_a,wt_vt_num,wt_num,tuffyversionids,source);
    }

    public static Map<Integer, Handler> channelMap() {
        Map<Integer, Handler> result = new LinkedHashMap<>();
        int key = 1;

        result.put(key, new Handler() {
            @Override
            public String handle(FlinkWebTrends webTrends) {
                String obj = webTrends.getOtherParams().getOrDefault("sdcAgent", null);
                String res = null;
                if (obj != null && obj.toLowerCase().contains("aneapp")) {
                    res = "证券APP";
                }
                return res;
            }
        });
        key++;
        result.put(key, new Handler() {
            @Override
            public String handle(FlinkWebTrends webTrends) {
                String obj = webTrends.getOtherParams().getOrDefault("sdcAgent", null);
                String res = null;
                if (obj != null && obj.toLowerCase().contains("weixin")) {
                    res = "微信";
                }
                return res;
            }
        });
        key++;
        result.put(key, new Handler() {
            @Override
            public String handle(FlinkWebTrends webTrends) {
                String obj = webTrends.getOtherParams().getOrDefault("sdcSubagent", null);
                String res = null;
                if (obj != null && (obj.toLowerCase().contains("dazhihui") || obj.toLowerCase().contains("tdx-jiin") ||
                        obj.toLowerCase().contains("tdx-lccp") || obj.toLowerCase().contains("tdx-lcsc") ||
                        obj.toLowerCase().contains("rym") || obj.toLowerCase().contains("xyk") ||
                        obj.toLowerCase().contains("lujinsuo"))) {
                    res = "外部合作平台";
                }
                return res;
            }
        });
        key++;
        result.put(key, new Handler() {
            @Override
            public String handle(FlinkWebTrends webTrends) {
                String obj = webTrends.getOtherParams().getOrDefault("sdcPlatform", null);
                String res = null;
                if (obj != null && obj.toLowerCase().contains("pc")) {
                    res = "WEB";
                }
                return res;
            }
        });
        key++;
        result.put(key, new Handler() {
            @Override
            public String handle(FlinkWebTrends webTrends) {
                String obj = webTrends.getOtherParams().getOrDefault("sdcPlatform", null);
                String res = null;
                if (obj != null && (obj.toLowerCase().contains("android") || obj.toLowerCase().contains("ipad") || obj.toLowerCase().contains("iphone"))) {
                    res = "WAP";
                }
                return res;
            }
        });
        key++;
        result.put(key, new Handler() {
            @Override
            public String handle(FlinkWebTrends webTrends) {
                return "其他";
            }
        });

        return result;
    }

    public static List<String> readFilter(String localFile, Logger logger) throws IOException {
        File local = new File(localFile);
        List<String> filter = new ArrayList<String>();

        if (!local.exists()) {
            logger.error("Local file {} does not exists!", localFile);
            return null;
        }

        BufferedReader bufferedReader = new BufferedReader(new FileReader(local));
        String line = null;
        while ((line = bufferedReader.readLine()) != null) {
            filter.add(line);
        }
        return filter;
    }

    private static String coalesce(String... value) {
        for (int i = 0; i < value.length; i++) {
            String temp = value[i];
            if (temp != null) {
                return temp;
            } else {
                continue;
            }
        }
        return null;
    }

    private static Map<String,String> ParseUrlQuery(String urlstr) {
        URL url = null;
        String temp;
        String[] kv;
        Map<String, String> map = new HashMap<>();

        if (urlstr != null && !urlstr.trim().isEmpty()) {
            if (!urlstr.contains("http")) {
                urlstr = "http://" + urlstr;
            }
            try {
                url = new URL(urlstr);
                temp = url.getQuery();
                if (temp == null || temp.trim().isEmpty() || temp.indexOf("&") == -1) {
                    return map;
                }
                for (String s :
                        temp.split("&")) {
                    kv = s.split("=");
                    if (kv.length != 2) {
                        continue;
                    } else {
                        map.put(kv[0], kv[1]);
                    }
                }
                return map;
            } catch (MalformedURLException e) {
                System.err.println(urlstr);
                e.printStackTrace();
                return map;
            }
        } else {
            return map;
        }
    }

    private static String ParseUrl(String urlstr, String partToExtract) {
        URL url = null;
        String result = null;

        if (urlstr != null && !urlstr.trim().isEmpty() && partToExtract!= null ) {
            if (!urlstr.contains("http")) {
                urlstr = "http://" + urlstr;
            }
            try {
                url = new URL(urlstr);
            } catch (MalformedURLException e) {
                e.printStackTrace();
                System.err.println(urlstr);
                return null;
            }
        } else {
            return null;
        }
        if (partToExtract.equals("HOST")) {
            return url.getHost();
        }
        if (partToExtract.equals("PATH")) {
            return url.getPath();
        }
        if (partToExtract.equals("QUERY")) {
            return url.getQuery();
        }
        if (partToExtract.equals("REF")) {
            return url.getRef();
        }
        if (partToExtract.equals("PROTOCOL")) {
            return url.getProtocol();
        }
        if (partToExtract.equals("FILE")) {
            return url.getFile();
        }
        if (partToExtract.equals("AUTHORITY")) {
            return url.getAuthority();
        }
        if (partToExtract.equals("USERINFO")) {
            return url.getUserInfo();
        }
        return null;
    }

    /*public static void main(String[] args) {
        FlinkWebTrends webTrends = new FlinkWebTrends();
        webTrends.setRecv_time(System.currentTimeMillis());
        Map<String, String> map = new HashMap<>();
        map.put("sdcAgent", "aneapp_6.9.1.0");
        webTrends.setOtherParams(map);
        System.out.println(simplify(webTrends).channel);

        String channel = null;

        Map<Integer, Handler> channelMap = channelMap();
        for (Map.Entry<Integer, Handler> entry :
                channelMap.entrySet()) {
            channel = entry.getValue().handle(webTrends);
            if (channel != null) {
                break;
            }
        }
        System.out.println(channel);

        map.put("sdcAgent", "weixin");
        webTrends.setOtherParams(map);
        for (Map.Entry<Integer, Handler> entry :
                channelMap.entrySet()) {
            channel = entry.getValue().handle(webTrends);
            if (channel != null) {
                break;
            }
        }
        System.out.println(channel);

        map.put("sdcAgent", "xxx");
        map.put("sdcSubagent", "app-grzx-lczc");
        webTrends.setOtherParams(map);
        for (Map.Entry<Integer, Handler> entry :
                channelMap.entrySet()) {
            channel = entry.getValue().handle(webTrends);
            if (channel != null) {
                break;
            }
        }
        System.out.println(channel);

        map.put("sdcAgent", "xxx");
        map.put("sdcSubagent", "lujinsuo");
        webTrends.setOtherParams(map);
        for (Map.Entry<Integer, Handler> entry :
                channelMap.entrySet()) {
            channel = entry.getValue().handle(webTrends);
            if (channel != null) {
                break;
            }
        }
        System.out.println(channel);

        map.put("sdcAgent", "xxx");
        map.put("sdcSubagent", "app-grzx-lczc");
        map.put("sdcPlatform", "pc");
        webTrends.setOtherParams(map);
        for (Map.Entry<Integer, Handler> entry :
                channelMap.entrySet()) {
            channel = entry.getValue().handle(webTrends);
            if (channel != null) {
                break;
            }
        }
        System.out.println(channel);

        map.put("sdcAgent", "xxx");
        map.put("sdcSubagent", "app-grzx-lczc");
        map.put("sdcPlatform", "android");
        webTrends.setOtherParams(map);
        for (Map.Entry<Integer, Handler> entry :
                channelMap.entrySet()) {
            channel = entry.getValue().handle(webTrends);
            if (channel != null) {
                break;
            }
        }
        System.out.println(channel);

    }*/
}
