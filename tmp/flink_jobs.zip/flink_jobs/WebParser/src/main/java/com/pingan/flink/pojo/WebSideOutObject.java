package com.pingan.flink.pojo;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by WANGYI422 on 2018/4/16.
 */
public class WebSideOutObject {
    public String ct;
    public String t;
    public String id;
    public Map<String, Object> v;

    public WebSideOutObject(String ct, String t, String id, Map<String, Object> v) {
        this.ct = ct;
        this.t = t;
        this.id = id;
        this.v = v;
    }

    public WebSideOutObject(String ct, String t, String id, WebSimplifyLog simplifyLog) {
        this.ct = ct;
        this.t = t;
        this.id = id;
        Map<String, Object> map = new LinkedHashMap<>(74);
        map.put("device_id", simplifyLog.device_id);
        map.put("wt_id", simplifyLog.wt_id);
        map.put("sd_uid", simplifyLog.sd_uid);
        map.put("sd_sid", simplifyLog.sd_sid);
        map.put("visitorid", simplifyLog.visitorid);
        map.put("wt_unionid", simplifyLog.wt_unionid);
        map.put("omm_session_id", simplifyLog.omm_session_id);
        map.put("ip", simplifyLog.ip);
        map.put("app_type", simplifyLog.app_type);
        map.put("app_version", simplifyLog.app_version);
        map.put("model", simplifyLog.model);
        map.put("label", simplifyLog.label);
        map.put("name", simplifyLog.name);
        map.put("referer", simplifyLog.referer);
        map.put("host", simplifyLog.host);
        map.put("page_url", simplifyLog.page_url);
        map.put("query_mcid", simplifyLog.query_mcid);
        map.put("query_inner_entry", simplifyLog.query_inner_entry);
        map.put("query_inner_media", simplifyLog.query_inner_media);
        map.put("query_pid", simplifyLog.query_pid);
        map.put("query_shid", simplifyLog.query_shid);
        map.put("query_adid", simplifyLog.query_adid);
        map.put("query_aid", simplifyLog.query_aid);
        map.put("query_sid", simplifyLog.query_sid);
        map.put("query_ouid", simplifyLog.query_ouid);
        map.put("query_id", simplifyLog.query_id);
        map.put("query_infid", simplifyLog.query_infid);
        map.put("query_t", simplifyLog.query_t);
        map.put("query_innerchannel", simplifyLog.query_innerchannel);
        map.put("wt_sys", simplifyLog.wt_sys);
        map.put("dcsref", simplifyLog.dcsref);
        map.put("dcshost", simplifyLog.dcshost);
        map.put("keyword", simplifyLog.keyword);
        map.put("click_time", simplifyLog.click_time);
        map.put("recv_time", simplifyLog.recv_time);
        map.put("channel", simplifyLog.channel);
        map.put("platform", simplifyLog.platform);
        map.put("user_agent", simplifyLog.user_agent);
        map.put("otherparams", simplifyLog.otherparams);
        map.put("wt_click", simplifyLog.wt_click);
        map.put("wt_bh", simplifyLog.wt_bh);
        map.put("wt_bs", simplifyLog.wt_bs);
        map.put("wt_cd", simplifyLog.wt_cd);
        map.put("wt_ct", simplifyLog.wt_ct);
        map.put("wt_dat", simplifyLog.wt_dat);
        map.put("wt_dl", simplifyLog.wt_dl);
        map.put("wt_es", simplifyLog.wt_es);
        map.put("wt_fv", simplifyLog.wt_fv);
        map.put("wt_hp", simplifyLog.wt_hp);
        map.put("wt_jo", simplifyLog.wt_jo);
        map.put("wt_js", simplifyLog.wt_js);
        map.put("wt_jv", simplifyLog.wt_jv);
        map.put("wt_le", simplifyLog.wt_le);
        map.put("wt_pa_cgn", simplifyLog.wt_pa_cgn);
        map.put("wt_pa_cgs", simplifyLog.wt_pa_cgs);
        map.put("wt_pa_dom", simplifyLog.wt_pa_dom);
        map.put("wt_pa_ref", simplifyLog.wt_pa_ref);
        map.put("wt_pagetitle", simplifyLog.wt_pagetitle);
        map.put("wt_pageurl", simplifyLog.wt_pageurl);
        map.put("wt_pv_num", simplifyLog.wt_pv_num);
        map.put("wt_re_cgn", simplifyLog.wt_re_cgn);
        map.put("wt_re_cgs", simplifyLog.wt_re_cgs);
        map.put("wt_slv", simplifyLog.wt_slv);
        map.put("wt_sr", simplifyLog.wt_sr);
        map.put("wt_ssl", simplifyLog.wt_ssl);
        map.put("wt_tz", simplifyLog.wt_tz);
        map.put("wt_ul", simplifyLog.wt_ul);
        map.put("wt_vt_f", simplifyLog.wt_vt_f);
        map.put("wt_vt_f_a", simplifyLog.wt_vt_f_a);
        map.put("wt_vt_num", simplifyLog.wt_vt_num);
        map.put("wt_num", simplifyLog.wt_num);
        map.put("tuffyversionids", simplifyLog.tuffyversionids);
        map.put("source", simplifyLog.source);
        this.v = map;
    }

    public String getCt() {
        return ct;
    }

    public String getT() {
        return t;
    }

    public String getId() {
        return id;
    }

    public Map<String, Object> getV() {
        return v;
    }

    public void setCt(String ct) {
        this.ct = ct;
    }

    public void setT(String t) {
        this.t = t;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setV(Map<String, Object> v) {
        this.v = v;
    }
}

