package com.pingan.flink.pojo;

import java.util.Map;

/**
 * Created by WANGYI422 on 2018/4/13.
 */
public class WebSimplifyLog {
    public String device_id ;
    public String wt_id;
    public String sd_uid;
    public String sd_sid;
    public String visitorid;
    public String wt_unionid;
    public String omm_session_id;
    public String ip;
    public String app_type;
    public String app_version;
    public String model;
    public String label;
    public String name;
    public String referer;
    public String host;
    public String page_url;
    public String query_mcid;
    public String query_inner_entry;
    public String query_inner_media;
    public String query_pid;
    public String query_shid;
    public String query_adid;
    public String query_aid;
    public String query_sid;
    public String query_ouid;
    public String query_id;
    public String query_infid;
    public String query_t;
    public String query_innerchannel;
    public String wt_sys;
    public String dcsref;
    public String dcshost;
    public String keyword;
    public String click_time;
    public String recv_time;
    public String channel;
    public String platform;
    public String user_agent;
    public Map<String,String> otherparams;
    public String wt_click;
    public String wt_bh;
    public String wt_bs;
    public String wt_cd;
    public String wt_ct;
    public String wt_dat;
    public String wt_dl;
    public String wt_es;
    public String wt_fv;
    public String wt_hp;
    public String wt_jo;
    public String wt_js;
    public String wt_jv;
    public String wt_le;
    public String wt_pa_cgn;
    public String wt_pa_cgs;
    public String wt_pa_dom;
    public String wt_pa_ref;
    public String wt_pagetitle;
    public String wt_pageurl;
    public String wt_pv_num;
    public String wt_re_cgn;
    public String wt_re_cgs;
    public String wt_slv;
    public String wt_sr;
    public String wt_ssl;
    public String wt_tz;
    public String wt_ul;
    public String wt_vt_f;
    public String wt_vt_f_a;
    public String wt_vt_num;
    public String wt_num;
    public String tuffyversionids;
    public String source;

    public WebSimplifyLog(String device_id, String wt_id, String sd_uid, String sd_sid, String visitorid, String wt_unionid, String omm_session_id, String ip, String app_type, String app_version, String model, String label, String name, String referer, String host, String page_url, String query_mcid, String query_inner_entry, String query_inner_media, String query_pid, String query_shid, String query_adid, String query_aid, String query_sid, String query_ouid, String query_id, String query_infid, String query_t, String query_innerchannel, String wt_sys, String dcsref, String dcshost, String keyword, String click_time, String recv_time, String channel, String platform, String user_agent, Map otherparams, String wt_click, String wt_bh, String wt_bs, String wt_cd, String wt_ct, String wt_dat, String wt_dl, String wt_es, String wt_fv, String wt_hp, String wt_jo, String wt_js, String wt_jv, String wt_le, String wt_pa_cgn, String wt_pa_cgs, String wt_pa_dom, String wt_pa_ref, String wt_pagetitle, String wt_pageurl, String wt_pv_num, String wt_re_cgn, String wt_re_cgs, String wt_slv, String wt_sr, String wt_ssl, String wt_tz, String wt_ul, String wt_vt_f, String wt_vt_f_a, String wt_vt_num, String wt_num, String tuffyversionids, String source) {
        this.device_id = device_id;
        this.wt_id = wt_id;
        this.sd_uid = sd_uid;
        this.sd_sid = sd_sid;
        this.visitorid = visitorid;
        this.wt_unionid = wt_unionid;
        this.omm_session_id = omm_session_id;
        this.ip = ip;
        this.app_type = app_type;
        this.app_version = app_version;
        this.model = model;
        this.label = label;
        this.name = name;
        this.referer = referer;
        this.host = host;
        this.page_url = page_url;
        this.query_mcid = query_mcid;
        this.query_inner_entry = query_inner_entry;
        this.query_inner_media = query_inner_media;
        this.query_pid = query_pid;
        this.query_shid = query_shid;
        this.query_adid = query_adid;
        this.query_aid = query_aid;
        this.query_sid = query_sid;
        this.query_ouid = query_ouid;
        this.query_id = query_id;
        this.query_infid = query_infid;
        this.query_t = query_t;
        this.query_innerchannel = query_innerchannel;
        this.wt_sys = wt_sys;
        this.dcsref = dcsref;
        this.dcshost = dcshost;
        this.keyword = keyword;
        this.click_time = click_time;
        this.recv_time = recv_time;
        this.channel = channel;
        this.platform = platform;
        this.user_agent = user_agent;
        this.otherparams = otherparams;
        this.wt_click = wt_click;
        this.wt_bh = wt_bh;
        this.wt_bs = wt_bs;
        this.wt_cd = wt_cd;
        this.wt_ct = wt_ct;
        this.wt_dat = wt_dat;
        this.wt_dl = wt_dl;
        this.wt_es = wt_es;
        this.wt_fv = wt_fv;
        this.wt_hp = wt_hp;
        this.wt_jo = wt_jo;
        this.wt_js = wt_js;
        this.wt_jv = wt_jv;
        this.wt_le = wt_le;
        this.wt_pa_cgn = wt_pa_cgn;
        this.wt_pa_cgs = wt_pa_cgs;
        this.wt_pa_dom = wt_pa_dom;
        this.wt_pa_ref = wt_pa_ref;
        this.wt_pagetitle = wt_pagetitle;
        this.wt_pageurl = wt_pageurl;
        this.wt_pv_num = wt_pv_num;
        this.wt_re_cgn = wt_re_cgn;
        this.wt_re_cgs = wt_re_cgs;
        this.wt_slv = wt_slv;
        this.wt_sr = wt_sr;
        this.wt_ssl = wt_ssl;
        this.wt_tz = wt_tz;
        this.wt_ul = wt_ul;
        this.wt_vt_f = wt_vt_f;
        this.wt_vt_f_a = wt_vt_f_a;
        this.wt_vt_num = wt_vt_num;
        this.wt_num = wt_num;
        this.tuffyversionids = tuffyversionids;
        this.source = source;
    }

    public String getDevice_id() {
        return device_id;
    }

    public String getWt_id() {
        return wt_id;
    }

    public String getSd_uid() {
        return sd_uid;
    }

    public String getSd_sid() {
        return sd_sid;
    }

    public String getVisitorid() {
        return visitorid;
    }

    public String getWt_unionid() {
        return wt_unionid;
    }

    public String getOmm_session_id() {
        return omm_session_id;
    }

    public String getIp() {
        return ip;
    }

    public String getApp_type() {
        return app_type;
    }

    public String getApp_version() {
        return app_version;
    }

    public String getModel() {
        return model;
    }

    public String getLabel() {
        return label;
    }

    public String getName() {
        return name;
    }

    public String getReferer() {
        return referer;
    }

    public String getHost() {
        return host;
    }

    public String getPage_url() {
        return page_url;
    }

    public String getQuery_mcid() {
        return query_mcid;
    }

    public String getQuery_inner_entry() {
        return query_inner_entry;
    }

    public String getQuery_inner_media() {
        return query_inner_media;
    }

    public String getQuery_pid() {
        return query_pid;
    }

    public String getQuery_shid() {
        return query_shid;
    }

    public String getQuery_adid() {
        return query_adid;
    }

    public String getQuery_aid() {
        return query_aid;
    }

    public String getQuery_sid() {
        return query_sid;
    }

    public String getQuery_ouid() {
        return query_ouid;
    }

    public String getQuery_id() {
        return query_id;
    }

    public String getQuery_infid() {
        return query_infid;
    }

    public String getQuery_t() {
        return query_t;
    }

    public String getQuery_innerchannel() {
        return query_innerchannel;
    }

    public String getWt_sys() {
        return wt_sys;
    }

    public String getDcsref() {
        return dcsref;
    }

    public String getDcshost() {
        return dcshost;
    }

    public String getKeyword() {
        return keyword;
    }

    public String getClick_time() {
        return click_time;
    }

    public String getRecv_time() {
        return recv_time;
    }

    public String getChannel() {
        return channel;
    }

    public String getPlatform() {
        return platform;
    }

    public String getUser_agent() {
        return user_agent;
    }

    public Map<String, String> getOtherparams() {
        return otherparams;
    }

    public String getWt_click() {
        return wt_click;
    }

    public String getWt_bh() {
        return wt_bh;
    }

    public String getWt_bs() {
        return wt_bs;
    }

    public String getWt_cd() {
        return wt_cd;
    }

    public String getWt_ct() {
        return wt_ct;
    }

    public String getWt_dat() {
        return wt_dat;
    }

    public String getWt_dl() {
        return wt_dl;
    }

    public String getWt_es() {
        return wt_es;
    }

    public String getWt_fv() {
        return wt_fv;
    }

    public String getWt_hp() {
        return wt_hp;
    }

    public String getWt_jo() {
        return wt_jo;
    }

    public String getWt_js() {
        return wt_js;
    }

    public String getWt_jv() {
        return wt_jv;
    }

    public String getWt_le() {
        return wt_le;
    }

    public String getWt_pa_cgn() {
        return wt_pa_cgn;
    }

    public String getWt_pa_cgs() {
        return wt_pa_cgs;
    }

    public String getWt_pa_dom() {
        return wt_pa_dom;
    }

    public String getWt_pa_ref() {
        return wt_pa_ref;
    }

    public String getWt_pagetitle() {
        return wt_pagetitle;
    }

    public String getWt_pageurl() {
        return wt_pageurl;
    }

    public String getWt_pv_num() {
        return wt_pv_num;
    }

    public String getWt_re_cgn() {
        return wt_re_cgn;
    }

    public String getWt_re_cgs() {
        return wt_re_cgs;
    }

    public String getWt_slv() {
        return wt_slv;
    }

    public String getWt_sr() {
        return wt_sr;
    }

    public String getWt_ssl() {
        return wt_ssl;
    }

    public String getWt_tz() {
        return wt_tz;
    }

    public String getWt_ul() {
        return wt_ul;
    }

    public String getWt_vt_f() {
        return wt_vt_f;
    }

    public String getWt_vt_f_a() {
        return wt_vt_f_a;
    }

    public String getWt_vt_num() {
        return wt_vt_num;
    }

    public String getWt_num() {
        return wt_num;
    }

    public String getTuffyversionids() {
        return tuffyversionids;
    }

    public String getSource() {
        return source;
    }

    public void setDevice_id(String device_id) {
        this.device_id = device_id;
    }

    public void setWt_id(String wt_id) {
        this.wt_id = wt_id;
    }

    public void setSd_uid(String sd_uid) {
        this.sd_uid = sd_uid;
    }

    public void setSd_sid(String sd_sid) {
        this.sd_sid = sd_sid;
    }

    public void setVisitorid(String visitorid) {
        this.visitorid = visitorid;
    }

    public void setWt_unionid(String wt_unionid) {
        this.wt_unionid = wt_unionid;
    }

    public void setOmm_session_id(String omm_session_id) {
        this.omm_session_id = omm_session_id;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public void setApp_type(String app_type) {
        this.app_type = app_type;
    }

    public void setApp_version(String app_version) {
        this.app_version = app_version;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setReferer(String referer) {
        this.referer = referer;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public void setPage_url(String page_url) {
        this.page_url = page_url;
    }

    public void setQuery_mcid(String query_mcid) {
        this.query_mcid = query_mcid;
    }

    public void setQuery_inner_entry(String query_inner_entry) {
        this.query_inner_entry = query_inner_entry;
    }

    public void setQuery_inner_media(String query_inner_media) {
        this.query_inner_media = query_inner_media;
    }

    public void setQuery_pid(String query_pid) {
        this.query_pid = query_pid;
    }

    public void setQuery_shid(String query_shid) {
        this.query_shid = query_shid;
    }

    public void setQuery_adid(String query_adid) {
        this.query_adid = query_adid;
    }

    public void setQuery_aid(String query_aid) {
        this.query_aid = query_aid;
    }

    public void setQuery_sid(String query_sid) {
        this.query_sid = query_sid;
    }

    public void setQuery_ouid(String query_ouid) {
        this.query_ouid = query_ouid;
    }

    public void setQuery_id(String query_id) {
        this.query_id = query_id;
    }

    public void setQuery_infid(String query_infid) {
        this.query_infid = query_infid;
    }

    public void setQuery_t(String query_t) {
        this.query_t = query_t;
    }

    public void setQuery_innerchannel(String query_innerchannel) {
        this.query_innerchannel = query_innerchannel;
    }

    public void setWt_sys(String wt_sys) {
        this.wt_sys = wt_sys;
    }

    public void setDcsref(String dcsref) {
        this.dcsref = dcsref;
    }

    public void setDcshost(String dcshost) {
        this.dcshost = dcshost;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public void setClick_time(String click_time) {
        this.click_time = click_time;
    }

    public void setRecv_time(String recv_time) {
        this.recv_time = recv_time;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public void setUser_agent(String user_agent) {
        this.user_agent = user_agent;
    }

    public void setOtherparams(Map otherparams) {
        this.otherparams = otherparams;
    }

    public void setWt_click(String wt_click) {
        this.wt_click = wt_click;
    }

    public void setWt_bh(String wt_bh) {
        this.wt_bh = wt_bh;
    }

    public void setWt_bs(String wt_bs) {
        this.wt_bs = wt_bs;
    }

    public void setWt_cd(String wt_cd) {
        this.wt_cd = wt_cd;
    }

    public void setWt_ct(String wt_ct) {
        this.wt_ct = wt_ct;
    }

    public void setWt_dat(String wt_dat) {
        this.wt_dat = wt_dat;
    }

    public void setWt_dl(String wt_dl) {
        this.wt_dl = wt_dl;
    }

    public void setWt_es(String wt_es) {
        this.wt_es = wt_es;
    }

    public void setWt_fv(String wt_fv) {
        this.wt_fv = wt_fv;
    }

    public void setWt_hp(String wt_hp) {
        this.wt_hp = wt_hp;
    }

    public void setWt_jo(String wt_jo) {
        this.wt_jo = wt_jo;
    }

    public void setWt_js(String wt_js) {
        this.wt_js = wt_js;
    }

    public void setWt_jv(String wt_jv) {
        this.wt_jv = wt_jv;
    }

    public void setWt_le(String wt_le) {
        this.wt_le = wt_le;
    }

    public void setWt_pa_cgn(String wt_pa_cgn) {
        this.wt_pa_cgn = wt_pa_cgn;
    }

    public void setWt_pa_cgs(String wt_pa_cgs) {
        this.wt_pa_cgs = wt_pa_cgs;
    }

    public void setWt_pa_dom(String wt_pa_dom) {
        this.wt_pa_dom = wt_pa_dom;
    }

    public void setWt_pa_ref(String wt_pa_ref) {
        this.wt_pa_ref = wt_pa_ref;
    }

    public void setWt_pagetitle(String wt_pagetitle) {
        this.wt_pagetitle = wt_pagetitle;
    }

    public void setWt_pageurl(String wt_pageurl) {
        this.wt_pageurl = wt_pageurl;
    }

    public void setWt_pv_num(String wt_pv_num) {
        this.wt_pv_num = wt_pv_num;
    }

    public void setWt_re_cgn(String wt_re_cgn) {
        this.wt_re_cgn = wt_re_cgn;
    }

    public void setWt_re_cgs(String wt_re_cgs) {
        this.wt_re_cgs = wt_re_cgs;
    }

    public void setWt_slv(String wt_slv) {
        this.wt_slv = wt_slv;
    }

    public void setWt_sr(String wt_sr) {
        this.wt_sr = wt_sr;
    }

    public void setWt_ssl(String wt_ssl) {
        this.wt_ssl = wt_ssl;
    }

    public void setWt_tz(String wt_tz) {
        this.wt_tz = wt_tz;
    }

    public void setWt_ul(String wt_ul) {
        this.wt_ul = wt_ul;
    }

    public void setWt_vt_f(String wt_vt_f) {
        this.wt_vt_f = wt_vt_f;
    }

    public void setWt_vt_f_a(String wt_vt_f_a) {
        this.wt_vt_f_a = wt_vt_f_a;
    }

    public void setWt_vt_num(String wt_vt_num) {
        this.wt_vt_num = wt_vt_num;
    }

    public void setWt_num(String wt_num) {
        this.wt_num = wt_num;
    }

    public void setTuffyversionids(String tuffyversionids) {
        this.tuffyversionids = tuffyversionids;
    }

    public void setSource(String source) {
        this.source = source;
    }
}
