package com.pingan.stock.data.collect3;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.apache.flink.api.java.tuple.Tuple;
import org.apache.flink.streaming.api.functions.windowing.RichWindowFunction;
import org.apache.flink.streaming.api.functions.windowing.WindowFunction;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * Created by ZHANGXING130 on 2018/10/24.
 */
public class ApplyWindowFunction extends RichWindowFunction<KafkaMsgEntity, KafkaMsgEntity, Tuple, TimeWindow> {

    private static Logger logger = LoggerFactory.getLogger(ApplyWindowFunction.class);
    @Override
    public void apply(Tuple s, TimeWindow timeWindow, Iterable<KafkaMsgEntity> iterable, Collector<KafkaMsgEntity> collector) throws Exception {
        //logger.info("start");
        Map<String,String> config = this.getRuntimeContext().getExecutionConfig().getGlobalJobParameters().toMap();
        String timeFieldSchema = config.get("sortFieldSchema");
        JSONObject jsonObject = JSON.parseObject(timeFieldSchema);

        Iterator<KafkaMsgEntity> iter = iterable.iterator();
        KafkaMsgEntity kafkaMsgEntity = null;
        while (iter!=null&&iter.hasNext()) {
            KafkaMsgEntity input = iter.next();
            if(kafkaMsgEntity==null){
                kafkaMsgEntity = input;
            }else {
                if(kafkaMsgEntity.getEventTime()<input.getEventTime()){
                    kafkaMsgEntity = input;
                }else if(kafkaMsgEntity.getEventTime().equals(input.getEventTime())){
                    if(jsonObject!=null) {
                        String sortSchema = jsonObject.getString(kafkaMsgEntity.getMsgType());
                        if(sortSchema!=null) {
                            String[] schemaArr = sortSchema.split(",");
                            String mapKey = schemaArr[1];
                            String sortKey = schemaArr[0];
                            String fieldType = schemaArr[2];
                            Object ob1 = null, ob2 = null;
                            if (mapKey.equals("uppV")) {
                                ob1 = kafkaMsgEntity.getUppVDataObject().get(sortKey);
                                ob2 = input.getUppVDataObject().get(sortKey);
                            } else if (mapKey.equals("calV")) {
                                ob1 = kafkaMsgEntity.getCalcVDataObject().get(sortKey);
                                ob2 = input.getCalcVDataObject().get(sortKey);
                            } else if (mapKey.equals("v")) {
                                ob1 = kafkaMsgEntity.gettDataObject().get(sortKey);
                                ob2 = input.gettDataObject().get(sortKey);
                            }
                            if (fieldType.equals("long")) {
                                Long l1 = 0L;
                                if(ob1!=null) {
                                    l1 = Long.parseLong(ob1.toString());
                                }
                                Long l2 = 0L;
                                if(ob2!=null) {
                                    l2 = Long.parseLong(ob2.toString());
                                }
                                //todo 判断null
                                if (l1 < l2) {
                                    kafkaMsgEntity = input;
                                }
                            }
                            if (fieldType.equals("string")) {
                                String s1 = (String) ob1;
                                String s2 = (String) ob2;
                                //todo 判断null
                                if (s1!=null&&s2!=null&&s1.compareTo(s2) < 0) {
                                    kafkaMsgEntity = input;
                                }else if(s1==null){
                                    kafkaMsgEntity = input;
                                }
                            }
                        }
                    }
                }
            }
        }
        if(kafkaMsgEntity!=null) {
            collector.collect(kafkaMsgEntity);
        }
        //logger.info("end:"+kafkaMsgEntity);
    }

}
