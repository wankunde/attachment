package com.pingan.stock.data.collect3;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.configuration.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

/**
 * Created by ZHANGXING130 on 2018/10/24.
 */
public class EventTimeMapFunction extends RichMapFunction<KafkaMsgEntity, KafkaMsgEntity> {
    private static Logger logger = LoggerFactory.getLogger(EventTimeMapFunction.class);
        private JSONObject jsonObject;
        @Override
        public KafkaMsgEntity map(KafkaMsgEntity kafkaMsgEntity) throws Exception {
            String msgType = kafkaMsgEntity.getMsgType();
            String fieldSchema = null;
            if(jsonObject!=null) {
                fieldSchema = jsonObject.getString(msgType);
            }
            if(fieldSchema!=null) {
                String[] schemaArr = fieldSchema.split(",");
                String timeFormate = schemaArr[2];
                String mapKey = schemaArr[1];
                String timeKey = schemaArr[0];
                String timeStr = null;
                if (mapKey.equals("uppV")) {
                    timeStr = (String) kafkaMsgEntity.getUppVDataObject().get(timeKey);
                } else if (mapKey.equals("calV")) {
                    timeStr = (String) kafkaMsgEntity.getCalcVDataObject().get(timeKey);
                } else if (mapKey.equals("v")) {
                    timeStr = (String) kafkaMsgEntity.gettDataObject().get(timeKey);
                }
                if(timeStr!=null) {
                    SimpleDateFormat format = new SimpleDateFormat(timeFormate);
                    Date eventDate = format.parse(timeStr);
                    kafkaMsgEntity.setEventTime(eventDate.getTime());
                    //logger.info(kafkaMsgEntity.toString());
                    //logger.info(timeStr);
                }
            }else{
                kafkaMsgEntity.setEventTime(kafkaMsgEntity.getMsgTime());
            }

            return kafkaMsgEntity;
        }

        @Override
        public void open(Configuration parameters){
            Map<String,String> configMap = this.getRuntimeContext().getExecutionConfig().getGlobalJobParameters().toMap();
            String timeFieldSchema = configMap.get("timeFieldSchema");
            jsonObject = JSON.parseObject(timeFieldSchema);
        }
}
