package com.pingan.stock.data.collect3;

import org.apache.flink.api.common.serialization.DeserializationSchema;
import org.apache.flink.api.common.serialization.SerializationSchema;
import org.apache.flink.api.common.typeinfo.TypeInformation;

import java.io.IOException;

/**
 * Created by ZHANGXING130 on 2018/10/10.
 */
public class KafkaMsgEntitySchema implements DeserializationSchema<KafkaMsgEntity>, SerializationSchema<KafkaMsgEntity> {

    private static final long serialVersionUID = 6154188370181669758L;

    private String env;
    public KafkaMsgEntitySchema(String env){
        this.env = env;
    }

    @Override
    public KafkaMsgEntity deserialize(byte[] bytes) throws IOException {
        if(env.equals("prd")){
            return KafkaMsgEntity.fromString(new String(bytes));
        }else {
            return KafkaMsgEntity.fromStringTest(new String(bytes));
        }
    }

    @Override
    public boolean isEndOfStream(KafkaMsgEntity kafkaMsgEntity) {
        return false;
    }

    @Override
    public byte[] serialize(KafkaMsgEntity kafkaMsgEntity) {
        return kafkaMsgEntity.toString().getBytes();
    }

    @Override
    public TypeInformation<KafkaMsgEntity> getProducedType() {
        return TypeInformation.of(KafkaMsgEntity.class);
    }
}
