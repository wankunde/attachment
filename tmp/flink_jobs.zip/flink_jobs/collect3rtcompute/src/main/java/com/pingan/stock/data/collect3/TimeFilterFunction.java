package com.pingan.stock.data.collect3;

import org.apache.flink.api.common.functions.RichFilterFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Calendar;

/**
 * Created by ZHANGXING130 on 2018/10/24.
 */
public class TimeFilterFunction extends RichFilterFunction<KafkaMsgEntity> {
    private static Logger logger = LoggerFactory.getLogger(TimeFilterFunction.class);
    @Override
    public boolean filter(KafkaMsgEntity kafkaMsgEntity) throws Exception {
        Long eventTime = kafkaMsgEntity.getEventTime();
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY,0);
        calendar.set(Calendar.MINUTE,0);
        calendar.set(Calendar.MILLISECOND,0);
        calendar.set(Calendar.SECOND,0);
        if(eventTime==null||eventTime<calendar.getTimeInMillis()){
            return false;
        }else{
            return true;
        }
    }
}
