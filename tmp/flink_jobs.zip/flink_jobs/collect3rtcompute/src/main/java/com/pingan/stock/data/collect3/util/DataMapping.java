package com.pingan.stock.data.collect3.util;

import com.alibaba.fastjson.JSONObject;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * Created by ZHANGXING130 on 2018/10/15.
 */
public class DataMapping {
    public static Object getFieldValue(String type,Object dataValue) {

        String value;
        if(dataValue!=null&&!dataValue.equals("null")&&!dataValue.equals("")){
            value = dataValue.toString();
        }else{
            return null;
        }
        Object result = value;
        switch (type) {
            case "long":
                result = StringUtil.getSafeLong(value);
                break;
            case "int":
                result = StringUtil.getSafeInterger(value);
                break;
            case "integer":
                result = StringUtil.getSafeInterger(value);
                break;
            case "bigint":
                result = StringUtil.getSafeLong(value);
                break;
            case "short":
                result = StringUtil.getSafeShort(value);
                break;
            case "double":
                result = StringUtil.getSafeDouble(value);
                break;
            case "float":
                result = StringUtil.getSafeFloat(value);
                break;
            case "boolean":
                result = StringUtil.getSafeBoolean(value);
                break;
            case "date":
                if (value.contains("-")) {
                    DateFormat hiveFormat = new SimpleDateFormat("yyyy-MM-dd");
                    DateFormat esFormat= new SimpleDateFormat("yyyyMMdd");
                    try {
                        result = esFormat.format(hiveFormat.parse(value));
                    } catch (ParseException e) {
                       e.printStackTrace();
                    }
                }else{
                    result = StringUtil.getSafeDate(value);
                }
                break;
            case "string":
                result = StringUtil.getSafeString(value);
                break;
            default:
                if (type.startsWith("map")) {
                    /*String[] strs = type.split(",");
                    String realtype = strs[1].replace(">", "");
                    result = getFieldValue(null, fieldName, value);*/
                } else if (type.startsWith("decimal")) {
                    result = StringUtil.getSafeDouble(value);
                }
                break;
        }
        return result;
    }

}
