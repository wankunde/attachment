package com.pingan.stock.data.collect3;

import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.apache.flink.streaming.connectors.elasticsearch5.shaded.org.apache.http.HttpResponse;
import org.apache.flink.streaming.connectors.elasticsearch5.shaded.org.apache.http.client.methods.HttpGet;
import org.apache.flink.streaming.connectors.elasticsearch5.shaded.org.apache.http.impl.client.CloseableHttpClient;
import org.apache.flink.streaming.connectors.elasticsearch5.shaded.org.apache.http.impl.client.HttpClients;
import org.apache.flink.streaming.connectors.elasticsearch5.shaded.org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.TimeZone;

/**
 * Created by ZHANGXING130 on 2018/10/31.
 */
public class RulesSource implements SourceFunction<Tuple2<String, Boolean>> {
    private boolean running = true;
    public boolean indexyestoday = false;
    private String taskConfig;
    private String taskIndex;
    private static Logger logger = LoggerFactory.getLogger(RulesSource.class);
    public RulesSource(String taskConfig,String taskIndex){
        this.taskConfig = taskConfig;
        this.taskIndex = taskIndex;
    }
    public void run(SourceContext<Tuple2<String, Boolean>> sourceContext) throws Exception {
        Thread.currentThread().sleep(10000);
        while(running){
            String[] urlArray = this.taskConfig.split(",");
            SimpleDateFormat simpleDateFormat  = new SimpleDateFormat("yyyyMMdd");
            Timestamp timestamp = new Timestamp(System.currentTimeMillis()-2*24*60*60*1000);
            String data = simpleDateFormat.format(timestamp);
            for(String url : urlArray) {
                String esUrl = "http://"+url+"/"+this.taskIndex+"/_alias";
                CloseableHttpClient httpclient = HttpClients.createDefault();
                HttpGet hg = new HttpGet(esUrl);
                HttpResponse res = null;
                try {
                    res = httpclient.execute(hg);
                    logger.info("statuscode"+res.getStatusLine().getStatusCode());
                    if (res.getStatusLine().getStatusCode() == 200) {
                        String result = EntityUtils.toString(res.getEntity());
                        logger.info(result);
                        if(result.contains(this.taskIndex+"_" + data)){
                            this.indexyestoday = true;
                        }else {
                            this.indexyestoday = false;
                        }
                    }else if(res.getStatusLine().getStatusCode()==404){
                        this.indexyestoday = false;
                    }
                    break;
                } catch (IOException e) {
                    logger.error(e.getMessage());
                }
            }
            logger.info("indexyestoday"+indexyestoday);
            sourceContext.collect(Tuple2.of("indexyestoday", indexyestoday));
            Thread.currentThread().sleep(30000*10);
        }
    }

    public void cancel() {
        running = false;
    }
}

