package com.pingan.stock.data.collect3;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by ZHANGXING130 on 2018/10/10.
 */
public class KafkaMsgEntity {

    private String msgType;
    private String custCode;
    private Long msgTime;
    private Long eventTime;
    private Map<String,Object> calcVDataObject;
    private Map<String,Object> uppVDataObject;
    private Map<String,Object> tDataObject;
    private Map<String,Object> configObject;
    private static Logger logger= LoggerFactory.getLogger(KafkaMsgEntity.class);

    public Map<String, Object> getCalcVDataObject() {
        return calcVDataObject;
    }

    public void setCalcVDataObject(Map<String, Object> calcVDataObject) {
        this.calcVDataObject = calcVDataObject;
    }

    public Map<String, Object> getUppVDataObject() {
        return uppVDataObject;
    }

    public void setUppVDataObject(Map<String, Object> uppVDataObject) {
        this.uppVDataObject = uppVDataObject;
    }

    public String getMsgType() {
        return msgType;
    }

    public void setMsgType(String msgType) {
        this.msgType = msgType;
    }

    public String getCustCode() {
        return custCode;
    }

    public void setCustCode(String custCode) {
        this.custCode = custCode;
    }

    public Long getMsgTime() {
        return msgTime;
    }

    public void setMsgTime(Long msgTime) {
        this.msgTime = msgTime;
    }

    public Long getEventTime() {
        return eventTime;
    }

    public void setEventTime(Long eventTime) {
        this.eventTime = eventTime;
    }

    public Map<String, Object> gettDataObject() {
        return tDataObject;
    }

    public void settDataObject(Map<String, Object> tDataObject) {
        this.tDataObject = tDataObject;
    }

    public Map<String, Object> getConfigObject() {
        return configObject;
    }

    public void setConfigObject(Map<String, Object> configObject) {
        this.configObject = configObject;
    }

    public KafkaMsgEntity(){

    }


    public KafkaMsgEntity(String msgType,String custCode,Long msgTime,Map<String,Object> calcVDataObject,Map<String,Object> uppVDataObject,Map<String,Object> tDataObject){
        this.msgType = msgType;
        this.custCode = custCode;
        this.msgTime = msgTime;
        this.calcVDataObject = calcVDataObject;
        this.uppVDataObject = uppVDataObject;
        this.tDataObject = tDataObject;
        this.configObject = new HashMap<>();
    }


    public static KafkaMsgEntity fromString(String eventStr) {
        JSONObject jsonObject = JSON.parseObject(eventStr);
        String msgType = jsonObject.getString("t");
        JSONObject calcVBody = jsonObject.getJSONObject("calcV");
        Map<String,Object> calcVDataObject = null;
        if(calcVBody==null) {
            calcVDataObject = new HashMap<>();
        }else{
            calcVDataObject = calcVBody.getInnerMap();
        }
        JSONObject uppVBody = jsonObject.getJSONObject("uppV");
        Map<String,Object> uppVDataObject = null;
        if(uppVBody==null) {
            uppVDataObject = new HashMap<>();
        }else{
            uppVDataObject = uppVBody.getInnerMap();
        }
        JSONObject tBody = jsonObject.getJSONObject("v");
        Map<String,Object> tDataObject = null;
        if(tBody==null) {
            tDataObject = new HashMap<>();
        }else{
            tDataObject = tBody.getInnerMap();
        }
        String custCode = uppVBody.getString("cust_code");
        Long msgTime = jsonObject.getLong("ct");

        return new KafkaMsgEntity(msgType, custCode, msgTime,calcVDataObject,uppVDataObject,tDataObject);
    }

    public static KafkaMsgEntity fromStringTest(String eventStr) {
       /* JSONObject jsonObject = JSON.parseObject(eventStr);
        String msgType = jsonObject.getString("t");
        JSONObject body = jsonObject.getJSONObject("v");
        Map<String,Object> dataObject = body.getInnerMap();
        String custCode = body.getString("sid");
        Long msgTime = jsonObject.getLong("ct");
        logger.info(eventStr);
        return new KafkaMsgEntity(msgType, custCode, msgTime,dataObject,dataObject);
*/

       logger.info(eventStr);

        JSONObject jsonObject = JSON.parseObject(eventStr);
        String msgType = jsonObject.getString("t");
        JSONObject calcVBody = jsonObject.getJSONObject("calcV");
        Map<String,Object> calcVDataObject = null;
        if(calcVBody==null) {
            calcVDataObject = new HashMap<>();
        }else{
            calcVDataObject = calcVBody.getInnerMap();
        }
        JSONObject uppVBody = jsonObject.getJSONObject("uppV");
        Map<String,Object> uppVDataObject = null;
        if(uppVBody==null) {
            uppVDataObject = new HashMap<>();
        }else{
            uppVDataObject = uppVBody.getInnerMap();
        }
        JSONObject tBody = jsonObject.getJSONObject("v");
        Map<String,Object> tDataObject = null;
        if(tBody==null) {
            tDataObject = new HashMap<>();
        }else{
            tDataObject = tBody.getInnerMap();
        }
        String custCode = calcVBody.getString("userid");
        Long msgTime = jsonObject.getLong("ct");
        return new KafkaMsgEntity(msgType, custCode, msgTime,calcVDataObject,uppVDataObject,tDataObject);

    }

    @Override
    public String toString() {
        return this.getMsgTime()+","+this.getCustCode()+","+this.getMsgType()+","+this.calcVDataObject.toString()+","+this.getUppVDataObject().toString()+","+this.gettDataObject();
    }
}
