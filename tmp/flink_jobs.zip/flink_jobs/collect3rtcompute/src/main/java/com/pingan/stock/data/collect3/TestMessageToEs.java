package com.pingan.stock.data.collect3;

/*import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.java.ExecutionEnvironment;
import org.apache.flink.api.java.tuple.Tuple;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.co.RichCoFlatMapFunction;
import org.apache.flink.streaming.api.functions.source.RichSourceFunction;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.apache.flink.streaming.api.functions.timestamps.AscendingTimestampExtractor;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer08;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaProducer011;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaProducer08;
import org.apache.flink.util.Collector;*/
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.InputStream;
import java.util.*;
import java.util.jar.JarFile;

/**
 * Created by ZHANGXING130 on 2018/11/1.
 */
public class TestMessageToEs {
    private static Logger logger = LoggerFactory.getLogger(TestMessageToEs.class);
    public static void main(String[] args) throws Exception {

        /*logger.info("task start");
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.getConfig().setRestartStrategy(RestartStrategies.fixedDelayRestart(6, 600000));
        env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);
        env.getConfig().setTaskCancellationInterval(1000*60);
        env.getConfig().setTaskCancellationTimeout(1000*60*60);
        Properties propertiesKafka = new Properties();
        propertiesKafka.put("bootstrap.servers","10.25.224.97:9092,10.25.224.98:9092");
        //propertiesKafka.put("zookeeper.connect","10.25.161.128:2181,10.25.161.129:2181,10.25.161.130:2181,10.25.161.183:2181,10.25.161.184:2181/kafka/mbus/uat");
        //propertiesKafka.put("group.id",group);

        DataStream<String> ds = env.addSource(new RichSourceFunction<String>() {
            @Override
            public void run(SourceContext<String> sourceContext) throws Exception {
               //while (true) {
                   sourceContext.collect("{\"test\":\"2222222ttttt\"}");
                   Thread.currentThread().sleep(100000);
               //}
            }

            @Override
            public void cancel() {

            }
        });

        ds.addSink(
                new FlinkKafkaProducer011<>(
                        "test1",
                        new SimpleStringSchema(),
                        propertiesKafka));

        env.execute("Kafka 0.10 Example");*/
    }
}
