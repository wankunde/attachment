package com.pingan.stock.data.collect3;

/*import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer011;


import java.util.Properties;*/

/**
 * Created by ZHANGXING130 on 2018/11/20.
 */
public class TestConsumer {


    public static void main(String[] args) throws Exception {

        /*StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.getConfig().setRestartStrategy(RestartStrategies.fixedDelayRestart(6, 600000));
        env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);
        env.getConfig().setTaskCancellationInterval(1000 * 60);
        env.getConfig().setTaskCancellationTimeout(1000 * 60 * 60);
        Properties propertiesKafka = new Properties();
        propertiesKafka.put("bootstrap.servers", "10.25.224.97:9092,10.25.224.98:9092");
        propertiesKafka.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        propertiesKafka.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        propertiesKafka.put("group.id","test.test");

        env.addSource(
                new FlinkKafkaConsumer011<>(
                        "test2",
                        new SimpleStringSchema(),
                        propertiesKafka).setStartFromTimestamp((System.currentTimeMillis()-1000*60*60*24))).print();

        env.execute("Kafka 0.10 Example");*/

    }
}
