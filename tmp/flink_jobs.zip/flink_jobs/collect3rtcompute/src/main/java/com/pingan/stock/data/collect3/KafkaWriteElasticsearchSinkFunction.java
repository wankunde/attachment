package com.pingan.stock.data.collect3;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.pingan.stock.data.collect3.util.DataMapping;
import org.apache.flink.api.common.functions.RuntimeContext;
import org.apache.flink.streaming.connectors.elasticsearch.ElasticsearchSinkFunction;
import org.apache.flink.streaming.connectors.elasticsearch.RequestIndexer;
import org.elasticsearch.action.update.UpdateRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by ZHANGXING130 on 2018/10/24.
 */
public class KafkaWriteElasticsearchSinkFunction implements ElasticsearchSinkFunction<KafkaMsgEntity> {
    private static Logger logger= LoggerFactory.getLogger(KafkaWriteElasticsearchSinkFunction.class);
    @Override
    public void process(KafkaMsgEntity element, RuntimeContext ctx, RequestIndexer indexer)  {
        Map<String,String> configMap  = ctx.getExecutionConfig().getGlobalJobParameters().toMap();
        long currentTime = System.currentTimeMillis();
        Timestamp todayTs = new Timestamp(currentTime);
        Timestamp yestodsyTs = new Timestamp(currentTime-24*60*60*1000);
        Timestamp beforeYestodsyTs = new Timestamp(currentTime-2*24*60*60*1000);
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");

        String yestodayStr = dateFormat.format(yestodsyTs);
        String beforeYestodayStr =  dateFormat.format(beforeYestodsyTs);
        String todayStr =  dateFormat.format(todayTs);

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(currentTime);
        calendar.set(Calendar.HOUR_OF_DAY,0);
        calendar.set(Calendar.MINUTE,0);
        calendar.set(Calendar.MILLISECOND,0);
        calendar.set(Calendar.SECOND,0);
        String fieldSuffix = yestodayStr;
        if (element.getEventTime() >= calendar.getTimeInMillis()) {
            fieldSuffix = todayStr;
            indexer.add(createUpdateRequest(element, configMap, yestodayStr, fieldSuffix));
        }
        //calendar.set(Calendar.HOUR_OF_DAY,8);
        //calendar.set(Calendar.MINUTE,30);
        //Boolean indexYestoday = (Boolean)element.getConfigObject().getOrDefault("indexyestoday",false);
        //if(System.currentTimeMillis()<calendar.getTimeInMillis()||indexYestoday) {
            indexer.add(createUpdateRequest(element, configMap, beforeYestodayStr, fieldSuffix));
        //}
    }
    private  UpdateRequest createUpdateRequest(KafkaMsgEntity element, Map<String,String> configMap, String indexSuffix, String fieldSuffix) {
        String custCode = element.getCustCode();
        Map<String,Object> calVDataMap = element.getCalcVDataObject();
        Map<String,Object> uppVDataMap = element.getUppVDataObject();
        Map<String,Object> sourceMap =new HashMap<>();
        String msgType = element.getMsgType();
        String updateSchema = configMap.get("updateDataSchema");
        JSONObject jsonObject = JSON.parseObject(updateSchema);
        JSONArray jsonArray = jsonObject.getJSONArray(msgType);
        String dynamicField = configMap.get("dynamicField");
        JSONObject dynamicFieldObject = JSON.parseObject(dynamicField);
        String index = configMap.get("es.index");
        String type = configMap.get("es.type");
        for(int i=0;i<jsonArray.size();i++){
            String key = jsonArray.getString(i);
            String[] keyArr = key.split(",");
            Boolean dynamic = dynamicFieldObject.getBoolean(keyArr[1]);
            String fieldKey = keyArr[1];
            String dyFieldKey = "";
            String mapKey = keyArr[2];
            String fieldType = keyArr[3];
            if(dynamic!=null&&dynamic){
                dyFieldKey = keyArr[1]+"_"+fieldSuffix;
            }
            if(mapKey.equals("uppV")){
                Object value = DataMapping.getFieldValue(fieldType,uppVDataMap.get(keyArr[0]));
                if(value!=null) {
                    sourceMap.put(fieldKey, value);
                    if (dynamic != null && dynamic) {
                        sourceMap.put(dyFieldKey, value);
                    }
                }
            }else{
                Object value = DataMapping.getFieldValue(fieldType,calVDataMap.get(keyArr[0]));
                if(value!=null) {
                    sourceMap.put(fieldKey, value);
                    if (dynamic != null && dynamic) {
                        sourceMap.put(dyFieldKey, value);
                    }
                }
            }
        }

        logger.info(index+"_"+indexSuffix+","+sourceMap.toString());

        UpdateRequest updateRequest = new UpdateRequest();
        updateRequest.index(index+"_"+indexSuffix);
        updateRequest.type(type);
        updateRequest.id(custCode);
        updateRequest.doc(sourceMap);
        //updateRequest.versionType(VersionType.EXTERNAL);
        //updateRequest.version()
        updateRequest.retryOnConflict(3);
        //updateRequest.setRefreshPolicy(WriteRequest.RefreshPolicy.WAIT_UNTIL);
        updateRequest.docAsUpsert(true);
        return updateRequest;
    }
}
