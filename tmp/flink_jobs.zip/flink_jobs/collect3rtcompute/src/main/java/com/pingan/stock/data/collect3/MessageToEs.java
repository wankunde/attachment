package com.pingan.stock.data.collect3;


import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.java.tuple.Tuple;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.timestamps.AscendingTimestampExtractor;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.connectors.elasticsearch5.ElasticsearchSink;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer08;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.util.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * Created by ZHANGXING130 on 2018/10/10.
 */
public class MessageToEs {
    private static Logger logger = LoggerFactory.getLogger(MessageToEs.class);
    public static void main(String[] args) throws Exception {
        logger.info("task start");
        InputStream in =  MessageToEs.class.getClassLoader().getResourceAsStream("config.properties");
        final ParameterTool parameterTool = ParameterTool.fromPropertiesFile(in);
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.getConfig().setRestartStrategy(RestartStrategies.fixedDelayRestart(6, 600000));
        //env.getConfig().setRestartStrategy(RestartStrategies.fixedDelayRestart(6, 6000));
        if(parameterTool.get("env").equals("prd")) {
            env.enableCheckpointing(10000, CheckpointingMode.EXACTLY_ONCE);
        }
        env.getConfig().setGlobalJobParameters(parameterTool); // make parameters available in the web interface
        env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);
        env.getConfig().setTaskCancellationInterval(1000*60);
        env.getConfig().setTaskCancellationTimeout(1000*60*60);
        Properties properties = parameterTool.getProperties();
        logger.info("config:"+properties.toString());
        Properties propertiesKafka = new Properties();
        propertiesKafka.put("bootstrap.servers",properties.getProperty("bootstrap.servers"));
        propertiesKafka.put("zookeeper.connect",properties.getProperty("zookeeper.connect"));
        String group = properties.getProperty("group.id");
        propertiesKafka.put("group.id",group);
        String topic = properties.getProperty("topic");
        List<String> topicList = Arrays.asList(topic.split(","));
           FlinkKafkaConsumer08 consumer = new FlinkKafkaConsumer08<>(
                topicList,
                new KafkaMsgEntitySchema(properties.getProperty("env")),
                properties);
           if(args.length>0&&args[0].equals("latest")){
               logger.info(args[0]);
               consumer.setStartFromLatest();
           }
/*        String taskUrl = properties.getProperty("task.url");
        String taskIndex = properties.getProperty("task.index");*/
        //DataStream<Tuple2<String, Boolean>> ds = env.addSource(new RulesSource(taskUrl,taskIndex));


        DataStream<KafkaMsgEntity> input = env
                .addSource(consumer).assignTimestampsAndWatermarks(new AscendingTimestampExtractor<KafkaMsgEntity>() {
                        @Override
                        public long extractAscendingTimestamp(KafkaMsgEntity kafkaMsgEntity) {
                            return System.currentTimeMillis();
                        }
                    }).filter(new FilterTypeFunction()).map(new EventTimeMapFunction())
                .filter(new TimeFilterFunction());


            /*SingleOutputStreamOperator<KafkaMsgEntity> streamOperator =
                    input.connect(ds.broadcast()).
                            flatMap(new RichCoFlatMapFunction<KafkaMsgEntity, Tuple2<String, Boolean>, KafkaMsgEntity>() {
                                private Map<String, Boolean> thresholdByType = new HashMap<>();

                                @Override
                                public void flatMap1(KafkaMsgEntity kafkaMsgEntity, Collector<KafkaMsgEntity> out) throws Exception {
                                    kafkaMsgEntity.getConfigObject().put("indexyestoday", thresholdByType.get("indexyestoday"));
                                    out.collect(kafkaMsgEntity);
                                }

                                @Override
                                public void flatMap2(Tuple2<String, Boolean> stringBooleanTuple2, Collector<KafkaMsgEntity> out) throws Exception {
                                    thresholdByType.put(stringBooleanTuple2.f0, stringBooleanTuple2.f1);
                                }
                            });*/

                KeyedStream<KafkaMsgEntity,Tuple> keyedStream = input.keyBy("custCode","msgType");
                DataStream<KafkaMsgEntity> outStream = keyedStream.timeWindow(Time.seconds(10)).
                        apply(new ApplyWindowFunction());

        String[] configArray = {"cluster.name",
                "bulk.flush.max.actions",
                "bulk.flush.backoff.enable",
                "bulk.flush.backoff.type",
                "bulk.flush.backoff.delay",
                "bulk.flush.backoff.retries"};
        Map<String, String> config = new HashMap<>();
        for (String configName:configArray) {
            config.put(configName,properties.getProperty(configName));
        }
        //config.put("client.transport.sniff", "true");

        List<InetSocketAddress> transports = new ArrayList<>();
        String[] esServers = properties.getProperty("es.servers").split(",");

        for (String esServer:esServers) {
            String[] esServerArray = esServer.split(":");
            logger.info(esServer+esServerArray[0]+esServerArray[1]);
            transports.add(new InetSocketAddress(esServerArray[0], Integer.parseInt(esServerArray[1])));
        }

        ElasticsearchSink elasticsearchSink =  new ElasticsearchSink<>(config, transports,
                new KafkaWriteElasticsearchSinkFunction(),new CustRetryRejectedExecutionFailureHandler());

        outStream.addSink(elasticsearchSink).name("es");
        env.execute("Collect3.KafkaToEs");
    }



}
