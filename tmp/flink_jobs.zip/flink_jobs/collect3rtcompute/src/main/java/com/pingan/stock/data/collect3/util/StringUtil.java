package com.pingan.stock.data.collect3.util;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public final class StringUtil {

	private StringUtil() {
	}

	private static Logger logger = LoggerFactory.getLogger(StringUtil.class);

	public static final String EMPTY = "";

	public static boolean isBlank(String str) {
		return StringUtils.isBlank(str);
	}

	public static boolean isNotBlank(String str) {
		return StringUtils.isNotBlank(str);
	}

	public static String formatDate(Date date, String format) {
		SimpleDateFormat df = new SimpleDateFormat(format);
		return df.format(date);
	}

	public static boolean equals(String str1, String str2) {
		return str1 == null ? str2 == null : str1.equals(str2);
	}

	/**
	 * 过滤掉超过3个字节的UTF8字符
	 * 
	 * @param text
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	public static String filterOffUtf8Mb4(String text) {
		String returnStr = null;
		try {
			byte[] bytes = text.getBytes("utf-8");
			ByteBuffer buffer = ByteBuffer.allocate(bytes.length);
			int i = 0;
			while (i < bytes.length) {
				short b = bytes[i];
				if (b > 0) {
					buffer.put(bytes[i++]);
					continue;
				}
				// 去掉符号位
				b += 256;
				if ((b ^ 0xC0) >> 4 == 0) {
					buffer.put(bytes, i, 2);
					i += 2;
				} else if ((b ^ 0xE0) >> 4 == 0) {
					buffer.put(bytes, i, 3);
					i += 3;
				} else if ((b ^ 0xF0) >> 4 == 0) {
					i += 4;
				} else {
					// 添加处理如b的指为-48等情况出现的死循环
					buffer.put(bytes[i++]);
					continue;
				}
			}
			buffer.flip();
			returnStr = new String(buffer.array(), "utf-8");
		} catch (UnsupportedEncodingException e) {
			logger.error("filter off Utf8Mb4 error : " + e.getMessage(), e);
			returnStr = "";
		}
		return returnStr;
	}

	public static String replaceFirst(String input, String target, String replacement) {
		int index = input.indexOf(target);
		int len = target.length();
		String begin = input.substring(0, index);
		String end = input.substring(len + index, input.length());
		return begin + replacement + end;
	}

	public static String urlencodeString(String string) throws Exception {
		return URLEncoder.encode(string, "utf-8").replace("+", "%20");
	}

	public static String urldecodeString(String string) throws Exception {
		return URLDecoder.decode(string, "utf-8").replace(" ", "+");
	}

	public static byte[] InputStreamToByte(InputStream is) throws IOException {
		ByteArrayOutputStream bytestream = new ByteArrayOutputStream();
		int ch;
		while ((ch = is.read()) != -1) {
			bytestream.write(ch);
		}
		byte imgdata[] = bytestream.toByteArray();
		bytestream.close();
		return imgdata;
	}

	/**
	 * 字符串比较，位數小的小，位數相等的時候比較字符
	 * 
	 * @param valueOf
	 * @param localSize
	 * @return
	 */
	public static int compare(String valueOf, String localSize) {
		if (valueOf.length() < localSize.length()) {
			return -1;
		} else if (valueOf.length() > localSize.length()) {
			return 1;
		} else {
			return valueOf.compareTo(localSize);
		}
	}

	/**
	 * 判断当前字符是否为纯数字
	 * 
	 * @param str
	 * @return
	 */
	public static boolean isDigit(String str) {
		String pattern = "-{0,1}\\d+";
		return str.matches(pattern);
	}

	public static boolean isFloat(String str) {
		String pattern = "-{0,1}\\d+(\\.\\d+)+";
		return str.matches(pattern);
	}

	public static long getSafeLong(String value) {
		if (isBlank(value)) {
			return 0;
		}
		if (!isDigit(value)) {
			if(isFloat(value)){
				return Float.valueOf(value).longValue();
			}else {
				return 0;
			}
		}
		return Long.valueOf(value);
	}

	public static boolean isBool(String value) {
		if ("true".equalsIgnoreCase(value) || "false".equalsIgnoreCase(value)) {
			return Boolean.valueOf(value);
		} else if (value.equals("1")) {
			return true;
		}
		return false;
	}

	public static boolean getSafeBoolean(String value) {
		if (isBlank(value)) {
			return false;
		}
		if (!isBool(value)) {
			return false;
		}
		return Boolean.valueOf(value);
	}

	public static double getSafeDouble(String value) {
		if (isBlank(value)) {
			return 0;
		}
		// if (!isFloat(value)) {
		// return 0;
		// }
		return Double.valueOf(value);
	}

	public static Integer getSafeInterger(String value) {
		if (isBlank(value)) {
			return 0;
		}
		if (!isDigit(value)) {
			return 0;
		}
		return Integer.valueOf(value);
	}

	public static short getSafeShort(String value) {
		if (isBlank(value)) {
			return 0;
		}
		if (!isDigit(value)) {
			return 0;
		}
		return Short.valueOf(value);
	}

	public static float getSafeFloat(String value) {
		if (isBlank(value)) {
			return 0;
		}
		if (!isFloat(value)) {
			return 0;
		}
		return Float.valueOf(value);
	}

	public static String getSafeString(String value) {
		if (isBlank(value)) {
			return "";
		}
		return value;
	}

	public static Object getSafeDate(String value) {
		if (isDigit(value)) {
			return value;
		}
		return value;
	}

	/**
	 * 字符串转map
	 * 
	 * @param str
	 * @return
	 */
	public static Map<String, Object> stringCastMap(String str) {
		if (isBlank(str)) {
			return null;
		}
		try {
			Map<String, Object> map = new HashMap<String, Object>();
			String[] split = str.split(",");
			for (int x = 0; x < split.length; x++) {
				String string = split[x];
				string = string.replace("{", "").replace("}", "");
				String[] mapString = string.split("=");
				String key = mapString[0].trim();
				String value = mapString[1].trim();
				map.put(key, value);
			}
			return map;
		} catch (Exception e) {
		}
		return null;
	}

}
