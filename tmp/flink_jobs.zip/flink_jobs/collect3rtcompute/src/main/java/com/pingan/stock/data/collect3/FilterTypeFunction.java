package com.pingan.stock.data.collect3;

import org.apache.flink.api.common.functions.RichFilterFunction;
import org.apache.flink.configuration.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * Created by ZHANGXING130 on 2018/10/24.
 */
public class FilterTypeFunction extends RichFilterFunction<KafkaMsgEntity> {
    private static Logger logger = LoggerFactory.getLogger(FilterTypeFunction.class);
    private List<String> msgTypeList  = new ArrayList<>();
    @Override
    public boolean filter(KafkaMsgEntity kafkaMsgEntity) throws Exception {
        String msgType = kafkaMsgEntity.getMsgType();
        String custCode = kafkaMsgEntity.getCustCode();
        if(!msgTypeList.contains(msgType)|| custCode==null||custCode.equals("")){
            return false;
        }else{
            return true;
        }
    }
    @Override
    public void open(Configuration parameters){
        Map<String,String> configMap = this.getRuntimeContext().getExecutionConfig().getGlobalJobParameters().toMap();
        String msgTypeConfig = configMap.get("msgtype");
        String[] msgTypeArray = msgTypeConfig.split(",");
        msgTypeList = Arrays.asList(msgTypeArray);
    }
}
