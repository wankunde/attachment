package pingan.com.collie_flow;

import java.util.Properties;

import org.apache.flink.api.common.functions.FilterFunction;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.functions.ReduceFunction;
import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.apache.flink.streaming.api.functions.timestamps.BoundedOutOfOrdernessTimestampExtractor;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer08;
import org.apache.flink.table.shaded.org.apache.commons.lang.StringUtils;
import org.apache.flink.util.Collector;
import org.apache.flink.util.OutputTag;

public class CollieFlowJobForMacsTracelog {

	public static void main(String[] args) throws Exception {
		
		final String influxdbURL;
		final String measurement;
		final String topic;
		final String kafkaURL;
		final String zkURL;
		final String groupID;
		final int windowLength;
		final int waterMark;
		
		final String code_2xx = ",code_2xx=1,";
		final String code_3xx = "code_3xx=0,";
		final String code_4xx = "code_4xx=0,";
		final String code_5xx = "code_5xx=0,";
		final String code_other = "code_other=0";
		
        try {
            final ParameterTool params = ParameterTool.fromArgs(args);
            influxdbURL = params.get("influxdburl") == null ? 
            		"http://10.17.162.186:8086/write?db=app" : params.get("influxdburl");
            measurement = params.get("measurement") == null ? 
            		"app_server_log_test" :params.get("measurement");
            topic = params.get("topic") == null ? 
            		"SMT-HS-JAD-DMZWEB-MACS-tracelog" : params.get("topic");
            kafkaURL = params.get("kafkaurl") == null ? 
            		"10.17.187.61:9092,10.17.187.62:9092" : params.get("kafkaurl");
            zkURL = params.get("zkurl") == null ? 
            		"26.6.0.24:2181,26.6.0.25:2181,26.6.0.26:2181,26.6.0.27:2181,26.6.0.31:2181/kafka/prdbigdata" : params.get("zkurl");
            groupID = params.get("groupid") == null ? 
            		"sa_app_test" : params.get("groupid");
            windowLength = params.getInt("windowlength") == 0 ? 
            		1 : params.getInt("windowlength");
            waterMark = params.getInt("watermark") == 0 ? 
            		1 : params.getInt("watermark");
        } catch (Exception e) {
        	System.out.println(e.getMessage());
            return;
        }
		
		Properties pro = new Properties();
		pro.put("zookeeper.connect", zkURL);
		pro.put("group.id", groupID);
		pro.put("bootstrap.servers", kafkaURL);
		pro.put("auto.commit.enable", true);
		
		
		StreamExecutionEnvironment env = StreamExecutionEnvironment
				.getExecutionEnvironment(); 
		env.getConfig().disableSysoutLogging(); 
		env.getConfig().setRestartStrategy(
				RestartStrategies.fixedDelayRestart(4, 10000));
		//快照
		env.enableCheckpointing(5000);
		
		//设置flink时间类型
		env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime);
		
		final OutputTag<Tuple3<String, DataEntity, Long>> lateOutputTag = new OutputTag<Tuple3<String, DataEntity, Long>>("late-data"){
			private static final long serialVersionUID = 1L;};
			
		SingleOutputStreamOperator<Tuple3<String, DataEntity, Long>>  operator = 
				env.addSource(new FlinkKafkaConsumer08<String>(topic, new SimpleStringSchema(),
						pro))
				.filter(new FilterFunction<String>() {	
					private static final long serialVersionUID = 1L;
					@Override
					public boolean filter(String value) throws Exception {
						if(StringUtils.isNotBlank(value))
							if(value.contains("com.hundsun.macs.servicecore.interfaces.task.MacsTask"))
								return true;
						return false;
					}
				})
				.flatMap(new FlatMapFunction<String, Tuple3<String, DataEntity, Long>>() {
					static final long serialVersionUID = 1L;
					@Override
					public void flatMap(String value, Collector<Tuple3<String, DataEntity, Long>> out)
							throws Exception {
							StringBuilder sb = new StringBuilder(value);
							
							String subsystemnoStr = "\\\"\\\"subsystemno\\\"\\\":";
							String subsystemno = getNumber(sb,subsystemnoStr).trim();
							String methodStr = "\\\"\\\"method\\\"\\\":";
							String method = getNumber(sb,methodStr).trim();
							String endticketStr = "\\\"\\\"endticket\\\"\\\":";
							long endticket = Long.parseLong(getNumber(sb,endticketStr).trim());
							String startticketStr = "\\\"\\\"startticket\\\"\\\":";
							long startticket = Long.parseLong(getNumber(sb,startticketStr).trim());
							
							long res_time = endticket - startticket;
							String item = subsystemno +"|"+ method;
							
							DataEntity entity = new DataEntity(res_time);
							
							//将endticket 作为该条数据的 timestample
							out.collect(new Tuple3<String, DataEntity, Long>(item,entity,endticket));
					}
				})
				.assignTimestampsAndWatermarks(new BoundedOutOfOrdernessTimestampExtractor<Tuple3<String, DataEntity, Long>>(Time.minutes(waterMark)) {
					private static final long serialVersionUID = 1L;

					@Override
					public long extractTimestamp(Tuple3<String, DataEntity, Long> element) {
						if(element != null) {
							return element.f2;
						}else {
							return 0;
						}
					}
				})
				.keyBy(0)
				.timeWindow(Time.minutes(windowLength))
				.sideOutputLateData(lateOutputTag)
				.reduce(new ReduceFunction<Tuple3<String, DataEntity, Long>>() {
					private static final long serialVersionUID = 1L;
					@Override
					public Tuple3<String, DataEntity, Long> reduce(Tuple3<String, DataEntity, Long> value1,
							Tuple3<String, DataEntity, Long> value2) throws Exception {
						DataEntity tagV1 = null;
						DataEntity tagV2 = null;
						
						if(value1 == null)
							tagV1 = new DataEntity();
						else 
							tagV1 = value1.f1;
						
						if(value2 == null)
							tagV2 = new DataEntity();
						else
							tagV2 = value2.f1;
							
						
						String item = value1.f0;
						Long timeStample = value1.f2;
						
						tagV1.reduce(tagV2); 
						
						return new Tuple3<String, DataEntity, Long>(item,tagV1,timeStample);
					}
				});
		operator.addSink(new RichSinkFunction<Tuple3<String, DataEntity, Long>>(){

			private static final long serialVersionUID = 1L;
			
			@Override
			public void invoke(Tuple3<String, DataEntity, Long> value) throws Exception {
				
				String item = value.f0;
				long timestample = value.f2;
				String message = value.f1.toString(); 
				
				StringBuilder sb = new StringBuilder();
				sb.append( measurement)
				  .append(",")
				  .append("item=")
				  .append(item)
				  .append(" ")
				  .append(message)
				  .append(code_2xx)
				  .append(code_3xx)
				  .append(code_4xx)
				  .append(code_5xx)
				  .append(code_other)
				  .append(" ")
				  .append(timestample)
				  .append(getRandomNs())
				  .append("\r\n");
				
				SendPool.addData(sb.toString(),influxdbURL);
			}
		});
		  
		operator.getSideOutput(lateOutputTag)
				.assignTimestampsAndWatermarks(new BoundedOutOfOrdernessTimestampExtractor<Tuple3<String, DataEntity, Long>>(Time.minutes(waterMark)) {
					private static final long serialVersionUID = 1L;

					@Override
					public long extractTimestamp(Tuple3<String, DataEntity, Long> element) {
						if(element != null) {
							long timestample = element.f2;
							return timestample;
						}else {
							return 0;
						}
					}
				})
				.keyBy(0)
				.timeWindow(Time.minutes(windowLength))
				.reduce(new ReduceFunction<Tuple3<String, DataEntity, Long>>() {
					private static final long serialVersionUID = 1L;
					@Override
					public Tuple3<String, DataEntity, Long> reduce(Tuple3<String, DataEntity, Long> value1,
							Tuple3<String, DataEntity, Long> value2) throws Exception {
						DataEntity tagV1 = value1.f1;
						DataEntity tagV2 = value2.f1;
						
						String item = value1.f0;
						Long timeStample = value1.f2;
						
						tagV1.setPv(tagV1.getPv() + tagV2.getPv());
						
						return new Tuple3<String, DataEntity, Long>(item,tagV1,timeStample);
					}
				})
				.addSink(new RichSinkFunction<Tuple3<String, DataEntity, Long>>() {
					private static final long serialVersionUID = 1L;
					@Override
					public void invoke(Tuple3<String, DataEntity, Long> record) throws Exception{
						DataEntity entity = record.f1;
						String item = record.f0;
						Long timestample = record.f2;
						
						StringBuilder sb = new StringBuilder();
						sb.append( measurement)
						  .append(",")
						  .append("item=")
						  .append(item)
						  .append(" ")
						  .append("out_side=")
						  .append(entity.getPv())
						  .append(code_2xx)
						  .append(code_3xx)
						  .append(code_4xx)
						  .append(code_5xx)
						  .append(code_other)
						  .append(" ")
						  .append(timestample)
						  .append(getRandomNs())
						  .append("\r\n");
						
						SendPool.addData(sb.toString(),influxdbURL);
						System.out.println("warning : there is out side data , pv = "+entity.getPv());
					}
				});
				 
		env.execute("Collie Flow Job For Macs Tracelog");
	}
	
	/**
	 * 该方法用来提取给定参数后的连续多位整数并以字符串形式返回
	 * @param sb
	 * @param start
	 * @return
	 */
	public static String getNumber(StringBuilder sb,String start) {
		
		int index = sb.indexOf(start) + start.length();
		char[] number = new char[20];
		char c = sb.charAt(index);
		int i = 0;
		while (!String.valueOf(c).matches(",")) {
			index++;
			if(String.valueOf(c).matches("^[0-9]*$")) {
				number[i] = c;
				i++;
			}
			if(index < sb.length()) {
				c = sb.charAt(index);
			}else {
				break;
			}
		}
		return String.copyValueOf(number);
	}
	
	private static String getRandomNs() {
		StringBuilder sb = new StringBuilder();
		for(int i = 0 ; i<9 ; i++) {
			sb.append((int)(Math.random()*9));
		}
		return sb.toString();
	}
}
