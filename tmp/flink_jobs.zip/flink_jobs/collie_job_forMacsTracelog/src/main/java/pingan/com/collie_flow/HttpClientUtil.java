package pingan.com.collie_flow;

import java.io.IOException;

import org.apache.http.ParseException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
/*
 * 利用HttpClient进行post请求的工具类
 */
public class HttpClientUtil {
	
	public static HttpClientBuilder bulider;
	
	static{
		bulider = HttpClientBuilder.create();
		bulider.setMaxConnTotal(10);
	}
		
	public static String send(String data,String url) 
			throws ParseException, IOException{
		//创建httpclient对象
		CloseableHttpClient client = HttpClients.createDefault();
		//创建post方式请求对象
		HttpPost httpPost = new HttpPost(url);
		
		//设置参数到请求对象中
		httpPost.setEntity(new ByteArrayEntity(data.getBytes()));

		//设置header信息
		//以二进制流传输数据
		httpPost.setHeader("Content-type", "application/octet-stream");
		
		//提交数据
		client.execute(httpPost);
        return "";
	}
	
}