package pingan.com.collie_flow;

import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SendPool {
	
	private static ExecutorService pool;
	
	private static SendPool send = new SendPool();
	
	private static Queue<String> dataQueue = new LinkedList<String>();
	
	private SendPool() {
		pool = Executors.newFixedThreadPool(10);
	}
	
	public static SendPool init() {
		return send;
	}
	
	public static void addData(String data,String url) {
		dataQueue.offer(data);
		
		if(dataQueue.size() > 10) {
			StringBuilder sb = new StringBuilder();
			for(int i = 0 ; i < 10 ; i++) {
				String s = dataQueue.poll();
				if(s != null) {
					sb.append(s);
				}else {
					break;
				}
			}
			send(sb.toString(),url);
		}
	}
	
	public static void send(String data,String url) {
		pool.execute(new Runnable() {
			@Override
			public void run() {
				try {
					HttpClientUtil.send(data,url);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
