package pingan.com.collie_flow;

import java.io.Serializable;

public class DataEntity implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private int pv;
	private int failed;
	private int success;
	private long response_time_total;
	private int du_300;
	private int du_500;
	private int du_1000;
	private int du_3000;
	private int du_5000;
	private int du_10000;
	private int ge_10000;
	
	public DataEntity() {}
	
	public DataEntity(long dif) {
		
		setPv(1);
		
		if(dif >3000) 
			failed = 1;
		
		if(dif <= 3000) 
			success = 1;
		
		setResponse_time_total(dif);
		
		if(dif <= 300) 
			du_300 = 1;
		
		if(dif <= 500 &&  dif > 300) 
			du_500 = 1;
		
		if(dif <= 1000 &&  dif > 500) 
			du_1000 = 1;
		
		if(dif <= 3000 &&  dif > 1000) 
			du_3000 = 1;
		
		if(dif <= 5000 &&  dif > 3000) 
			du_5000 = 1;
		
		if(dif <= 10000 &&  dif > 5000) 
			du_10000 = 1;
		
		if(dif > 10000) 
			ge_10000 = 1;
	}

	public int getFailed() {
		return failed;
	}

	public void setFailed(int failed) {
		this.failed = failed;
	}

	public int getSuccess() {
		return success;
	}

	public void setSuccess(int success) {
		this.success = success;
	}

	public long getResponse_time_total() {
		return response_time_total;
	}

	public void setResponse_time_total(long response_time_total) {
		this.response_time_total = response_time_total;
	}

	public int getDu_300() {
		return du_300;
	}

	public void setDu_300(int du_300) {
		this.du_300 = du_300;
	}

	public int getDu_500() {
		return du_500;
	}

	public void setDu_500(int du_500) {
		this.du_500 = du_500;
	}

	public int getDu_1000() {
		return du_1000;
	}

	public void setDu_1000(int du_1000) {
		this.du_1000 = du_1000;
	}

	public int getDu_3000() {
		return du_3000;
	}

	public void setDu_3000(int du_3000) {
		this.du_3000 = du_3000;
	}

	public int getDu_5000() {
		return du_5000;
	}

	public void setDu_5000(int du_5000) {
		this.du_5000 = du_5000;
	}

	public int getDu_10000() {
		return du_10000;
	}

	public void setDu_10000(int du_10000) {
		this.du_10000 = du_10000;
	}

	public int getGe_10000() {
		return ge_10000;
	}

	public void setGe_10000(int ge_10000) {
		this.ge_10000 = ge_10000;
	}

	public int getPv() {
		return pv;
	}

	public void setPv(int pv) {
		this.pv = pv;
	}
	
	public DataEntity reduce(DataEntity entity) {
		
		this.setPv(this.getPv() + entity.getPv());
		this.setSuccess(this.getSuccess() + entity.getSuccess());
		this.setFailed(this.getFailed() + entity.getFailed());
		this.setResponse_time_total(this.getResponse_time_total() + entity.getResponse_time_total());
		this.setDu_300(this.getDu_300() + entity.getDu_300());
		this.setDu_500(this.getDu_500() + entity.getDu_500());
		this.setDu_1000(this.getDu_1000() + entity.getDu_1000());
		this.setDu_3000(this.getDu_3000() + entity.getDu_3000());
		this.setDu_5000(this.getDu_5000() + entity.getDu_5000());
		this.setDu_10000(this.getDu_10000() + entity.getDu_10000());
		this.setGe_10000(this.getGe_10000() + entity.getGe_10000());
		
		return this;
	}

	@Override
	public String toString() {
		return "pv=" + pv + ",failed=" + failed + ",success=" + success + ",du_avg="
				+ (response_time_total/pv) + ",du_300=" + du_300 + ",du_500=" + du_500 + ",du_1000=" + du_1000
				+ ",du_3000=" + du_3000 + ",du_5000=" + du_5000 + ",du_10000=" + du_10000 + ",ge_10000=" + ge_10000;
	}
}
