import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class SendMsg {


//
//
//    public static void main(String[] args) {
//        ApplicationContext context = new FileSystemXmlApplicationContext("classpath:applicationContext-msg.xml");
//        HttpAsyncAppender httpAsyncAppender = (HttpAsyncAppender)context.getBean("httpAsyncAppender");
//        int i=0;
//        while(true) {
//            i++;
//            Map<String, Object> body = new HashMap<>();
//            body.put("isFirstBindOfWeChatAccount", "0");
//            body.put("sid", ""+i);
//            body.put("isFirstBindOfUserId", "1");
//            body.put("userId", "10626921");
//            body.put("unionId", "thirdsub180827100001");
//            body.put("aid", "");
//            body.put("bindDate", "2018-10-08 18:56:42");
//            body.put("registerTime", "2018-10-08 16:56:42");
//            body.put("openId", "sub180827000001");
//            String type = "USERSERVICE_WXBD";
//            String messageId = UUID.randomUUID().toString();
//            Boolean result = httpAsyncAppender.offer(type, messageId, body);
//            System.out.println(i);
//            System.out.println(System.in.read());
//    }
}
