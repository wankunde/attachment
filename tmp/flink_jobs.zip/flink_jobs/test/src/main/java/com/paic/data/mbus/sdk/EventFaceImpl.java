package com.paic.data.mbus.sdk;

import com.alibaba.fastjson.JSONObject;
import com.paic.data.mbus.sdk.annotation.MsgType;
import com.paic.data.mbus.sdk.subscribe.TriggerEventFace;
/**
 * 消息处理类开发<br>
 * 1、实现接口TriggerEventFace<T> <br>
 * 2、@MsgType //配置要订阅消息类型，处理多个类型以逗号分隔<br>
 * 3、注册到消费工厂 ConsumerFactory<br>
 * @author RUANXIEQUAN682
 */
@MsgType("VAST_APP_EVENT_5,CALC.VAST_APP_EVENT_5")
public class EventFaceImpl implements TriggerEventFace<JSONObject> {
	@Override
	public void onEvent(JSONObject data) {
		System.out.println(this.getClass().getName()+" 成功接收到消息:"+data.toJSONString());
	}
}
