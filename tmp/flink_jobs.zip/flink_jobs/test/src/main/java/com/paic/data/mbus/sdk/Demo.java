package com.paic.data.mbus.sdk;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import com.paic.data.mbus.sdk.http.ApiHttpClientService;
import com.paic.data.mbus.sdk.http.ApiHttpClientServiceImpl;
import com.paic.data.mbus.sdk.http.HttpAsyncAppender;
import com.paic.data.mbus.sdk.subscribe.ConsumerFactory;

public class Demo {
    private ApiHttpClientService api = null;
    private ConsumerFactory consumer = null;
    private HttpAsyncAppender appender = null;

    /**
     * 初始化并获取数据发送端服务类（优先使用Spring注入方式）
     *
     * @return
     */
    public synchronized HttpAsyncAppender getSender() {
        if (api == null) {
            api = new ApiHttpClientServiceImpl();
        }
        if (appender == null) {
            appender = new HttpAsyncAppender(api);
            appender.init();
        }
        return appender;
    }

    /**
     * 初始化数据接收端服务类（优先使用Spring注入方式）
     *
     * @return
     */
    public synchronized ConsumerFactory getConsumer() {
        if (api == null) {
            api = new ApiHttpClientServiceImpl();
        }
        if (consumer == null) {
            consumer = new ConsumerFactory(api);
            consumer.init();
        }
        return consumer;
    }

    /**
     * 发送数据
     */
    public void sendData() {
        //消息类型
        String msgType="VAST_APP_EVENT_5";
        for (int i = 0; i < 100; i++) {
            //消息id
            String messageId = UUID.randomUUID().toString();

            //消息体
            Map<String, Object> messageBody = new HashMap<>();
            messageBody.put("userid", "1821271");
            messageBody.put("click_time", "2018-10-23 17:21:07+0800");

            messageBody.put("helloworld", "HELLOWORLD测试");

            //发送消息
            getSender().offer(msgType, messageId, messageBody);
        }

    }

    /**
     * 消费数据
     */
    public void receiveData() {
        //实例化消息处理类
        EventFaceImpl eventImpl = new EventFaceImpl();
        //注册消息处理对象
        getConsumer().register(eventImpl);
    }

    public static void main(String[] args) {
        Demo demo = new Demo();
//        demo.receiveData();
        demo.sendData();

        try {
            Thread.sleep(30000L);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        demo.getSender().destroy();
//        demo.getConsumer().destroy();
    }

}
