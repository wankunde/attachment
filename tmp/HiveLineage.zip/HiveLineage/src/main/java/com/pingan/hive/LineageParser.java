package com.pingan.hive;

import com.google.common.collect.Lists;
import com.google.gson.Gson;
import org.apache.hadoop.hive.common.ObjectPair;
import org.apache.hadoop.hive.metastore.api.FieldSchema;
import org.apache.hadoop.hive.metastore.api.Table;
import org.apache.hadoop.hive.ql.QueryPlan;
import org.apache.hadoop.hive.ql.exec.ColumnInfo;
import org.apache.hadoop.hive.ql.exec.SelectOperator;
import org.apache.hadoop.hive.ql.exec.Utilities;
import org.apache.hadoop.hive.ql.hooks.*;
import org.apache.hadoop.hive.ql.optimizer.lineage.LineageCtx.Index;
import org.apache.hadoop.hive.ql.plan.HiveOperation;
import org.apache.hadoop.hive.ql.session.SessionState;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * Created by WANGYI422 on 2018/10/31.
 */
public class LineageParser implements ExecuteWithHookContext{
    private static final Logger LOG = LoggerFactory.getLogger(LineageParser.class);

    private static final HashSet<String> OPERATION_NAMES = new HashSet<>();
    static {
        OPERATION_NAMES.add(HiveOperation.QUERY.getOperationName());
        OPERATION_NAMES.add(HiveOperation.CREATETABLE_AS_SELECT.getOperationName());
        OPERATION_NAMES.add(HiveOperation.ALTERVIEW_AS.getOperationName());
        OPERATION_NAMES.add(HiveOperation.CREATEVIEW.getOperationName());
    }

    private List<EntityObject> getEntitys(QueryPlan plan, Index index) {
        LinkedHashMap<String, ObjectPair<SelectOperator,
                org.apache.hadoop.hive.ql.metadata.Table>> finalSelOps = index.getFinalSelectOps();
        Map<String, EntityObject> entityCache = new LinkedHashMap<>();
        List<EntityObject> entitys = new ArrayList<>();

        for (ObjectPair<SelectOperator,
                org.apache.hadoop.hive.ql.metadata.Table> pair : finalSelOps.values()) {
            List<FieldSchema> fieldSchemas = plan.getResultSchema().getFieldSchemas();
            SelectOperator finalSelOp = pair.getFirst();
            org.apache.hadoop.hive.ql.metadata.Table table = pair.getSecond();

            String destTableName = null;
            List<String> colNames = null;

            if (table != null) {
                destTableName = table.getDbName() + "." + table.getTableName();
                fieldSchemas = table.getCols();
            } else {
                for (WriteEntity output : plan.getOutputs()) {
                    Entity.Type entityType = output.getType();
                    if (entityType == Entity.Type.TABLE || entityType == Entity.Type.PARTITION) {
                        table = output.getTable();
                        destTableName = table.getDbName() + "." + table.getTableName();
                        List<FieldSchema> cols = table.getCols();
                        if (cols != null && !cols.isEmpty()) {
                            colNames = Utilities.getColumnNamesFromFieldSchema(cols);
                        }
                        break;
                    }
                }
//                log("destination table is null, should use CREATE TABLE AS SELECT clause");
//                return entitys;
            }

            Map<ColumnInfo, LineageInfo.Dependency> colMap = index.getDependencies(finalSelOp);
            List<LineageInfo.Dependency> dependencies = colMap != null ? Lists.newArrayList(colMap.values()) : null;
            int fieldsNum = fieldSchemas.size();

            if (dependencies == null || dependencies.size() != fieldsNum) {
                log("Result schema has " + fieldsNum
                        + " fields, but we don't get as many dependencies");
            } else {
                for (int i = 0; i < fieldsNum; i++) {
                    EntityObject entity = getOrCreateEntity(entityCache,
                            getQualifiedName(i, table.getDbName(), table.getTableName(), colNames, fieldSchemas));
                    LineageInfo.Dependency dep = dependencies.get(i);
                    addEntity(entityCache, entitys, dep.getBaseCols(), entity, dep.getExpr());
                }
            }
        }
        return entitys;
    }

    private void log(String error) {
        SessionState.LogHelper console = SessionState.getConsole();
        if (console != null) console.printError(error);
    }

    private EntityObject getOrCreateEntity(Map<String, EntityObject> cache, String label) {
        EntityObject entity = cache.get(label);
        if (entity == null) {
            entity = new EntityObject(label.split("\\."));
            cache.put(label, entity);
        }
        return entity;
    }

    private String getQualifiedName(int fieldIndex, String dbName, String tableName, List<String> colNames, List<FieldSchema> fieldSchemas) {
        String fieldName = fieldSchemas.get(fieldIndex).getName();
        String[] parts = fieldName.split("\\.");
        if (dbName != null && tableName != null) {
            String colName = parts[parts.length - 1];
            if (colNames != null && !colNames.contains(colName)) colName = colNames.get(fieldIndex);
            return dbName + "." + tableName + "." + colName;
        }
        return "unknown.unknown." + parts[parts.length - 1];
    }

    private void addEntity(Map<String, EntityObject> cache, List<EntityObject> entitys,
                         Set<LineageInfo.BaseColumnInfo> srcCols, EntityObject entity, String expr) {
        List<EntityObject> deps = setDependencyEntity(cache, srcCols, entity);
        entity.setExpr(expr);
        entity.setDependency(deps);
        entitys.add(entity);
    }

    private List<EntityObject> setDependencyEntity(
            Map<String, EntityObject> cache, Collection<LineageInfo.BaseColumnInfo> baseCols, EntityObject entity) {
        List<EntityObject> deps = new LinkedList<>();
        if (baseCols != null && !baseCols.isEmpty()) {
            for (LineageInfo.BaseColumnInfo bCol : baseCols) {
                Table table = bCol.getTabAlias().getTable();
                if (table.isTemporary()) continue;

                String tableName = table.getDbName() + "." + table.getTableName();
                FieldSchema fieldSchema = bCol.getColumn();
                String label = tableName + ".null";
                if (fieldSchema != null) {
                    label = tableName + "." + fieldSchema.getName();
                    if ((entity.getDbName() + "." + entity.getTableName() + "." + entity.getColName()).equals(label)) {
                        label = label + "(self)";
                    }
                }
                deps.add(getOrCreateEntity(cache, label));
            }
        }
        return deps;
    }

    private String printEdges(List<EntityObject> deps) {
        Gson gson = new Gson();
        return gson.toJson(deps);
    }

    @Override
    public void run(HookContext hookContext) throws Exception {
        QueryPlan plan = hookContext.getQueryPlan();
        Index index = hookContext.getIndex();
        SessionState ss = SessionState.get();
        if (ss != null && index != null &&
                OPERATION_NAMES.contains(plan.getOperationName())) {
            String queryStr = plan.getQueryStr().trim();
            LOG.info("query String: " + queryStr);
            List<EntityObject> entitys = getEntitys(plan, index);
            LOG.info(printEdges(entitys));
        }
    }
}
