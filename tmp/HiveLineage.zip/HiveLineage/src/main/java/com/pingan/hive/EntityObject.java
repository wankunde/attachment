package com.pingan.hive;

import org.apache.commons.collections.ListUtils;
import org.apache.commons.lang.StringUtils;

import java.util.List;

/**
 * Created by WANGYI422 on 2018/11/1.
 */
public class EntityObject {
    private String dbName;
    private String tableName;
    private String colName;
    private String expr;
    private List<EntityObject> dependency;

    public EntityObject(String dbName, String tableName, String colName, String expr, List<EntityObject> dependency) {
        this.dbName = dbName;
        this.tableName = tableName;
        this.colName = colName;
        this.expr = expr;
        this.dependency = dependency;
    }

    public EntityObject(String dbName, String tableName, String colName) {
        this(dbName, tableName, colName, null, null);
    }

    public EntityObject(String[] in) {
        this(in[0], in[1], in[2]);
    }

    public String getDbName() {
        return dbName;
    }

    public String getTableName() {
        return tableName;
    }

    public String getColName() {
        return colName;
    }

    public String getExpr() {
        return expr;
    }

    public List<EntityObject> getDependency() {
        return dependency;
    }

    public void setDbName(String dbName) {
        this.dbName = dbName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public void setColName(String colName) {
        this.colName = colName;
    }

    public void setExpr(String expr) {
        this.expr = expr;
    }

    public void setDependency(List<EntityObject> dependency) {
        this.dependency = dependency;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        if (expr != null) {
            sb.append(", expr=").append(expr);
        }
        if (dependency != null) {
            sb.append(", dependency=");
            for (EntityObject e : dependency) {
                sb.append(e.toString() + ":");
            }
            sb.deleteCharAt(sb.length() - 1);
        }
        return "Entity{" +
                "dbName='" + dbName + '\'' +
                ", tableName='" + tableName + '\'' +
                ", colName='" + colName + '\'' + sb.toString() + '}';
    }

    @Override
    public int hashCode() {
        return 31 * (
                31 * (
                        31 * (
                                31 * (
                                        31 + dbName.hashCode()
                                ) + tableName.hashCode()
                        ) + colName.hashCode()
                ) + expr.hashCode()
        ) + ListUtils.hashCodeForList(dependency);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof EntityObject)) {
            return false;
        }
        EntityObject entity = (EntityObject) obj;
        return StringUtils.equals(entity.dbName, dbName) && StringUtils.equals(entity.tableName, tableName) &&
                StringUtils.equals(entity.colName, colName) && StringUtils.equals(entity.expr, expr) &&
                ListUtils.isEqualList(entity.dependency, dependency);
    }
}
