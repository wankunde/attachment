package com.pingan.hive;

import org.apache.hadoop.hive.conf.HiveConf;
import org.apache.hadoop.hive.ql.CommandNeedRetryException;
import org.apache.hadoop.hive.ql.Driver;
import org.apache.hadoop.hive.ql.processors.CommandProcessorResponse;
import org.apache.hadoop.hive.ql.session.SessionState;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * Created by WANGYI422 on 2018/10/30.
 */
public class Main {
    private HiveConf conf;
    private SessionState ss;
    private Driver driver;

    public void setUp(String preHook, String postHook) throws Exception {
        conf = new HiveConf();
        if (preHook != null) conf.set("hive.exec.pre.hooks", preHook);
        if (postHook != null) conf.set("hive.exec.post.hooks", postHook);
        ss = new SessionState(conf);
        ss = SessionState.start(ss);
        SessionState.setCurrentSessionState(ss);
        driver = new Driver(conf);
    }

    public void runCommand(String cmd) throws Exception {
        runCommandWithDelay(cmd, 0);
    }

    public void runCommandWithDelay(String cmd, int sleep) throws Exception{
        ss.setCommandType(null);
        CommandProcessorResponse response = driver.run(cmd);
        if (response.getResponseCode() != 0) throw new RuntimeException("CommandProcessorResponse is not 0");
        if (sleep >= 0) Thread.sleep(sleep);
    }

    public void printResults(List<String> res) throws IOException, CommandNeedRetryException {
        if (res == null) return;
        driver.getResults(res);
        for (String row : res) {
            System.out.println(row);
        }
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            System.out.println("Missing parameters!\n" +
                    "Usage: java -jar <Jar.file> <properties>");
            return;
        }

        Properties properties = new Properties();
        FileInputStream in = new FileInputStream(args[0]);
        properties.load(in);
        in.close();

        String preHook = properties.getProperty("prehook",null);
        String postHook = properties.getProperty("posthook", null);
        Main main = new Main();
        main.setUp(preHook, postHook);
        main.runCommand(properties.getProperty("sql"));
        List<String> values = new ArrayList<>();
        main.printResults(values);

    }
}
