package com.paic.data.hive.common.udf;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;


public class MeasureObjExMapTest {
	
	@Test
	public void test() {
		Map<String, String> aa = new HashMap<>();
		aa.put("ygxm-relation-202031_last", "胡军浩");
		aa.put("time-relation-202031_last", "20160612");
		
		Map<String, String> bb = new HashMap<>();
		bb.put("ygxm-relation-202031_last", "王俊斌");
		bb.put("time-relation-202031_last", "20160912");
		
		MeasureObjExMap test = new MeasureObjExMap();
		Map<String, String> result = test.evaluate(aa, bb);
		System.out.println(result.get("ygxm-relation-202031_last"));

	}

}
