package com.paic.data.hive.common.udf;

import java.text.ParseException;

import org.junit.Assert;
import org.junit.Test;

public class MimimumExTest {
	
	@Test
	public void basicTest() throws ParseException{
		MimimumEx min = new MimimumEx();
		
		Assert.assertNull(min.evaluate(5, 12,null));
		Assert.assertNull(min.evaluate(5, 12,5));
		Assert.assertNull(min.evaluate(-1, 6));
		Assert.assertNull(min.evaluate(0, 6));
		Assert.assertNull(min.evaluate(Integer.MAX_VALUE, 6));
		
		Assert.assertEquals(7, min.evaluate(3, 3,23,5,7,9,51,78).intValue());
		Assert.assertEquals(3, min.evaluate(3, 3,23,5,-7,9,51,-78).intValue());
		Assert.assertEquals(3, min.evaluate(3, 3,23,5,null,-7,9,51,-78).intValue());
		
		
		Assert.assertEquals(23L, min.evaluate(5, 3L,23L,5L,7L,9L,51L,78L).longValue());
		
		Assert.assertEquals(9.0, min.evaluate(4, 3.0,23.78,5.45,7.0,9.0,51.0,78.0).doubleValue(), 0.1);
		Assert.assertEquals(5.78, min.evaluate(4, 3.0, 5.78, 5.45, 4.0, 9.0, 51.0, 78.0).doubleValue(), 0.1);
	}

}
