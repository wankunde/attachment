package com.paic.data.hive.common.udf.profite;

import org.apache.hadoop.hive.common.type.HiveDecimal;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.Arrays;

/**
 * Created by wankun603 on 2018-06-22.
 */
public class MaxProfiteTest {

  @Test
  public void testMaxProfite() throws HiveException {
    MaxProfite.MaxProfiteEvaluator evaluator = new MaxProfite.MaxProfiteEvaluator();
    MaxProfite.MaxProfiteEvaluator.StocksBuf agg = new MaxProfite.MaxProfiteEvaluator.StocksBuf();
    Object[] res = null;
    // Test 1
    evaluator.reset(agg);
    agg.dts = Arrays.asList("1", "2", "3", "4", "5", "6");
    agg.values = Arrays.asList(toD(5), toD(6), toD(2), toD(5), toD(1), toD(3));
    System.out.println("\n\nTest 1 ");
    res = (Object[]) evaluator.terminate(agg);
    System.out.println(Arrays.toString(res));

    // Test 2
    evaluator.reset(agg);
    agg.dts = Arrays.asList("1", "2", "3", "4", "5", "6");
    agg.values = Arrays.asList(toD(4), toD(2), toD(3), toD(1), toD(6), toD(5));
    System.out.println("\n\nTest 2 ");
    res = (Object[]) evaluator.terminate(agg);
    System.out.println(Arrays.toString(res));

    // Test 3
    evaluator.reset(agg);
    agg.dts = Arrays.asList("1", "2", "3", "4", "5", "6");
    agg.values = Arrays.asList(toD(10), toD(8), toD(7), toD(6.5), toD(2), toD(1));
    System.out.println("\n\nTest 3 ");
    res = (Object[]) evaluator.terminate(agg);
    System.out.println(Arrays.toString(res));

    // Test 4
    evaluator.reset(agg);
    agg.dts = Arrays.asList("1");
    agg.values = Arrays.asList(toD(5));
    System.out.println("\n\nTest 4 ");
    res = (Object[]) evaluator.terminate(agg);
    System.out.println(Arrays.toString(res));

    evaluator.reset(agg);
    agg.dts = Arrays.asList();
    agg.values = Arrays.asList();
    System.out.println("\n\nTest 4-2 ");
    res = (Object[]) evaluator.terminate(agg);
    System.out.println(Arrays.toString(res));

    // Test 5
    evaluator.reset(agg);
    agg.dts = Arrays.asList("1", "2");
    agg.values = Arrays.asList(toD(5), toD(6));
    System.out.println("\n\nTest 5 ");
    res = (Object[]) evaluator.terminate(agg);
    System.out.println(Arrays.toString(res));

    // Test 6
    evaluator.reset(agg);
    agg.dts = Arrays.asList("1", "2");
    agg.values = Arrays.asList(toD(6), toD(5));
    System.out.println("\n\nTest 6 ");
    res = (Object[]) evaluator.terminate(agg);
    System.out.println(Arrays.toString(res));

    // Test 7
    evaluator.reset(agg);
    agg.dts = Arrays.asList("1", "2", "3", "4", "5", "6");
    agg.values = Arrays.asList(toD(6), toD(8), toD(8), toD(7), toD(8.5), toD(1));
    System.out.println("\n\nTest 7 ");
    res = (Object[]) evaluator.terminate(agg);
    System.out.println(Arrays.toString(res));
  }

  public static HiveDecimal toD(Double d) {
    return HiveDecimal.create(BigDecimal.valueOf(d));
  }

  public static HiveDecimal toD(int d) {
    return HiveDecimal.create(BigDecimal.valueOf(d));
  }
}
