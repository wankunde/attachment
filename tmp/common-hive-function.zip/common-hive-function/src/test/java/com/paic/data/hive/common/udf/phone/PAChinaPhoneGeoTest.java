package com.paic.data.hive.common.udf.phone;

import org.junit.Assert;
import org.junit.Test;

import com.paic.data.hive.common.udf.phone.PAChinaPhoneGeo.Location;


public class PAChinaPhoneGeoTest {

    @Test
    public void testUDF() {
        PAChinaPhoneGeo phoneGeo = new PAChinaPhoneGeo();
        Location location = phoneGeo.evaluate("139237135351");

        Assert.assertEquals("广东省", location.province);

        location = phoneGeo.evaluate("+86015821971762");
        Assert.assertEquals("上海市", location.province);

        location = phoneGeo.evaluate("+86015821971");
        Assert.assertNull(location.province);
    }

}
