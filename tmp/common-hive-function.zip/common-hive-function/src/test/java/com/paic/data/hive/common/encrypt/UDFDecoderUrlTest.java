package com.paic.data.hive.common.encrypt;

import org.junit.Test;

import com.paic.data.hive.common.udf.UDFDecoderUrl;

public class UDFDecoderUrlTest {
	@Test
	public void test() {
		String urlStr="%e5%b9%b3%e5%ae%89%20%e8%af%81%e5%88%b8";
		String result = new UDFDecoderUrl().evaluate(urlStr);
		System.out.println(result);
	}
}
