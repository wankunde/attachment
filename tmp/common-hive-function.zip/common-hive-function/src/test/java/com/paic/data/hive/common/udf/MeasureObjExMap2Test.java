package com.paic.data.hive.common.udf;

import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class MeasureObjExMap2Test {

	@Test
	public void basicTest() throws JsonParseException, JsonMappingException, IOException{
		MeasureObjExMap objExMap = new MeasureObjExMap();
		
		Assert.assertNull(objExMap.evaluate(null, null));
		Assert.assertNotNull(objExMap.evaluate(new HashMap<String,String>(), null));
		Assert.assertNotNull(objExMap.evaluate(null, new HashMap<String,String>()));
		Assert.assertEquals(objExMap.evaluate(new HashMap<String,String>(), null).size(), 0);
		
		String jsonData = "{\"time-login_channel-PA18_init\":\"20161201\",\"login_time-login_channel-APP_init\":\"20161201\",\"login_time-scr_id-2_init\":\"20161203\",\"time_last\":\"20161204\",\"time-login_channel-APP_init\":\"20161201\",\"login_time-login_channel-APP_last\":\"20161204\",\"time-login_channel-PA18_last\":\"20161201\",\"time-scr_id-1_init\":\"20161201\",\"time_init\":\"20161201\",\"login_time-login_channel-PA18_init\":\"20161201\",\"login_time-scr_id-2_last\":\"20161203\",\"time-scr_id-1_last\":\"20161204\",\"login_time_init\":\"20161201\",\"login_time_last\":\"20161204\",\"login_time-login_channel-PA18_last\":\"20161201\",\"login_time-scr_id-1_init\":\"20161201\",\"time-scr_id-2_last\":\"20161203\",\"login_time-scr_id-1_last\":\"20161204\",\"time-scr_id-2_init\":\"20161203\",\"time-login_channel-APP_last\":\"20161204\"}";
		ObjectMapper mapper = new ObjectMapper();
		LinkedHashMap<String, String> mapData = mapper.readValue(jsonData,
				new TypeReference<LinkedHashMap<String, String>>() {
				});
		
		String jsonData2 = "{\"time-login_channel-PA18_init\":\"20161101\",\"login_time-login_channel-APP_init\":\"20161201\",\"login_time-scr_id-2_init\":\"20161203\",\"time_last\":\"20161204\",\"time-login_channel-APP_init\":\"20161201\",\"login_time-login_channel-APP_last\":\"20161204\",\"time-login_channel-PA18_last\":\"20161201\",\"time-scr_id-1_init\":\"20161201\",\"time_init\":\"20161101\",\"login_time-login_channel-PA18_init\":\"20161101\",\"login_time-scr_id-2_last\":\"20161203\",\"time-scr_id-1_last\":\"20161204\",\"login_time_init\":\"20161101\",\"login_time_last\":\"20161204\",\"login_time-login_channel-PA18_last\":\"20161201\",\"login_time-scr_id-1_init\":\"20161201\",\"time-scr_id-2_last\":\"20161203\",\"login_time-scr_id-1_last\":\"20161204\",\"time-scr_id-2_init\":\"20161203\",\"time-login_channel-APP_last\":\"20161204\"}";
		LinkedHashMap<String, String> mapData2 = mapper.readValue(jsonData2,
				new TypeReference<LinkedHashMap<String, String>>() {
				});
		
		Map<String, String> res = objExMap.evaluate(mapData, mapData2);
		System.out.println(JSON.toJSONString(res));
		
		Assert.assertNotNull(res);
		Assert.assertNotNull(res.get("login_time_init"));
		Assert.assertNotNull(res.get("time_init"));
		Assert.assertNotNull(res.get("login_time_last"));
		Assert.assertEquals(res.get("login_time_init"), "20161101");
		Assert.assertEquals(res.get("login_time_last"), "20161204");
		
		Assert.assertNotNull(res.get("login_time-login_channel-APP_init"));
		Assert.assertNotNull(res.get("login_time-login_channel-APP_last"));
		Assert.assertNotNull(res.get("login_time-login_channel-PA18_last"));
		Assert.assertNotNull(res.get("login_time-login_channel-PA18_init"));
		Assert.assertEquals(res.get("login_time-login_channel-APP_init"), "20161201");
		Assert.assertEquals(res.get("login_time-login_channel-APP_last"), "20161204");
		Assert.assertEquals(res.get("login_time-login_channel-PA18_last"), "20161201");
		Assert.assertEquals(res.get("login_time-login_channel-PA18_init"), "20161101");
		
		Assert.assertNotNull(res.get("login_time-scr_id-2_init"));
		Assert.assertNotNull(res.get("login_time-scr_id-2_last"));
		Assert.assertNotNull(res.get("login_time-scr_id-1_init"));
		Assert.assertNotNull(res.get("login_time-scr_id-1_last"));
		Assert.assertEquals(res.get("login_time-scr_id-2_init"), "20161203");
		Assert.assertEquals(res.get("login_time-scr_id-2_last"), "20161203");
		Assert.assertEquals(res.get("login_time-scr_id-1_init"), "20161201");
		Assert.assertEquals(res.get("login_time-scr_id-1_last"), "20161204");
		
	}
}
