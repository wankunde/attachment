package com.paic.data.hive.common.udf.uds.idcard;

import static org.junit.Assert.*;

import org.junit.Test;

import com.paic.data.hive.common.udf.uds.idcard.UDS_EXPLORE_IDCARD.IDCardInfo;

public class UDS_EXPLORE_IDCARDTest {

	@Test
	public void testEvaluate() {
		
		String idCard1 = "320412199302166683";
		
		UDS_EXPLORE_IDCARD explore = new UDS_EXPLORE_IDCARD();
		explore.setNeedInitProvinceInfo(false);
		
		String idCard5 = "1328291977091273*9";
		IDCardInfo info4 = explore.evaluate(idCard5);
		
		assertTrue(info4.provinceCode == null);
		assertTrue(info4.cityCode == null);
		assertTrue(info4.countyCode == null);
		assertTrue(info4.birthday == null);
		assertTrue(info4.gender == null);
		
		IDCardInfo info = explore.evaluate(idCard1);
		
		assertTrue(info.provinceCode == 32);
		assertTrue(info.cityCode == 3204);
		assertTrue(info.countyCode == 320412);
		assertTrue("19930216".equals(info.birthday));
		assertTrue(info.gender == "F");
		assertTrue(info.age != null && info.age < 1000);
		
		
		String idCard2 = "3204121993021666831";
		IDCardInfo info1 = explore.evaluate(idCard2);
		
		assertTrue(info1.provinceCode == null);
		assertTrue(info1.cityCode == null);
		assertTrue(info1.countyCode == null);
		assertTrue(info1.birthday == null);
		assertTrue(info1.gender == null);
		
		String idCard3 = "110105197109235829";  // 18位   110105197109235829 
		IDCardInfo info2 = explore.evaluate(idCard3);
		
		assertTrue(info2.provinceCode == 11);
		assertTrue(info2.cityCode == 1101);
		assertTrue(info2.countyCode == 110105);
		assertTrue(info2.birthday.equals("19710923"));
		assertTrue(info2.gender.equals("F"));
		assertTrue(info.age != null && info.age < 1000);
		
		String idCard4 = "110105197109405829";
		IDCardInfo info3 = explore.evaluate(idCard4);
		
		assertTrue(info3.provinceCode == null);
		assertTrue(info3.cityCode == null);
		assertTrue(info3.countyCode == null);
		assertTrue(info3.birthday == null);
		assertTrue(info3.gender == null);
	}

}
