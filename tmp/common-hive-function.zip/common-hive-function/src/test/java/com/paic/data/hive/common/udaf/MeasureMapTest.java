package com.paic.data.hive.common.udaf;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDAFEvaluator.AggregationBuffer;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDAFEvaluator.Mode;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.junit.Assert;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.paic.data.hive.common.udaf.MeasureMap.MeasureMapDoubleEvaluator;
import com.paic.data.hive.common.udaf.MeasureMap.MeasureMapDoubleEvaluator.DoubleMapBean;


public class MeasureMapTest {
	
	@Test
	public void basicTest() throws HiveException, JsonParseException, JsonMappingException, IOException{
		MeasureMapDoubleEvaluator measureMap = this.get();
		
		AggregationBuffer agg = new DoubleMapBean();
		
		measureMap.iterate(agg, new Object[]{new DoubleWritable(2), new Text("login_count"),new Text("")});
		measureMap.iterate(agg, new Object[]{new DoubleWritable(1), new Text("login_count"),new Text("")});
		measureMap.iterate(agg, new Object[]{new DoubleWritable(2), new Text("login_count"),new Text("")});
		
		ObjectMapper mapper = new ObjectMapper();
		Map<Text, DoubleWritable> res = (Map<Text, DoubleWritable>)measureMap.terminatePartial(agg);
		Assert.assertNotNull(res);
		Assert.assertNotNull(res.get(new Text("login_count")));
		Assert.assertEquals(res.get(new Text("login_count")).get(), 5.0, 0.001);
		System.out.println(res.toString());
		
		
		String jsonData = "{\"login_count\":5.0}";
		LinkedHashMap<Text, DoubleWritable> mapData = mapper.readValue(jsonData,
				new TypeReference<LinkedHashMap<Text, DoubleWritable>>() {
				});
		
		measureMap.merge(agg, mapData);
		res = (Map<Text, DoubleWritable>)measureMap.terminate(agg);
		
		Assert.assertNotNull(res);
		Assert.assertNotNull(res.get(new Text("login_count")));
		Assert.assertEquals(res.get(new Text("login_count")).get(), 10.0, 0.001);
		
		System.out.println(res.toString());
	}
	
	@Test
	public void basicOneDeminsionTest() throws HiveException, JsonParseException, JsonMappingException, IOException{
		MeasureMapDoubleEvaluator measureMap = this.get();
		
		AggregationBuffer agg = new DoubleMapBean();
		
		measureMap.iterate(agg, new Object[]{new DoubleWritable(2), new Text("login_count"),new Text("login_channel"),new Text("APP")});
		measureMap.iterate(agg, new Object[]{new DoubleWritable(1), new Text("login_count"),new Text("login_channel"),new Text("APP")});
		measureMap.iterate(agg, new Object[]{new DoubleWritable(2), new Text("login_count"),new Text("login_channel"),new Text("PA18")});
		
		ObjectMapper mapper = new ObjectMapper();
		Map<Text, DoubleWritable> res = (Map<Text, DoubleWritable>)measureMap.terminatePartial(agg);
		Assert.assertNotNull(res);
		Assert.assertNotNull(res.get(new Text("login_count")));
		Assert.assertNotNull(res.get(new Text("login_count-login_channel-PA18")));
		Assert.assertNotNull(res.get(new Text("login_count-login_channel-APP")));
		Assert.assertEquals(res.get(new Text("login_count")).get(), 5.0, 0.001);
		Assert.assertEquals(res.get(new Text("login_count-login_channel-PA18")).get(), 2.0, 0.001);
		Assert.assertEquals(res.get(new Text("login_count-login_channel-APP")).get(), 3.0, 0.001);
		System.out.println(res.toString());
		
		
		String jsonData = "{\"login_count\":5.0,\"login_count-login_channel-PA18\":2.0,\"login_count-login_channel-APP\":3.0}";
		LinkedHashMap<Text, DoubleWritable> mapData = mapper.readValue(jsonData,
				new TypeReference<LinkedHashMap<Text, DoubleWritable>>() {
				});
		
		measureMap.merge(agg, mapData);
		res = (Map<Text, DoubleWritable>)measureMap.terminate(agg);
		
		Assert.assertNotNull(res);
		Assert.assertNotNull(res.get(new Text("login_count")));
		Assert.assertNotNull(res.get(new Text("login_count-login_channel-PA18")));
		Assert.assertNotNull(res.get(new Text("login_count-login_channel-APP")));
		Assert.assertEquals(res.get(new Text("login_count")).get(), 10.0, 0.001);
		Assert.assertEquals(res.get(new Text("login_count-login_channel-PA18")).get(), 4.0, 0.001);
		Assert.assertEquals(res.get(new Text("login_count-login_channel-APP")).get(), 6.0, 0.001);
		System.out.println(res.toString());
	}
	
	@Test
	public void basicTwoDeminsionTest() throws HiveException, JsonParseException, JsonMappingException, IOException{
		MeasureMapDoubleEvaluator measureMap = this.get();
		
		AggregationBuffer agg = new DoubleMapBean();
		
		measureMap.iterate(agg, new Object[]{new DoubleWritable(2), new Text("login_count"),new Text("login_channel&src_id"),new Text("APP"),new Text("1")});
		measureMap.iterate(agg, new Object[]{new DoubleWritable(1), new Text("login_count"),new Text("login_channel&src_id"),new Text("APP"),new Text("1")});
		measureMap.iterate(agg, new Object[]{new DoubleWritable(2), new Text("login_count"),new Text("login_channel&src_id"),new Text("PA18"),new Text("2")});
		
		ObjectMapper mapper = new ObjectMapper();
		Map<Text, DoubleWritable> res = (Map<Text, DoubleWritable>)measureMap.terminatePartial(agg);
		Assert.assertNotNull(res);
		Assert.assertNotNull(res.get(new Text("login_count")));
		Assert.assertNotNull(res.get(new Text("login_count-login_channel-PA18")));
		Assert.assertNotNull(res.get(new Text("login_count-login_channel-APP")));
		Assert.assertEquals(res.get(new Text("login_count")).get(), 5.0, 0.001);
		Assert.assertEquals(res.get(new Text("login_count-login_channel-PA18")).get(), 2.0, 0.001);
		Assert.assertEquals(res.get(new Text("login_count-login_channel-APP")).get(), 3.0, 0.001);
		
		Assert.assertNotNull(res.get(new Text("login_count-src_id-1")));
		Assert.assertNotNull(res.get(new Text("login_count-src_id-2")));
		Assert.assertEquals(res.get(new Text("login_count-src_id-1")).get(), 3.0, 0.001);
		Assert.assertEquals(res.get(new Text("login_count-src_id-2")).get(), 2.0, 0.001);
		
		System.out.println(res.toString());
		
		
		String jsonData = "{\"login_count\":5.0,\"login_count-login_channel-PA18\":2.0,\"login_count-login_channel-APP\":3.0}";
		LinkedHashMap<Text, DoubleWritable> mapData = mapper.readValue(jsonData,
				new TypeReference<LinkedHashMap<Text, DoubleWritable>>() {
				});
		
		measureMap.merge(agg, mapData);
		res = (Map<Text, DoubleWritable>)measureMap.terminate(agg);
		
		Assert.assertNotNull(res);
		Assert.assertNotNull(res.get(new Text("login_count")));
		Assert.assertNotNull(res.get(new Text("login_count-login_channel-PA18")));
		Assert.assertNotNull(res.get(new Text("login_count-login_channel-APP")));
		Assert.assertEquals(res.get(new Text("login_count")).get(), 10.0, 0.001);
		Assert.assertEquals(res.get(new Text("login_count-login_channel-PA18")).get(), 4.0, 0.001);
		Assert.assertEquals(res.get(new Text("login_count-login_channel-APP")).get(), 6.0, 0.001);
		
		Assert.assertNotNull(res.get(new Text("login_count-src_id-1")));
		Assert.assertNotNull(res.get(new Text("login_count-src_id-2")));
		Assert.assertEquals(res.get(new Text("login_count-src_id-1")).get(), 3.0, 0.001);
		Assert.assertEquals(res.get(new Text("login_count-src_id-2")).get(), 2.0, 0.001);
		
		System.out.println(res.toString());
	}
	
	
	private MeasureMapDoubleEvaluator get() throws HiveException{
		MeasureMapDoubleEvaluator measureMap = new MeasureMapDoubleEvaluator();
		
		ObjectInspector[] args = new ObjectInspector[5];
		args[0] = PrimitiveObjectInspectorFactory.writableDoubleObjectInspector;
		args[1] = PrimitiveObjectInspectorFactory.writableStringObjectInspector;
		args[2] = PrimitiveObjectInspectorFactory.writableStringObjectInspector;
		args[3] = PrimitiveObjectInspectorFactory.writableStringObjectInspector;
		args[4] = PrimitiveObjectInspectorFactory.writableStringObjectInspector;
		
		measureMap.init(Mode.PARTIAL1, args);
		
		return measureMap;
	}

}
