package com.paic.data.hive.common.udf;

public class Murmur3Test {

	public static void main(String[] args) {
		/*
		 * 184090018
184121989
184137966
185305145
185245761
185300052
185193305
185233032
184770752
		 */
		int i=191949998;
		int value =Murmur3Hash.floorMod((Murmur3Hash.hash(String.valueOf(i))), 36);
		System.out.println(value);
	}
}
