package com.paic.data.hive.common.udf.uds;

import static org.junit.Assert.*;

import org.junit.Test;

public class UDS_TransGenderTest {

	@Test
	public void testEvaluate() {
		UDS_TransGender genderTrans = new UDS_TransGender();
		
		String strGender = null;
		Integer intGender = null;
		
		assertTrue("".equals(genderTrans.evaluate("")));
		assertTrue("".equals(genderTrans.evaluate(intGender)));
		assertTrue("".equals(genderTrans.evaluate(strGender)));
		assertTrue("".equals(genderTrans.evaluate("    ")));
		assertTrue("".equals(genderTrans.evaluate(12)));
		assertTrue("".equals(genderTrans.evaluate(-1)));
		assertTrue("".equals(genderTrans.evaluate("x")));
		
		assertTrue("0".equals(genderTrans.evaluate("0")));
		assertTrue("0".equals(genderTrans.evaluate(" 0 ")));
		assertTrue("0".equals(genderTrans.evaluate("m")));
		assertTrue("0".equals(genderTrans.evaluate(" M")));
		assertTrue("0".equals(genderTrans.evaluate("MAle ")));
		assertTrue("0".equals(genderTrans.evaluate(" 男  ")));
		assertTrue("0".equals(genderTrans.evaluate(0)));
		
		assertTrue("1".equals(genderTrans.evaluate("1")));
		assertTrue("1".equals(genderTrans.evaluate(" 1 ")));
		assertTrue("1".equals(genderTrans.evaluate("f")));
		assertTrue("1".equals(genderTrans.evaluate(" F")));
		assertTrue("1".equals(genderTrans.evaluate("feMale ")));
		assertTrue("1".equals(genderTrans.evaluate(" 女 ")));
		assertTrue("1".equals(genderTrans.evaluate(1)));

		assertTrue("2".equals(genderTrans.evaluate(2)));
		assertTrue("2".equals(genderTrans.evaluate("2")));
		assertTrue("2".equals(genderTrans.evaluate("  2 ")));
	}

}
