package com.paic.data.hive.common.udf;

import com.paic.data.hive.common.udf.bean.IpBean;
import org.junit.Test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

import static com.paic.data.hive.common.udf.IpParser.*;

/**
 * Created by WANKUN603 on 2017-04-13.
 */
public class IpParserTest {
/*
    public static final String[] colNames = {
            "ip_min",
            "ip_max",
            "descr",
            "country",
            "country_id",
            "area",
            "area_id",
            "region",
            "region_id",
            "city",
            "city_id",
            "county",
            "county_id",
            "isp",
            "isp_id"
    };

    @Test
    public void testIpDict() throws IOException {
        List<String> lines = Files.readAllLines(Paths.get("D:/tmp/ip_gps_carrier"));

        List<IpBean> list = new ArrayList<>(178408);
        IpBean bean;
        Map<String, String> map;
        for (String line : lines) {
            String[] cols = line.split("\u0001");
            if (cols.length > 2) {
                map = new HashMap<>(16, 1.0f);
                for (int i = 0; i < cols.length; i++) {
                    map.put(colNames[i], cols[i]);
                }
                bean = new IpBean();
                bean.setStart(Long.parseLong(cols[0]));
                bean.setEnd(Long.parseLong(cols[1]));
                bean.setData(map);
                System.out.println(bean);
            }
        }
        list.sort(new Comparator<IpBean>() {
            @Override
            public int compare(IpBean o1, IpBean o2) {
                long f = o1.getStart() - o2.getStart();
                return f > 0 ? 1 : (f < 0 ? -1 : 0);
            }
        });

    }
    */
}
