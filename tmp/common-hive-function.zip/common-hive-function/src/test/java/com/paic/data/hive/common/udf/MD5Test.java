package com.paic.data.hive.common.udf;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;

import org.junit.Assert;
import org.junit.Test;

public class MD5Test {

	@Test
	public void basicTest() throws NoSuchAlgorithmException, UnsupportedEncodingException {
		MD5 md5 = new MD5();
		System.out.println(md5.evaluate("aaa"));
		Assert.assertEquals("47bce5c74f589f4867dbd57e9ca9f808", md5.evaluate("aaa"));
	}
}
