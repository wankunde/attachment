package com.paic.data.hive.common.udf;

import org.junit.Test;

import java.text.ParseException;
import java.util.Map;

public class MultiLikeTest {

  @Test
  public void testBuildPatternTree() {
    MultiLike multiLike = new MultiLike();
    MultiLike.Node node = multiLike.buildPatternTree("abc", "acd", "bde");
    System.out.println(node);
  }

  @Test
  public void testMultiLike() {
    MultiLike multiLike = new MultiLike();
    Map<String, Boolean> res;
    res = multiLike.evaluate("xabcyacde", "abc", "acd", "bde");
    res.forEach((p, b) -> System.out.println(p + " : " + b));
    System.out.println();
    res = multiLike.evaluate("hijkl", "abc", "acd", "bde");
    res.forEach((p, b) -> System.out.println(p + " : " + b));
    System.out.println();
    res = multiLike.evaluate("a", "abc", "acd", "bde");
    res.forEach((p, b) -> System.out.println(p + " : " + b));
    System.out.println();
    res = multiLike.evaluate(null, "abc", "acd", "bde");
    res.forEach((p, b) -> System.out.println(p + " : " + b));
    System.out.println();
    res = multiLike.evaluate("badabacde", "abc", "acd", "bde");
    res.forEach((p, b) -> System.out.println(p + " : " + b));
    System.out.println();

  }
}
