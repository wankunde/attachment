package com.paic.data.hive.common.udf.uds;

import static org.junit.Assert.*;

import org.junit.Test;

public class UDS_TrimTest {

	@Test
	public void testEvaluate() {
		UDS_Trim udsTrim = new UDS_Trim();
		
		assertTrue(udsTrim.evaluate("      ").equals(""));
		assertTrue(udsTrim.evaluate("Null").equals(""));
		assertTrue(udsTrim.evaluate("null").equals(""));
		assertTrue(udsTrim.evaluate("nulL").equals(""));
		assertTrue(udsTrim.evaluate("\0").equals(""));
		assertTrue(udsTrim.evaluate("\0\0\0\0").equals(""));
		assertTrue(udsTrim.evaluate("\0\0XXXXX\0\0").equals("XXXXX"));
		assertTrue(udsTrim.evaluate("\0\0XXXXX").equals("XXXXX"));
		assertTrue(udsTrim.evaluate("XXXXX\0\0").equals("XXXXX"));
		assertTrue(udsTrim.evaluate("\0XXXXX").equals("XXXXX"));
		assertTrue(udsTrim.evaluate("XXXXX\0").equals("XXXXX"));
		assertTrue(udsTrim.evaluate("XXXXX\t").equals("XXXXX"));
		assertTrue(udsTrim.evaluate("\tXXXXX\t").equals("XXXXX"));
		assertTrue(udsTrim.evaluate("\tXXX\tXX\t").equals("XXX\tXX"));
		assertTrue(udsTrim.evaluate("\tXXX\0XX\t").equals("XXX\0XX"));

		assertFalse(udsTrim.evaluate("XXXXX\0").equals("XXXX"));
	}

}
