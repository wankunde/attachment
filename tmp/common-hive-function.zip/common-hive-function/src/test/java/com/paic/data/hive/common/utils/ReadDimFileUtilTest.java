package com.paic.data.hive.common.utils;

import java.io.IOException;
import java.util.Map;
import java.util.Set;

import org.junit.Assert;
import org.junit.Test;

public class ReadDimFileUtilTest {
	
	@Test
	public void basicTest() throws IOException{
		Map<String, Set<String>> data = ReadDimFileUtil.getIndexNameAndExtendName();
		
		Assert.assertEquals(data.size(), 1);
	}

}
