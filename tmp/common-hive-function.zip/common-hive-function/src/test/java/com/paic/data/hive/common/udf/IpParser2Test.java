package com.paic.data.hive.common.udf;

import org.junit.Test;

import java.util.Map;

import static org.junit.Assert.*;

public class IpParser2Test {

    @Test
    public void testevaluate() throws Exception {
        IpParser2 ipParser2 = new IpParser2();

        Map<String, String> map = ipParser2.evaluate("119.145.10.77");

        System.out.println(map.toString());
    }
}