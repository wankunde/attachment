package com.paic.data.hive.common.udf;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;

public class FilterMeasureMapTest {

	@Test
	public void measureExTest() throws IOException {
		FilterMeasureMap filter = new FilterMeasureMap();

		Assert.assertNull(filter.evaluate(null, null, ""));
		Assert.assertNull(filter.evaluate(null, null, "week"));
		Assert.assertNotNull(filter.evaluate(new HashMap<String, Double>(), null, "week"));
		Assert.assertEquals(filter.evaluate(new HashMap<String, Double>(), null, "week").size(), 0);

		Map<String, Double> data = this.getMeasureEx();
		Assert.assertEquals(filter.evaluate(data, null, "week").size(), 5);
		Assert.assertTrue(filter.evaluate(data, null, "week").containsKey("cash_in_amt_7n_sum"));
		Assert.assertTrue(filter.evaluate(data, null, "week").containsKey("cash_in_amt_7n_avg"));
		Assert.assertTrue(filter.evaluate(data, null, "week").containsKey("cash_in_amt_7n_tavg"));
		Assert.assertTrue(filter.evaluate(data, null, "week").containsKey("cash_in_amt_7n_max"));
		Assert.assertTrue(filter.evaluate(data, null, "week").containsKey("cash_in_amt_7n_min"));

		Assert.assertEquals(filter.evaluate(data, "cash_in_amt", "month").size(), 5);
		Assert.assertTrue(filter.evaluate(data, "cash_in_amt", "month").containsKey("cash_in_amt_30n_sum"));
		Assert.assertTrue(filter.evaluate(data, "cash_in_amt", "month").containsKey("cash_in_amt_30n_avg"));
		Assert.assertTrue(filter.evaluate(data, "cash_in_amt", "month").containsKey("cash_in_amt_30n_tavg"));
		Assert.assertTrue(filter.evaluate(data, "cash_in_amt", "month").containsKey("cash_in_amt_30n_max"));
		Assert.assertTrue(filter.evaluate(data, "cash_in_amt", "month").containsKey("cash_in_amt_30n_min"));

		Assert.assertEquals(filter.evaluate(data, "", "quarter").size(), 5);
		Assert.assertTrue(filter.evaluate(data, "", "quarter").containsKey("cash_in_amt_90n_sum"));
		Assert.assertTrue(filter.evaluate(data, "", "quarter").containsKey("cash_in_amt_90n_avg"));
		Assert.assertTrue(filter.evaluate(data, "", "quarter").containsKey("cash_in_amt_90n_tavg"));
		Assert.assertTrue(filter.evaluate(data, "", "quarter").containsKey("cash_in_amt_90n_max"));
		Assert.assertTrue(filter.evaluate(data, "", "quarter").containsKey("cash_in_amt_90n_min"));

		Assert.assertEquals(filter.evaluate(data, "cash_in_amt", "year").size(), 5);
		Assert.assertTrue(filter.evaluate(data, "cash_in_amt", "year").containsKey("cash_in_amt_360n_sum"));
		Assert.assertTrue(filter.evaluate(data, "cash_in_amt", "year").containsKey("cash_in_amt_360n_avg"));
		Assert.assertTrue(filter.evaluate(data, "cash_in_amt", "year").containsKey("cash_in_amt_360n_tavg"));
		Assert.assertTrue(filter.evaluate(data, "cash_in_amt", "year").containsKey("cash_in_amt_360n_min"));
		Assert.assertTrue(filter.evaluate(data, "cash_in_amt", "year").containsKey("cash_in_amt_360n_max"));
		
	}
	
	@Test
	public void measureILTest() throws IOException{
		FilterMeasureMap filter = new FilterMeasureMap();

		Assert.assertNull(filter.evaluate(null, null));
		Assert.assertNotNull(filter.evaluate(new HashMap<String, String>(), null));
		Assert.assertNotNull(filter.evaluate(new HashMap<String, String>(), "trade_movt_il"));
		
		Map<String, String> dataIL = this.getMeasureIL();
		Assert.assertEquals(filter.evaluate(dataIL, "trade_movt_il").size(), 4);
		Assert.assertTrue(filter.evaluate(dataIL, "trade_movt_il").containsKey("trade_movt_il-trd_date_init"));
		Assert.assertTrue(filter.evaluate(dataIL, "trade_movt_il").containsKey("trade_movt_il-trd_date_last"));
		Assert.assertTrue(filter.evaluate(dataIL, "trade_movt_il").containsKey("trade_movt_il-trd_date-trd_dir-i_init"));
		Assert.assertTrue(filter.evaluate(dataIL, "trade_movt_il").containsKey("trade_movt_il-trd_type_init"));
	}
	
	@Test
	public void measureTest() throws IOException{
		FilterMeasureMap filter = new FilterMeasureMap();

		Assert.assertNull(filter.evaluate(null, null, ""));
		Assert.assertNull(filter.evaluate(null, null, "day"));
		Assert.assertNotNull(filter.evaluate(new HashMap<String, Double>(), null, "Current"));
		Assert.assertEquals(filter.evaluate(new HashMap<String, Double>(), null, "Current").size(), 0);
		
		Map<String, Double> data = this.getMeasure();
		Assert.assertEquals(filter.evaluate(data, null, "Current").size(), 1);
		Assert.assertTrue(filter.evaluate(data, null, "Current").containsKey("cash_in_amt"));
	}

	private Map<String, Double> getMeasureEx() {
		Map<String, Double> data = new HashMap<>();

		data.put("cash_in_amt_7n_sum", 100.0);
		data.put("cash_in_amt_30n_sum", 100.0);
		data.put("cash_in_amt_90n_sum", 100.0);
		data.put("cash_in_amt_180n_sum", 100.0);
		data.put("cash_in_amt_360n_sum", 100.0);

		data.put("cash_in_amt_7n_avg", 100.0);
		data.put("cash_in_amt_30n_avg", 100.0);
		data.put("cash_in_amt_90n_avg", 100.0);
		data.put("cash_in_amt_180n_avg", 100.0);
		data.put("cash_in_amt_360n_avg", 100.0);

		data.put("cash_in_amt_7n_tavg", 100.0);
		data.put("cash_in_amt_30n_tavg", 100.0);
		data.put("cash_in_amt_90n_tavg", 100.0);
		data.put("cash_in_amt_180n_tavg", 100.0);
		data.put("cash_in_amt_360n_tavg", 100.0);

		data.put("cash_in_amt_7n_max", 100.0);
		data.put("cash_in_amt_30n_max", 100.0);
		data.put("cash_in_amt_90n_max", 100.0);
		data.put("cash_in_amt_180n_max", 100.0);
		data.put("cash_in_amt_360n_max", 100.0);

		data.put("cash_in_amt_7n_min", 100.0);
		data.put("cash_in_amt_30n_min", 100.0);
		data.put("cash_in_amt_90n_min", 100.0);
		data.put("cash_in_amt_180n_min", 100.0);
		data.put("cash_in_amt_360n_min", 100.0);

		data.put("cash_in_amt_1c_sum_5000", 20160610D);
		data.put("cash_in_amt_1c_sum_1000", 20160610D);

		return data;
	}
	
	
	private Map<String, Double> getMeasure() {
		Map<String, Double> data = new HashMap<>();

		data.put("cash_in_amt", 100.0);

		return data;
	}
	
	private Map<String, String> getMeasureIL(){
		Map<String, String> data = new HashMap<>();
		
		data.put("handle_fee&trade_cls$1_last", "0.6");
		data.put("market_last", "10");
		data.put("trd_dir&trd_dir$U&trade_cls$5_last", "U");
		
		data.put("trade_movt_il-trd_date_init", "20140901");
		data.put("trade_movt_il-trd_date_last", "20161130");
		data.put("trade_movt_il-trd_date-trd_dir-i_init", "20150901");
		data.put("trade_movt_il-trd_type_init", "3");
		
		return data;
	}
}
