package com.paic.data.hive.common.udf;

import com.paic.data.hive.common.udf.loose.ValueBean;
import org.apache.hadoop.hive.common.type.HiveDecimal;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by WANKUN603 on 2018-05-22.
 */
public class LooseTest {

  @Test
  public void testLoose() {
    List<ValueBean> list = new ArrayList<>();
    list.add(new ValueBean("20170629", HiveDecimal.create(BigDecimal.valueOf(-0.0423))));
//    list.add(new ValueBean("20180102", HiveDecimal.create(BigDecimal.valueOf(11.0))));
//    list.add(new ValueBean("20180103", HiveDecimal.create(BigDecimal.valueOf(8.0))));
//    list.add(new ValueBean("20180104", HiveDecimal.create(BigDecimal.valueOf(7.0))));
//    list.add(new ValueBean("20180105", HiveDecimal.create(BigDecimal.valueOf(9.0))));
//    list.add(new ValueBean("20180105", HiveDecimal.create(BigDecimal.valueOf(8.0))));

    ValueBean[] res = ValueBean.loose(list);
    System.out.println(Arrays.toString(res));
  }
}
