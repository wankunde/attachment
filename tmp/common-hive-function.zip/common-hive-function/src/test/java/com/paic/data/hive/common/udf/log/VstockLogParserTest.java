package com.paic.data.hive.common.udf.log;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.paic.data.hive.common.udf.log.VstockLogParser.DealBehavior;

import junit.framework.Assert;

public class VstockLogParserTest {

    @Test
    public void test() {
        String content = "2016/12/12 11:39:10 [error] 1570#0: *24619932 [lua] utils.lua:259: addTrace(): <TRACE>callDZH_Response|e9ebb7f3a1f4b5ee412f10eb9653f5f0|1481513950|0|[\"[{\\\"Data\\\":{\\\"RepDataQueryOrderRsp\\\":[{\\\"RspNo\\\":0,\\\"CapitalId\\\":\\\"61d40c78b4\\\",\\\"OrderList\\\":[{\\\"OrderType\\\":\\\"R\\\",\\\"OrderTime\\\":\\\"2016-12-12 11:37:56\\\",\\\"ProductCode\\\":\\\"SH600436\\\",\\\"ProductName\\\":\\\"鐗囦粩鐧�\\\",\\\"BuyOrSell\\\":\\\"S\\\",\\\"OrderAmount\\\":21100,\\\"OrderNo\\\":\\\"405037\\\",\\\"OrderPrice\\\":46.59,\\\"Status\\\":\\\"3\\\"},{\\\"OrderType\\\":\\\"R\\\",\\\"OrderTime\\\":\\\"2016-12-12 11:39:05\\\",\\\"ProductCode\\\":\\\"SH600436\\\",\\\"ProductName\\\":\\\"鐗囦粩鐧�\\\",\\\"BuyOrSell\\\":\\\"S\\\",\\\"OrderAmount\\\":21100,\\\"OrderNo\\\":\\\"405054\\\",\\\"OrderPrice\\\":46.58,\\\"Status\\\":\\\"2\\\"}],\\\"RspDesc\\\":\\\"OK\\\"}],\\\"Id\\\":160},\\\"Counter\\\":1,\\\"Qid\\\":\\\"\\\",\\\"Err\\\":0}]\",200]</TRACE> while sending to client, client: 175.167.128.14, server: m.stock.pingan.com, request: \"POST /vstock/proxy/single?random=0.5195013540796936 HTTP/1.1\", host: \"m.stock.pingan.com\", referrer: \"https://m.stock.pingan.com/static/vstock/cancel.html\"";
        VstockLogParser parser = new VstockLogParser();
        
        List<DealBehavior> result = parser.evaluate(content);
        assertTrue(result.size() == 2);
        for(DealBehavior behavior : result) {
            assertTrue("61d40c78b4".equals(behavior.capitalId));
            System.out.println(behavior.dealPrice);
        }
        
        content = "Content:2016/12/12 10:39:11 [error] 1564#0: *24492828 [lua] utils.lua:259: addTrace(): <TRACE>callDZH_Response|ceb585d4ff0a27be3a106c4d72a4c96e|1481510351|0|[\"[{\\\"Data\\\":{\\\"RepDataQueryDealRsp\\\":[{\\\"RspNo\\\":0,\\\"CapitalId\\\":\\\"61dbf22f59\\\",\\\"DealList\\\":[{\\\"BuyOrSell\\\":\\\"B\\\",\\\"Fee\\\":10.92,\\\"DealPrice\\\":91,\\\"DealTime\\\":\\\"2016-12-12 10:09:06\\\",\\\"ProductCode\\\":\\\"SZ300547\\\",\\\"DealNo\\\":\\\"267268\\\",\\\"ProductName\\\":\\\"宸濈幆绉戞妧\\\",\\\"DealAmount\\\":400}],\\\"RspDesc\\\":\\\"OK\\\"}],\\\"Id\\\":161},\\\"Counter\\\":1,\\\"Qid\\\":\\\"\\\",\\\"Err\\\":0}]\",200]</TRACE> while sending to client, client: 211.97.75.11, server: m.stock.pingan.com, request: \"POST /vstock/proxy/single?random=0.5168284028768539 HTTP/1.1\", host: \"m.stock.pingan.com\", referrer: https://m.stock.pingan.com/static/vstock/queryList.html?c=1";
        result = parser.evaluate(content);
        assertTrue(result.size() == 1);
        for(DealBehavior behavior : result) {
            assertTrue("61dbf22f59".equals(behavior.capitalId));
            System.out.println(behavior.dealPrice);
        }
    }

}
