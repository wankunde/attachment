package com.paic.data.hive.common.udf;

import org.junit.Test;

import java.text.ParseException;

public class PDateFormatTest {
    
    @Test
    public void testDateFormat() throws ParseException {
        PDateFormat pdateFormat = new PDateFormat();
        String result = pdateFormat.evaluate("", "yyyy-MM-dd HH:mm:ss","'yyyyMMddHHmmss'", true);
        System.out.println(result);


        result =pdateFormat.evaluate("20050531","yyyyMMdd","yyyy-MM-dd");
        System.out.println(result);
    }


}
