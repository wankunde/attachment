package com.paic.data.hive.common.udf;

import java.io.IOException;
import java.text.ParseException;

import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.junit.Assert;
import org.junit.Test;

public class DTAddForTradeDayTest {

	@Test
	public void basicTest() throws ParseException, HiveException, IOException{
		DTAddForTradeDay addTradyDay = new DTAddForTradeDay();
		
		Assert.assertEquals(addTradyDay.evaluate("20161010", 0), "20161010");
		Assert.assertEquals(addTradyDay.evaluate("20161015", 0), "20161017");
		Assert.assertEquals(addTradyDay.evaluate("20161016", 0), "20161017");
		
		Assert.assertEquals(addTradyDay.evaluate("20161010", 2), "20161012");
		Assert.assertEquals(addTradyDay.evaluate("20161010", 6), "20161018");
	}
}
