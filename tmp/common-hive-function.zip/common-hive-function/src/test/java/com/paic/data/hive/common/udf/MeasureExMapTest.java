package com.paic.data.hive.common.udf;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import static org.junit.Assert.assertTrue;

/**
 * 
 * measure_ex_map(t2.cash_transfer_in_amt_his,'${start|yyyyMMdd}',t1.
 * cash_transfer_in_amt,
 * '90n_max,3m_max,180n_max,5t_max,7d_max,20t_max,10t_max,1m_max,360n_max,
 * 30n_max,7n_max,12m_max,6m_max,12m_sum_10000,1c_sum_3000,12m_sum_150000,
 * 1c_sum_1000,1c_sum_100,1c_sum_1,6m_sum,12m_sum,7d_sum,1m_sum,12m_sum_300000,
 * 360n_sum,7n_sum,30n_sum,90n_sum,180n_sum,3m_sum,12m_sum_5000,12m_sum_3000,
 * 12m_sum_1000,12m_sum_100,1c_sum_10000,1c_sum_5000,12m_sum_100000',
 * 'cash_transfer_in_amt','',t2.cash_transfer_in_amt_ex) as
 * cash_transfer_in_amt_ex, t1.secu_transfer_out_amt,
 *
 */
public class MeasureExMapTest {

    @Test
    public void test() throws HiveException, IOException, ParseException {
        MeasureExMap test = new MeasureExMap();

        String cash_transfer_in_amt_his = "{\"cash_transfer_in_amt\":{\"20161128\":143000.0,\"20161129\":76000.0,\"20161122\":77000.0,\"20160205\":127.44,\"20161121\":77039.57,\"20161124\":100000.0,\"20161123\":100000.0,\"20161125\":100000.0,\"20161130\":67000.0,\"20160930\":100000.0,\"20161214\":0.0,\"20161213\":52000.0,\"20160601\":45000.0,\"20161212\":52000.0,\"20161109\":57000.0,\"20151230\":18149.99,\"20160608\":64.02,\"20161108\":57000.0,\"20161107\":0.0,\"20160531\":0.0,\"20161205\":92000.0,\"20161209\":92000.0,\"20161208\":92000.0,\"20160809\":41000.0,\"20161201\":67000.0,\"20160805\":45000.0,\"20160808\":11000.0,\"20161202\":67000.0,\"20160801\":45000.0,\"20161012\":76000.0,\"20160802\":45000.0,\"20161011\":100000.0,\"20161010\":100000.0,\"20151221\":41000.36,\"20160804\":45000.0,\"20151223\":291000.0,\"20161118\":67000.0,\"20161117\":67000.0,\"20161014\":100000.0,\"20161116\":67000.0,\"20161013\":126000.0,\"20161115\":67000.0,\"20161114\":57000.0,\"20161019\":200000.0,\"20151228\":0.0,\"20161018\":100500.25,\"20151229\":0.0,\"20161017\":100000.0,\"20161111\":57224.24,\"20160818\":56000.0,\"20160819\":56000.0,\"20160816\":71486.91,\"20160817\":71000.0,\"20160913\":0.0,\"20160914\":136000.0,\"20160912\":136000.0,\"20160106\":68178.16,\"20160719\":55000.0,\"20160104\":68000.0,\"20160105\":0.0,\"20160718\":55395.67,\"20160615\":10000.0,\"20160715\":55000.0,\"20160617\":0.0,\"20160714\":55000.0,\"20160919\":136501.52,\"20160713\":47000.0,\"20160712\":47000.0,\"20160711\":47000.0,\"20160510\":10000.0,\"20160811\":41000.0,\"20160810\":41000.0,\"20160815\":71000.0,\"20160812\":41000.0,\"20160829\":93000.56,\"20160922\":87000.0,\"20160429\":75000.0,\"20160923\":87000.0,\"20160427\":75000.11,\"20160428\":75000.0,\"20160728\":45000.0,\"20160729\":45000.0,\"20160426\":0.0,\"20160920\":36000.0,\"20160629\":56000.0,\"20160921\":87000.03,\"20160628\":56000.0,\"20160725\":46000.0,\"20160627\":56000.0,\"20160727\":64000.0,\"20160726\":36000.0,\"20160624\":35000.0,\"20160927\":0.0,\"20160721\":64000.0,\"20160623\":35000.0,\"20160720\":44000.0,\"20160926\":84000.0,\"20160622\":35000.0,\"20160929\":74500.0,\"20160621\":35000.47,\"20160722\":56000.0,\"20160928\":74000.0,\"20160620\":35000.0,\"20160523\":10000.0,\"20160822\":56000.0,\"20160824\":67000.0,\"20160823\":82000.0,\"20160826\":67000.0,\"20160825\":67000.0,\"20160120\":37000.0,\"20160121\":73000.0,\"20160125\":57000.0,\"20160122\":57000.0,\"20160126\":58000.0,\"20160222\":10000.0,\"20160831\":0.0,\"20160630\":39000.0,\"20160830\":146000.0,\"20161020\":200000.0,\"20161021\":200000.0,\"20161026\":190000.0,\"20160111\":0.0,\"20161027\":190000.0,\"20160112\":70000.0,\"20161024\":180000.0,\"20160113\":70000.0,\"20161025\":0.0,\"20160114\":73000.0,\"20151217\":0.0,\"20160706\":48000.0,\"20160115\":90000.0,\"20151216\":248.74,\"20160707\":68000.0,\"20160708\":47000.0,\"20160118\":58107.02,\"20160119\":0.0,\"20160901\":0.0,\"20160902\":78000.0,\"20160905\":79000.0,\"20160907\":129000.0,\"20160701\":49000.0,\"20160906\":79000.0,\"20160909\":109000.0,\"20160908\":178000.0,\"20160705\":48000.0,\"20160704\":49000.0,\"20160506\":61000.0,\"20160505\":61000.0,\"20160504\":61000.0,\"20160503\":75000.0}}";
        // String cash_transfer_in_amt_ex =
        // "{\"cash_transfer_in_amt_360n_max\":200000.0,\"cash_transfer_in_amt_10t_max\":92000.0,\"cash_transfer_in_amt_1c_sum_1000\":2.0141015E7,\"cash_transfer_in_amt_1c_sum_10000\":2.0141015E7,\"cash_transfer_in_amt_6m_max\":200000.0,\"cash_transfer_in_amt_30n_max\":92000.0,\"cash_transfer_in_amt_1c_sum_100\":2.0141015E7,\"cash_transfer_in_amt_90n_max\":200000.0,\"cash_transfer_in_amt_6m_sum\":8023649.220000001,\"cash_transfer_in_amt_12m_sum_300000\":2.0150601E7,\"cash_transfer_in_amt_180n_sum\":7631648.75,\"cash_transfer_in_amt_12m_sum_10000\":2.0141015E7,\"cash_transfer_in_amt_90n_sum\":3612764.06,\"cash_transfer_in_amt_360n_sum\":9361125.969999999,\"cash_transfer_in_amt_1c_sum_5000\":2.0141015E7,\"cash_transfer_in_amt_12m_sum_3000\":2.0141015E7,\"cash_transfer_in_amt_7n_sum\":104000.0,\"cash_transfer_in_amt_20t_max\":143000.0,\"cash_transfer_in_amt_7d_sum\":288000.0,\"cash_transfer_in_amt_1m_max\":143000.0,\"cash_transfer_in_amt_12m_sum_100000\":2.0150305E7,\"cash_transfer_in_amt_12m_sum_5000\":2.0141015E7,\"cash_transfer_in_amt_7d_max\":92000.0,\"cash_transfer_in_amt_7n_max\":52000.0,\"cash_transfer_in_amt_12m_sum_1000\":2.0141015E7,\"cash_transfer_in_amt_3m_sum\":4378765.609999999,\"cash_transfer_in_amt_12m_sum\":9711525.06,\"cash_transfer_in_amt_180n_max\":200000.0,\"cash_transfer_in_amt_3m_max\":200000.0,\"cash_transfer_in_amt_12m_sum_150000\":2.0150305E7,\"cash_transfer_in_amt_5t_max\":92000.0,\"cash_transfer_in_amt_1c_sum_1\":2.0141015E7,\"cash_transfer_in_amt_1m_sum\":1522039.57,\"cash_transfer_in_amt_12m_max\":291000.0,\"cash_transfer_in_amt_30n_sum\":514000.0,\"cash_transfer_in_amt_12m_sum_100\":2.0141015E7,\"cash_transfer_in_amt_1c_sum_3000\":2.0141015E7}";
        String cash_transfer_in_amt_ex = "{\"cash_transfer_in_amt_360n_max\":200000.0,\"cash_transfer_in_amt_10t_max\":92000.0,\"cash_transfer_in_amt_1c_sum_10000\":2.0141015E7,\"cash_transfer_in_amt_6m_max\":200000.0,\"cash_transfer_in_amt_30n_max\":92000.0,\"cash_transfer_in_amt_1c_sum_100\":2.0141015E7,\"cash_transfer_in_amt_90n_max\":200000.0,\"cash_transfer_in_amt_6m_sum\":8023649.220000001,\"cash_transfer_in_amt_12m_sum_300000\":2.0150601E7,\"cash_transfer_in_amt_180n_sum\":7631648.75,\"cash_transfer_in_amt_12m_sum_10000\":2.0141015E7,\"cash_transfer_in_amt_90n_sum\":3612764.06,\"cash_transfer_in_amt_360n_sum\":9361125.969999999,\"cash_transfer_in_amt_1c_sum_5000\":2.0141015E7,\"cash_transfer_in_amt_12m_sum_3000\":2.0141015E7,\"cash_transfer_in_amt_7n_sum\":104000.0,\"cash_transfer_in_amt_20t_max\":143000.0,\"cash_transfer_in_amt_7d_sum\":288000.0,\"cash_transfer_in_amt_1m_max\":143000.0,\"cash_transfer_in_amt_12m_sum_100000\":2.0150305E7,\"cash_transfer_in_amt_12m_sum_5000\":2.0141015E7,\"cash_transfer_in_amt_7d_max\":92000.0,\"cash_transfer_in_amt_7n_max\":52000.0,\"cash_transfer_in_amt_12m_sum_1000\":2.0141015E7,\"cash_transfer_in_amt_3m_sum\":4378765.609999999,\"cash_transfer_in_amt_12m_sum\":9711525.06,\"cash_transfer_in_amt_180n_max\":200000.0,\"cash_transfer_in_amt_3m_max\":200000.0,\"cash_transfer_in_amt_12m_sum_150000\":2.0150305E7,\"cash_transfer_in_amt_5t_max\":92000.0,\"cash_transfer_in_amt_1c_sum_1\":2.0141015E7,\"cash_transfer_in_amt_1m_sum\":1522039.57,\"cash_transfer_in_amt_12m_max\":291000.0,\"cash_transfer_in_amt_30n_sum\":514000.0,\"cash_transfer_in_amt_12m_sum_100\":2.0141015E7,\"cash_transfer_in_amt_1c_sum_3000\":2.0141015E7}";
        String cash_transfer_in_amt = "{\"cash_transfer_in_amt\":22606.0}";
        JSONObject hisJsonObject = (JSONObject) JSONObject.parse(cash_transfer_in_amt_his);

        Map<String, Map<String, Double>> historyData = new HashMap<String, Map<String, Double>>();
        for (String key : hisJsonObject.keySet()) {
            JSONObject dailyValue = (JSONObject) hisJsonObject.get(key);
            Map<String, Double> values = new HashMap<>();
            for (String vkey : dailyValue.keySet()) {
                values.put(vkey, dailyValue.getDouble(vkey));
            }
            historyData.put(key, values);
        }

        JSONObject exJsonObject = (JSONObject) JSONObject.parse(cash_transfer_in_amt_ex);
        Map<String, Double> extvalues = new HashMap<>();
        for (String vkey : exJsonObject.keySet()) {
            extvalues.put(vkey, exJsonObject.getDouble(vkey));
        }

        JSONObject vvJsonObject = (JSONObject) JSONObject.parse(cash_transfer_in_amt);
        Map<String, Double> vvvalues = new HashMap<>();
        for (String vkey : vvJsonObject.keySet()) {
            vvvalues.put(vkey, vvJsonObject.getDouble(vkey));
        }

        Map<String, Double> result = test.evaluate(historyData, "20161130", vvvalues,
                "90n_max,3m_max,180n_max,5t_max,7d_max,20t_max,10t_max,1m_max,360n_max,30n_max,7n_max,12m_max,6m_max,12m_sum_10000,1c_sum_3000,12m_sum_150000,1c_sum_1000,1c_sum_100,1c_sum_1,6m_sum,12m_sum,7d_sum,1m_sum,12m_sum_300000,360n_sum,7n_sum,30n_sum,90n_sum,180n_sum,3m_sum,12m_sum_5000,12m_sum_3000,12m_sum_1000,12m_sum_100,1c_sum_10000,1c_sum_5000,12m_sum_100000",
                "cash_transfer_in_amt", "", extvalues);

        assertTrue(result.get("cash_transfer_in_amt_360n_max") - 200000.0 < 0.0001);

        assertTrue(result.get("cash_transfer_in_amt_1c_sum_100") - 20141015 < 0.0001);

        assertTrue(result.get("cash_transfer_in_amt_7n_sum") - 241606.0 < 0.0001);

        for (String aakey : result.keySet()) {
            System.out.println("value:" + aakey + ":" + result.get(aakey));
        }
    }

	@Test
	public void test2() throws HiveException, IOException, ParseException {
		MeasureExMap test = new MeasureExMap();

		String cash_transfer_in_amt_his = "{\"score_test\":{\"20170826\":569.4407964293,\"20170827\":569.4407964293,\"20170828\":569.4407964293,\"20170829\":566.5360368047,\"20170831\":566.5360368047,\"20170830\":566.5360368047,\"20170825\":569.4407964293}}";
		// String cash_transfer_in_amt_ex =
		// "{\"cash_transfer_in_amt_360n_max\":200000.0,\"cash_transfer_in_amt_10t_max\":92000.0,\"cash_transfer_in_amt_1c_sum_1000\":2.0141015E7,\"cash_transfer_in_amt_1c_sum_10000\":2.0141015E7,\"cash_transfer_in_amt_6m_max\":200000.0,\"cash_transfer_in_amt_30n_max\":92000.0,\"cash_transfer_in_amt_1c_sum_100\":2.0141015E7,\"cash_transfer_in_amt_90n_max\":200000.0,\"cash_transfer_in_amt_6m_sum\":8023649.220000001,\"cash_transfer_in_amt_12m_sum_300000\":2.0150601E7,\"cash_transfer_in_amt_180n_sum\":7631648.75,\"cash_transfer_in_amt_12m_sum_10000\":2.0141015E7,\"cash_transfer_in_amt_90n_sum\":3612764.06,\"cash_transfer_in_amt_360n_sum\":9361125.969999999,\"cash_transfer_in_amt_1c_sum_5000\":2.0141015E7,\"cash_transfer_in_amt_12m_sum_3000\":2.0141015E7,\"cash_transfer_in_amt_7n_sum\":104000.0,\"cash_transfer_in_amt_20t_max\":143000.0,\"cash_transfer_in_amt_7d_sum\":288000.0,\"cash_transfer_in_amt_1m_max\":143000.0,\"cash_transfer_in_amt_12m_sum_100000\":2.0150305E7,\"cash_transfer_in_amt_12m_sum_5000\":2.0141015E7,\"cash_transfer_in_amt_7d_max\":92000.0,\"cash_transfer_in_amt_7n_max\":52000.0,\"cash_transfer_in_amt_12m_sum_1000\":2.0141015E7,\"cash_transfer_in_amt_3m_sum\":4378765.609999999,\"cash_transfer_in_amt_12m_sum\":9711525.06,\"cash_transfer_in_amt_180n_max\":200000.0,\"cash_transfer_in_amt_3m_max\":200000.0,\"cash_transfer_in_amt_12m_sum_150000\":2.0150305E7,\"cash_transfer_in_amt_5t_max\":92000.0,\"cash_transfer_in_amt_1c_sum_1\":2.0141015E7,\"cash_transfer_in_amt_1m_sum\":1522039.57,\"cash_transfer_in_amt_12m_max\":291000.0,\"cash_transfer_in_amt_30n_sum\":514000.0,\"cash_transfer_in_amt_12m_sum_100\":2.0141015E7,\"cash_transfer_in_amt_1c_sum_3000\":2.0141015E7}";
		String cash_transfer_in_amt = "{\"score_test\":566.5360368047}";
		JSONObject hisJsonObject = (JSONObject) JSONObject.parse(cash_transfer_in_amt_his);

		Map<String, Map<String, Double>> historyData = new HashMap<String, Map<String, Double>>();
		for (String key : hisJsonObject.keySet()) {
			JSONObject dailyValue = (JSONObject) hisJsonObject.get(key);
			Map<String, Double> values = new HashMap<>();
			for (String vkey : dailyValue.keySet()) {
				values.put(vkey, dailyValue.getDouble(vkey));
			}
			historyData.put(key, values);
		}

		Map<String, Double> extvalues = new HashMap<>();

		JSONObject vvJsonObject = (JSONObject) JSONObject.parse(cash_transfer_in_amt);
		Map<String, Double> vvvalues = new HashMap<>();
		for (String vkey : vvJsonObject.keySet()) {
			vvvalues.put(vkey, vvJsonObject.getDouble(vkey));
		}

		Map<String, Double> result = test.evaluate(historyData, "20170831", vvvalues,
				"7n_min",
				"score_test", "", extvalues);

		for (String aakey : result.keySet()) {
			System.out.println("value:" + aakey + ":" + result.get(aakey));
		}
	}
    
    @Test
    public void basicOneDeminsionTest() throws JsonParseException, JsonMappingException, IOException, HiveException, ParseException{
    	MeasureExMap exMap = new MeasureExMap();
    	
    	String hisJsonData = "{\"login_count\":{\"20161103\":15,\"20161102\":12,\"20161101\":6},\"login_count-login_channel-PA18\":{\"20161103\":9,\"20161102\":7,\"20161101\":3},\"login_count-login_channel-APP\":{\"20161103\":6,\"20161102\":5,\"20161101\":3}}";
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Map<String, Double>> hisMapData = mapper.readValue(hisJsonData,
				new TypeReference<LinkedHashMap<String, Map<String, Double>>>() {
				});
		
		String todayJsonData = "{\"login_count\":5.0,\"login_count-login_channel-PA18\":2.0,\"login_count-login_channel-APP\":3.0}";
		Map<String, Double> todayMapData = mapper.readValue(todayJsonData,
				new TypeReference<LinkedHashMap<String, Double>>() {
				});
		
		String hisJsonDataEx = "{\"login_count_90n_sum\":5.0,\"login_count_90n_sum_10\":\"20161101\",\"login_count-login_channel-PA18_90n_sum\":2.0,\"login_count-login_channel-APP_90n_sum\":3.0}";
		Map<String, Double> hisMapDataEx = mapper.readValue(hisJsonDataEx,
				new TypeReference<LinkedHashMap<String, Double>>() {
				});
		
		long start = System.currentTimeMillis();
		Map<String, Double> res = exMap.evaluate(hisMapData, "20161205", todayMapData, "90n_sum,90n_sum_10,30n_avg,1m_avg", "login_count", "login_channel", hisMapDataEx);
		long end = System.currentTimeMillis();
		System.out.println("sub:" + (end - start));
		
		System.out.println(JSON.toJSONString(res));
		Assert.assertNotNull(res.get("login_count-login_channel-APP_90n_sum"));
		Assert.assertNotNull(res.get("login_count-login_channel-APP_90n_sum_10"));
		Assert.assertNotNull(res.get("login_count-login_channel-PA18_90n_sum"));
		Assert.assertNotNull(res.get("login_count-login_channel-PA18_90n_sum_10"));
		Assert.assertNotNull(res.get("login_count_90n_sum_10"));
		Assert.assertNotNull(res.get("login_count_90n_sum"));
		
		Assert.assertEquals(res.get("login_count-login_channel-APP_90n_sum"), 17.0, 0.001);
		Assert.assertEquals(res.get("login_count-login_channel-APP_90n_sum_10"), 20161103, 0.001);
		Assert.assertEquals(res.get("login_count-login_channel-PA18_90n_sum"), 21.0, 0.001);
		Assert.assertEquals(res.get("login_count-login_channel-PA18_90n_sum_10"), 20161102, 0.001);
		Assert.assertEquals(res.get("login_count_90n_sum_10"), 20161101, 0.001);
		Assert.assertEquals(res.get("login_count_90n_sum"), 38.0, 0.001);
    }
    
    @Test
    public void basicOneDeminsionTestIncludeNegative() throws JsonParseException, JsonMappingException, IOException, HiveException, ParseException{
    	MeasureExMap exMap = new MeasureExMap();
    	
    	String hisJsonData = "{\"login_count\":{\"20161103\":15,\"20161102\":12,\"20161101\":6},\"login_count-login_channel-PA18\":{\"20161103\":9,\"20161102\":7,\"20161101\":3},\"login_count-login_channel--1\":{\"20161103\":6,\"20161102\":5,\"20161101\":3}}";
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Map<String, Double>> hisMapData = mapper.readValue(hisJsonData,
				new TypeReference<LinkedHashMap<String, Map<String, Double>>>() {
				});
		
		String todayJsonData = "{\"login_count\":5.0,\"login_count-login_channel-PA18\":2.0,\"login_count-login_channel--1\":3.0}";
		Map<String, Double> todayMapData = mapper.readValue(todayJsonData,
				new TypeReference<LinkedHashMap<String, Double>>() {
				});
		
		String hisJsonDataEx = "{\"login_count_90n_sum\":5.0,\"login_count_90n_sum_10\":\"20161101\",\"login_count-login_channel-PA18_90n_sum\":2.0,\"login_count-login_channel--1_90n_sum\":3.0}";
		Map<String, Double> hisMapDataEx = mapper.readValue(hisJsonDataEx,
				new TypeReference<LinkedHashMap<String, Double>>() {
				});
		
		long start = System.currentTimeMillis();
		Map<String, Double> res = exMap.evaluate(hisMapData, "20161201", todayMapData, "90n_sum,90n_sum_10", "login_count", "login_channel", hisMapDataEx);
		long end = System.currentTimeMillis();
		System.out.println("sub:" + (end - start));
		
		System.out.println(JSON.toJSONString(res));
		Assert.assertNotNull(res.get("login_count-login_channel--1_90n_sum"));
		Assert.assertNotNull(res.get("login_count-login_channel--1_90n_sum_10"));
		Assert.assertNotNull(res.get("login_count-login_channel-PA18_90n_sum"));
		Assert.assertNotNull(res.get("login_count-login_channel-PA18_90n_sum_10"));
		Assert.assertNotNull(res.get("login_count_90n_sum_10"));
		Assert.assertNotNull(res.get("login_count_90n_sum"));
		
		Assert.assertEquals(res.get("login_count-login_channel--1_90n_sum"), 17.0, 0.001);
		Assert.assertEquals(res.get("login_count-login_channel--1_90n_sum_10"), 20161103, 0.001);
		Assert.assertEquals(res.get("login_count-login_channel-PA18_90n_sum"), 21.0, 0.001);
		Assert.assertEquals(res.get("login_count-login_channel-PA18_90n_sum_10"), 20161102, 0.001);
		Assert.assertEquals(res.get("login_count_90n_sum_10"), 20161101, 0.001);
		Assert.assertEquals(res.get("login_count_90n_sum"), 38.0, 0.001);
    }

}
