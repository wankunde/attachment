package com.paic.data.hive.common.udf;

import java.text.ParseException;
import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;


public class RemoveRepeatTest {
    @Test
    public void test() throws ParseException{
        RemoveRepeat removeRepeat = new RemoveRepeat();
        String s = removeRepeat.evaluate("aa","bb","ccc","aa");
        String[] arr = s.split(",");
        List<String> list = Arrays.asList(arr);
        Assert.assertEquals(arr.length,3);
        Assert.assertEquals(list.contains("aa"),true);
        Assert.assertEquals(list.contains("bb"),true);
        Assert.assertEquals(list.contains("ccc"),true);
    }
}
