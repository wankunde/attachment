package com.paic.data.hive.common.utils;

import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.junit.Test;

import java.io.IOException;
import java.text.ParseException;
import java.util.Arrays;

/**
 * Created by WANKUN603 on 2016-06-16.
 */
public class UdfUtilsTest {

    @Test
    public void testGetDays() throws Exception {
        String[] dts = UdfUtils.getDays("20150101","20160606");
        System.out.println(Arrays.toString(dts));
    }

    @Test
    public void testGetCalendarStart() throws Exception {
        System.out.println(UdfUtils.getCalendarStart("20160104",90));
    }
    
    @Test
    public void basicTest() throws ParseException, HiveException, IOException{
    	String period = "1m";
    	String dt="20161130";
    	
    	String startDate = UdfUtils.shiftDate(period, dt, -1);
        String endDate = dt;
        
        System.out.println("startDate:" + startDate + ", endDate:" + endDate);
    }

}