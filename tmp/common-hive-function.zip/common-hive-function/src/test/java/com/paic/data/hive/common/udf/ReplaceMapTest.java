package com.paic.data.hive.common.udf;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDF.DeferredJavaObject;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDF.DeferredObject;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.io.Text;
import org.junit.Assert;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ReplaceMapTest {

	@Test
	public void basicDoubleTest() throws JsonParseException, JsonMappingException, IOException, HiveException{
		ReplaceMap replace = getDouble();
		
		String jsonData = "{\"login_count\":5.0,\"login_count&login_channel$PA18\":2.0,\"login_count&login_channel$APP\":3.0}";
		
		DeferredObject[] deferredObject = this.getDoubleArgements(jsonData);

		Map<String, Double> res = (Map<String, Double>) replace.evaluate(deferredObject);
		System.out.println(res);
		
		Assert.assertEquals(res.size(), 3);
		Assert.assertNotNull(res.get("login_count"));
		Assert.assertNotNull(res.get("login_count-login_channel-PA18"));
		Assert.assertNotNull(res.get("login_count-login_channel-APP"));
		
		Assert.assertEquals(res.get("login_count"), 5.0, 0.001);
		Assert.assertEquals(res.get("login_count-login_channel-PA18"), 2.0, 0.001);
		Assert.assertEquals(res.get("login_count-login_channel-APP"), 3.0, 0.001);
		
	}
	
	@Test
	public void basicStringTest() throws JsonParseException, JsonMappingException, IOException, HiveException{
		ReplaceMap replace = getString();
		
		String jsonData = "{\"time&login_channel$PA18_init\":\"20161101\",\"login_time&login_channel$APP_init\":\"20161201\",\"login_time_init\":\"20161201\",\"login_time_last\":\"20161204\",\"time_last\":\"20161204\",\"time&login_channel$APP_init\":\"20161201\",\"login_time&login_channel$APP_last\":\"20161204\",\"time&login_channel$PA18_last\":\"20161201\",\"login_time&login_channel$PA18_last\":\"20161201\",\"time_init\":\"20161201\",\"login_time&login_channel$PA18_init\":\"20161101\",\"time&login_channel$APP_last\":\"20161204\"}";
		
		DeferredObject[] deferredObject = this.getStringArgements(jsonData);

		Map<String, String> res = (Map<String, String>) replace.evaluate(deferredObject);
		System.out.println(res);
		
		Assert.assertNotNull(res);
		Assert.assertNotNull(res.get("login_time_init"));
		Assert.assertNotNull(res.get("time_init"));
		Assert.assertNotNull(res.get("login_time_last"));
		Assert.assertEquals(res.get("login_time_init"), "20161201");
		Assert.assertEquals(res.get("login_time_last"), "20161204");
		
		Assert.assertNotNull(res.get("login_time-login_channel-APP_init"));
		Assert.assertNotNull(res.get("login_time-login_channel-APP_last"));
		Assert.assertNotNull(res.get("login_time-login_channel-PA18_last"));
		Assert.assertNotNull(res.get("login_time-login_channel-PA18_init"));
		Assert.assertEquals(res.get("login_time-login_channel-APP_init"), "20161201");
		Assert.assertEquals(res.get("login_time-login_channel-APP_last"), "20161204");
		Assert.assertEquals(res.get("login_time-login_channel-PA18_last"), "20161201");
		Assert.assertEquals(res.get("login_time-login_channel-PA18_init"), "20161101");
		
	}
	
	private ReplaceMap getDouble() throws UDFArgumentException {
		ReplaceMap item = new ReplaceMap();
		ObjectInspector[] args = new ObjectInspector[5];
		args[0] = ObjectInspectorFactory.getStandardMapObjectInspector(
				PrimitiveObjectInspectorFactory.writableStringObjectInspector,
				ObjectInspectorFactory.getStandardMapObjectInspector(
						PrimitiveObjectInspectorFactory.writableStringObjectInspector,
						PrimitiveObjectInspectorFactory.writableDoubleObjectInspector));
		args[1] = PrimitiveObjectInspectorFactory.writableStringObjectInspector;
		args[2] = PrimitiveObjectInspectorFactory.writableStringObjectInspector;
		args[3] = PrimitiveObjectInspectorFactory.writableStringObjectInspector;
		args[4] = PrimitiveObjectInspectorFactory.writableStringObjectInspector;

		item.initializeAndFoldConstants(args);

		return item;
	}
	
	private ReplaceMap getString() throws UDFArgumentException {
		ReplaceMap item = new ReplaceMap();
		ObjectInspector[] args = new ObjectInspector[5];
		args[0] = ObjectInspectorFactory.getStandardMapObjectInspector(
				PrimitiveObjectInspectorFactory.writableStringObjectInspector,
				ObjectInspectorFactory.getStandardMapObjectInspector(
						PrimitiveObjectInspectorFactory.writableStringObjectInspector,
						PrimitiveObjectInspectorFactory.writableDoubleObjectInspector));
		args[1] = PrimitiveObjectInspectorFactory.writableStringObjectInspector;
		args[2] = PrimitiveObjectInspectorFactory.writableStringObjectInspector;
		args[3] = PrimitiveObjectInspectorFactory.writableStringObjectInspector;
		args[4] = PrimitiveObjectInspectorFactory.writableStringObjectInspector;

		item.initializeAndFoldConstants(args);

		return item;
	}
	

	private DeferredObject[] getDoubleArgements(String jsonData)
			throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper mapper = new ObjectMapper();
		LinkedHashMap<String, Double> mapData = mapper.readValue(jsonData,
				new TypeReference<LinkedHashMap<String, Double>>() {
				});

		DeferredObject[] deferredObject = new DeferredObject[5];
		deferredObject[0] = new DeferredJavaObject(mapData);
		deferredObject[1] = new DeferredJavaObject(new Text("&"));
		deferredObject[2] = new DeferredJavaObject(new Text("-"));
		deferredObject[3] = new DeferredJavaObject(new Text("\\$"));
		deferredObject[4] = new DeferredJavaObject(new Text("-"));

		return deferredObject;
	}
	
	private DeferredObject[] getStringArgements(String jsonData)
			throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper mapper = new ObjectMapper();
		LinkedHashMap<String, String> mapData = mapper.readValue(jsonData,
				new TypeReference<LinkedHashMap<String, String>>() {
				});

		DeferredObject[] deferredObject = new DeferredObject[5];
		deferredObject[0] = new DeferredJavaObject(mapData);
		deferredObject[1] = new DeferredJavaObject(new Text("&"));
		deferredObject[2] = new DeferredJavaObject(new Text("-"));
		deferredObject[3] = new DeferredJavaObject(new Text("\\$"));
		deferredObject[4] = new DeferredJavaObject(new Text("-"));

		return deferredObject;
	}
}
