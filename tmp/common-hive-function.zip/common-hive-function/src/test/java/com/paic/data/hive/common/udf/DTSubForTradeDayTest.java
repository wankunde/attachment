package com.paic.data.hive.common.udf;

import java.io.IOException;
import java.text.ParseException;

import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.junit.Assert;
import org.junit.Test;


public class DTSubForTradeDayTest {

	@Test
	public void basicTest() throws ParseException, HiveException, IOException{
		DTSubForTradeDay tradeDay = new DTSubForTradeDay();
		
		Assert.assertEquals(tradeDay.evaluate("20161015", 0), "20161014");
		Assert.assertEquals(tradeDay.evaluate("20161016", 0), "20161014");
		Assert.assertEquals(tradeDay.evaluate("20161010", 0), "20161010");
		
		Assert.assertEquals(tradeDay.evaluate("20161010", 3), "20160928");
		Assert.assertEquals(tradeDay.evaluate("20161011", 1), "20161010");
		Assert.assertEquals(tradeDay.evaluate("20161017", 3), "20161012");
	}
}
