package com.paic.data.hive.common;

/**
 * Created by WANKUN603 on 2016-10-26.
 */
public class TransformMeasure {
    public static String tranform(String key){
        StringBuffer sb = new StringBuffer();
        char c = '&';
        for (int i = 0; i < key.length(); i++) {
            char x = key.charAt(i);
            if (x == '-') {
                sb.append(c);
                if (c == '&') {
                    c = '$';
                } else {
                    c = '&';
                }
            } else {
                sb.append(x);
            }
        }
        String res = sb.toString();
        return res;
    }

    /*public static void main(String[] args) throws IOException {
        List<String> lines = Files.readAllLines(Paths.get("D:/tmp/input.txt"));
        for(String line:lines){
            String[] tabs = line.split("\t");
            StringBuffer sb = new StringBuffer();
            for(String tab:tabs){
                sb.append(tranform(tab)+"\t");
            }
            System.out.println(sb.toString());
        }
    }*/
}
