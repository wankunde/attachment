package com.paic.data.hive.common.udf;

import java.text.ParseException;

import org.junit.Test;

public class PTimestampFormatTest {
	
	@Test
	public void test() throws ParseException {
		PTimestampFormat test = new PTimestampFormat();
		System.out.println(test.evaluate(20160809152525l, "yyyyMMddHHmmss"));
	}

}
