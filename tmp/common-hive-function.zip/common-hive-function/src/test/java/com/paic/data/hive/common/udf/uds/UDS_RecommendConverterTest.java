package com.paic.data.hive.common.udf.uds;

import static org.junit.Assert.*;

import org.junit.Test;

public class UDS_RecommendConverterTest {

	@Test
	public void testEvaluate() {
		UDS_RecommendConverter converter = new UDS_RecommendConverter();
		
		assertTrue(converter.evaluate(null) == null);
		assertTrue(converter.evaluate("") == null );
		assertTrue(converter.evaluate("     ") == null);
		assertTrue(converter.evaluate("   asdfsd  ").equals("ASDFSD"));
		assertTrue(converter.evaluate("ZTSX1223453 ").equals("1223453"));
		assertTrue(converter.evaluate("ZTSX-1223453 ").equals("1223453"));
		assertTrue(converter.evaluate("ZTSX---1223453 ").equals("1223453"));
		assertTrue(converter.evaluate("ZtsX---122a3453 ").equals("122A3453"));
		assertTrue(converter.evaluate("PASK1223453 ").equals("1223453"));
		assertTrue(converter.evaluate("PAsk1223453 ").equals("1223453"));
		assertTrue(converter.evaluate("PASK-1223453 ").equals("1223453"));
		assertTrue(converter.evaluate("PASK---1223453 ").equals("1223453"));
		assertTrue(converter.evaluate("1234567BD").equals("1234567"));
		assertTrue(converter.evaluate("1234567W2").equals("1234567"));
		assertTrue(converter.evaluate("1234a567w2").equals("1234A567"));
		assertTrue(converter.evaluate("1234a567 w2").equals("1234A567"));
		assertTrue(converter.evaluate("1234567   BD").equals("1234567"));
		assertTrue(converter.evaluate("ZTSX1223453 BD").equals("1223453"));
		assertTrue(converter.evaluate("ZTSX---1223453 BD").equals("1223453"));
		assertTrue(converter.evaluate("PASK1223453 BD").equals("1223453"));
		assertTrue(converter.evaluate("PASK---1223453 BD").equals("1223453"));
		assertTrue(converter.evaluate("ZTSX1223453 w2").equals("1223453"));
		assertTrue(converter.evaluate("ZTSX---1223453 w2").equals("1223453"));
		assertTrue(converter.evaluate("PASK1223453 W2").equals("1223453"));
		assertTrue(converter.evaluate("PASK---1223453 W2").equals("1223453"));
	}

}
