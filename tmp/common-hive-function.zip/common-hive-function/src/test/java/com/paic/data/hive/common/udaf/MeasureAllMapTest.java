package com.paic.data.hive.common.udaf;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.paic.data.hive.common.udaf.MeasureAllMap.MeasureMapDoubleEvaluator;
import com.paic.data.hive.common.udaf.MeasureAllMap.DoubleMapBean;

/**
 * @author SHIDAWEN768
 *
 */
public class MeasureAllMapTest {

	@Test
	public void basicTest() throws JsonParseException, JsonMappingException, IOException{
		MeasureMapDoubleEvaluator allMap = new MeasureMapDoubleEvaluator();
		
		allMap.iterate(34.0, "20161201", "aum", "");
		allMap.iterate(34.0, "20161202", "aum", "");
		allMap.iterate(34.0, "20161203", "aum", "");
		allMap.iterate(34.0, "20161204", "aum", "");
		
		Assert.assertNotNull(allMap.terminate());
		Assert.assertNotNull(allMap.terminatePartial());
		System.out.println(JSON.toJSONString(allMap.terminate()));
		
		String jsonData = "{\"aum\":{\"20161103\":34,\"20161102\":34,\"20161101\":34,\"20161104\":34}}";
		ObjectMapper mapper = new ObjectMapper();
		LinkedHashMap<String, Map<String, Double>> mapData = mapper.readValue(jsonData,
				new TypeReference<LinkedHashMap<String, Map<String, Double>>>() {
				});
		
		DoubleMapBean mapBean = new DoubleMapBean();
		mapBean.value = mapData;
		
		allMap.merge(mapBean);
		
		Assert.assertNotNull(allMap.terminate());
		Assert.assertNotNull(allMap.terminatePartial());
		Assert.assertNotNull(allMap.terminate().get("aum"));
		Assert.assertEquals(allMap.terminate().get("aum").size(), 8);
	}
	
	@Test
	public void basicOneDeminsionTest() throws JsonParseException, JsonMappingException, IOException{
		MeasureMapDoubleEvaluator allMap = new MeasureMapDoubleEvaluator();
		
		allMap.iterate(3D, "20161201", "login_count", "login_channel", new Object[]{"APP"});
		allMap.iterate(5D, "20161202", "login_count", "login_channel", new Object[]{"APP"});
		allMap.iterate(6D, "20161203", "login_count", "login_channel", new Object[]{"APP"});
		allMap.iterate(3D, "20161201", "login_count", "login_channel", new Object[]{"PA18"});
		allMap.iterate(7D, "20161202", "login_count", "login_channel", new Object[]{"PA18"});
		allMap.iterate(9D, "20161203", "login_count", "login_channel", new Object[]{"PA18"});
		
		Assert.assertNotNull(allMap.terminate());
		Assert.assertNotNull(allMap.terminatePartial());
		System.out.println(JSON.toJSONString(allMap.terminate()));
		
		String jsonData = "{\"login_count\":{\"20161103\":15,\"20161102\":12,\"20161101\":6},\"login_count-login_channel-PA18\":{\"20161103\":9,\"20161102\":7,\"20161101\":3},\"login_count-login_channel-APP\":{\"20161103\":6,\"20161102\":5,\"20161101\":3}}";
		ObjectMapper mapper = new ObjectMapper();
		LinkedHashMap<String, Map<String, Double>> mapData = mapper.readValue(jsonData,
				new TypeReference<LinkedHashMap<String, Map<String, Double>>>() {
				});
		
		DoubleMapBean mapBean = new DoubleMapBean();
		mapBean.value = mapData;
		
		allMap.merge(mapBean);
		
		Assert.assertNotNull(allMap.terminate());
		Assert.assertNotNull(allMap.terminatePartial());
		Assert.assertNotNull(allMap.terminate().get("login_count"));
		Assert.assertNotNull(allMap.terminate().get("login_count-login_channel-PA18"));
		Assert.assertNotNull(allMap.terminate().get("login_count-login_channel-APP"));
		
		Assert.assertEquals(allMap.terminate().get("login_count").size(), 6);
		Assert.assertEquals(allMap.terminate().get("login_count-login_channel-PA18").size(), 6);
		Assert.assertEquals(allMap.terminate().get("login_count-login_channel-APP").size(), 6);
	}
	
	
	@Test
	public void basicTwoDeminsionTest() throws JsonParseException, JsonMappingException, IOException{
		MeasureMapDoubleEvaluator allMap = new MeasureMapDoubleEvaluator();
		
		allMap.iterate(3D, "20161201", "login_count", "login_channel&src_id", new Object[]{"APP", 1});
		allMap.iterate(5D, "20161202", "login_count", "login_channel&src_id", new Object[]{"APP", 1});
		allMap.iterate(6D, "20161203", "login_count", "login_channel&src_id", new Object[]{"APP", 2});
		allMap.iterate(3D, "20161201", "login_count", "login_channel&src_id", new Object[]{"PA18", 1});
		allMap.iterate(7D, "20161202", "login_count", "login_channel&src_id", new Object[]{"PA18", 2});
		allMap.iterate(9D, "20161203", "login_count", "login_channel&src_id", new Object[]{"PA18", 1});
		
		Assert.assertNotNull(allMap.terminate());
		Assert.assertNotNull(allMap.terminatePartial());
		System.out.println(JSON.toJSONString(allMap.terminate()));
		
		String jsonData = "{\"login_count\":{\"20161103\":15,\"20161102\":12,\"20161101\":6},\"login_count-login_channel-PA18\":{\"20161103\":9,\"20161102\":7,\"20161101\":3},\"login_count-login_channel-APP\":{\"20161103\":6,\"20161102\":5,\"20161101\":3}}";
		ObjectMapper mapper = new ObjectMapper();
		LinkedHashMap<String, Map<String, Double>> mapData = mapper.readValue(jsonData,
				new TypeReference<LinkedHashMap<String, Map<String, Double>>>() {
				});
		
		DoubleMapBean mapBean = new DoubleMapBean();
		mapBean.value = mapData;
		
		allMap.merge(mapBean);
		
		Assert.assertNotNull(allMap.terminate());
		Assert.assertNotNull(allMap.terminatePartial());
		Assert.assertNotNull(allMap.terminate().get("login_count"));
		Assert.assertNotNull(allMap.terminate().get("login_count-login_channel-PA18"));
		Assert.assertNotNull(allMap.terminate().get("login_count-login_channel-APP"));
		Assert.assertNotNull(allMap.terminate().get("login_count-src_id-2"));
		Assert.assertNotNull(allMap.terminate().get("login_count-src_id-1"));
		
		System.out.println(JSON.toJSONString(allMap.terminate()));
		
		Assert.assertEquals(allMap.terminate().get("login_count").size(), 6);
		Assert.assertEquals(allMap.terminate().get("login_count-login_channel-PA18").size(), 6);
		Assert.assertEquals(allMap.terminate().get("login_count-login_channel-APP").size(), 6);
		Assert.assertEquals(allMap.terminate().get("login_count-src_id-2").size(), 2);
		Assert.assertEquals(allMap.terminate().get("login_count-src_id-1").size(), 3);
	}
	
	@Test
	public void basicTwoDeminsionCombineTest() throws JsonParseException, JsonMappingException, IOException{
		MeasureMapDoubleEvaluator allMap = new MeasureMapDoubleEvaluator();
		
		allMap.iterate(3D, "20161201", "login_count", "login_channel:src_id", new Object[]{"APP", 1});
		allMap.iterate(5D, "20161202", "login_count", "login_channel:src_id", new Object[]{"APP", 1});
		allMap.iterate(6D, "20161203", "login_count", "login_channel:src_id", new Object[]{"APP", 2});
		allMap.iterate(3D, "20161201", "login_count", "login_channel:src_id", new Object[]{"PA18", 1});
		allMap.iterate(7D, "20161202", "login_count", "login_channel:src_id", new Object[]{"PA18", 2});
		allMap.iterate(9D, "20161203", "login_count", "login_channel:src_id", new Object[]{"PA18", 1});
		
		Assert.assertNotNull(allMap.terminate());
		Assert.assertNotNull(allMap.terminatePartial());
		System.out.println(JSON.toJSONString(allMap.terminate()));
		
		String jsonData = "{\"login_count\":{\"20161103\":15,\"20161102\":12,\"20161101\":6},\"login_count-login_channel-APP-src_id-1\":{\"20161102\":5,\"20161101\":3},\"login_count-login_channel-PA18-src_id-1\":{\"20161103\":9,\"20161101\":3},\"login_count-login_channel-APP-src_id-2\":{\"20161103\":6},\"login_count-login_channel-PA18-src_id-2\":{\"20161102\":7}}";
		ObjectMapper mapper = new ObjectMapper();
		LinkedHashMap<String, Map<String, Double>> mapData = mapper.readValue(jsonData,
				new TypeReference<LinkedHashMap<String, Map<String, Double>>>() {
				});
		
		DoubleMapBean mapBean = new DoubleMapBean();
		mapBean.value = mapData;
		
		allMap.merge(mapBean);
		
		Assert.assertNotNull(allMap.terminate());
		Assert.assertNotNull(allMap.terminatePartial());
		Assert.assertNotNull(allMap.terminate().get("login_count"));
		Assert.assertNotNull(allMap.terminate().get("login_count-login_channel-APP-src_id-1"));
		Assert.assertNotNull(allMap.terminate().get("login_count-login_channel-PA18-src_id-1"));
		Assert.assertNotNull(allMap.terminate().get("login_count-login_channel-APP-src_id-2"));
		Assert.assertNotNull(allMap.terminate().get("login_count-login_channel-PA18-src_id-2"));
		
		System.out.println(JSON.toJSONString(allMap.terminate()));
		
		Assert.assertEquals(allMap.terminate().get("login_count").size(), 6);
		Assert.assertEquals(allMap.terminate().get("login_count-login_channel-APP-src_id-1").size(), 4);
		Assert.assertEquals(allMap.terminate().get("login_count-login_channel-PA18-src_id-1").size(), 4);
		Assert.assertEquals(allMap.terminate().get("login_count-login_channel-APP-src_id-2").size(), 2);
		Assert.assertEquals(allMap.terminate().get("login_count-login_channel-PA18-src_id-2").size(), 2);
	}
}
