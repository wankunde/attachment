package com.paic.data.hive.common.udf;

import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.junit.Assert;
import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author SHIDAWEN768
 */
public class MeasureHisMapTest {

    @Test
    public void basicTest()
            throws JsonParseException, JsonMappingException, IOException, HiveException, ParseException {
        MeasureHisMap hisMap = new MeasureHisMap();

        Assert.assertNotNull(hisMap.evaluate(null, "20161210", null, null));
        Assert.assertNotNull(hisMap.evaluate(new HashMap<String, Map<String, Double>>(), "20161210", null, ""));
        Assert.assertNotNull(hisMap.evaluate(null, "20161210", new HashMap<String, Double>(), ""));
        Assert.assertNotNull(hisMap.evaluate(new HashMap<String, Map<String, Double>>(), "20161210", null, "360n_sum,180n_sum,90n_sum,30n_sum,7n_sum,0d_sum,6m_sum,3m_sum,1m_sum,7d_sum,12m_sum"));

        String jsonData = "{\"aum\":{\"20161128\":9.73,\"20161129\":9.73,\"20161122\":9.73}}";

        ObjectMapper mapper = new ObjectMapper();
        Map<String, Map<String, Double>> mapHisData = mapper.readValue(jsonData,
                new TypeReference<Map<String, Map<String, Double>>>() {
                });

        String jsonTodayData = "{\"aum\":30.0}";
        Map<String, Double> mapTodayData = mapper.readValue(jsonTodayData, new TypeReference<Map<String, Double>>() {
        });

        Map<String, Map<String, Double>> res = hisMap.evaluate(mapHisData, "20161210", mapTodayData,
                "360n_sum,180n_sum,90n_sum,30n_sum,7n_sum,0d_sum,6m_sum,3m_sum,1m_sum,7d_sum,12m_sum");

        System.out.println(JSON.toJSONString(res));
    }

    @Test
    public void basic02Test() throws JsonParseException, JsonMappingException, IOException, HiveException, ParseException {
        MeasureHisMap hisMap = new MeasureHisMap();

        Map<String, Map<String, Double>> mapHisData = new HashMap<>();

        ObjectMapper mapper = new ObjectMapper();
        String jsonTodayData = "{\"aum\":30.0}";
        Map<String, Double> mapTodayData = mapper.readValue(jsonTodayData, new TypeReference<Map<String, Double>>() {
        });

        Map<String, Map<String, Double>> res = hisMap.evaluate(mapHisData, "20161210", mapTodayData,
                "");

        System.out.println(JSON.toJSONString(res));

    }

    @Test
    public void basic03Test() throws JsonParseException, JsonMappingException, IOException, HiveException, ParseException {
        MeasureHisMap hisMap = new MeasureHisMap();

        String jsonData = "{\"aum\":{\"20161128\":9.73,\"20161129\":9.73,\"20161122\":9.73}}";

        ObjectMapper mapper = new ObjectMapper();
        Map<String, Map<String, Double>> mapHisData = mapper.readValue(jsonData,
                new TypeReference<Map<String, Map<String, Double>>>() {
                });

        String jsonTodayData = "{\"aum\":30.0}";
        Map<String, Double> mapTodayData = mapper.readValue(jsonTodayData, new TypeReference<Map<String, Double>>() {
        });

        Map<String, Map<String, Double>> res = hisMap.evaluate(mapHisData, "20161210", mapTodayData,
                "");

        System.out.println(JSON.toJSONString(res));

    }

    @Test
    public void basic04Test()
            throws IOException, HiveException, ParseException {
        MeasureExMap ex = new MeasureExMap();

        String jsonData = "{\"asset_inout\":{\"20161128\":-1600.0,\"20161129\":0.0,\"20161122\":4500.0,\"20161121\":0.0,\"20161124\":0.0,\"20161123\":0.0,\"20161125\":0.0,\"20161130\":0.0,\"20160930\":-4000.0,\"20170207\":0.0,\"20170206\":0.0,\"20161109\":0.0,\"20170209\":0.0,\"20170208\":0.0,\"20170203\":0.0,\"20161108\":200.0,\"20161107\":-500.0,\"20161102\":0.0,\"20160530\":0.0,\"20161101\":-1300.0,\"20161104\":4000.0,\"20160531\":0.0,\"20161103\":0.0,\"20160401\":0.0,\"20160408\":0.0,\"20160407\":39.05,\"20160406\":0.0,\"20160405\":0.0,\"20160809\":0.0,\"20160805\":-1477.71,\"20160808\":0.0,\"20160801\":0.0,\"20161012\":0.0,\"20160802\":4238.82,\"20161011\":0.0,\"20161010\":3000.0,\"20160803\":-124.73,\"20160804\":0.0,\"20161118\":0.0,\"20161117\":0.0,\"20161014\":0.0,\"20161116\":0.0,\"20161013\":0.0,\"20161115\":-900.0,\"20161019\":0.0,\"20161114\":0.0,\"20161018\":0.0,\"20161017\":2000.0,\"20161111\":-1700.0,\"20161110\":0.0,\"20160818\":0.0,\"20160519\":-624.33,\"20160819\":0.0,\"20160816\":0.0,\"20160411\":0.0,\"20160817\":0.0,\"20160913\":-28.56,\"20160914\":-124.62,\"20160418\":0.0,\"20160912\":-1600.0,\"20160419\":0.0,\"20160719\":0.0,\"20160412\":0.0,\"20160413\":0.0,\"20160414\":398.0,\"20160415\":0.0,\"20160718\":0.0,\"20160615\":0.0,\"20160614\":0.0,\"20160715\":0.0,\"20160714\":200.0,\"20160617\":0.0,\"20160616\":0.0,\"20160713\":0.0,\"20160919\":0.0,\"20170125\":0.0,\"20170220\":0.0,\"20160712\":-1000.0,\"20170126\":0.0,\"20160711\":0.0,\"20170221\":0.0,\"20160613\":-1900.0,\"20170222\":3000.0,\"20160510\":0.0,\"20170223\":3000.0,\"20160811\":0.0,\"20170224\":-3000.0,\"20160512\":0.0,\"20160511\":379.34,\"20160810\":0.0,\"20170123\":0.0,\"20170227\":0.0,\"20170124\":-3000.0,\"20160513\":0.0,\"20170228\":0.0,\"20160815\":0.0,\"20160516\":0.0,\"20160518\":-42.22,\"20160517\":-300.0,\"20160812\":0.0,\"20170120\":0.0,\"20160421\":0.0,\"20160422\":0.0,\"20160829\":0.0,\"20160420\":0.0,\"20160329\":1.0,\"20160922\":0.0,\"20160429\":0.0,\"20160923\":5564.63,\"20160427\":0.0,\"20160428\":-30.47,\"20160425\":2500.0,\"20160728\":0.0,\"20160426\":0.0,\"20160729\":-30.53,\"20160920\":2817.24,\"20160629\":-513.36,\"20160921\":-2817.24,\"20160628\":0.0,\"20160725\":0.0,\"20160627\":0.0,\"20170118\":0.0,\"20160727\":0.0,\"20170119\":0.0,\"20160726\":0.0,\"20160927\":0.0,\"20160721\":0.0,\"20160624\":3941.5,\"20170116\":0.0,\"20160926\":0.0,\"20170117\":0.0,\"20160623\":24.94,\"20160720\":0.0,\"20160520\":0.0,\"20160622\":94.82,\"20160929\":-5000.0,\"20160928\":0.0,\"20160722\":-371.25,\"20160621\":0.0,\"20170210\":0.0,\"20160525\":-403.0,\"20170215\":0.0,\"20170112\":1000.0,\"20160620\":0.0,\"20170113\":0.0,\"20160524\":2882.0,\"20170216\":0.0,\"20170110\":2000.0,\"20160523\":0.0,\"20160822\":0.0,\"20170213\":0.0,\"20170111\":0.0,\"20170214\":0.0,\"20160824\":0.0,\"20160823\":0.0,\"20160826\":0.0,\"20170217\":0.0,\"20160527\":0.0,\"20160526\":-582.82,\"20160825\":0.0,\"20170301\":5000.0,\"20170103\":-1000.0,\"20170104\":0.0,\"20170105\":-1000.0,\"20170106\":-3310.1,\"20170109\":310.1,\"20160831\":0.0,\"20160830\":0.0,\"20160630\":0.0,\"20160509\":-1000.0,\"20160706\":0.0,\"20160707\":0.0,\"20160708\":0.0,\"20160901\":0.0,\"20160902\":0.0,\"20160905\":0.0,\"20160907\":0.0,\"20160701\":0.0,\"20160906\":0.0,\"20160909\":-1000.0,\"20160908\":0.0,\"20160705\":0.0,\"20160704\":-1037.94,\"20160506\":0.0,\"20160505\":0.0,\"20160504\":0.0,\"20160503\":53.44,\"20161216\":-2000.0,\"20161215\":0.0,\"20161219\":0.0,\"20160603\":-53.97,\"20160606\":0.0,\"20161214\":0.0,\"20161213\":-1030.0,\"20161212\":0.0,\"20160601\":83.19,\"20160602\":0.0,\"20160331\":973.5,\"20160330\":1000.0,\"20160608\":0.0,\"20160607\":-128.72,\"20161205\":3100.0,\"20161207\":0.0,\"20161206\":0.0,\"20161209\":-70.0,\"20161208\":0.0,\"20161201\":0.0,\"20161202\":-4000.0,\"20161230\":0.0,\"20161222\":0.0,\"20161223\":1000.0,\"20161220\":0.0,\"20161221\":0.0,\"20161226\":0.0,\"20161227\":2000.0,\"20161228\":0.0,\"20161229\":0.0,\"20161031\":0.0,\"20161020\":0.0,\"20161021\":-300.0,\"20161026\":0.0,\"20161027\":0.0,\"20161024\":0.0,\"20161025\":-400.0,\"20161028\":0.0}}";

        ObjectMapper mapper = new ObjectMapper();
        Map<String, Map<String, Double>> mapHisData = mapper.readValue(jsonData,
                new TypeReference<Map<String, Map<String, Double>>>() {
                });

        String jsonTodayData = "{\"aum\":30.0}";
        Map<String, Double> mapTodayData = mapper.readValue(jsonTodayData, new TypeReference<Map<String, Double>>() {
        });

        Map<String, Double> res = ex.evaluate(mapHisData, "20170301", "0d_sum_10000", "asset_inout", "");

        System.out.println(JSON.toJSONString(res));
    }
}
