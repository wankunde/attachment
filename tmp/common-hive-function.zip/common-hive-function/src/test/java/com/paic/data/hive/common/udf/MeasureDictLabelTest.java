package com.paic.data.hive.common.udf;

import java.io.IOException;

import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.junit.Assert;
import org.junit.Test;

public class MeasureDictLabelTest {
	
	@Test
	public void basicTest() throws HiveException, IOException{
		MeasureDictLabel label = new MeasureDictLabel();
		
		Assert.assertNotNull(label.evaluate(null, "SUBSCRIBE_STATUS"));
		Assert.assertNotNull(label.evaluate("其他", "SUBSCRIBE_STATUS"));
		
		Assert.assertEquals(label.evaluate("0", "SUBSCRIBE_STATUS"), "已订阅");
	}

}
