package com.paic.data.hive.common.udf;

import java.io.IOException;

import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.junit.Assert;
import org.junit.Test;

public class MeasureDictTest {

	@Test
	public void basicTest() throws HiveException, IOException{
		MeasureDict dict = new MeasureDict();
		
		Assert.assertNotNull(dict.evaluate(null, "SUBSCRIBE_STATUS"));
		Assert.assertNotNull(dict.evaluate("#other", "SUBSCRIBE_STATUS"));
		
		Assert.assertEquals(dict.evaluate("0", "SUBSCRIBE_STATUS"), "0");
	}
}
