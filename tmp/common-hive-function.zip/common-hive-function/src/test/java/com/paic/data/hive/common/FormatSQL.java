package com.paic.data.hive.common;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by WANKUN603 on 2016-07-13.
 */
public class FormatSQL {
    public static void main(String[] args) {

        Pattern p1 = Pattern.compile("module_(.*)_dict as");
        Pattern p2 = Pattern.compile("module_(.*) as");


        String sql = "select cust_code,sha_open_date,sza_open_date,trd_count_ex['trd_count-trade_cls-1_3m_max'] trd_count_trade_cls_1_3m_max,unify_sid from fact.UI_INDEX_MODULE_COLLECT2 where dt=20160810";
        sql = sql.replaceAll("set ", "\nset ");
        sql = sql.replaceAll("\\\\r", " ");
        sql = sql.replaceAll("\\\\n", " ");
        sql = sql.replaceAll("\\\\t", " ");
        sql = sql.replaceAll("with ", "\nwith ");
        sql = sql.replaceAll("insert ", "\ninsert ");
        sql = sql.replaceAll("select", "\nselect");
        sql = sql.replaceAll("SELECT", "\nSELECT");
        sql = sql.replaceAll("from", "\nfrom");
        sql = sql.replaceAll("where", "\nwhere");
        sql = sql.replaceAll("left join ", "\nleft join ");
        sql = sql.replaceAll("group by", "\ngroup by");
        sql = sql.replaceAll(" on ", "\non ");
        sql = sql.replaceAll("measure_", "\nmeasure_");

        Matcher m1 = p1.matcher(sql);
        if (m1.find()) {
            sql = sql.replace(m1.group(), "\n" + m1.group());
        }
//        Matcher m2 = p2.matcher(sql);
//        while (m2.find()) {
////            for(int i=0;i<m2.groupCount();i++){
//                System.out.println(m2.group());
//                System.out.println(m2.group(1));
////            }

//            sql = sql.replaceAll(m2.group(), "\n" + m2.group());
//        }
        System.out.println(sql);
    }
}
