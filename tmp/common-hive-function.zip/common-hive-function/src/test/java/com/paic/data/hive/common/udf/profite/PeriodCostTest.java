package com.paic.data.hive.common.udf.profite;

import org.apache.hadoop.hive.common.type.HiveDecimal;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDAFEvaluator;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.ArrayList;

/**
 * Created by wankun603 on 2018-06-15.
 */
public class PeriodCostTest {

  @Test
  public void computeCost() throws HiveException {
    PeriodCost.PeriodCostEvaluator evaluator = new PeriodCost.PeriodCostEvaluator();

    PeriodCost.PeriodCostEvaluator.PeriodCostBuf agg = new PeriodCost.PeriodCostEvaluator.PeriodCostBuf();
    agg.values = new ArrayList<>();
    agg.values.add(HiveDecimal.create(BigDecimal.valueOf(1.1)));
    agg.values.add(HiveDecimal.create(BigDecimal.valueOf(1.2)));
    agg.values.add(HiveDecimal.create(BigDecimal.valueOf(1.3)));
    System.out.println(evaluator.terminate(agg));

  }
}
