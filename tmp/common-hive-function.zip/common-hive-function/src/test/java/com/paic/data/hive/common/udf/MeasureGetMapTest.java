package com.paic.data.hive.common.udf;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDF.DeferredObject;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDF.DeferredJavaObject;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.junit.Assert;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author SHIDAWEN768
 *
 */
public class MeasureGetMapTest {

	@Test
	public void basicTest() throws JsonParseException, JsonMappingException, IOException, HiveException {
		MeasureGetMap get = this.get();
		String jsonData = "{\"aum\":{\"20161128\":9.73,\"20161129\":9.73,\"20161122\":9.73,\"20161121\":9.73,\"20161124\":9.73,\"20161123\":9.73,\"20161125\":9.73,\"20161130\":9.73,\"20160930\":9.73,\"20161109\":9.73,\"20161108\":9.73,\"20161107\":9.73,\"20161102\":9.73,\"20160530\":9.71,\"20161101\":9.73,\"20160531\":9.71,\"20161104\":9.73,\"20161103\":9.73,\"20160401\":9.71,\"20160408\":9.71,\"20160407\":9.71,\"20160406\":9.71,\"20160405\":9.71,\"20160809\":9.72,\"20160805\":9.72,\"20160808\":9.72,\"20160801\":9.72,\"20161012\":9.73,\"20160802\":9.72,\"20161011\":9.73,\"20160803\":9.72,\"20161010\":9.73,\"20160804\":9.72,\"20161118\":9.73,\"20161014\":9.73,\"20161117\":9.73,\"20161116\":9.73,\"20161013\":9.73,\"20161115\":9.73,\"20161114\":9.73,\"20161019\":9.73,\"20161018\":9.73,\"20161017\":9.73,\"20161111\":9.73,\"20161110\":9.73,\"20160818\":9.72,\"20160519\":9.71,\"20160819\":9.72,\"20160314\":9.7,\"20160816\":9.72,\"20160315\":9.7,\"20160817\":9.72,\"20160411\":9.71,\"20160316\":9.7,\"20160317\":9.7,\"20160318\":9.7,\"20160913\":9.72,\"20160914\":9.72,\"20160108\":9.0,\"20160418\":9.71,\"20160912\":9.72,\"20160419\":9.71,\"20160719\":9.72,\"20160106\":9.0,\"20160412\":9.71,\"20160107\":9.0,\"20160413\":9.71,\"20160310\":9.7,\"20160104\":9.0,\"20160414\":9.71,\"20160311\":9.7,\"20160105\":9.0,\"20160718\":9.72,\"20160415\":9.71,\"20160615\":9.71,\"20160715\":9.72,\"20160614\":9.71,\"20160714\":9.72,\"20160617\":9.71,\"20160919\":9.72,\"20160713\":9.72,\"20160616\":9.71,\"20160712\":9.72,\"20160711\":9.72,\"20160510\":9.71,\"20160613\":9.71,\"20160811\":9.72,\"20160512\":9.71,\"20160810\":9.72,\"20160511\":9.71,\"20160513\":9.71,\"20160815\":9.72,\"20160516\":9.71,\"20160518\":9.71,\"20160812\":9.72,\"20160517\":9.71,\"20160421\":9.71,\"20160422\":9.71,\"20160829\":9.72,\"20160324\":9.71,\"20160325\":9.71,\"20160420\":9.71,\"20160328\":9.71,\"20160329\":9.71,\"20160922\":9.73,\"20160429\":9.71,\"20160923\":9.73,\"20160427\":9.71,\"20160428\":9.71,\"20160728\":9.72,\"20160425\":9.71,\"20160322\":9.71,\"20160729\":9.72,\"20160426\":9.71,\"20160323\":9.71,\"20160920\":9.72,\"20160629\":9.72,\"20160921\":9.73,\"20160321\":9.71,\"20160725\":9.72,\"20160628\":9.72,\"20160627\":9.72,\"20160727\":9.72,\"20160726\":9.72,\"20160721\":9.72,\"20160927\":9.73,\"20160624\":9.72,\"20160926\":9.73,\"20160720\":9.72,\"20160623\":9.72,\"20160520\":9.71,\"20160929\":9.73,\"20160622\":9.72,\"20160928\":9.73,\"20160722\":9.72,\"20160621\":9.72,\"20160525\":9.71,\"20160620\":9.71,\"20160524\":9.71,\"20160822\":9.72,\"20160523\":9.71,\"20160824\":9.72,\"20160823\":9.72,\"20160826\":9.72,\"20160527\":9.71,\"20160825\":9.72,\"20160526\":9.71,\"20160120\":9.0,\"20160121\":9.0,\"20160229\":9.7,\"20160125\":9.0,\"20160225\":9.0,\"20160122\":9.0,\"20160226\":9.0,\"20160128\":9.0,\"20160223\":9.0,\"20160129\":9.0,\"20160224\":9.0,\"20160126\":9.0,\"20160127\":9.0,\"20160222\":9.0,\"20160831\":9.72,\"20160630\":9.72,\"20160830\":9.72,\"20160308\":9.7,\"20160218\":9.0,\"20160309\":9.7,\"20160219\":9.0,\"20160307\":9.7,\"20160304\":9.7,\"20160111\":9.0,\"20160112\":9.0,\"20160215\":9.0,\"20160302\":9.7,\"20160113\":9.0,\"20160216\":9.0,\"20160303\":9.7,\"20160509\":9.71,\"20160114\":9.0,\"20160217\":9.0,\"20160706\":9.72,\"20160115\":9.0,\"20160301\":9.7,\"20160707\":9.72,\"20160708\":9.72,\"20160118\":9.0,\"20160119\":9.0,\"20160901\":9.72,\"20160902\":9.72,\"20160905\":9.72,\"20160701\":9.72,\"20160907\":9.72,\"20160906\":9.72,\"20160909\":9.72,\"20160908\":9.72,\"20160705\":9.72,\"20160704\":9.72,\"20160506\":9.71,\"20160505\":9.71,\"20160504\":9.71,\"20160503\":9.71,\"20160202\":9.0,\"20160201\":9.0,\"20160204\":9.0,\"20160203\":9.0,\"20160205\":9.0,\"20161216\":9.73,\"20161215\":9.73,\"20161219\":9.73,\"20160603\":9.71,\"20160606\":9.71,\"20161214\":9.73,\"20161213\":9.73,\"20160601\":9.71,\"20161212\":9.73,\"20160602\":9.71,\"20151230\":9.7,\"20160331\":9.71,\"20151231\":9.7,\"20160330\":9.71,\"20160608\":9.71,\"20160607\":9.71,\"20161205\":9.73,\"20161207\":9.73,\"20161206\":9.73,\"20161209\":9.73,\"20161208\":9.73,\"20161201\":9.73,\"20161202\":9.73,\"20151221\":9.7,\"20151222\":9.7,\"20151223\":9.7,\"20151224\":9.7,\"20151225\":9.7,\"20151228\":9.7,\"20151229\":9.7,\"20161220\":9.73,\"20161031\":9.73,\"20161020\":9.73,\"20161021\":9.73,\"20161026\":9.73,\"20161027\":9.73,\"20161024\":9.73,\"20161025\":9.73,\"20161028\":9.73}}";

		DeferredObject[] deferredObject = this.getArgements(jsonData);

		Map<Text, DoubleWritable> res = (Map<Text, DoubleWritable>) get.evaluate(deferredObject);

		Assert.assertEquals(res.size(), 1);
		Assert.assertNotNull(res.get(new Text("aum")));
		Assert.assertEquals(res.get(new Text("aum")).get(), 9.73, 0.001);

	}

	@Test
	public void basicBoundaryTest() throws JsonParseException, JsonMappingException, IOException, HiveException {
		MeasureGetMap get = this.get();

		String jsonData = "{\"aum\":{}}";

		DeferredObject[] deferredObject = this.getArgements(jsonData);
		Map<Text, DoubleWritable> res = (Map<Text, DoubleWritable>) get.evaluate(deferredObject);

		Assert.assertEquals(res.size(), 0);
		Assert.assertNull(res.get(new Text("aum")));
		
		jsonData = "{}";
		deferredObject = this.getArgements(jsonData);
		res = (Map<Text, DoubleWritable>) get.evaluate(deferredObject);
		
		Assert.assertEquals(res.size(), 0);
		Assert.assertNull(res.get(new Text("aum")));
	}

	private MeasureGetMap get() throws UDFArgumentException {
		MeasureGetMap get = new MeasureGetMap();
		ObjectInspector[] args = new ObjectInspector[2];
		args[0] = ObjectInspectorFactory.getStandardMapObjectInspector(
				PrimitiveObjectInspectorFactory.writableStringObjectInspector,
				ObjectInspectorFactory.getStandardMapObjectInspector(
						PrimitiveObjectInspectorFactory.writableStringObjectInspector,
						PrimitiveObjectInspectorFactory.writableDoubleObjectInspector));
		args[1] = PrimitiveObjectInspectorFactory.writableStringObjectInspector;

		get.initializeAndFoldConstants(args);

		return get;
	}

	private DeferredObject[] getArgements(String jsonData)
			throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper mapper = new ObjectMapper();
		LinkedHashMap<String, LinkedHashMap<String, Double>> mapData = mapper.readValue(jsonData,
				new TypeReference<LinkedHashMap<String, LinkedHashMap<String, Double>>>() {
				});

		DeferredObject[] deferredObject = new DeferredObject[2];
		deferredObject[0] = new DeferredJavaObject(mapData);
		deferredObject[1] = new DeferredJavaObject(new Text("20161128"));

		return deferredObject;
	}

}
