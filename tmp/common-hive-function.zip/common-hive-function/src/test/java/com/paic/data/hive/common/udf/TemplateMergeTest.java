package com.paic.data.hive.common.udf;

import java.io.IOException;

import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.junit.Test;

import com.alibaba.fastjson.JSONObject;
import com.paic.data.hive.common.udf.template.TemplateMerge;

public class TemplateMergeTest {
	
	@Test
	public void template()throws HiveException, IOException{
		TemplateMerge template = new TemplateMerge();
		String content = "温馨提示：您参与申购的[$NAME$]已中签，中签缴款日为[$DATE$]，请及时登录账户系统查看中签情况";
		JSONObject json = new JSONObject();
		json.put("name","隆利科技");
		json.put("date", "2018年11月23日");
		System.out.println("template_merge:params="+json);
		String replaceContent = template.evaluate(json.toString(),content);
		System.out.println("template_merge:replaceContent="+replaceContent);
	}

}
