package com.paic.data.hive.common.utils;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by WANKUN603 on 2016-10-14.
 */
public class MakeDateTool {

    public String[] split(String line, char... spliters) {
        List<String> res = new ArrayList<>();
        String s = new String();
        boolean f = false;
        for (int j = 0; j < line.length(); j++) {
            char c = line.charAt(j);
            for (char sp : spliters) {
                if (sp == c) {
                    f = true;
                    if (s.length() > 0)
                        res.add(s);
                    s = new String();
                }
            }
            if (!f)
                s += c;
            f = false;
        }
        if (s.length() > 0)
            res.add(s);
        return res.toArray(new String[res.size()]);
    }


    public String[][] headers() throws IOException {
        File f = new File("src/test/resources/TestSchema");
        List<String> lines = FileUtils.readLines(f);
        String[][] headers = new String[lines.size()][2];
        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);
            String[] ss = split(line, ' ', '\t');
            headers[i][0] = ss[0];
            headers[i][1] = ss[1];
        }
        return headers;
    }

    public void datas() throws IOException {
        File f = new File("src/test/resources/TestData");
        List<String> lines = FileUtils.readLines(f);
        String[][] headers = headers();
        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);
            String[] ss = split(line, '\t');
            //补数据位
            if (ss.length < headers.length) {
                String[] nss = new String[headers.length];
                System.arraycopy(ss, 0, nss, 0, ss.length);
                Arrays.fill(nss, ss.length, nss.length, "NULL");
                ss = nss;
            }
            for (int j = 0; j < headers.length; j++) {
                if (ss[j].equals("NULL"))
                    ss[j] = "null";
                else if (headers[j][1].equals("string"))
                    ss[j] = "\"" + ss[j] + "\"";
                else if (headers[j][1].equals("Long"))
                    ss[j] = ss[j] + "l";
                else if (headers[j][1].equals("Double"))
                    ss[j] = ss[j] + "d";

                String d = null;
                switch (headers[j][1]) {
                    case "string":
                        d = "String " + headers[j][0] + " = " + ss[j] + ";";
                        break;
                    case "bigint":
                        d = "Long " + headers[j][0] + " = " + ss[j] + ";";
                        break;
                    case "int":
                        d = "Integer " + headers[j][0] + " = " + ss[j] + ";";
                        break;
                }
                System.out.println(d);
            }
            System.out.println("/*************************************/");
        }
    }


    public static void main(String[] args) throws IOException {
        new MakeDateTool().datas();
    }
}
