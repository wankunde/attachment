package com.paic.data.hive.common.udaf;

import java.io.IOException;
import java.util.LinkedHashMap;

import org.junit.Assert;
import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.paic.data.hive.common.udaf.MeasureObjMap.MeasureObjMapEvaluator;
import com.paic.data.hive.common.udaf.MeasureObjMap.StringMapBean;

public class MeasureObjMap2Test {

	@Test
	public void basicTest() throws JsonParseException, JsonMappingException, IOException{
		MeasureObjMapEvaluator objMap = new MeasureObjMapEvaluator();
		
		objMap.iterate("20161201", "20161201", "login_time", "", "init", new Object[]{"20161201"});
		objMap.iterate("20161201", "20161201", "login_time", "", "init", new Object[]{"20161201"});
		objMap.iterate("20161203", "20161203", "login_time", "", "init", new Object[]{"20161203"});
		objMap.iterate("20161204", "20161204", "login_time", "", "init", new Object[]{"20161204"});
		
		Assert.assertNotNull(objMap.terminate());
		Assert.assertNotNull(objMap.terminatePartial());
		Assert.assertNotNull(objMap.terminate().get("login_time_init"));
		Assert.assertNotNull(objMap.terminate().get("time_init"));
		Assert.assertEquals(objMap.terminate().get("login_time_init"), "20161201");
		System.out.println(JSON.toJSONString(objMap.terminate()));
		
		String jsonData = "{\"login_time_init\":\"20161201\",\"time_init\":\"20161201\"}";
		ObjectMapper mapper = new ObjectMapper();
		LinkedHashMap<String, String> mapData = mapper.readValue(jsonData,
				new TypeReference<LinkedHashMap<String, String>>() {
				});
		
		StringMapBean stringMapBean = new StringMapBean();
		stringMapBean.value = mapData;
		
		objMap.merge(stringMapBean);
		
		Assert.assertNotNull(objMap.terminate());
		Assert.assertNotNull(objMap.terminatePartial());
		Assert.assertNotNull(objMap.terminate().get("login_time_init"));
		Assert.assertNotNull(objMap.terminate().get("time_init"));
		Assert.assertEquals(objMap.terminate().get("login_time_init"), "20161201");
		System.out.println(JSON.toJSONString(objMap.terminate()));
		
		
		
		jsonData = "{\"login_time_init\":\"20161101\",\"time_init\":\"20161101\"}";
		mapData = mapper.readValue(jsonData,
				new TypeReference<LinkedHashMap<String, String>>() {
				});
		
		stringMapBean.value = mapData;
		
		objMap.merge(stringMapBean);
		
		Assert.assertNotNull(objMap.terminate());
		Assert.assertNotNull(objMap.terminatePartial());
		Assert.assertNotNull(objMap.terminate().get("login_time_init"));
		Assert.assertNotNull(objMap.terminate().get("time_init"));
		Assert.assertEquals(objMap.terminate().get("login_time_init"), "20161101");
		System.out.println(JSON.toJSONString(objMap.terminate()));
	}
	
	@Test
	public void basicInitAndLastTest() throws JsonParseException, JsonMappingException, IOException{
		MeasureObjMapEvaluator objMap = new MeasureObjMapEvaluator();
		
		objMap.iterate("20161201", "20161201", "login_time", "", "init&last", new Object[]{"20161201"});
		objMap.iterate("20161201", "20161201", "login_time", "", "init&last", new Object[]{"20161201"});
		objMap.iterate("20161203", "20161203", "login_time", "", "init&last", new Object[]{"20161203"});
		objMap.iterate("20161204", "20161204", "login_time", "", "init&last", new Object[]{"20161204"});
		
		Assert.assertNotNull(objMap.terminate());
		Assert.assertNotNull(objMap.terminatePartial());
		Assert.assertNotNull(objMap.terminate().get("login_time_init"));
		Assert.assertNotNull(objMap.terminate().get("time_init"));
		Assert.assertNotNull(objMap.terminate().get("login_time_last"));
		Assert.assertNotNull(objMap.terminate().get("time_last"));
		Assert.assertEquals(objMap.terminate().get("login_time_init"), "20161201");
		Assert.assertEquals(objMap.terminate().get("login_time_last"), "20161204");
		System.out.println(JSON.toJSONString(objMap.terminate()));
		
		String jsonData = "{\"login_time_init\":\"20161101\",\"login_time_last\":\"20161204\",\"time_last\":\"20161204\",\"time_init\":\"20161101\"}";
		ObjectMapper mapper = new ObjectMapper();
		LinkedHashMap<String, String> mapData = mapper.readValue(jsonData,
				new TypeReference<LinkedHashMap<String, String>>() {
				});
		
		StringMapBean stringMapBean = new StringMapBean();
		stringMapBean.value = mapData;
		
		objMap.merge(stringMapBean);
		
		Assert.assertNotNull(objMap.terminate());
		Assert.assertNotNull(objMap.terminatePartial());
		Assert.assertNotNull(objMap.terminate().get("login_time_init"));
		Assert.assertNotNull(objMap.terminate().get("time_init"));
		Assert.assertNotNull(objMap.terminate().get("login_time_last"));
		Assert.assertNotNull(objMap.terminate().get("time_last"));
		Assert.assertEquals(objMap.terminate().get("login_time_init"), "20161101");
		Assert.assertEquals(objMap.terminate().get("login_time_last"), "20161204");
		System.out.println(JSON.toJSONString(objMap.terminate()));
		
		
		
		jsonData = "{\"login_time_init\":\"20161101\",\"login_time_last\":\"20161204\",\"time_last\":\"20161204\",\"time_init\":\"20161101\"}";
		mapData = mapper.readValue(jsonData,
				new TypeReference<LinkedHashMap<String, String>>() {
				});
		
		stringMapBean.value = mapData;
		
		objMap.merge(stringMapBean);
		
		Assert.assertNotNull(objMap.terminate());
		Assert.assertNotNull(objMap.terminatePartial());
		Assert.assertNotNull(objMap.terminate().get("login_time_init"));
		Assert.assertNotNull(objMap.terminate().get("time_init"));
		Assert.assertNotNull(objMap.terminate().get("login_time_last"));
		Assert.assertNotNull(objMap.terminate().get("time_last"));
		Assert.assertEquals(objMap.terminate().get("login_time_init"), "20161101");
		Assert.assertEquals(objMap.terminate().get("login_time_last"), "20161204");
		System.out.println(JSON.toJSONString(objMap.terminate()));
	}
	
	@Test
	public void basicOneDeminsionInitAndLastTest() throws JsonParseException, JsonMappingException, IOException{
		MeasureObjMapEvaluator objMap = new MeasureObjMapEvaluator();
		
		objMap.iterate("20161201", "20161201", "login_time", "login_channel", "init&last", new Object[]{"20161201", "APP"});
		objMap.iterate("20161201", "20161201", "login_time", "login_channel", "init&last", new Object[]{"20161201", "PA18"});
		objMap.iterate("20161203", "20161203", "login_time", "login_channel", "init&last", new Object[]{"20161203", "APP"});
		objMap.iterate("20161204", "20161204", "login_time", "login_channel", "init&last", new Object[]{"20161204", "APP"});
		
		Assert.assertNotNull(objMap.terminate());
		Assert.assertNotNull(objMap.terminatePartial());
		Assert.assertNotNull(objMap.terminate().get("login_time_init"));
		Assert.assertNotNull(objMap.terminate().get("time_init"));
		Assert.assertNotNull(objMap.terminate().get("login_time_last"));
		Assert.assertEquals(objMap.terminate().get("login_time_init"), "20161201");
		Assert.assertEquals(objMap.terminate().get("login_time_last"), "20161204");
		
		Assert.assertNotNull(objMap.terminate().get("login_time-login_channel-APP_init"));
		Assert.assertNotNull(objMap.terminate().get("login_time-login_channel-APP_last"));
		Assert.assertNotNull(objMap.terminate().get("login_time-login_channel-PA18_last"));
		Assert.assertNotNull(objMap.terminate().get("login_time-login_channel-PA18_init"));
		Assert.assertEquals(objMap.terminate().get("login_time-login_channel-APP_init"), "20161201");
		Assert.assertEquals(objMap.terminate().get("login_time-login_channel-APP_last"), "20161204");
		Assert.assertEquals(objMap.terminate().get("login_time-login_channel-PA18_last"), "20161201");
		Assert.assertEquals(objMap.terminate().get("login_time-login_channel-PA18_init"), "20161201");

		System.out.println(JSON.toJSONString(objMap.terminate()));
		
		String jsonData = "{\"time-login_channel-PA18_init\":\"20161101\",\"login_time-login_channel-APP_init\":\"20161201\",\"login_time_init\":\"20161201\",\"login_time_last\":\"20161204\",\"time_last\":\"20161204\",\"time-login_channel-APP_init\":\"20161201\",\"login_time-login_channel-APP_last\":\"20161204\",\"time-login_channel-PA18_last\":\"20161201\",\"login_time-login_channel-PA18_last\":\"20161201\",\"time_init\":\"20161201\",\"login_time-login_channel-PA18_init\":\"20161101\",\"time-login_channel-APP_last\":\"20161204\"}";
		ObjectMapper mapper = new ObjectMapper();
		LinkedHashMap<String, String> mapData = mapper.readValue(jsonData,
				new TypeReference<LinkedHashMap<String, String>>() {
				});
		
		StringMapBean stringMapBean = new StringMapBean();
		stringMapBean.value = mapData;
		
		objMap.merge(stringMapBean);
		
		Assert.assertNotNull(objMap.terminate());
		Assert.assertNotNull(objMap.terminatePartial());
		Assert.assertNotNull(objMap.terminate().get("login_time_init"));
		Assert.assertNotNull(objMap.terminate().get("time_init"));
		Assert.assertNotNull(objMap.terminate().get("login_time_last"));
		Assert.assertEquals(objMap.terminate().get("login_time_init"), "20161201");
		Assert.assertEquals(objMap.terminate().get("login_time_last"), "20161204");
		
		Assert.assertNotNull(objMap.terminate().get("login_time-login_channel-APP_init"));
		Assert.assertNotNull(objMap.terminate().get("login_time-login_channel-APP_last"));
		Assert.assertNotNull(objMap.terminate().get("login_time-login_channel-PA18_last"));
		Assert.assertNotNull(objMap.terminate().get("login_time-login_channel-PA18_init"));
		Assert.assertEquals(objMap.terminate().get("login_time-login_channel-APP_init"), "20161201");
		Assert.assertEquals(objMap.terminate().get("login_time-login_channel-APP_last"), "20161204");
		Assert.assertEquals(objMap.terminate().get("login_time-login_channel-PA18_last"), "20161201");
		Assert.assertEquals(objMap.terminate().get("login_time-login_channel-PA18_init"), "20161101");
		
		System.out.println(JSON.toJSONString(objMap.terminate()));
	}
	
	
	@Test
	public void basicTwoDeminsionInitAndLastTest() throws JsonParseException, JsonMappingException, IOException{
		MeasureObjMapEvaluator objMap = new MeasureObjMapEvaluator();
		
		objMap.iterate("20161201", "20161201", "login_time", "login_channel&scr_id", "init&last", new Object[]{"20161201", "APP", 1});
		objMap.iterate("20161201", "20161201", "login_time", "login_channel&scr_id", "init&last", new Object[]{"20161201", "PA18", 1});
		objMap.iterate("20161203", "20161203", "login_time", "login_channel&scr_id", "init&last", new Object[]{"20161203", "APP", 2});
		objMap.iterate("20161204", "20161204", "login_time", "login_channel&scr_id", "init&last", new Object[]{"20161204", "APP", 1});
		
		Assert.assertNotNull(objMap.terminate());
		Assert.assertNotNull(objMap.terminatePartial());
		Assert.assertNotNull(objMap.terminate().get("login_time_init"));
		Assert.assertNotNull(objMap.terminate().get("time_init"));
		Assert.assertNotNull(objMap.terminate().get("login_time_last"));
		Assert.assertEquals(objMap.terminate().get("login_time_init"), "20161201");
		Assert.assertEquals(objMap.terminate().get("login_time_last"), "20161204");
		
		Assert.assertNotNull(objMap.terminate().get("login_time-login_channel-APP_init"));
		Assert.assertNotNull(objMap.terminate().get("login_time-login_channel-APP_last"));
		Assert.assertNotNull(objMap.terminate().get("login_time-login_channel-PA18_last"));
		Assert.assertNotNull(objMap.terminate().get("login_time-login_channel-PA18_init"));
		Assert.assertEquals(objMap.terminate().get("login_time-login_channel-APP_init"), "20161201");
		Assert.assertEquals(objMap.terminate().get("login_time-login_channel-APP_last"), "20161204");
		Assert.assertEquals(objMap.terminate().get("login_time-login_channel-PA18_last"), "20161201");
		Assert.assertEquals(objMap.terminate().get("login_time-login_channel-PA18_init"), "20161201");
		
		Assert.assertNotNull(objMap.terminate().get("login_time-scr_id-2_init"));
		Assert.assertNotNull(objMap.terminate().get("login_time-scr_id-2_last"));
		Assert.assertNotNull(objMap.terminate().get("login_time-scr_id-1_init"));
		Assert.assertNotNull(objMap.terminate().get("login_time-scr_id-1_last"));
		Assert.assertEquals(objMap.terminate().get("login_time-scr_id-2_init"), "20161203");
		Assert.assertEquals(objMap.terminate().get("login_time-scr_id-2_last"), "20161203");
		Assert.assertEquals(objMap.terminate().get("login_time-scr_id-1_init"), "20161201");
		Assert.assertEquals(objMap.terminate().get("login_time-scr_id-1_last"), "20161204");

		System.out.println(JSON.toJSONString(objMap.terminate()));
		
		String jsonData = "{\"time-login_channel-PA18_init\":\"20161201\",\"login_time-login_channel-APP_init\":\"20161201\",\"login_time-scr_id-2_init\":\"20161203\",\"time_last\":\"20161204\",\"time-login_channel-APP_init\":\"20161201\",\"login_time-login_channel-APP_last\":\"20161204\",\"time-login_channel-PA18_last\":\"20161201\",\"time-scr_id-1_init\":\"20161201\",\"time_init\":\"20161201\",\"login_time-login_channel-PA18_init\":\"20161201\",\"login_time-scr_id-2_last\":\"20161203\",\"time-scr_id-1_last\":\"20161204\",\"login_time_init\":\"20161201\",\"login_time_last\":\"20161204\",\"login_time-login_channel-PA18_last\":\"20161201\",\"login_time-scr_id-1_init\":\"20161201\",\"time-scr_id-2_last\":\"20161203\",\"login_time-scr_id-1_last\":\"20161204\",\"time-scr_id-2_init\":\"20161203\",\"time-login_channel-APP_last\":\"20161204\"}";
		ObjectMapper mapper = new ObjectMapper();
		LinkedHashMap<String, String> mapData = mapper.readValue(jsonData,
				new TypeReference<LinkedHashMap<String, String>>() {
				});
		
		StringMapBean stringMapBean = new StringMapBean();
		stringMapBean.value = mapData;
		
		objMap.merge(stringMapBean);
		
		Assert.assertNotNull(objMap.terminate());
		Assert.assertNotNull(objMap.terminatePartial());
		Assert.assertNotNull(objMap.terminate().get("login_time_init"));
		Assert.assertNotNull(objMap.terminate().get("time_init"));
		Assert.assertNotNull(objMap.terminate().get("login_time_last"));
		Assert.assertEquals(objMap.terminate().get("login_time_init"), "20161201");
		Assert.assertEquals(objMap.terminate().get("login_time_last"), "20161204");
		
		Assert.assertNotNull(objMap.terminate().get("login_time-login_channel-APP_init"));
		Assert.assertNotNull(objMap.terminate().get("login_time-login_channel-APP_last"));
		Assert.assertNotNull(objMap.terminate().get("login_time-login_channel-PA18_last"));
		Assert.assertNotNull(objMap.terminate().get("login_time-login_channel-PA18_init"));
		Assert.assertEquals(objMap.terminate().get("login_time-login_channel-APP_init"), "20161201");
		Assert.assertEquals(objMap.terminate().get("login_time-login_channel-APP_last"), "20161204");
		Assert.assertEquals(objMap.terminate().get("login_time-login_channel-PA18_last"), "20161201");
		Assert.assertEquals(objMap.terminate().get("login_time-login_channel-PA18_init"), "20161201");
		
		Assert.assertNotNull(objMap.terminate().get("login_time-scr_id-2_init"));
		Assert.assertNotNull(objMap.terminate().get("login_time-scr_id-2_last"));
		Assert.assertNotNull(objMap.terminate().get("login_time-scr_id-1_init"));
		Assert.assertNotNull(objMap.terminate().get("login_time-scr_id-1_last"));
		Assert.assertEquals(objMap.terminate().get("login_time-scr_id-2_init"), "20161203");
		Assert.assertEquals(objMap.terminate().get("login_time-scr_id-2_last"), "20161203");
		Assert.assertEquals(objMap.terminate().get("login_time-scr_id-1_init"), "20161201");
		Assert.assertEquals(objMap.terminate().get("login_time-scr_id-1_last"), "20161204");
		
		System.out.println(JSON.toJSONString(objMap.terminate()));
	}
	
	
}
