package com.paic.data.hive.common.udf.uds.idcard;

import static org.junit.Assert.*;

import org.junit.Test;

import com.paic.data.hive.common.udf.uds.idcard.UDS_IsValidIdCard;

public class UDS_IsValidIdCardTest {

	@Test
	public void testEvaluate() {
		UDS_IsValidIdCard valid = new UDS_IsValidIdCard();
		
		boolean isvalid = false;

	    isvalid = valid.evaluate("5102025108282121");
	    assertFalse(isvalid);
	    
	    isvalid = valid.evaluate("51020251082821");
	    assertFalse(isvalid);
	    
		isvalid = valid.evaluate("110108004733785");
		assertFalse(isvalid);
		
	    isvalid = valid.evaluate("510202510828212");
	    assertTrue(isvalid);

	    isvalid = valid.evaluate("51022419761040002x");
		assertFalse(isvalid);
		
	    isvalid = valid.evaluate("51022419761002002x");
		assertTrue(isvalid);
		
	    isvalid = valid.evaluate("000000000820457");
	    assertFalse(isvalid);
	    
	    isvalid = valid.evaluate("340102691031201");
	    assertTrue(isvalid);

	    isvalid = valid.evaluate("3401026910312*1");
	    assertFalse(isvalid);
	    
	    isvalid = valid.evaluate("510202510828212A");
	    assertFalse(isvalid);
	    
	    isvalid = valid.evaluate("51020251082821a1");
	    assertFalse(isvalid);
	}

}
