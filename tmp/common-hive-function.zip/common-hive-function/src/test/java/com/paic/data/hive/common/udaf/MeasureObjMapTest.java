package com.paic.data.hive.common.udaf;

import org.junit.Test;

/**
 * Created by WANKUN603 on 2016-10-14.
 */
public class MeasureObjMapTest {

    private MeasureObjMap.MeasureObjMapEvaluator map1() {
        String cust_code = "180368633";
        String fund_type = "1";
        String fund_code = "#other";
        String seq_no = "20160727095420ayzzyh";
        Long sub_time = 20160727l;
        String asset_acct = null;
        Long unsub_time = null;
        String channel = null;

        MeasureObjMap.MeasureObjMapEvaluator e = new MeasureObjMap.MeasureObjMapEvaluator();
        e.iterate(seq_no, seq_no, "sub_time&asset_acct&unsub_time&channel&fund_code",
                "fund_type&fund_code",
                "init&last",
                sub_time, asset_acct, unsub_time, channel, fund_code, fund_type);
        return e;
    }

    private MeasureObjMap.MeasureObjMapEvaluator map2() {
        String cust_code = "180368633";
        String fund_type = "0";
        String fund_code = "5149";
        String seq_no = "201604111148075149";
        Long sub_time = 20160411l;
        String asset_acct = "302619043049";
        Long unsub_time = null;
        String channel = "1";

        MeasureObjMap.MeasureObjMapEvaluator e = new MeasureObjMap.MeasureObjMapEvaluator();
        e.iterate(seq_no, seq_no, "sub_time&asset_acct&unsub_time&channel&fund_code",
                "fund_type&fund_code",
                "init&last",
                sub_time, asset_acct, unsub_time, channel, fund_code, fund_type);
        return e;
    }

    @Test
    public void testIterator() {
        MeasureObjMap.MeasureObjMapEvaluator e1 = map1();
        MeasureObjMap.MeasureObjMapEvaluator e2 = map2();
        e1.merge(e2.countAgg);
        System.out.println(e1.countAgg.value);
    }
}
