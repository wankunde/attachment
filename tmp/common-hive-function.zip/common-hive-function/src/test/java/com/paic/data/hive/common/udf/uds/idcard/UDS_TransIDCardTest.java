package com.paic.data.hive.common.udf.uds.idcard;

import static org.junit.Assert.*;

import org.junit.Test;

public class UDS_TransIDCardTest {

	@Test
	public void testEvaluate() {
		UDS_TransIDCard idcardTrans = new UDS_TransIDCard();
		String eighteenIDCard = "";
		// 不足15位
		eighteenIDCard = idcardTrans.evaluate("1234567890123");
		assertTrue(eighteenIDCard.equals("1234567890123"));
		// 多于15位
		eighteenIDCard = idcardTrans.evaluate("12345678901234567");
		assertTrue(eighteenIDCard.equals("12345678901234567"));
		// ==15位
		eighteenIDCard = idcardTrans.evaluate("110108004733785");
		assertTrue(eighteenIDCard.equals("110108004733785"));
		// ==15位
		eighteenIDCard = idcardTrans.evaluate("510211610622152");
		assertTrue(eighteenIDCard.equals("510211196106221520"));
		// ==15位
		eighteenIDCard = idcardTrans.evaluate("510214800815082");
		assertTrue(eighteenIDCard.equals("510214198008150827"));
		// ==15位
		eighteenIDCard = idcardTrans.evaluate("510214198008150827");
		assertTrue(eighteenIDCard.equals("510214198008150827"));
		// ==18位
		eighteenIDCard = idcardTrans.evaluate("33062119830907839X");
		assertTrue(eighteenIDCard.equals("33062119830907839X"));
		// ==18位
		eighteenIDCard = idcardTrans.evaluate("33062119830907839x");
		assertTrue(eighteenIDCard.equals("33062119830907839X"));
		// ==18位
		eighteenIDCard = idcardTrans.evaluate("51022419761002002x");
		assertTrue(eighteenIDCard.equals("51022419761002002X"));
		// ==18位
		eighteenIDCard = idcardTrans.evaluate("33062119830907439X");
		assertTrue(eighteenIDCard.equals("33062119830907439X"));
		// ==18位
		eighteenIDCard = idcardTrans.evaluate("33062119830907439x");
		assertTrue(eighteenIDCard.equals("33062119830907439x"));
		
		// ==18位
		eighteenIDCard = idcardTrans.evaluate("000000000820457");
		assertTrue(eighteenIDCard.equals("000000000820457"));
		
	}

}
