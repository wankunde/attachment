/* 
 * Copyright Walker Studio 
 * All Rights Reserved. 
 *  
 * 文件名称： TreeNode.java 
 * 摘 要： 
 * 作 者： Rechard
 * 创建时间： 2013-03-19 
 */  
package tree;
  
/** 
 * 树节点 
 *  
 * @author Rechard
 * @version 1.0.0.0 
 */  
public class TreeNode   
{   
        private int index=0;  
        private double data=0;  
        private boolean isVisted=false;  
        private TreeNode leftChild=null;  
        private TreeNode midChild=null;
        private TreeNode rightChild=null;  
        private TreeNode parent = null;
        
        public TreeNode(){}  
          
        /** 
         * @param key  层序编码 
         * @param data 数据域 
         */  
        public TreeNode(int index,double data){  
            this.index=index;  
            this.data=data;  
            this.leftChild=null;  
            this.midChild=null;
            this.rightChild=null;  
            this.parent=null;
        }  
        
        public int getIndex(){
        	return index;
        }
        
        public double getData(){
        	return data;
        }
        
        public TreeNode getParent(){  
            return this.parent;  
        }  
        
        public void setParent(TreeNode parent){  
            this.parent = parent;  
        }  
  
        public void setChild(TreeNode child,int k)
        {
        	if(k==-2)
        		this.leftChild=child;
        	if(k==-1)
        		this.midChild=child;
        	if(k==0)
        		this.rightChild=child;
        		
        }
        
        public TreeNode getLeftChild()
        {
        	return this.leftChild;
        }
        
        public TreeNode getMidChild()
        {
        	return this.midChild;
        }
        
        public TreeNode getRightChild()
        {
        	return this.rightChild;
        }
        
}  



