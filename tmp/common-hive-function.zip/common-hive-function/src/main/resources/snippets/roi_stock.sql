-- -------------------
-- warning
-- not sufficiently-tested. just for reference
-- -------------------

-- -------------------
-- hiverc
-- -------------------
use zq_stock_safe;
set mapred.queue.name=queue_0302_01;
add jar /home/hduser0302/common-hive-function-1.0-SNAPSHOT.jar;
create temporary function dt_add as "com.paic.data.hive.common.udf.DTAdd";
create temporary function dt_sub as "com.paic.data.hive.common.udf.DTSub";

-- -------------------
-- status
-- -------------------
CREATE TABLE IF NOT EXISTS report_status_roi_user_stock (
	user_code	string,
	secu_intl   string,
	buy	double,
	sell double,
	market_value double
) PARTITIONED BY (
	dt string
);
ALTER TABLE report_status_roi_user_stock SET FILEFORMAT ORC;

-- -------------------
-- update daily-status
-- -------------------
INSERT OVERWRITE TABLE report_status_roi_user_stock
    PARTITION (dt=${dt})
SELECT
    t11.user_code,
    t11.secu_intl,
    if(t11.share > t12.dividend, t11.market_value / t11.share * (t11.share - t12.dividend) - t12.bonus, t11.market_value - t12.bonus) AS market_value,
	t12.buy,
	t12.sell
FROM (
    SELECT
        CUST_CODE AS user_code,
        SECU_INTL AS secu_intl,
        nvl(MKT_VAL,0) AS market_value,
        nvl(SHARE_AVL,0) AS share
    FROM
        kgdb_shares
    WHERE
        dt=${dt}
)t11
LEFT OUTER JOIN (
    SELECT
        user_code,
        secu_intl,
        sum(buy) AS buy,
        sum(sell) AS sell,
        sum(dividend) AS dividend,
        sum(bonus) AS bonus
    FROM (
        SELECT
            CUST_CODE AS user_code,
            SECU_INTL AS secu_intl,
            IF(TRD_ID IN ('9X', '9U', '9W'), nvl(MATCHED_QTY,0), 0) AS buy,
            IF(TRD_ID IN ('9Y', '9A', '9V', '9Z'), nvl(MATCHED_QTY,0), 0) AS sell,
            IF(TRD_ID = 'ZA' AND MATCHED_AMT=0, nvl(MATCHED_QTY,0), 0) AS dividend,
            IF(TRD_ID = 'ZA' AND MATCHED_QTY=0, nvl(MATCHED_AMT,0), 0) AS bonus
        FROM
            kgdb_matching
        WHERE
            dt=${dt}
            AND
            TRD_ID IN ('ZA', '9X', '9U', '9W', '9Y', '9A', '9V', '9Z')
        )t121
    GROUP BY
        user_code,
        secu_intl
)t12
ON
    t11.user_code = t12.user_code
    AND
    t11.secu_intl = t12.secu_intl
;