-- -------------------
-- warning
-- not sufficiently-tested. just for reference
-- -------------------

-- -------------------
-- hiverc
-- -------------------
use zq_stock_safe;
set mapred.queue.name=queue_0302_01;
add jar /home/hduser0302/common-hive-function-1.0-SNAPSHOT.jar;
create temporary function dt_add as "com.paic.data.hive.common.udf.DTAdd";
create temporary function dt_sub as "com.paic.data.hive.common.udf.DTSub";

SELECT
    user_code,
    unit,
    (end_capital - start_capital - rollin + rollout + 0.0) / (start_capital + rollin + 0.0) AS profit
FROM (
    -- -----------
    -- daily
    -- -----------
    SELECT
        user_code,
        max(if(dt=${dt}, capital, 0)) AS start_capital,
        max(if(dt=dt_sub(${dt}, 1, 'D'), capital, 0)) AS end_capital,
        sum(rollin) AS rollin,
        sum(rollout) AS rollout,
        "D" AS unit
    FROM
        report_status_roi_user
    WHERE
        dt BETWEEN dt_sub(${dt}, 1, 'D') AND ${dt}
    GROUP BY
        user_code,
        dt

    UNION ALL

    -- -----------
    -- weekly
    -- -----------
    SELECT
            user_code,
            max(if(dt=${dt}, capital, 0)) AS start_capital,
            max(if(dt=dt_sub(${dt}, 1, 'W'), capital, 0)) AS end_capital,
            sum(rollin) AS rollin,
            sum(rollout) AS rollout,
            "W" AS unit
        FROM
            report_status_roi_user
        WHERE
            --dt BETWEEN max(enroll_dt, dt_sub(${dt}, 1, 'W')) AND ${dt}
            dt BETWEEN dt_sub(${dt}, 1, 'W') AND ${dt}
        GROUP BY
            user_code,
            dt
)t;

