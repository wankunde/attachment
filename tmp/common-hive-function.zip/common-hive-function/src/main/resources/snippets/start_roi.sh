start_str=$1
end=$2

start=`date -d "$start_str" +%Y%m%d`
while [ $start -le $end ]
do
    echo "start running roi $start"
    hive -d dt=${start}  -f roi.sql
    echo "end running roi $start"
    start=`date -d "1 day $start" +%Y%m%d`
done