-- -------------------
-- hiverc
-- -------------------
use zq_stock_safe;
set mapred.queue.name=queue_0302_01;
add jar /home/hduser0302/common-hive-function-1.0-SNAPSHOT.jar;
create temporary function dt_add as "com.paic.data.hive.common.udf.DTAdd";
create temporary function dt_sub as "com.paic.data.hive.common.udf.DTSub";

-- -------------------
-- status
-- -------------------
CREATE TABLE IF NOT EXISTS report_status_roi_user(
	user_code	string,
	rollin	double,
	rollout double,
	capital double,
	enroll_dt string
) PARTITIONED BY (
	dt string
);
ALTER TABLE report_status_roi_user SET FILEFORMAT ORC;

-- -------------------
-- update daily-status
-- -------------------
INSERT OVERWRITE TABLE report_status_roi_user
    PARTITION (dt=${dt})
SELECT
    t1.user_code,
    t1.rollin,
    t1.rollout,
    t1.capital,
    nvl(t2.enroll_dt, ${dt}) AS enroll_dt
FROM (
    SELECT
        t11.user_code AS user_code,
        t11.capital AS capital,
        nvl(t12.rollout,0) AS rollout,
        nvl(t12.rollin, 0) AS rollin
    FROM (
        SELECT
            SRC_CUST_NO AS user_code,
            sum(nvl(ASSET_AMT,0)) AS capital
        FROM
            ods_opsecods_dm_g_a_cash_acct_total
        WHERE
            dt=${dt}
        GROUP BY
            SRC_CUST_NO
    )t11
    LEFT OUTER JOIN (
        SELECT
            USER_CODE AS user_code,
            sum(if(nvl(CPTL_AMT,0) > 0, nvl(CPTL_AMT,0), 0)) AS rollin,
            sum(if(nvl(CPTL_AMT,0) < 0, -1 * nvl(CPTL_AMT,0), 0)) AS rollout
        FROM
            kgdb_cptl_log
        WHERE
            dt=${dt}
            AND
            biz_code in (110030,130060,140020,140030,140040,140050,130010,5000,100000,100010,104640,104650,104740,110040,4600,104600,104700,110070,120040,120070,130065,151011,151014,2000,2010,2100,2110,2120,2500,2030,2020,3100,3105,3108,2130,1125042,5631,4720,4631,4621,5201,4681,3190,3000,3120,3121,3124,3125,3160,3161,3162,3163,3223,5203,5630,130600,1125009,140060,120030,171500,2025,3143,3153,3183,2125,3142,3152,110050,110060,130030,100050,120050,120060)
        GROUP BY
            user_code
    )t12
    ON
        t11.user_code = t12.user_code
 )t1
LEFT OUTER JOIN (
    SELECT
        user_code,
        enroll_dt
    FROM
        report_status_roi_user
    WHERE
        report_status_roi_user.dt = dt_sub(${dt}, 1, 'D')
)t2
ON
    t1.user_code = t2.user_code;

-- -------------------
-- generate report of
--  1D
--  1W
--  1M
--  3M
--  6M
--  1Y
--  ALL
-- -------------------