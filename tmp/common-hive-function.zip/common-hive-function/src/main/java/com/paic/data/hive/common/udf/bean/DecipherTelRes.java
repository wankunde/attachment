package com.paic.data.hive.common.udf.bean;

/**
 * Created by wangyi422 on 2018/3/22.
 */
public class DecipherTelRes {
    private int retCode;
    private String retMsg  = null;
    private String plainText = null;

    public DecipherTelRes() {
    }

    public int getRetCode() {
        return retCode;
    }

    public String getRetMsg() {
        return retMsg;
    }

    public String getPlainText() {
        return plainText;
    }

    public void setRetCode(int retCode) {
        this.retCode = retCode;
    }

    public void setRetMsg(String retMsg) {
        this.retMsg = retMsg;
    }

    public void setPlainText(String plainText) {
        this.plainText = plainText;
    }
}
