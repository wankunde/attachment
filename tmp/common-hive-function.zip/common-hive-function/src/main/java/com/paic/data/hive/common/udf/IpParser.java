package com.paic.data.hive.common.udf;

import com.paic.data.hive.common.udf.bean.IpBean;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.io.IOUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.*;

/**
 * Created by WANKUN603 on 2017-04-13.
 */
@Description(name = "ip_parser",
        value = "_FUNC_(ip) - Returns a map which contains information of the input ip ")
public class IpParser extends UDF {

    private static final Log LOG = LogFactory.getLog(IpParser.class);

    private static final String IP_REG = "^(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|[1-9])\\."
            + "(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)\\."
            + "(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)\\."
            + "(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)$";

    private static final Map BLANK_MAP = new HashMap();

    private static Long[] arr1 = null;
    private static Long[] arr2 = null;
    private static Map[] data = null;

    public Map<String, String> evaluate(String ipStr) throws HiveException {
        if (StringUtils.isBlank(ipStr) || !ipStr.matches(IP_REG)) {
            LOG.warn("input string " + ipStr + " is not a valid ip address!");
            return BLANK_MAP;
        }
        Long ipValue = 0l;
        String[] fields = ipStr.split("\\.");
        if (fields.length != 4)
            throw new HiveException("ip should have 4 fields!");
        for (int i = 0; i < 4; i++) {
            ipValue += Integer.parseInt(fields[i]) << (8 * (3 - i));
        }
        return evaluateLong(ipValue);
    }

    private Map<String, String> evaluateLong(Long ipValue) {
        LOG.debug("ip value : " + ipValue);

        if (data == null || data.length == 0) {
            List<IpBean> ipBeanList = loadIpArray();
            arr1 = new Long[ipBeanList.size()];
            arr2 = new Long[ipBeanList.size()];
            data = new Map[ipBeanList.size()];
            for (int i = 0; i < ipBeanList.size(); i++) {
                IpBean ip = ipBeanList.get(i);
                arr1[i] = ip.getStart();
                arr2[i] = ip.getEnd();
                data[i] = ip.getData();
            }
        }
        return rangeSearch(ipValue, arr1, arr2, data);
    }

    public static synchronized List<IpBean> loadIpArray() {
        LOG.debug("start load ip array.");
        long memStart = Runtime.getRuntime().totalMemory();

        List<IpBean> list = new ArrayList<>(180000);
        Configuration conf = new Configuration();
        String uri = "hdfs://pasc/metadata/dim/ip_gps_carrier";
        FSDataInputStream in = null;
        BufferedReader reader = null;
        try {
            FileSystem hdfs = FileSystem.get(URI.create(uri), conf);
            in = hdfs.open(new Path(uri));
            reader = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            String line;
            IpBean bean = null;
            Map<String, String> map;
            while ((line = reader.readLine()) != null) {
                String[] cols = line.split("\u0001");
                if (cols.length > 2) {
                    map = new HashMap<>(4, 1.0f);
                    map.put("country", cols[3]);
                    map.put("area", cols[5]);
                    map.put("region", cols[7]);
                    map.put("city", cols[9]);
                    bean = new IpBean();
                    bean.setStart(Long.parseLong(cols[0]));
                    bean.setEnd(Long.parseLong(cols[1]));
                    bean.setData(map);
                }
                list.add(bean);
            }

        } catch (IOException e) {
            LOG.error("load ip array error!", e);
        } finally {
            try {
                reader.close();
            } catch (IOException e) {
            }
            IOUtils.closeStream(in);
            long memEnd = Runtime.getRuntime().totalMemory();
            LOG.info("load ip array. memory usage : " + (memEnd - memStart) / 1024 / 1024 + " MB ");
        }

        Collections.sort(list, new Comparator<IpBean>() {
            @Override
            public int compare(IpBean o1, IpBean o2) {
                long f = o1.getStart() - o2.getStart();
                return f > 0 ? 1 : (f < 0 ? -1 : 0);
            }
        });

        LOG.debug("success load ip array. size : " + list.size());
        return list;
    }

    public Map rangeSearch(Long l, Long[] arr1, Long[] arr2, Map[] data) {
        int idx1 = floorBinarySearch(arr1, l);
        int idx2 = ceilBinarySearch(arr2, l);

        if (idx1 < idx2) {
            StringBuffer sb = new StringBuffer();
            for (int i = idx1; i <= idx2; i++) {
                sb.append(data[i]);
                sb.append(",");
            }
            LOG.warn("find cross ip range: " + sb.toString());
            return data[idx1];
        } else if (idx1 == idx2)
            return data[idx1];
        // (idx1 > idx2)
        return null;
    }

    private int floorBinarySearch(Object[] a, Object key) {
        int low = 0;
        int high = a.length - 1;

        while (high - low > 1) {
            int mid = (low + high) >>> 1;
            Comparable midVal = (Comparable) a[mid];
            int cmp = midVal.compareTo(key);
            if (cmp == 0)
                return mid;
            else if (cmp < 0)
                low = mid;
            else if (cmp > 0)
                high = mid;
        }
        return low;
    }

    private int ceilBinarySearch(Object[] a, Object key) {
        int low = 0;
        int high = a.length - 1;

        while (high - low > 1) {
            int mid = (low + high) >>> 1;
            Comparable midVal = (Comparable) a[mid];
            int cmp = midVal.compareTo(key);
            if (cmp == 0)
                return mid;
            else if (cmp < 0)
                low = mid;
            else if (cmp > 0)
                high = mid;
        }
        return high;
    }
}

