package com.paic.data.hive.common.udf.uds;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;

@Description(name = "uds_recommend_converter", value = "_FUNC_(String value) - Returns String")
public class UDS_RecommendConverter extends UDF {
	public String evaluate(String oldRecommend) {
		if (oldRecommend == null) {
			return null;
		} 
		String recommend = oldRecommend.trim().toUpperCase();
		
		if (recommend.endsWith("BD")) {
			recommend = recommend.substring(0, recommend.length() -2).trim();
		} else if (recommend.endsWith("W2")) {
			recommend = recommend.substring(0, recommend.length() -2).trim();
		}
		
		if (recommend.startsWith("ZTSX")) {
			recommend = recommend.replaceFirst("ZTSX-*", "").trim();
		}
		else if (recommend.startsWith("PASK")) {
			recommend = recommend.replaceFirst("PASK-*", "").trim();
		}
		
		recommend = recommend.trim();
		if (recommend.equals("")) {
			return null;
		} else {
			return recommend;
		}
	}
}
