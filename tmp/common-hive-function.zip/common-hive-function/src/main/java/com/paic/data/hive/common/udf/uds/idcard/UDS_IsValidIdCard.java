package com.paic.data.hive.common.udf.uds.idcard;

import java.text.SimpleDateFormat;
import java.util.HashSet;
import java.util.Set;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;

@Description(name = "uds_isvalid_idcard", value = "_FUNC_(String id) - Returns boolean")
public class UDS_IsValidIdCard extends UDF {
	private static Set<String> PROVINCE_CODES = new HashSet<String>();
	private static SimpleDateFormat dateFormat = null;
	
	static {
		PROVINCE_CODES.add("11");
		PROVINCE_CODES.add("12");
		PROVINCE_CODES.add("13");
		PROVINCE_CODES.add("14");
		PROVINCE_CODES.add("15");
		PROVINCE_CODES.add("21");
		PROVINCE_CODES.add("22");
		PROVINCE_CODES.add("23");
		PROVINCE_CODES.add("31");
		PROVINCE_CODES.add("32");
		PROVINCE_CODES.add("33");
		PROVINCE_CODES.add("34");
		PROVINCE_CODES.add("35");
		PROVINCE_CODES.add("36");
		PROVINCE_CODES.add("37");
		PROVINCE_CODES.add("41");
		PROVINCE_CODES.add("42");
		PROVINCE_CODES.add("43");
		PROVINCE_CODES.add("44");
		PROVINCE_CODES.add("45");
		PROVINCE_CODES.add("46");
		PROVINCE_CODES.add("50");
		PROVINCE_CODES.add("51");
		PROVINCE_CODES.add("52");
		PROVINCE_CODES.add("53");
		PROVINCE_CODES.add("54");
		PROVINCE_CODES.add("61");
		PROVINCE_CODES.add("62");
		PROVINCE_CODES.add("63");
		PROVINCE_CODES.add("64");
		PROVINCE_CODES.add("65");
		PROVINCE_CODES.add("66");
		PROVINCE_CODES.add("71");
		PROVINCE_CODES.add("81");
		PROVINCE_CODES.add("82");
		
		dateFormat = new SimpleDateFormat("yyyyMMdd");
		dateFormat.setLenient(false);
	}
	public boolean evaluate(String idCard) {
		return isValidIdCard(idCard);
	}
	
	public static boolean isValidIdCard(String idCard) {
		if (idCard == null || idCard.trim().equals("") ) {
			return false;
		}
		try {
			String identityId = idCard.trim();
			if (identityId.length() != 15 && identityId.length() != 18) {
				return false;
			}
			String province = identityId.substring(0, 2);
			if (!PROVINCE_CODES.contains(province)) {
				return false;
			}
			if (!isValidDate(identityId)) {
				return false;
			}

			if (identityId.length() == 18) {
				try {
					// check the last 4 char, they are must be numbers
					Integer.valueOf(identityId.substring(14, 17));
				} catch (NumberFormatException e) {
					return false;
				}
				
				if (verify(identityId.toUpperCase())) {
					return true;
				} else {
					return false;
				}
			}
			else if (identityId.length() == 15) {
				try {
					// check the last 4 char, they are must be numbers
					Integer.valueOf(identityId.substring(12));
				} catch (NumberFormatException e) {
					return false;
				}
				return true;
			}
		} catch (Exception ex) {
			return false;
		}
		return false;
	}
	
    private static boolean isValidDate(String idCard) {
		try {
			String identityId = idCard.trim();
			if (identityId.length() == 18) {
				String birthday = identityId.substring(6, 14);
				dateFormat.parse(birthday);
			} else if (identityId.length() == 15) {
				String birthday = identityId.substring(6, 12);
				dateFormat.parse("19"+birthday);
			} else {
				return false;
			}
		} catch (Exception ex) {
			return false;
		}
		return true;
    }
    
    private static boolean verify(String idCardNumber) throws Exception{  
        if(idCardNumber == null || idCardNumber.length() != 18) {  
            return false;
        }
        return UDS_TransIDCard.getVerifyCode(idCardNumber) == idCardNumber.charAt(idCardNumber.length() - 1);  
    }
    
}
