package com.paic.data.hive.common.udf.template.node;


import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.paic.data.hive.common.udf.template.TNode;
import com.paic.data.hive.common.udf.template.TPushData;
import com.paic.data.hive.common.udf.template.TUserData;



public class TSellUrlNode extends TVarNode {
	
	private final TNode url;
	private long clearMS = 0;
	private boolean needShortLink = false;

	
	public TSellUrlNode(TNode url) {
		this.url = url;
	}

	public void setNeedShortLink(boolean needShortLink) {
		this.needShortLink = needShortLink;
	}

	@Override
	public void params(Collection<String> params) {
		url.params(params);
	}
	
	private Map<String, OUrl> ourls = new ConcurrentHashMap<String, OUrl>();
	private class OUrl {
		public boolean hasPumb;
		public boolean hasParam;
		public String baseUrl;
		public String slBaseUrl;
	}

	private OUrl createOUrl(String ourl) {
		boolean pumb = false;
		StringBuffer output = new StringBuffer();
		int pos = ourl.indexOf('?');
		if (ourl.indexOf('?') < 0 || ourl.length() == pos + 1) {
			output.append(ourl);
			if (ourl.length() != pos + 1) output.append('?');
		} else {
			int from = 0; 
			int offset = pos + 1;
			char[] temp = ourl.toCharArray();
			
			while (offset < temp.length) {
				boolean skip = false;
				// check skip
				if (temp[offset] == 'p' && offset + 2 < temp.length) {
					if (temp[offset+1] == 'i' && temp[offset+2] == 'd') {
						skip = true;
					} else if (offset + 3 < temp.length) {
						if (temp[offset+1] == 't' && temp[offset+2] == 'y' &&temp[offset+3] == 'p') {
							skip = true;
						} else if (temp[offset+1] == 'u') {
							if (temp[offset+2] == 'c' && temp[offset+3] == 'd') {
								skip = true;
							} else if (temp[offset+2] == 'i' &&temp[offset+3] == 'd') {
								skip = true;
							} else if (temp[offset+2] == 'm' &&temp[offset+3] == 'b') {
								skip = true;
								pumb = true;
							}
						}
					}
				}
				// do skip
				if (skip) {
					output.append(temp, from, offset - from);
				}
				for (; offset < temp.length; offset ++) {
					if (temp[offset] == '&') {
						offset ++;
						break;
					}
				}
				if (skip) {
					from = offset;
				}
			}
			if (from < offset) {
				output.append(temp, from, offset - from);
				output.append('&');
			}
		}
		
		OUrl ret = new OUrl();
		ret.hasPumb = pumb;
		ret.baseUrl = output.toString();
		ret.hasParam = ret.baseUrl.endsWith("&");
		ret.baseUrl = ret.baseUrl.substring(0, ret.baseUrl.length() - 1);
		ret.slBaseUrl = null;
		return ret;
	}
	
	
	public static void main(String[] args) throws Exception {
		TUserData userData = new TUserData();
		userData.mobile = "mobile";
		userData.userCode = "userCode";
		userData.userId = "userId";
		TPushData pushData = new TPushData();
		pushData.pushId = "Preivew";
		TSellUrlNode node = new TSellUrlNode(new TTextNode("http://stock.pingan.com/huodong/jqlc/index.html?a=a"));
		System.out.println(node.toString("sms", userData, pushData));
		System.out.println(node.toString("app", userData, pushData));
		System.out.println(node.toString("wx", userData, pushData));
		System.out.println(node.toString("im", userData, pushData));
	}

	@Override
	public void toString(StringBuffer output, String channel, TUserData userData, TPushData pushData) {
		// TODO Auto-generated method stub
		
	}
}
