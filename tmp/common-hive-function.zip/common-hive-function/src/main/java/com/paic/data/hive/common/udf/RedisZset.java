package com.paic.data.hive.common.udf;

import com.google.common.base.Joiner;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.exec.UDFArgumentLengthException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDF;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorConverters;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.type.TypeFactory;
import org.codehaus.jackson.type.JavaType;
import redis.clients.jedis.Connection;
import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.*;

/**
 * Created by wankun603 on 2018-03-21.
 *
 * Paic redis Client : mvn install:install-file -Dfile=D:\tmp\jedis-3.0.0-20180612.085950-1.jar -DgroupId=redis.clients -DartifactId=jedis -Dversion=3.0.0-SNAPSHOT -Dpackaging=jar
 */
@Description(name = "redis_zset", value = "_FUNC_(cluster, key, array(string)) - set kv to redis cluster")
public class RedisZset extends GenericUDF {
  private static final Log LOG = LogFactory.getLog(RedisZset.class);

  private static final JsonFactory JSON_FACTORY = new JsonFactory();
  static {
    // Allows for unescaped ASCII control characters in JSON values
    JSON_FACTORY.enable(JsonParser.Feature.ALLOW_UNQUOTED_CONTROL_CHARS);
  }
  private static final ObjectMapper MAPPER = new ObjectMapper(JSON_FACTORY);
  private static final JavaType MAP_TYPE = TypeFactory.fromClass(Map.class);

  private transient ObjectInspectorConverters.Converter[] converters;

  @Override
  public ObjectInspector initialize(ObjectInspector[] arguments) throws UDFArgumentException {
    if (arguments.length == 3) {
      converters = new ObjectInspectorConverters.Converter[arguments.length];
      converters[0] = ObjectInspectorConverters.getConverter(arguments[0],
              PrimitiveObjectInspectorFactory.writableStringObjectInspector);
      converters[1] = ObjectInspectorConverters.getConverter(arguments[1],
              PrimitiveObjectInspectorFactory.writableStringObjectInspector);
      converters[2] = ObjectInspectorConverters.getConverter(arguments[2],
              ObjectInspectorFactory.getStandardListObjectInspector(
                      PrimitiveObjectInspectorFactory.writableStringObjectInspector));
    } else
      throw new UDFArgumentLengthException(
              "The function redis_zset(cluster, key, array(string)) takes 3 arguments.");

    return ObjectInspectorFactory
            .getStandardListObjectInspector(
                    PrimitiveObjectInspectorFactory.writableStringObjectInspector);
  }

  @Override
  public Object evaluate(DeferredObject[] arguments) throws HiveException {
    String clusterId = (converters[0].convert(arguments[0].get())).toString();
    JedisCluster cluster = RedisUtils.initJedisCluster(clusterId);
    String key = (converters[1].convert(arguments[1].get())).toString();
    ArrayList<Text> result = new ArrayList<Text>();
    cluster.del(key);

    List<Text> values = (List<Text>) (converters[2].convert(arguments[2].get()));
    for (Text text : values) {
      String value = text.toString();
      Map m;
      try {
        m = MAPPER.readValue(value, MAP_TYPE);
      } catch (IOException e) {
        throw new HiveException("parse value "+value + " to json error!");
      }
      if(!m.containsKey("score"))
        throw new HiveException("score must be set in  "+value);

      Double score = Double.parseDouble(m.get("score").toString());

      cluster.zadd(key, score, value);
      result.add(new Text(key + "->" + value + ":" + score));
    }
    return result;

  }

  @Override
  public String getDisplayString(String[] children) {
    return "redis_zset(" + Joiner.on(",").join(children) + ")";
  }
}
