package com.paic.data.hive.common.udf;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;

import com.alibaba.fastjson.JSONObject;
@Description(name = "sign_continue_times", value = "_FUNC_(value,startDate,endDate,firstTimes,withHis) - Returns a first continue sign times")
public class SignContinueTimes extends UDF{
	private final static Pattern p=Pattern.compile(":?[1-9]+");
	private final static SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMdd");
	public String evaluate(String value,String start,String end,Integer firstTimes,Integer withHis){
		JSONObject json=new JSONObject();
		if(withHis==null)withHis=0;
		if(firstTimes==null)firstTimes=0;
		if (value == null) {
			return json.toJSONString();
		}
		Date startDate=null;
		Date endDate=null;
		try {
			if(start!=null && start.trim().length()>0) 
				startDate=sdf.parse(start);
			if(end!=null && end.trim().length()>0) 
				endDate=sdf.parse(end);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		try {
			json=calc(value,startDate,endDate,firstTimes,withHis);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json.toJSONString();
	}
	private JSONObject calc(String value,Date start,Date end,int firstTimes,int withHis) {
		JSONObject json=new JSONObject();
		ArrayList<String> yvs=new ArrayList<>(Arrays.asList(value.split(",")));
		Collections.sort(yvs, new Comparator<String>() {
			@Override
			public int compare(String o1, String o2) {
				return o1.split(":")[0].compareTo(o2.split(":")[0]);
			}
		});
		if(end!=null) {
			Calendar ce=Calendar.getInstance();
			ce.setTime(end);
			int year=ce.get(Calendar.YEAR);
			int dayOfYear=ce.get(Calendar.DAY_OF_YEAR);
			for(int i=yvs.size()-1;i>=0;i--) {
				String yearSub=yvs.get(i).split(":")[0];
				String vs=yvs.get(i).split(":")[1];
				if(Integer.valueOf(yearSub)>year) {
					yvs.remove(i);
				}else if(Integer.valueOf(yearSub)==year) {
					vs=vs.substring(0, dayOfYear);
					yvs.set(i, year+":"+vs);
				}else
					break;
			}
		}
		if(start!=null) {
			Calendar cs=Calendar.getInstance();
			cs.setTime(start);
			int year=cs.get(Calendar.YEAR);
			int dayOfYear=cs.get(Calendar.DAY_OF_YEAR);
			
			for(int i=yvs.size()-1;i>=0;i--) {
				String yearSub=yvs.get(i).split(":")[0];
				String vs=yvs.get(i).split(":")[1];
				if(Integer.valueOf(yearSub)==year) {
					vs=vs.substring(dayOfYear);
					if(withHis==0) {
						yvs.set(i, year+":"+vs);
					}else {
						String tmpVs=vs.substring(0,dayOfYear);
						tmpVs=tmpVs.substring(tmpVs.lastIndexOf("1"));
						vs=tmpVs+vs;
						yvs.set(i, year+":"+vs);
						if(dayOfYear==1) {
							i--;
							int yearTemp=year-1;
							while(i>=0 && yvs.get(i-1).split(":")[0].equals(yearTemp+"")) {
								String tvs=yvs.get(i-1).split(":")[1];
								if(tvs.lastIndexOf("1")==0) {
									i--;
									yearTemp=year-1;
								}else {
									tvs=tvs.substring(tvs.lastIndexOf("1"));
									yvs.set(i, yearTemp+":"+tvs);
								}
							}
						}
					}
				}else if(Integer.valueOf(yearSub)<year) {
					yvs.remove(i);
				}
			}
		}
		String year=null;
		String signs="";
		String startYear=null;
		int startIndex=-1;
		for(String vs:yvs) {
			if(year!=null && Integer.valueOf(vs.split(":")[0])!=Integer.valueOf(year)+1) {
				signs+="YEARLOST";
			}
			if(startYear==null) {
				startYear=vs.split(":")[0];
				Calendar cs=Calendar.getInstance();
				cs.set(Calendar.YEAR, Integer.valueOf(startYear));
				startIndex=cs.getMaximum(Calendar.DAY_OF_YEAR)-vs.split(":")[1].length();
			}
			
			signs+=vs.split(":")[1];
			year=vs.split(":")[0];
		}
		Matcher m=p.matcher(signs);
		String max="";
		String last="";
		String first="";
		String firstReach="";
		while(m.find()) {
			String str=m.group();
			if(max.length()<str.length())
				max=str;
			last=str;
			if(first.length()==0) {
				first=str;
			}
			if(firstReach.length()==0 && str.length()>=firstTimes) {
				firstReach=str;
			}
		}
		Date[] ds1=getDateRange(signs,startYear,startIndex,max,0);
		Date[] ds2=getDateRange(signs,startYear,startIndex,first,0);
		Date[] ds3=getDateRange(signs,startYear,startIndex,last,1);
		Date[] ds4=getDateRange(signs,startYear,startIndex,firstReach,0);
		json.put("maxTimes", max.length());
		json.put("lastTimes", last.length());
		json.put("firstContinueTimes", first.length());
		json.put("firstReachTimes", firstReach.length());
		json.put("maxTimesRange", ds1!=null?sdf.format(ds1[0])+"|"+sdf.format(ds1[1]):"");
		json.put("lastTimesRange", ds3!=null?sdf.format(ds3[0])+"|"+sdf.format(ds3[1]):"");
		json.put("firstContinueTimesRange",ds2!=null? sdf.format(ds2[0])+"|"+sdf.format(ds2[1]):"");
		json.put("firstReachRange", ds4!=null?sdf.format(ds4[0])+"|"+sdf.format(ds4[1]):"");
		return json;
	}
	private Date[] getDateRange(String value,String startYear,int startIndex,String subStr,int desc) {
		if(value.length()==0 || subStr.length()==0) return null;
		Date[] dateRange=new Date[2];
		String first=null;
		if(desc==0) {
			first=value.substring(0,value.indexOf(subStr)+subStr.length());
		}else {
			first=value.substring(0,value.lastIndexOf(subStr)+subStr.length());
		}
		int y=0;
		while(first.indexOf("YEARLOST")>-1) {
			first=first.substring(first.indexOf("YEARLOST")+"YEARLOST".length());
			y++;
		}
		Calendar cs=Calendar.getInstance();
		cs.set(Calendar.YEAR, Integer.valueOf(startYear));
		cs.add(Calendar.YEAR, y);
		if(y>0) {
			cs.set(Calendar.DAY_OF_YEAR, first.length());
		}else {
			cs.set(Calendar.DAY_OF_YEAR, first.length()+startIndex);
		}
		dateRange[1]=cs.getTime();
		cs.add(Calendar.DATE, (subStr.length()-1)*-1);
		dateRange[0]=cs.getTime();
		return dateRange;
	}
	
	public static void main(String[] args) {
		String value="2016:000000000000000000001101110111111111011110111111111111111110111111111111101111111111110111110111011101111001111010011101111110110100010000000000000000000000000000000000000000000001000001100000000010000000001000001001100001000100000000000000000100001000000000010111100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000,2018:00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001111101111114101112113110111111410111111411112100001000011110101021001011100000000001000000000000000000000000000000000000000000000000000010000000000100100000000000000000000000000000000000000000000000000000000000000000000000000000000112000000000000";
		SignContinueTimes st=new SignContinueTimes();
		System.out.println(st.evaluate(value, "", "",10, 0));
	}
}
