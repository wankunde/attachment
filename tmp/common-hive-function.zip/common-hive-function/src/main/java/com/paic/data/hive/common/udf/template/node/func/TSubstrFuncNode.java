package com.paic.data.hive.common.udf.template.node.func;

import java.util.Collection;

import com.paic.data.hive.common.udf.template.TNode;
import com.paic.data.hive.common.udf.template.TPushData;
import com.paic.data.hive.common.udf.template.TUserData;
import com.paic.data.hive.common.udf.template.node.TFuncNode;
import com.paic.data.hive.common.udf.template.node.TTextNode;


public class TSubstrFuncNode extends TFuncNode {
	
	private final TNode str;
	private final TNode from;
	private final TNode length;
	private int ifrom;
	private int ilen;
	
	public TSubstrFuncNode(TNode str, TNode from, TNode length) {
		this.str = str;
		this.from = from;
		this.length = length;
		if (from instanceof TTextNode) {
			ifrom = Integer.parseInt(from.toString());
		} else {
			ifrom = -1;
		}
		if (length instanceof TTextNode) {
			ilen = Integer.parseInt(length.toString());
		} else {
			ilen = -1;
		}
	}

	@Override
	public void params(Collection<String> params) {
		str.params(params);
		from.params(params);
		length.params(params);
	}

	@Override
	public void toString(StringBuffer output, String channel, TUserData userData, TPushData pushData) {
		String s = str.toString(channel, userData, pushData);
		int begin = ifrom;
		if (ifrom == -1) {
			begin = Integer.parseInt(from.toString(channel, userData, pushData));
		}
		int end = begin + ilen;
		if (ilen == -1) {
			end = begin + Integer.parseInt(length.toString(channel, userData, pushData));
		}
		output.append(s.substring(begin, end));
	}

}
