package com.paic.data.hive.common.udf.uds.idcard;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.io.IOUtils;

@Description(name = "uds_explore_idcard", value = "_FUNC_(String id) - Returns IDCardInfo")
public class UDS_EXPLORE_IDCARD extends UDF {
	private static Map<Integer, String> PROVINCE_INFO = null;
	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
	
	private boolean needInitProvinceInfo = true;
	
	public static class IDCardInfo {
		public Integer provinceCode;
		public String  provinceName;
		public Integer cityCode;
		public String  cityName;
		public Integer countyCode;
		public String  countyName;
		public String  birthday;
		public Integer age;
		public String  gender;
	}
	
	private static UDS_TransIDCard idCardConverter = new UDS_TransIDCard();
	private static UDS_IsValidIdCard idCardJudger = new UDS_IsValidIdCard();
	
	public boolean isNeedInitProvinceInfo() {
		return needInitProvinceInfo;
	}

	public void setNeedInitProvinceInfo(boolean needInitProvinceInfo) {
		this.needInitProvinceInfo = needInitProvinceInfo;
	}

	public IDCardInfo evaluate(String _idCard) {
		IDCardInfo info = new IDCardInfo();
		
		if (!idCardJudger.evaluate(_idCard)) {
			return info;
		}
		
		if (PROVINCE_INFO == null && needInitProvinceInfo == true) {
			PROVINCE_INFO = loadProvinceInfo();
		}		
		
		try {
			String id = idCardConverter.evaluate(_idCard);
			
			info.provinceCode = Integer.valueOf(id.substring(0, 2));
			info.cityCode = Integer.valueOf(id.substring(0, 4));
			info.countyCode = Integer.valueOf(id.substring(0, 6));
			info.birthday = id.substring(6, 14);
			
			Calendar age = Calendar.getInstance();
			age.setTime(sdf.parse(info.birthday));
			
			Calendar cale = Calendar.getInstance();
			if (age.get(Calendar.MONTH) > cale.get(Calendar.MONTH) 
			    || (age.get(Calendar.MONTH) == cale.get(Calendar.MONTH) && age.get(Calendar.DAY_OF_MONTH) > cale.get(Calendar.DAY_OF_MONTH))) {
				info.age = cale.get(Calendar.YEAR) - age.get(Calendar.YEAR) - 1;
			} else {
				info.age = cale.get(Calendar.YEAR) - age.get(Calendar.YEAR);
			}	
			
			if (PROVINCE_INFO != null) {
				info.provinceName = PROVINCE_INFO.get(info.provinceCode);
				info.cityName = PROVINCE_INFO.get(info.cityCode);
			}
			int gender = Integer.valueOf(id.substring(16,17));
			info.gender = gender % 2 == 1 ? "M" : "F";
			
		} catch (ParseException e) {
			info = new IDCardInfo();
		}
		return info;
	}
	
	private static Map<Integer, String> loadProvinceInfo() {
		Map<Integer, String> provinceInfo = new HashMap<Integer, String>();
		Configuration conf = new Configuration();
		String uri = "hdfs:///user/hive/warehouse/dim.db/idno_area_code/000000_0";
	    FSDataInputStream in = null;
	    BufferedReader reader = null;
	    
	    try {
	        FileSystem hdfs = FileSystem.get(URI.create(uri), conf);
	        in = hdfs.open(new Path(uri));
	        reader = new BufferedReader(new InputStreamReader(in, "UTF-8"));
	        String line;
	        while ((line = reader.readLine()) != null) {
	        	String[] cols = line.split("\u0001");
	        	provinceInfo.put(Integer.valueOf(cols[0]), cols[1]);
	        }
	    } catch (IOException e) {
			// TODO Auto-generated catch block
	    	provinceInfo = null;
		} finally {
	        IOUtils.closeStream(in);
	    }
	    
		return provinceInfo;
	}
}
