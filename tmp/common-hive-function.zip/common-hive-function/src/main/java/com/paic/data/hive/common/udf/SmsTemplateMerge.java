package com.paic.data.hive.common.udf;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
@Description(name = "sms_merge", value = "_FUNC_(template,content) - Returns a sms_content")
public class SmsTemplateMerge extends UDF{
	private final static Pattern p=Pattern.compile("\\[\\$[a-z0-9A-Z_]+\\$\\]");
	public String evaluate(String template,String content){	
		if (template == null) {
			return content;
		}
		if (content == null) {
			return template;
		}
		return convert(template,content);
	}
	private String convert(String template,String content) {
		String result=template;
		content=content.trim();
		template=template.trim();
		JSONObject json=null;
		if(content.startsWith("{") && content.endsWith("}")) {
			json=JSON.parseObject(content);
		}else {
			json=new JSONObject();
			if(content.startsWith("\""))content=content.substring(1,content.length());
			if(content.endsWith("\""))content=content.substring(0,content.length()-1);
			String[] c=content.split("\"\"");
			for(int i=0;i<c.length;i++) {
				json.put(i+1+"", c[i]);
			}
		}
		Matcher m=p.matcher(template);
		while(m.find()) {
			String f1=m.group();
			String f2=f1.substring(2,f1.length()-2);
			String fv=json.getString(f2);
			result=result.replace(f1, fv==null?"":fv);
		}
		return result;
	}
}
