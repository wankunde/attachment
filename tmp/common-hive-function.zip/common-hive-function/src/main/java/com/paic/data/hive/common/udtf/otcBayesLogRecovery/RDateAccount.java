package com.paic.data.hive.common.udtf.otcBayesLogRecovery;

public  class RDateAccount{
	 public String date;
	 public double mkt;
	 public double b;
	 public double s;
	 public double div;
	 public double probability;
	 public RDateAccount(String date,double mkt,double b,double s,double div,double probability){
	    	this.date=date;
	    	this.mkt=mkt;
	        this.b=b;
	        this.s=s;
	        this.div=div;
	        this.probability=probability;
	    }
	 
	 public static RDateAccount getAccount(String date,double mkt,double b,double s,double div,double probability){
			RDateAccount account=new RDateAccount(date,mkt,b,s,div,probability);
			return account;		
		}
	 
	 @Override
	 public String toString() {
		 return String.format("date=%s,mkt=%.2f,b=%.2f,s=%.2f,div=%.2f,probability=%.2f", date,mkt,b,s,div,probability);
	 }
}