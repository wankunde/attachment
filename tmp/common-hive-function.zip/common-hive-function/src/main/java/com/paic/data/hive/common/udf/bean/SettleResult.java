package com.paic.data.hive.common.udf.bean;

import java.util.HashMap;
import java.util.Map;

/**
 * @author TIANHUI868
 * @date 2016年7月28日
 */
public class SettleResult {
	public final static String OPEN_FEE_SECU = "OPEN_FEE_SECU";
	public final static String OPEN_FEE_SECU_TRADE = "OPEN_FEE_SECU_TRADE";
	public final static String OPEN_FEE_SECU_OVER = "OPEN_FEE_SECU_OVER";
	public final static String OPEN_FEE_SECU_MAX = "OPEN_FEE_SECU_MAX";
	
	public final static String OPEN_FEE_ASSET = "OPEN_FEE_ASSET";
	public final static String OPEN_FEE_ASSET_TRADE = "OPEN_FEE_ASSET_TRADE";
	
	public final static String OPEN_FEE_OMM = "OPEN_FEE_OMM";
	public final static String OPEN_FEE_OMM_TRADE = "OPEN_FEE_OMM_TRADE";

	public final static String OPEN_SECU_SETTLE_DATE = "OPEN_SECU_SETTLE_DATE";
	public final static String OPEN_OMM_SETTLE_DATE = "OPEN_OMM_SETTLE_DATE";
	public final static String AWARD_ASSET_MAX_SETTLE_DATE = "AWARD_ASSET_MAX_SETTLE_DATE";
	public final static String AWARD_OMM_TRADE_SETTLE_DATE = "AWARD_OMM_TRADE_SETTLE_DATE";
	
	public final static String COMMISSION_FEE_SECU = "COMMISSION_FEE_SECU";
	public final static String COMMISSION_FEE_FUND = "COMMISSION_FEE_FUND";
	public final static String COMMISSION_FEE_OTC = "COMMISSION_FEE_OTC";

	public final static String COMMISSION_SECU = "COMMISSION_SECU";
	public final static String COMMISSION_FUND = "COMMISSION_FUND";
	public final static String COMMISSION_OTC = "COMMISSION_OTC";
	
	public final static String AWARD_SECU_TRADE = "AWARD_SECU_TRADE";
	public final static String AWARD_SECU_OVER = "AWARD_SECU_OVER";
	public final static String AWARD_ASSET_MAX = "AWARD_ASSET_MAX";
	public final static String AWARD_OMM_TRADE = "AWARD_OMM_TRADE";
	
	private Long custCode;
	
	private Integer settleMonth;//-结算月份，如2016年1月的，为201601
	
	private Integer ruleId;//结算规则id
	
	private Double openFeeSecu;//股票双户开户结算费用
	
	private Double openFeeSecuTrade;//股票有交易开户结算费用
	
	private Double openFeeSecuOver;//股票有入金开户结算费用
	
	private Double openFeeSecuMax;//股票达到资产峰值开户结算费用
	
	private Double openFeeAcct;//资金开户结算费用
	
	private Double openFeeAcctTrade;//资金购买产品开户结算费用
	
	private Double openFeeOmm;//理财开户结算费用
	
	private Double openFeeOmmTrade;//理财购买产品开户结算费用
	
	private Integer openSecuSettleDate;//-开户结算日期，如2016年1月的，为201601
	
	private Integer openOmmSettleDate;//-开户结算日期，如2016年1月的，为201601
	
//	private Double tradeAmountSecu;//用户月交易金额，单元为元
//
//	private Double tradeAmountFund;//用户月基金交易金额，单元为元
//
//	private Double tradeAmountOtc;//用户月OTC交易金额，单元为元
	
//	private Double grossCommissionSecu;//用户股票毛佣金，单元为元
//	private Double grossCommissionFund;//用户基金毛佣金，单元为元
//	private Double grossCommissionOtc;//用户otc毛佣金，单元为元
	
//	private Double commissionSecu;//用户股票应结算佣金，单元为元
//	private Double commissionFund;//用户基金应结算佣金，单元为元
//	private Double commissionOtc;//用户otc应结算佣金，单元为元
	
	private Double commissionFeeSecu;//用户股票佣金费用，单元为元
	private Double commissionFeeFund;//用户基金佣金费用，单元为元
	private Double commissionFeeOtc;//用户otc佣金费用，单元为元
	
//	private Integer tradeCountSecu;//月股票交易次数
//	private Integer tradeCountFund;//月基金交易次数
//	private Integer tradeCountOtc;//月理财交易次数
//	
//	private Integer tradeCountLarge2w;//月股票交易大于两万次数
	
//	private Double custAsset;//用户月末客户资产，单元为元
//	
//	private Double feeRatio;//佣金费率

	private Double awardSecuTrade;//股东户有交易二轮结算费用
	private Double awardSecuOver;//股东户入金二轮结算费用
	private Double awardAssetMax;//资产峰值二轮结算费用
	private Double awardOmmTrade;//基金户产品购买二轮结算费用
	
	static public enum AcctType {
		asset(1),
		secu_single(2),
		secu_two(4),
		omm(8);
		
		
		private int value;
		
		private static Map<Integer, AcctType> map = new HashMap<Integer, AcctType>();
		static{
			for(AcctType status : AcctType.values()){
				map.put(status.getValue(), status);
			}
		}
		
		private AcctType(int value) {
			this.value = value;
		}

		public int getValue() {
			return value;
		}

		public void setValue(int value) {
			this.value = value;
		}

		public static AcctType getObject(int code){
			return map.get(code);
		}

	}

	public Long getCustCode() {
		return custCode;
	}
	public void setCustCode(Long custCode) {
		this.custCode = custCode;
	}
	public Integer getSettleMonth() {
		return settleMonth;
	}
	public void setSettleMonth(Integer settleMonth) {
		this.settleMonth = settleMonth;
	}
	public Integer getRuleId() {
		return ruleId;
	}
	public void setRuleId(Integer ruleId) {
		this.ruleId = ruleId;
	}
	public Double getOpenFeeSecu() {
		return openFeeSecu;
	}
	public void setOpenFeeSecu(Double openFeeSecu) {
		this.openFeeSecu = openFeeSecu;
	}
	
	public Double getOpenFeeSecuTrade() {
		return openFeeSecuTrade;
	}
	public void setOpenFeeSecuTrade(Double openFeeSecuTrade) {
		this.openFeeSecuTrade = openFeeSecuTrade;
	}
	public Double getOpenFeeSecuOver() {
		return openFeeSecuOver;
	}
	public void setOpenFeeSecuOver(Double openFeeSecuOver) {
		this.openFeeSecuOver = openFeeSecuOver;
	}
	public Double getOpenFeeSecuMax() {
		return openFeeSecuMax;
	}
	public void setOpenFeeSecuMax(Double openFeeSecuMax) {
		this.openFeeSecuMax = openFeeSecuMax;
	}
	public Double getOpenFeeAcct() {
		return openFeeAcct;
	}
	public void setOpenFeeAcct(Double openFeeAcct) {
		this.openFeeAcct = openFeeAcct;
	}
	public Double getOpenFeeAcctTrade() {
		return openFeeAcctTrade;
	}
	public void setOpenFeeAcctTrade(Double openFeeAcctTrade) {
		this.openFeeAcctTrade = openFeeAcctTrade;
	}
	public Double getOpenFeeOmm() {
		return openFeeOmm;
	}
	public void setOpenFeeOmm(Double openFeeOmm) {
		this.openFeeOmm = openFeeOmm;
	}
	public Double getOpenFeeOmmTrade() {
		return openFeeOmmTrade;
	}
	public void setOpenFeeOmmTrade(Double openFeeOmmTrade) {
		this.openFeeOmmTrade = openFeeOmmTrade;
	}
	

	public Double getCommissionFeeSecu() {
		return commissionFeeSecu;
	}
	public void setCommissionFeeSecu(Double commissionFeeSecu) {
		this.commissionFeeSecu = commissionFeeSecu;
	}
	public Double getCommissionFeeFund() {
		return commissionFeeFund;
	}
	public void setCommissionFeeFund(Double commissionFeeFund) {
		this.commissionFeeFund = commissionFeeFund;
	}
	public Double getCommissionFeeOtc() {
		return commissionFeeOtc;
	}
	public void setCommissionFeeOtc(Double commissionFeeOtc) {
		this.commissionFeeOtc = commissionFeeOtc;
	}
	
	public Integer getOpenSecuSettleDate() {
		return openSecuSettleDate;
	}
	public void setOpenSecuSettleDate(Integer openSecuSettleDate) {
		this.openSecuSettleDate = openSecuSettleDate;
	}
	public Integer getOpenOmmSettleDate() {
		return openOmmSettleDate;
	}
	public void setOpenOmmSettleDate(Integer openOmmSettleDate) {
		this.openOmmSettleDate = openOmmSettleDate;
	}
	public Double getAwardSecuTrade() {
		return awardSecuTrade;
	}
	public void setAwardSecuTrade(Double awardSecuTrade) {
		this.awardSecuTrade = awardSecuTrade;
	}
	public Double getAwardSecuOver() {
		return awardSecuOver;
	}
	public void setAwardSecuOver(Double awardSecuOver) {
		this.awardSecuOver = awardSecuOver;
	}
	public Double getAwardAssetMax() {
		return awardAssetMax;
	}
	public void setAwardAssetMax(Double awardAssetMax) {
		this.awardAssetMax = awardAssetMax;
	}
	public Double getAwardOmmTrade() {
		return awardOmmTrade;
	}
	public void setAwardOmmTrade(Double awardOmmTrade) {
		this.awardOmmTrade = awardOmmTrade;
	}


}
