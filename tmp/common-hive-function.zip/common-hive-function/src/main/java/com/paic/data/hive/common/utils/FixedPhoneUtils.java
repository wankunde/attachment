package com.paic.data.hive.common.utils;


import java.io.PrintStream;
import java.util.Iterator;
import java.util.Set;
import org.apache.commons.lang.StringUtils;

public class FixedPhoneUtils
{
  public static int isCNFixedPhoneBasicNum(String fixedphoneno)
  {
    Iterator it = FixedPhoneConstant.allFixedPhoneList.iterator();
    return CollectionUtils.isStart(it, formatFixedPhoneBasicNo(fixedphoneno));
  }

  public static int isCNFixedPhoneStrongerNum(String fixedphoneno) {
    if (isCNFixedPhoneBasicNum(fixedphoneno) == 0) {
      Iterator it = FixedPhoneConstant.eightPhoneZoneList.iterator();
      return isEightStart(it, formatFixedPhoneBasicNo(fixedphoneno));
    }
    return -1;
  }

  public static String getFixedPhonePrefix(String fixedphoneno)
  {
    if (StringUtils.isEmpty(fixedphoneno)) {
      return null;
    }

    fixedphoneno = formatFixedPhoneBasicNo(fixedphoneno);
    Iterator it = FixedPhoneConstant.allFixedPhoneList.iterator();
    return CollectionUtils.getStart(it, fixedphoneno);
  }
  public static String formatFixedPhoneStrongerNo(String fixedphoneno) {
    if (isCNFixedPhoneStrongerNum(fixedphoneno) == 0) {
      fixedphoneno = formatFixedPhoneBasicNo(fixedphoneno);

      if (StringUtils.isEmpty(fixedphoneno)) {
        return null;
      }

      if (PAStringUtils.getNumCharCount(fixedphoneno) < 4) {
        return null;
      }

      if (PAStringUtils.getNumMaxCharCount(fixedphoneno) > 5) {
        return null;
      }

      if (PAStringUtils.getNumMaxConstantCount(fixedphoneno) > 4) {
        return null;
      }

      if (PAStringUtils.getNumDescAscCount(fixedphoneno) > 4) {
        return null;
      }
      return fixedphoneno;
    }
    return null;
  }

  public static String formatFixedPhoneBasicNo(String fixedPhoneNo)
  {
    if ((fixedPhoneNo == null) || ("".equals(fixedPhoneNo.trim()))) {
      return null;
    }

    fixedPhoneNo = fixedPhoneNo.replaceAll("[^0-9]", "");
    fixedPhoneNo = fixedPhoneNo.replaceAll("^86", "");

    if ((!fixedPhoneNo.startsWith("0")) && ((fixedPhoneNo.length() == 10) || (fixedPhoneNo.length() == 11))) {
      fixedPhoneNo = "0" + fixedPhoneNo;
    }

    if (fixedPhoneNo.length() >= 12) {
      fixedPhoneNo = fixedPhoneNo.substring(fixedPhoneNo.length() - 12);
    }

    if (fixedPhoneNo.length() < 11) {
      return null;
    }
    return fixedPhoneNo;
  }

  public static int isEightStart(Iterator it, String fixedPhoneNo)
  {
    String tmp = "";

    if (StringUtils.isEmpty(fixedPhoneNo)) {
      return -1;
    }

    while (it.hasNext()) {
      tmp = (String)it.next();
      if (((tmp.length() == 4) && (fixedPhoneNo.indexOf(tmp) == 0) && (fixedPhoneNo.length() == 12)) || 
        (fixedPhoneNo.length() == 11)) {
        return 0;
      }
    }

    return -1;
  }

  public static void main(String[] args)
  {
    String fixedphoneno = " +86-29-83056256";
    new FixedPhoneUtils(); System.out.println(formatFixedPhoneStrongerNo(fixedphoneno));
  }
}
