package com.paic.data.hive.common.udf.isms_isc;

import com.alibaba.fastjson.JSON;

import com.paic.data.hive.common.udf.bean.CipherTelReq;
import com.paic.data.hive.common.udf.bean.CipherTelRes;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.io.Text;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.BasicClientConnectionManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

/**
 * Created by wangyi422 on 2018/3/22.
 */
public class CipherTelUDF extends UDF{
    private final String sysID = "DSP-HBD";
    private final String userID = "DSP-HBD-JAD-APP-HADOOP";
    private final int type = 0;
    private static final int connTO = 3000;        //连接超时时间
    private static final int soTO = 3000;            //io超时时间

    private final String prdIp = "http://10.17.142.108:80/isc-openapi/isc/server/cipherTel";
    private final String uatIp = "http://10.25.163.144:80/isc-openapi/isc/server/cipherTel";

    private HttpPost httpPost = new HttpPost(prdIp);
    private StringEntity stringEntity;
    private static HttpParams httpParams = new BasicHttpParams();
    private static Scheme scheme = new Scheme("http", 80, PlainSocketFactory.getSocketFactory());
    private static SchemeRegistry schemeRegistry = new SchemeRegistry();
    private static ClientConnectionManager connMrg;

    private static HttpClient httpClient;
    private HttpResponse httpResponse;
    private HttpEntity httpEntity;
    private String response;
    private CipherTelRes cipherTelRes;
    private String result;
    //    private static final boolean keepAlive = true;//是否保持长连接
    static {
        httpParams.setParameter(CoreConnectionPNames.SO_TIMEOUT, soTO);
        httpParams.setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, connTO);
        schemeRegistry.register(scheme);
        connMrg = new BasicClientConnectionManager(schemeRegistry);
        httpClient = new DefaultHttpClient(connMrg, httpParams);
    }


    public CipherTelUDF() {
    }

    public Text evaluate(Text plainText) {

        long timestamp = System.currentTimeMillis();

        CipherTelReq cipherTelReq = new CipherTelReq(sysID, userID, type, plainText.toString(), timestamp);
        String request = JSON.toJSONString(cipherTelReq);
        stringEntity = new StringEntity(request, ContentType.APPLICATION_JSON);
        httpPost.setEntity(stringEntity);
        try {
            httpResponse = httpClient.execute(httpPost);
        } catch (IOException e) {
            e.printStackTrace();
        }
        httpEntity = httpResponse.getEntity();
        try {
            response = EntityUtils.toString(httpEntity, "utf-8");
            cipherTelRes = JSON.parseObject(response, CipherTelRes.class);
            result = cipherTelRes.getCipherText();
            connMrg.closeIdleConnections(1, TimeUnit.SECONDS);
        } catch (IOException e) {
            e.printStackTrace();
        } /*finally {
            connMrg.shutdown();
        }*/

        return result == null ? null : new Text(result);
    }
}
