package com.paic.data.hive.common.udf.profite;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.hive.common.type.HiveDecimal;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.parse.SemanticException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDAFEvaluator;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDAFParameterInfo;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDAFResolver2;
import org.apache.hadoop.hive.serde2.objectinspector.*;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorUtils;
import org.apache.hadoop.hive.serde2.typeinfo.TypeInfo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by wankun603 on 2018-06-15.
 */
@Description(name = "period_cost",
        value = "_FUNC_(aum) - \n")
public class PeriodCost implements GenericUDAFResolver2 {
  private static final Log LOG = LogFactory.getLog(PeriodCost.class.getName());

  @Override
  public GenericUDAFEvaluator getEvaluator(GenericUDAFParameterInfo paramInfo) throws SemanticException {
    TypeInfo[] parameters = paramInfo.getParameters();

    assert !paramInfo.isDistinct() : "DISTINCT not supported with *";
    assert !paramInfo.isAllColumns() : "One argument are needed!";
    if (parameters.length != 1) {

      throw new UDFArgumentException("Argument expected");
    }
    return new PeriodCostEvaluator();
  }

  @Override
  public GenericUDAFEvaluator getEvaluator(TypeInfo[] parameters) throws SemanticException {
    return new PeriodCostEvaluator();
  }

  public static class PeriodCostEvaluator extends GenericUDAFEvaluator {

    @AggregationType(estimable = false)
    static class PeriodCostBuf extends AbstractAggregationBuffer {
      List<HiveDecimal> values;
    }

    @Override
    public AggregationBuffer getNewAggregationBuffer() throws HiveException {
      PeriodCostBuf agg = new PeriodCostBuf();
      reset(agg);
      return agg;
    }

    @Override
    public void reset(AggregationBuffer agg) throws HiveException {
      ((PeriodCostBuf) agg).values = new ArrayList<>();
    }

    private transient ObjectInspector[] poi;
    private transient StandardListObjectInspector soi;

    @Override
    public ObjectInspector init(Mode m, ObjectInspector[] parameters) throws HiveException {
      super.init(m, parameters);
      this.poi = parameters;
      if (m == Mode.PARTIAL1 || m == Mode.PARTIAL2) {
        return ObjectInspectorFactory.getStandardListObjectInspector(
                PrimitiveObjectInspectorFactory.javaHiveDecimalObjectInspector);
      } else {
        soi = (StandardListObjectInspector) parameters[0];
        return PrimitiveObjectInspectorFactory.javaHiveDecimalObjectInspector;
      }
    }

    @Override
    public void iterate(AggregationBuffer agg, Object[] parameters) throws HiveException {
      HiveDecimal values2 = PrimitiveObjectInspectorUtils.getHiveDecimal(parameters[0], (PrimitiveObjectInspector) poi[0]);
      ((PeriodCostBuf) agg).values.add(values2);
      LOG.debug("iterate  values2: " + values2);
      LOG.debug("iterate  : " + ((PeriodCostBuf) agg).values);
    }

    @Override
    public Object terminatePartial(AggregationBuffer agg) throws HiveException {
      LOG.info("merge  : " + ((PeriodCostBuf) agg).values);
      return ((PeriodCostBuf) agg).values;
    }

    @Override
    public void merge(AggregationBuffer agg, Object partial) throws HiveException {
      if (partial != null) {
        List<Object> values = (List<Object>) soi.getList(partial);
        PrimitiveObjectInspector eoi = (PrimitiveObjectInspector) soi.getListElementObjectInspector();
        for (Object value : values) {
          LOG.debug("merge  : " + PrimitiveObjectInspectorUtils.getHiveDecimal(value, eoi));
          ((PeriodCostBuf) agg).values.add(PrimitiveObjectInspectorUtils.getHiveDecimal(value, eoi));
        }

      }
    }

    @Override
    public Object terminate(AggregationBuffer agg) throws HiveException {
      if (agg == null || ((PeriodCostBuf) agg).values.size() == 0)
        return null;

      LOG.debug("terminate  : " + ((PeriodCostBuf) agg).values);
      List<HiveDecimal> values = ((PeriodCostBuf) agg).values;
      BigDecimal max = BigDecimal.ZERO;
      for (HiveDecimal decimal : values) {
        if (decimal.bigDecimalValue().compareTo(max) > 0)
          max = decimal.bigDecimalValue();
      }
      BigDecimal limit = max.multiply(BigDecimal.valueOf(0.2));
      BigDecimal sum = BigDecimal.ZERO;
      Long count = 0l;
      for (HiveDecimal decimal : values) {
        if (decimal.bigDecimalValue().compareTo(limit) > 0) {
          sum = sum.add(decimal.bigDecimalValue());
          count++;
        }
      }
      return HiveDecimal.create(sum.divide(BigDecimal.valueOf(count)));
    }
  }

}
