package com.paic.data.hive.common.udf.encrypt;

import jodd.util.StringUtil;

public class UDSCipherUtil extends CipherUtil {
	private final static Object[] SEED = new Object[] { 11, "t0STSRQPONMLKJIHGFEDCBA98765g4n3i2r1" };

	public static String encrypt(String src) {
		String ret = "";
		if (!StringUtil.isEmpty(src)) {
			char[] cs = translateUnicode(src.trim(), false).toCharArray();
			ret = encode(new String(encrypt(cs, SEED)));
		}
		return ret;
	}

	public static String decrypt(String src) {
		String ret = null;
		if (StringUtil.isEmpty(src)) {
			ret = "";
		} else {
			src = decode(src);
			int len = src.length();
			int pos = (int) SEED[0] % len;
			String original = src.substring(pos).concat(src.substring(0, pos));
			char[] cs = original.toCharArray();
			ret = translateUnicode(new String(decrypt(cs, SEED)), true);
		}
		return ret;
	}

	public static void main(String[] args) {
		String xx = UDSCipherUtil.encrypt("Hello看了了");
		System.out.println(xx);
		System.out.println(UDSCipherUtil.decrypt(xx));
	}
}
