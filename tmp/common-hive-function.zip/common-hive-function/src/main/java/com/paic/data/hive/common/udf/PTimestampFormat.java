package com.paic.data.hive.common.udf;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;

@Description(name = "ptime_format", value = "_FUNC_(long) - Returns yyyyMMddHHmmss default")
public class PTimestampFormat extends UDF {

	public Timestamp evaluate(String timestamp, String pattern, boolean catchException) {
		Timestamp result = null;
		try {
			result = evaluate(timestamp, pattern);
		} catch (Throwable e) {
			e.printStackTrace();
			if (!catchException) {
				throw new RuntimeException(e);
			}
			return null;
		}
		return result;
	}

	public Timestamp evaluate(String timestamp, String pattern) throws ParseException {
		if (timestamp == null) {
			return null;
		}

		Date date = new SimpleDateFormat(pattern).parse(timestamp);
		Timestamp result = new Timestamp(date.getTime());

		return result;
	}

	public Timestamp evaluate(Long timestamp, String pattern, boolean catchException) {
		return evaluate(String.valueOf(timestamp), pattern, catchException);
	}

	public Timestamp evaluate(Long timestamp, String pattern) throws ParseException {
		return evaluate(String.valueOf(timestamp), pattern);
	}

}
