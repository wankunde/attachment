package com.paic.data.hive.common.udf.date;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;

@Description(name = "now_day_end", value = "_FUNC_(YYYYMMDD, diff) - Returns a shifted dt")
public class NowDayEnd extends UDF implements DTNowBase {
	
	@Override
	public String evaluate(String format, int diff) throws ParseException {
		Calendar calendar = Calendar.getInstance();
		if (diff != 0) {
			calendar.add(Calendar.DATE, diff);
		}
		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 59);
		calendar.set(Calendar.SECOND, 59);
		calendar.set(Calendar.MILLISECOND, 999);
		return new SimpleDateFormat(format).format(calendar.getTime());
    }
	
	public static void main(String[] args) throws ParseException {
		System.out.println(new NowDayEnd().evaluate("yyyyMMddHHmm", -1));
		System.out.println(new NowDayEnd().evaluate("yyyyMMddHHmm", 0));
		System.out.println(new NowDayEnd().evaluate("yyyyMMddHHmm", 1));
	}
}
