package com.paic.data.hive.common.udf;

import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;
import java.util.NavigableSet;
import java.util.TreeSet;

import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.hive.ql.metadata.HiveException;

import com.paic.data.hive.common.utils.UdfUtils;
import com.paic.data.hive.common.utils.date.DateUnit;

/**
 * @author shidawen768
 *
 */
@Description(name = "dt_sub_for_tradeday", value = "_FUNC_(YYYYMMDD, TradeDays) - "
		+ "Returns a shifted trade dt, tradeDays must be greater than or equal to zero.")
public class DTSubForTradeDay extends UDF {
	private NavigableSet<String> allSet = new TreeSet<String>();
	private Map<String, String> existTradeDayMap = new HashMap<String, String>();

	private String ForwardTradeDay(String dt, int tradeDays) throws ParseException, HiveException, IOException {
		if (allSet == null || allSet.isEmpty()) {
			this.load();
		}
		
		String firstLowerTradeDay = dt;
		while (allSet.contains(firstLowerTradeDay) == false) {
			firstLowerTradeDay = DateUnit.getInstance("D").shift(firstLowerTradeDay, -1);
		}

		int index = 0;
		String resDate = firstLowerTradeDay;
		while (index < tradeDays) {
			index++;
			resDate = allSet.lower(resDate);
		}
		
		String key = this.getKey(dt, tradeDays);
		this.existTradeDayMap.put(key, resDate);

		return resDate;
	}

	private synchronized void load() throws HiveException, IOException {
		NavigableSet<String> tmpSet = new UdfUtils().loadFromFile(null);

		this.allSet = tmpSet;
	}

	private String getKey(String dt, int tradeDays) {
		return String.format("%s_%s", dt, tradeDays);
	}

	public String evaluate(String dt, int tradeDays) throws ParseException, HiveException, IOException {
		if (tradeDays < 0) {
			throw new RuntimeException("tradeDays must be greater than or equal to zero, tradeDays=" + tradeDays);
		}
		
		if(StringUtils.isEmpty(dt) == true){
			return null;
		}

		String key = getKey(dt, tradeDays);
		if (existTradeDayMap.containsKey(key)) {
			return existTradeDayMap.get(key);
		}

		return ForwardTradeDay(dt, tradeDays);
	}
}
