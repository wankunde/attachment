package com.paic.data.hive.common.udf;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;

@Description(name = "md5_paic", value = "_FUNC_(content) - Returns a MD5")
public class MD5 extends UDF {

	private MessageDigest md;
	private StringBuilder sb = new StringBuilder();

	public String evaluate(String content) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		if (content == null) {
			return null;
		}

		if (md == null) {
			md = MessageDigest.getInstance("MD5");
		}

		// 计算md5函数
		md.update(content.getBytes("UTF-8"));

		return convert(md.digest());
	}

	private String convert(byte[] b) {
		int i;

		sb.setLength(0);
		for (int offset = 0; offset < b.length; offset++) {
			i = b[offset];
			if (i < 0)
				i += 256;
			if (i < 16)
				sb.append("0");
			sb.append(Integer.toHexString(i));
		}
		// 32位加密
		return sb.toString();
	}
}
