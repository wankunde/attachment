package com.paic.data.hive.common.udf;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URL;
import java.text.ParseException;
import java.util.NavigableSet;
import java.util.TreeSet;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.FsUrlStreamHandlerFactory;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.io.IOUtils;

import com.paic.data.hive.common.utils.date.DateUnit;

/**
 * Created by LIJUN124 on 2016-01-29.
 */
@Description(name = "trd_dt_sub", value = "_FUNC_(YYYYMMDD, num, [D|W|M|Y]) - Returns a shifted trade dt")
public class TradeDTSub extends UDF {
	static NavigableSet<String> allSet = new TreeSet<String>();

	static {
		try {
			URL.setURLStreamHandlerFactory(new FsUrlStreamHandlerFactory());
		} catch (Throwable e) {
			// ignore
		}
	}

	// SortedSet<String> allSet = new TreeSet<String>();
	private static NavigableSet<String> loadFromFile(String filePath) throws HiveException, IOException {
		// int i = 0;
		// ArrayList<String> list = new ArrayList<String>();
		NavigableSet<String> allSet = new TreeSet<String>();
		Configuration conf = new Configuration();
		String uri = "hdfs:///metadata/dim/tradecalender.csv";
		FSDataInputStream in = null;
		// Path path = new Path(uri);
		BufferedReader reader = null;
		try {
			FileSystem hdfs = FileSystem.get(URI.create(uri), conf);
			in = hdfs.open(new org.apache.hadoop.fs.Path(uri));
			reader = new BufferedReader(new InputStreamReader(in));
			String line = null;
			while ((line = reader.readLine()) != null) {
				allSet.add(line);
				// System.out.println(line);
			}
			IOUtils.copyBytes(in, System.out, 4096, false);
		} finally {
			IOUtils.closeStream(in);
		}
		return (NavigableSet<String>) allSet;
	}

	private static String findLTD(String dt, NavigableSet<String> Set) throws HiveException, IOException {
		// ArrayList<String> list = new ArrayList<String>();
		NavigableSet<String> allSet = new TreeSet<String>();
		allSet = Set;
		String LTD = dt;
		if (!allSet.contains(LTD)) {
			LTD = allSet.lower(LTD);
		}

		return LTD;
	}

	public String evaluate(String dt, int diff, String unit) throws ParseException, HiveException, IOException {
		String LTD = null;
		if (allSet.isEmpty())
			allSet = loadFromFile("hdfs:///metadata/dim/tradecalender.csv");
		LTD = DateUnit.getInstance(unit).shift(dt, -1 * diff);
		return findLTD(LTD, allSet);
	}

}
