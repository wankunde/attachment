package com.paic.data.hive.common.udtf.otcBayesLogRecovery2;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.math3.distribution.NormalDistribution;
import org.apache.hadoop.hive.ql.metadata.HiveException;

import com.paic.data.hive.common.udtf.otcBayesLogRecovery2.DateAccount;
import com.paic.data.hive.common.udtf.otcBayesLogRecovery2.MDateAccount;
import com.paic.data.hive.common.udtf.otcBayesLogRecovery2.MovedTable;
import com.paic.data.hive.common.udtf.otcBayesLogRecovery2.OffsetData;
import com.paic.data.hive.common.udtf.otcBayesLogRecovery2.RDateAccount;
import com.paic.data.hive.common.udtf.otcBayesLogRecovery2.TreeNode;
import com.paic.data.hive.common.udtf.otcBayesLogRecovery2.TrieTree;


public class OTCBayesLogRecoveryProcessor{
	public static double M = 0.001;  //正态分布均值
	public static double E = 0.03;   //正太分布方差
	public static double P_Threshold = 0.001;  
	public static double DayErroProb = 0.0001;
	
	public static List<RDateAccount> Recover(List<DateAccount> Linitial) throws HiveException, IOException {
	
    	List<RDateAccount> Lrectify_merge = new ArrayList<RDateAccount>();
    	int last_break_line=-1;
		int next_break_line = datebreakfind(Linitial,last_break_line);
    	while(last_break_line!=next_break_line&&last_break_line!=Linitial.size()){
    		List<DateAccount>  PartLinitial = new ArrayList<DateAccount>();
    		List<RDateAccount> PartLrectify = new ArrayList<RDateAccount>();
    		for(int dt=last_break_line>0?last_break_line:0;dt<next_break_line;dt++)
    		{
    			PartLinitial.add(Linitial.get(dt));
    		}
	    	PartLrectify=DFSBayes(PartLinitial);
			for(int dt=0;dt<PartLrectify.size();dt++)
			{
				Lrectify_merge.add(PartLrectify.get(dt));
			}	
			last_break_line=next_break_line;
			next_break_line = datebreakfind(Linitial,last_break_line);   	
	      }
		return Lrectify_merge;
	}
	
	public static List<RDateAccount> DFSBayes(List<DateAccount> Linitial){      //DFS-Bayes process
    	int last_s=-1,last_b=-1;	
    	List<RDateAccount> Lrectify = new ArrayList<RDateAccount>();
    	for(DateAccount da:Linitial)
    	{
	    	RDateAccount account = new RDateAccount(da.date,da.mkt,da.b,da.s,da.div,1);
	    	Lrectify.add(account);
    	}
    	int[] next=find(Lrectify,last_b,last_s);
		while(next[0]!=last_b||next[1]!=last_s){         //xun huan duan bu kai
			HashMap<String, Double> p = new HashMap<String, Double>();
    		List<List<TreeNode>> Instance_buy = new ArrayList<List<TreeNode>>();
    		List<List<TreeNode>> Instance_sell = new ArrayList<List<TreeNode>>();
    		List<Double> list_buy = new ArrayList<Double>();
    		List<Double> list_sell = new ArrayList<Double>();
        	int[] block= blockfind(Lrectify,last_b,last_s);
    		int up=block[0];
    		int down=block[1];
    		int last_up=getLastIndex(Lrectify,up);
    		int top=last_up+1>up-2?last_up+1:up-2;
    		list_buy=getcolumn(Lrectify,"buy");
    		list_sell=getcolumn(Lrectify,"sell");
    		int index_buy=getnextelement(list_buy,up-1);
    		int index_sell=getnextelement(list_sell,up-1);
    		
    		TreeNode Node_buy = new TreeNode(-1,-1);		
    		GetTable(Node_buy,list_buy,up,down,index_buy,last_b,top);
    		TrieTree tree_buy = new TrieTree(Node_buy);
    		Instance_buy=tree_buy.getBranch();   		
    		
    		TreeNode Node_sell = new TreeNode(-1,-1);
    		GetTable(Node_sell,list_sell,up,down,index_sell,last_s,top);
    		TrieTree tree_sell = new TrieTree(Node_sell);
    		Instance_sell=tree_sell.getBranch();
        	
    		//--------Bayes--------
    		MovedTable[][][] Capital = getCapital(up,down,top,Instance_buy,Instance_sell);
    		
    		for(int i=0;i<Capital.length;i++)  //length of the first dim of 3-dim Capital
    		{
    			List<MDateAccount> BlockLrec = new ArrayList<MDateAccount>();
    			int moved_num=0;
    			//if(up==0||up==1||up==2)
    			
    			//int k=down-top+1;
    			if(top==0)
    			{
    				for(int r=0;r<=down;r++)
    				{
    					int[] moved={0,0};
    					if(Capital[i][r][0].getMoved()!=0||Capital[i][r][1].getMoved()!=0){
    						moved[0]=Capital[i][r][0].getMoved();
    						moved[1]=Capital[i][r][1].getMoved();
    						moved_num++;
    					}
    					MDateAccount rec = new MDateAccount(Lrectify.get(r).date,Lrectify.get(r).mkt,Capital[i][r][0].getValue(),Capital[i][r][1].getValue(),Lrectify.get(r).div,moved);
    					BlockLrec.add(rec);   					
    				}
    			}	
    			else 
    			{
    				int[] default_moved={0,0};
    				MDateAccount one_more_rec = new MDateAccount(Lrectify.get(top-1).date,Lrectify.get(top-1).mkt,Lrectify.get(top-1).b,Lrectify.get(top-1).s,Lrectify.get(top-1).div,default_moved); //up-3.moved 0 or not 0 is OK, just convenint for profitrate calculation
    				BlockLrec.add(one_more_rec);
    				for(int r=top;r<=down;r++)
    				{
    					int[] moved={0,0};
    					if(Capital[i][r-top][0].getMoved()!=0||Capital[i][r-top][1].getMoved()!=0){
    						moved[0]=Capital[i][r-top][0].getMoved();
    						moved[1]=Capital[i][r-top][1].getMoved();
    						moved_num++;
    					}
    					MDateAccount rec = new MDateAccount(Lrectify.get(r).date,Lrectify.get(r).mkt,Capital[i][r-top][0].getValue(),Capital[i][r-top][1].getValue(),Lrectify.get(r).div,moved);
    					BlockLrec.add(rec);
    				}
    			}
    			double amts=0;
				if(moved_num<3&&BlockLrec.size()!=0){
        			//p.put(i+" "+moved_num,blockP(BlockLrec,moved_num));
					 amts = blockAccuracy(BlockLrec,moved_num,up,top);
					 p.put(i+" "+moved_num, amts);
					  //p.put(i+" "+moved_num,blockAccuracy(BlockLrec,moved_num,up));
				}
    	     }
			//String[] max = blockmax(p);
    		if(p.size()!=0)
    		{
				String[] max = probability(p);	
				if(max[0]!=null&&Double.parseDouble(max[1])>0)
				{	
					for(int u=top;u<=down;u++)
					{
							//int[] moved={Capital[Integer.parseInt(max[0])][u-up+2][0].getMoved(),Capital[Integer.parseInt(max[0])][u-up+2][1].getMoved()};
						RDateAccount rd = new RDateAccount(Lrectify.get(u).date,Lrectify.get(u).mkt,Capital[Integer.parseInt(max[0])][u-top][0].getValue(),Capital[Integer.parseInt(max[0])][u-top][1].getValue(),Lrectify.get(u).div,Double.parseDouble(max[1]));
						Lrectify.set(u, rd);
					}
				}
    		}
		
    		last_b=block[2];
    		last_s=block[3];
    		next=find(Lrectify,last_b,last_s);
    	}
			return Lrectify;   	
	}
	
	public static void GetTable(TreeNode Node,List<Double> list, int up, int down, int index, int last, int top)  //get the moved table
	{
		int moved_num = 0;
		if(index<=down&&Node.getAllowChild())
		{
			for(int k=(top>index-2?top:index-2)>last+1?(top>index-2?top:index-2):last+1;k<=index;k++)
			{
				TreeNode ChildNode = new TreeNode(k,list.get(index));
				Node.setChild(ChildNode, k-index);
				ChildNode.setParent(Node);
				ChildNode.setMoved(k-index);
				moved_num=ChildNode.getMovedSum();
				if(moved_num > 2)
				{					
					ChildNode.setAllowChild(false);
				}
				//T.add(Node(,k-index));
				int next=getnextelement(list,index);
				//System.out.println(k+"   "+list.get(index));
				GetTable(ChildNode,list,up,down,next,k,top);
			}
		}			
		else
			return;
	}
	
	public static MovedTable[][][] getCapital(int up, int down, int top,List<List<TreeNode>> Instance_buy, List<List<TreeNode>> Instance_sell)
	{
		int k=down-top+1;
/*		else if(up==1)
		{
			k=down-up+2;
			top=0;
		}
		else if(up==2)
		{
			k=down-up+3;
			top=0;
		}
		else
		{
			k=down-up+3;
			top=up-2;
		}*/
		int n=Instance_buy.size()*Instance_sell.size();
		MovedTable[][][] TotalCapital = new MovedTable[n][k][2];
		int t=0;
		for(int s=0;s<Instance_sell.size();s++)
		for(int b=0;b<Instance_buy.size();b++)
		{
			//Initial a double[][] array
			MovedTable[][] Capital = new MovedTable[k][2];
			for(int i=0;i<k;i++)
			for(int j=0;j<2;j++)
			{
				Capital[i][j]=new MovedTable(0,0);
			}
 			
			//give value to 2 column
			for(int i=0;i<Instance_buy.get(b).size();i++)
			{
				//Capital[Instance_buy.get(b).get(i).getIndex()-top][0]=Instance_buy.get(b).get(i).getData();
				Capital[Instance_buy.get(b).get(i).getIndex()-top][0].setValue(Instance_buy.get(b).get(i).getData());
				Capital[Instance_buy.get(b).get(i).getIndex()-top][0].setMoved(Instance_buy.get(b).get(i).getMoved());
			}
			for(int j=0;j<Instance_sell.get(s).size();j++)
			{
				//Capital[Instance_sell.get(s).get(j).getIndex()-top][1]=Instance_sell.get(s).get(j).getData();
				Capital[Instance_sell.get(s).get(j).getIndex()-top][1].setValue(Instance_sell.get(s).get(j).getData());
				Capital[Instance_sell.get(s).get(j).getIndex()-top][1].setMoved(Instance_sell.get(s).get(j).getMoved());
			}
			TotalCapital[t++]=Capital;
		}
		
		return TotalCapital;
	}
	
	
	 public static int[] find(List<RDateAccount> input,int last_b,int last_s) //确保输入合法,到底了則返回last_b,last_s。
	{
		int next_b = last_b, next_s = last_s, k = 0;
		int[] location = { 0, 0 };
		if ((last_b > last_s ? last_b : last_s) < input.size())
			k = (last_b > last_s) ? last_b : last_s;
		else if (last_b == input.size() && last_s < input.size())
			k = last_s;
		else if (last_s == input.size() && last_b < input.size())
			k = last_b;
		else {
			location[0] = last_b;
			location[1] = last_s;
			return location;
		}

		for (int i = k + 1; i < input.size(); ++i) {
			if (input.get(i).b != 0.0 && input.get(i).s == 0) {
				next_b = i;
				next_s = last_s;
				break;
			} else if (input.get(i).s != 0 && input.get(i).b == 0) {
				next_s = i;
				next_b = last_b;
				break;
			} else if (input.get(i).b != 0 && input.get(i).s != 0) {
				next_b = i;
				next_s = i;
				break;
			}

		}
		location[0] = next_b;
		location[1] = next_s;
		return location;
	}
	
	public static int datebreakfind(List<DateAccount> input,int last_break_line) throws HiveException, IOException{   //记录日期断点的两天的前一天，作为下一块的top;
		TRD_DT_SUB trd_dt = new TRD_DT_SUB();
		int next_break_line=last_break_line;
		int i=-1;
		for(i=last_break_line;i<input.size();i++)
		{
			if((i+1)<input.size()&&(i>=0)&&!trd_dt.findLTD(input.get(i).date).equals(input.get(i+1).date))
			{
				next_break_line = i+1;
				break;
			}
		}
		if(i==input.size()) 
			next_break_line=input.size(); 
		return next_break_line;
	}
	 
	public static int[] blockfind(List<RDateAccount> input, int last_b, int last_s) { //if up==down then: at the of the list or block capital exist one element.
		int[] location = { -1, -1, -1, -1 };
		int last_index = last_b>last_s?last_b:last_s;
		int up=last_index,down=last_index;
		int[] next = find(input, last_b, last_s);
		if (next[0] != last_b || next[1] != last_s) 
		{
			up = next[0] != last_b ? next[0] : next[1];
			last_index = up;
		}
		while (next[0] != last_b || next[1] != last_s) 
		{
			//int index = next[0] != last_b ? next[0] : next[1];
			int index = next[0]>next[1]?next[0]:next[1];
			if (index - last_index < 3) 
			{
				if(index-up>=10&&index-last_index>1)
					break;
				else if(index-up>=20)
					break;
				last_b = next[0];
				last_s = next[1];
				last_index = index;
				next = find(input, next[0], next[1]);
			}
			else break;
		}
		down = last_index;
		location[0] = up;
		location[1] = down;
		location[2] = last_b;
		location[3] = last_s;
		return location;
	}
	
	public static List<Double> getcolumn(List<RDateAccount> input, String label) //s={"buy","sell"}
	{
		List<Double> column=new ArrayList<Double>();
		if(label=="buy")
		{
			for(int i=0;i<input.size();i++)
			{
				column.add(input.get(i).b);
			}
		}
		else if(label=="sell")
		{
			for(int i=0;i<input.size();i++)
			{
				column.add(input.get(i).s);
			}
		}
		return column;
	}
	
	public static int getnextelement(List<Double> input, int last)
	{
		int index=last;
		boolean flag=false;
		for(int i=last+1;i<input.size();i++)
		{
			if(input.get(i)!=0)
			{
				index=i;
				flag=true;
				break;
			}
		}
		if(flag==true)
			return index;
		else
			return input.size();
	}
	
	public static int getLastIndex(List<RDateAccount> input, int up) //if up is the first row in the data set return -1 
	{
		int lastIndex=-1;
		if(up==0)
			return -1;
		else
			for(int i=0;i<up;i++)
			{
				if(input.get(i).b!=0||input.get(i).s!=0)
					lastIndex=i;
			}
		return lastIndex; 
	}
	

	/*public static List<DateAccount> read(String line) {
		TRD_DT_SUB trd_dt = new TRD_DT_SUB();
		List<DateAccount> list = new ArrayList<DateAccount>();
		try {
			String item[] = line.split("@");
			String str[] = new String[4];
			for (int i = 1; i < item.length; i++) {
				if (item[i].length() != 0) {
					int n=0;
					str = item[i].split("=|,|\"");
					List<Double> a = StringToDouble(str);
					DateAccount da = new DateAccount(str[1], a.get(1), a.get(2), a.get(3), a.get(4));
					list.add(da);
					if(i>=2)
				    while(!trd_dt.findLTD(list.get(i-1).date).equals(list.get(i-2).date))
				    {
				    	//System.out.println(trd_dt.findLTD(list.get(i-1).date));
				    	n++;
				    	if(n>2) break;
				    	DateAccount additon_captl = new DateAccount(trd_dt.findLTD(list.get(i-1).date),0.0,0.0,0.0,0.0);
				    	list.add(i-1,additon_captl);
				    }
					
				}
			}				
		} catch (Exception e) {
			e.printStackTrace();
		}
		Collections.sort(list);
			return list;
	}*/
	
	public static List<DateAccount> read(String line){
		//TRD_DT_SUB trd_dt = new TRD_DT_SUB();
		List<DateAccount> list = new ArrayList<DateAccount>();
		try {
			String item[] = line.split("@");
			String str[] = new String[4];
			for (int i = 1; i < item.length; i++) {
				if (item[i].length() != 0) {
					str = item[i].split("=|,|\"");
					List<Double> a = StringToDouble(str);
					DateAccount da = new DateAccount(str[1], a.get(1), a.get(2), a.get(3), a.get(4));
					list.add(da);
				}
			}				
		} catch (Exception e) {
			e.printStackTrace();
		}
		Collections.sort(list);
		/*for(int j=1;j<list.size();j++)
		{
			int n=0;
			while(!trd_dt.findLTD(list.get(j).date).equals(list.get(j-1).date))
			{
				//System.out.println(trd_dt.findLTD(list.get(j).date));
				n++;
				if(n>2) break;
				DateAccount additon_captl = new DateAccount(trd_dt.findLTD(list.get(j).date),0.0,0.0,0.0,0.0,true);
				list.add(j,additon_captl);
			}
		}*/
		/*for(int k=0;k<list.size();k++)
			System.out.println(list.get(k).date+" "+list.get(k).mkt+" "+list.get(k).b+" "+list.get(k).s+" "+list.get(k).div+" "+list.get(k).is_add_date);*/
			return list;
	}

	public static Double profitrate(List<MDateAccount> list, int index, double buy, double sell) { //calculate profitrate of each item in capitallog
		Double profitrate;
		if (index != 0)
			profitrate = (list.get(index).mkt + sell + list.get(index).div - list.get(index - 1).mkt - buy)
					/ (list.get(index - 1).mkt + buy);
		else
			profitrate = (list.get(index).mkt + sell + list.get(index).div - buy) / (buy);
		return profitrate;
	}

/*	public static double totalprofitrate(List<MDateAccount> list, int index, int top,int b_step, int s_step){   //计算连续3天收益率的乘积
		NormalDistribution normalDistributioin = new NormalDistribution(0, 1);
		int k=index-top+1;      //top的位置也算在内
		double[][] capital=new double[k][2];
		double P;
		boolean flag=false;
		double p = 1;
		double pw=0;
		double w=0;
		for(int i=0;i<k;i++)
		{
			capital[i][0]=list.get(top+i).b;
		    capital[i][1]=list.get(top+i).s;
		}
		if(b_step!=0)
		{
			capital[index-top+b_step][0]=capital[index-top][0];
			capital[index-top][0]=0;
		}
		if(s_step!=0)
		{
			capital[index-top+s_step][1]=capital[index-top][1];
			capital[index-top][1]=0;
		}
		for(int i=top;i<=index;i++)
		{
				double rate=profitrate(list,i,capital[i-top][0],capital[i-top][1]);
				double z = (rate - M) / E;
				double S = normalDistributioin.cumulativeProbability(z);
				if (z < 0)
					P = 2 * S;
				else
					P = 2 - 2 * S;
			if(list.get(i).mkt<100&&capital[i-top][0]==0&&capital[i-top][1]==0)
			{
					P=1;
			}
			
			double wi=0;
			if (i > top) {
				wi = Math.log(1 + (list.get(i).mkt + list.get(i-1).mkt) / 2);
			} else {
				wi = Math.log(1 + list.get(i).mkt);
			}
																
			pw += Math.log(P + Math.exp(-20)) * wi;
			w += wi;
			//p *= P;
		}
				
		return Math.exp(pw / w);
		
	}	*/
	
	public static double blockAccuracy(List<MDateAccount> list,int moved_num, int up, int top){   //计算块儿收益率
		NormalDistribution normalDistributioin = new NormalDistribution(0, 1);
		//HashMap<String, Double> map = new HashMap<String, Double>();
		//initial(map);
		double P=0,sum=0,F=0;
		int erro_num=0;
		if(top==0)
			for(int i=0;i<list.size();i++){
				double pbs = profitrate(list,i,list.get(i).b,list.get(i).s);
				double z = (pbs - M) / E;
				double S1 = normalDistributioin.cumulativeProbability(z);
				if (z < 0)
					P = 2 * S1;
				else
					P = 2 - 2 * S1;
				//p.put(b + " " + 0, map.get(b + "") * P);
				//D = D + map.get(b + "") * P;
				if(P<P_Threshold)
				{
					F+=getPossionProbability(erro_num, DayErroProb, list.size());
					erro_num++;
				}
				//sum+=P*map.get(list.get(i).getMoved()[0]+" "+list.get(i).getMoved()[1]);
			}
		else
			for(int i=1;i<list.size();i++){
				double pbs = profitrate(list,i,list.get(i).b,list.get(i).s);
				double z = (pbs - M) / E;
				double S1 = normalDistributioin.cumulativeProbability(z);
				if (z < 0)
					P = 2 * S1;
				else
					P = 2 - 2 * S1;
				//p.put(b + " " + 0, map.get(b + "") * P);
				//D = D + map.get(b + "") * P;
				if(P<P_Threshold)
				{
					F+=getPossionProbability(erro_num, DayErroProb, list.size()-1);
					erro_num++;
				}
				
				//sum+=P*map.get(list.get(i).getMoved()[0]+" "+list.get(i).getMoved()[1]);
			}
/*			System.out.println("-------------"+F+"--"+erro_num+"--------------");
			System.out.println();*/
			return (1-F);
	}
	
	public static double blockP(List<MDateAccount> list,int moved_num, int up)
	{
		NormalDistribution normalDistributioin = new NormalDistribution(0, 1);
		HashMap<String, Double> map = new HashMap<String, Double>();
		initial(map);
		double sum=0,mean=0,TestP=0;
		if(up==0)
			for(int i=0;i<list.size();i++)		
				sum += profitrate(list,i,list.get(i).b,list.get(i).s);		
		else
			for(int i=1;i<list.size();i++)
				sum += profitrate(list,i,list.get(i).b,list.get(i).s);
		if(up==0)
			mean=sum/list.size();
		else
			mean=sum/(list.size()-1);
		double z = (mean - M) / (E/Math.sqrt(list.size()));
		double S = normalDistributioin.cumulativeProbability(z);
		if (z < 0)
			TestP = 2 * S;
		else
			TestP = 2 - 2 * S;
		//P = totalprofitrate(list,index,((last_s - index + 1 > -2) ? last_s - index + 1 : -2)+index,0,s);
		//p.put(moved_num, map.get(moved_num+"")* P);
		//double probability = max(p).value / D;
		return map.get(moved_num+"")* TestP;
	}
	
	public static void initial(HashMap<String, Double> map) { // 初始化先验概率
		map.put(0+"", 1.0);        //不移动
		map.put(1+"", 0.2);	       //移动一次
		map.put(2+"", 0.1);  	   //移动两次	
	}

	public static OffsetData max(HashMap<String, Double> map) {
		// TODO Auto-generated method stub
		double maxV = -1;
		// int[] maxK=new int[2];
		String maxK = null;
		Iterator keys = map.keySet().iterator();
		for (Map.Entry<String, Double> entry : map.entrySet()) {
			double value = entry.getValue();
			if (value > maxV) {
				maxV = value;
				maxK = entry.getKey().toString();
			}
		}
		int[] value = new int[2];
		String[] str = maxK.split("\\s+");
		value = StringToInt(str);
		OffsetData data = new OffsetData(value[0], value[1], maxV);
		return data;
	}
		
	public static String[] probability(HashMap<String, Double> map) //map中，moved_num=0,1,2 每一种情况的最大值之间所对应的概率,返回最优的那个capital[id]和对应的概率。
	{
		HashMap<String, Double> prior = new HashMap<String, Double>();
		initial(prior);
		String[] capital_id = {"-1","-1","-1"};
		//double[] maxV={-1,-1,-1};
		double[] posterior={-1,-1,-1};
		double[] probability={0,0,0};
		double sum=0,max_prob=0;
		String max_capital=null;
		String[] max = {"-1","0"};  //第一个元素为capital_id,第二个元素为probability
		for (Map.Entry<String, Double> entry : map.entrySet()) {
			double value = entry.getValue();
			String[] str = entry.getKey().toString().split("\\s");
			//String capital_id = str[0];
			String moved_num = str[1];
			if(moved_num.equals("0")&&value > posterior[0])
			{
				posterior[0] = prior.get(0+"")*value;
				capital_id[0] =  str[0];
					//sum+=value;
			}
				
			else if(moved_num.equals("1")&&value > posterior[1])
		    {
				posterior[1] = prior.get(1+"")*value;
				capital_id[1] = str[0];
					//sum+=value;
			}
				
			else if(moved_num.equals("2")&&value > posterior[2])
			{
				posterior[2] = prior.get(2+"")*value;
				capital_id[2] = str[0];
					//sum+=value;
			}
			
		}
		for(int i=0;i<posterior.length;i++)    //求后验频率与后验频率的和
		{
			//posterior[i]=prior.get(i+"")*maxV[i];
			if(posterior[i]>=0)
				sum+=posterior[i];
		}
		for(int i=0;i<posterior.length;i++)   //求后验概率
		{
			if(posterior[i]>=0)
				probability[i]=posterior[i]/sum;
		}
		for(int j=0;j<probability.length;j++)   //取最大的后验概率
		{
			if(probability[j]>max_prob)
			{
				max_prob=probability[j];
				max_capital=capital_id[j];
			}
		}
		max[0]=max_capital;
		max[1]=max_prob+"";
		return max;
	}

	
	private static double getPossionProbability(int k, double day_erro_prob, int days) {
		double lamda=days*day_erro_prob;
        double c = Math.exp(-lamda), sum = 1;  
        for (int i = 1; i <= k; i++) {  
            sum *= lamda / i;  
        }  
        return sum * c;  
    }  
	
	public static String[] blockmax(HashMap<String, Double> map)
	{

		double maxV = -1;
		String maxK = null;
		Iterator keys = map.keySet().iterator();
		for (Map.Entry<String, Double> entry : map.entrySet()) {
			double value = entry.getValue();
			String[] str = entry.getKey().toString().split("\\s");
			String key=str[0];
			if (value > maxV) {
				maxV = value;
				maxK = key;
			}
		}
		String ss[]={maxK,maxV+""};
		return ss;
	}

	public static int[] StringToInt(String[] str) {
		// String str = "100 200 33 55";//字符串
		int[] result = new int[2];// int类型数组
		int i = 0;
		for (String a : str) {
			result[i] = Integer.parseInt(a);
			i++;
		}
		return result;
	}

	public static List<Double> StringToDouble(String[] arrs) {
		List<Double> list = new ArrayList<Double>();
		for (int i = 0; i < arrs.length; i++) {
			if (isNumeric(arrs[i]))
				list.add(Double.parseDouble(arrs[i]));
		}
		return list;
	}

	public static boolean isNumeric(String str) {
		Pattern pattern = Pattern.compile("^[-]?[0-9]+\\.?[0-9]*");
		Matcher isNum = pattern.matcher(str);
		if (!isNum.matches()) {
			return false;
		}
		return true;
	}
}