package com.paic.data.hive.common.udf.template.node.func;

import java.util.Collection;

import com.paic.data.hive.common.udf.template.TNode;
import com.paic.data.hive.common.udf.template.TPushData;
import com.paic.data.hive.common.udf.template.TUserData;
import com.paic.data.hive.common.udf.template.node.TFuncNode;


public class TShortFuncNode extends TFuncNode {

	private final TNode url;
	
	public TShortFuncNode(TNode url) {
		this.url = url;
	}
	
	@Override
	public void params(Collection<String> params) {
		url.params(params);
	}
	
	@Override
	public void toString(StringBuffer output, String channel, TUserData userData, TPushData pushData) {
		output.append("{short:");
		output.append(url.toString(channel, userData, pushData));
		output.append("}");
	}
}
