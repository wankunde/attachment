package com.paic.data.hive.common.udf;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.hive.ql.metadata.HiveException;

import java.io.IOException;
import java.text.ParseException;
import java.util.Map;

@Description(name = "measure_his_map",
        value = "_FUNC_(his,dt,today_measure_map,asset,title,colsGroup [, expr...]) - Returns map. The key is col group value,and value is sum(asset). ")

public class MeasureHisMap extends UDF {
    public Map<String, Map<String, Double>> evaluate(Map<String, Map<String, Double>> his, String dt,
                                                Map<String, Double> todayMeasureMap,
                                                String measureText) throws HiveException, IOException, ParseException {
        return MeasureUtil.mergeHisMap(his, dt, todayMeasureMap, measureText);
    }
}
