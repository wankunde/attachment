/* 
 * Copyright Walker Studio 
 * All Rights Reserved. 
 *  
 * 文件名称： TreeNode.java 
 * 摘 要： 
 * 作 者： Rechard
 * 创建时间： 2013-03-19 
 */  
package com.paic.data.hive.common.udtf.otcBayesLogRecovery2;

import com.paic.data.hive.common.udtf.otcBayesLogRecovery2.TreeNode;

/** 
 * 树节点 
 *  
 * @author Rechard
 * @version 1.0.0.0 
 */  
public class TreeNode   
{   
    private int index=0;  
    private int moved=0;
    private double data=0;
    private boolean allowChild=true;    //节点是否可以接上子节点  
    private TreeNode leftChild=null;  
    private TreeNode midChild=null;
    private TreeNode rightChild=null;  
    private TreeNode parent = null;
    
    public TreeNode(){}  
      
    /** 
     * @param key  层序编码 
     * @param data 数据域 
     */  
    public TreeNode(int index,double data){  
        this.index=index;  
        this.data=data;  
        this.allowChild=true;
        this.leftChild=null;  
        this.midChild=null;
        this.rightChild=null;  
        this.parent=null;
    }  
    
    public int getIndex(){
    	return index;
    }
    
    public int getMoved(){
    	return moved;
    }
    
    public double getData(){
    	return data;
    }
    
    public TreeNode getParent(){  
        return this.parent;  
    }  
    
    public boolean getAllowChild(){
    	return this.allowChild;
    }
    public int getMovedSum()
    {
    	int moved_num=0;
    	TreeNode Node=this;
    	while(Node.index!=-1)
    	{
    		if(Node.moved!=0)
    			moved_num++;
    		Node=Node.getParent();
    	}    	
    	return moved_num;
    }
    
    public void setMoved(int k){
    	this.moved = k;
    }
      
    public void setParent(TreeNode parent){  
        this.parent = parent;  
    }  

    public void setChild(TreeNode child,int k)
    {
    	if(k==-2)
    		this.leftChild=child;
    	if(k==-1)
    		this.midChild=child;
    	if(k==0)
    		this.rightChild=child;
    		
    }
    
    public void setAllowChild(boolean mark)
    {
    	this.allowChild=mark;
    }
    
    public TreeNode getLeftChild()
    {
    	return this.leftChild;
    }
    
    public TreeNode getMidChild()
    {
    	return this.midChild;
    }
    
    public TreeNode getRightChild()
    {
    	return this.rightChild;
    }
    
}  



