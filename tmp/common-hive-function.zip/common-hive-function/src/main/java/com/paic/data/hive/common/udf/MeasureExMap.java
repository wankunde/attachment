package com.paic.data.hive.common.udf;

import com.paic.data.hive.common.udf.bean.MeasureBean;
import com.paic.data.hive.common.udf.bean.MeasureType;
import com.paic.data.hive.common.utils.UdfUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.hive.ql.metadata.HiveException;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.*;

@Description(name = "measure_ex_map",
        value = "_FUNC_(his,dt,today_measure_map,measureText,measure_name,colsGroup,his_ex) - Returns map. The key is col group value,and value is sum(asset). ")
public class MeasureExMap extends UDF {

    private static final Log LOG = LogFactory.getLog(MeasureExMap.class);


    private Map<String, BigDecimal> allSum(Map<String, BigDecimal> res, String key, MeasureBean measure,
                                           Map<String, BigDecimal> hisData,
                                           Map<String, BigDecimal> hisEx) {
        BigDecimal hisValue = hisEx == null ? null : hisEx.get(key);
        String endDate = measure.getEndDate();
        if (hisValue == null) {
            hisValue = BigDecimal.ZERO;
            for (BigDecimal d : hisData.values()) {
                hisValue = hisValue.add(d);
            }
        } else {
            if (hisData.get(endDate) != null)
                hisValue = hisValue.add(hisData.get(endDate));
        }
        res.put(key, hisValue);
        return res;
    }

    /**
     * @param idx
     * @param tmp
     * @param idxValue
     * @param type
     * @param measure
     * @param firstValue
     * @return [0] 是否查找到结果 [1] tmp 为临时计算结果
     * @throws HiveException
     * @throws IOException
     */
    private Object[] getFirstDay(String idx,
                                 BigDecimal idxValue,
                                 BigDecimal tmp,
                                 MeasureType type,
                                 MeasureBean measure,
                                 BigDecimal firstValue) throws HiveException, IOException {
        boolean flag = false;
        if (idxValue != null) {
            if (tmp == null)
                tmp = idxValue;
            else {
                if (type.equals(MeasureType.MAX)) {
                    tmp = idxValue.compareTo(tmp) > 0 ? idxValue : tmp;
                } else if (type.equals(MeasureType.MIN)) {
                    tmp = idxValue.compareTo(tmp) < 0 ? idxValue : tmp;
                } else if (type.equals(MeasureType.SUM) || type.equals(MeasureType.AVG)) {
                    tmp = tmp.add(idxValue);
                } else if (type.equals(MeasureType.TAVG) && UdfUtils.tradeDayIdx(idx) > 0) {
                    tmp = tmp.add(idxValue);
                }
            }

            // 计算是否首次达到某个极值
            if (type.equals(MeasureType.MIN)
                    && tmp.compareTo(firstValue) <= 0) {
                flag = true;

            } else if ((type.equals(MeasureType.MAX) || type.equals(MeasureType.SUM))
                    && tmp.compareTo(firstValue) >= 0) {
                flag = true;
            } else {
                // 计算普通指标(avg,tavg),添加结果并返回
                BigDecimal avgvalue = null;
                if (type.equals(MeasureType.TAVG))
                    avgvalue = tmp.divide(BigDecimal.valueOf(measure.getTradeDays() == 0 ? 1 : measure.getTradeDays()), 4, BigDecimal.ROUND_HALF_UP);
                else if (type.equals(MeasureType.AVG))
                    avgvalue = tmp.divide(BigDecimal.valueOf(measure.getDts().length == 0 ? 1 : measure.getDts().length), 4, BigDecimal.ROUND_HALF_UP);

                // 计算是否首次达到某个平均值
                if ((type.equals(MeasureType.AVG) || type.equals(MeasureType.TAVG))
                        && avgvalue.compareTo(firstValue) >= 0) {
                    flag = true;
                }
            }
        }

        return new Object[]{flag, tmp};
    }

    /**
     * compute max,min,avg,sum
     *
     * @return
     */
    private Map<String, BigDecimal> compute(Map<String, BigDecimal> res, MeasureBean measure,
                                            String exKeyPre,
                                            Map<String, BigDecimal> hisData,
                                            Map<String, BigDecimal> hisEx) throws ParseException, HiveException, IOException {

        BigDecimal firstValue = measure.getFirstValue() == null ? null : BigDecimal.valueOf(measure.getFirstValue()); // 首次达到目标
        MeasureType type = measure.getType();
        String measureText = measure.getMeasureText();
        String key = exKeyPre + MeasureUtil.KEY_DELIMITER_4 + measureText;
//        if (LOG.isDebugEnabled())
//            LOG.debug("start new measure compute. Measure : " + measure);

        // 0d_sum 单独处理
        if (measureText.startsWith("0d_sum")) {
            if (measureText.equals("0d_sum")) {
                return allSum(res, key, measure, hisData, hisEx);
            } else {
                // 0d_sum 首次值的计算
                // 从历史数据中取数
                String sumKey = exKeyPre + MeasureUtil.KEY_DELIMITER_4 + "0d_sum";
                if (hisEx != null) {
                    BigDecimal hisValue = hisEx.get(key);
                    if (hisValue != null) {
                        res.put(key, hisValue);
                        return res;
                    }
                }

                BigDecimal hisValue = hisEx == null ? null : hisEx.get(sumKey);
                String endDate = measure.getEndDate();
                BigDecimal tmp = null;
//                LOG.info("0d_sum debug2: hisEx:"+hisEx+"\t hisData:"+hisData);
                if (hisValue == null) {
                    String[] alldts = hisData.keySet().toArray(new String[]{});
                    if (alldts == null || alldts.length == 0)
                        return res;

                    Arrays.sort(alldts);

                    for (String idx : alldts) {
//                        LOG.info("0d_sum debug:" + new ToStringBuilder(this)
//                                .append(idx).append(hisData.get(idx)).append(tmp)
//                                .append(type).append(measure).append(firstValue).toString());
                        Object[] objs = getFirstDay(idx, hisData.get(idx), tmp, type, measure, firstValue);
                        tmp = (BigDecimal) objs[1];
                        res = allSum(res, sumKey, measure, hisData, hisEx);
                        if ((boolean) objs[0] == true) {
                            res.put(key, BigDecimal.valueOf(Double.parseDouble(idx)));
                            return res;
                        }
                    }
                } else {
                    Object[] objs = getFirstDay(endDate, hisData.get(endDate), hisValue, type, measure, firstValue);
                    tmp = (BigDecimal) objs[1];
                    res.put(sumKey, tmp);
                    if ((boolean) objs[0] == true) {
                        res.put(key, BigDecimal.valueOf(Double.parseDouble(endDate)));
                        return res;
                    }
                }
            }
        }
        // 首次值指标计算
        else if (firstValue != null) {

            // 从历史数据中取数
            if (hisEx != null) {
                BigDecimal hisValue = hisEx.get(key);
                if (hisValue != null) {
                    res.put(key, hisValue);
                    return res;
                }
            }

            String[] alldts = hisData.keySet().toArray(new String[]{});
            if (alldts == null || alldts.length == 0)
                return res;

            Arrays.sort(alldts);
            if (hisEx == null || hisEx.size() == 0) {
                int diff = UdfUtils.daysBetween(alldts[0], measure.getStartDate());
                if (diff > 0)
                    measure = MeasureBean.updateByPeriod(measure, -diff);
                else
                    measure.setStartDate(alldts[0]);
            }

            Set<String> discard = new HashSet<>();
            while ((measure.getStartDate().compareTo(alldts[0]) == 0 ||
                    measure.getEndDate().compareTo(alldts[alldts.length - 1]) <= 0)
                    && measure.getStartDate().compareTo(alldts[alldts.length - 1]) <= 0) {
//                LOG.info(" measure : "+ measure+"\t alldts : "+Arrays.toString(alldts));
                BigDecimal tmp = null;
                for (String idx : measure.getDts()) {
                    if (UdfUtils.isTradeDay(idx) || !measure.getSperiod().endsWith("t")) {
                        Object[] objs = getFirstDay(idx, hisData.get(idx), tmp, type, measure, firstValue);
                        tmp = (BigDecimal) objs[1];
                        if ((boolean) objs[0] == true && !discard.contains(idx)) {
                            res.put(key, new BigDecimal(idx));
                            return res;
                        }
                    }
                }

                discard.add(measure.getEndDate());
                measure = MeasureBean.updateByPeriod(measure, 1);
            }
            discard = null;
        } else {
            BigDecimal tmp = null;
            for (String idx : measure.getDts()) {
                if (UdfUtils.isTradeDay(idx) || !measure.getSperiod().endsWith("t")) {
                    BigDecimal d = hisData.get(idx);
                    if (d != null) {
                        if (tmp == null) {
                            if ((type.compareTo(MeasureType.TAVG) == 0 && UdfUtils.tradeDayIdx(idx) > 0)
                                    || type.compareTo(MeasureType.TAVG) != 0)
                                tmp = d;
                        } else {
                            if (type.compareTo(MeasureType.MAX) == 0) {
                                tmp = d.compareTo(tmp) > 0 ? d : tmp;
                            } else if (type.compareTo(MeasureType.MIN) == 0) {
                                tmp = d.compareTo(tmp) < 0 ? d : tmp;
                            } else if (type.compareTo(MeasureType.SUM) == 0
                                    || type.compareTo(MeasureType.AVG) == 0) {
                                tmp = tmp.add(d);
                            } else if (type.compareTo(MeasureType.TAVG) == 0 && UdfUtils.tradeDayIdx(idx) > 0) {
                                tmp = tmp.add(d);
                            }
                        }
                    }
                }
            }

            if (tmp == null)
                return res;

            // 计算普通指标(max,min,sum,avg,tavg),添加结果并返回
            if (type.compareTo(MeasureType.TAVG) == 0)
                tmp = tmp.divide(BigDecimal.valueOf(measure.getTradeDays() == 0 ? 1 : measure.getTradeDays()), 4, BigDecimal.ROUND_HALF_UP);
            else if (type.compareTo(MeasureType.AVG) == 0)
                tmp = tmp.divide(BigDecimal.valueOf(measure.getDts().length == 0 ? 1 : measure.getDts().length), 4, BigDecimal.ROUND_HALF_UP);

            res.put(key, tmp);
        }
       /* if (LOG.isDebugEnabled())
            LOG.debug("compute resput : " + new ToStringBuilder(this)
                    .append("startDate", startDate)
                    .append("endDate", startDate)
                    .append("key", key)
                    .append("tmp", tmp)
                    .append("tradeDays", tradeDays)
                    .append("dts", dts)
                    .append("res", res).toString());*/

        return res;
    }

    public Map<String, Double> evaluate(Map<String, Map<String, Double>> his, String dt,
                                        String measureText,
                                        String indexName, String colsGroups) throws HiveException, IOException, ParseException {
        return evaluate(his, dt, new HashMap<String, Double>(), measureText, indexName, colsGroups, new HashMap<String, Double>());
    }

    public Map<String, Double> evaluate(Map<String, Map<String, Double>> his, String dt,
                                        String measureText,
                                        String indexName, String colsGroups,
                                        Map<String, Double> hisEx) throws HiveException, IOException, ParseException {
        return evaluate(his, dt, new HashMap<String, Double>(), measureText, indexName, colsGroups, hisEx);
    }

    public Map<String, Double> evaluate(Map<String, Map<String, Double>> his, String dt,
                                        Map<String, Double> todayMeasureMap, String measureText,
                                        String indexName, String colsGroups,
                                        Map<String, Double> hisEx) throws HiveException, IOException, ParseException {
        his = MeasureUtil.mergeHisMap(his, dt, todayMeasureMap, measureText);
        List<MeasureBean> measures = MeasureUtil.parseMeasure(measureText, dt);
        Map<String, BigDecimal> ex = new HashMap<>();
        try {
            Map<String, Map<String, Double>> hisDataMap = MeasureUtil.getColHis(his, indexName, colsGroups);
            for (Map.Entry<String, Map<String, Double>> hisData : hisDataMap.entrySet()) {
                for (MeasureBean measure : measures) {
                    /*ex = compute(ex, measure,
                            hisData.getKey().replaceAll("\\" + MeasureUtil.KEY_DELIMITER_1, "-").replaceAll(MeasureUtil.KEY_DELIMITER_3, "-"),
                            hisData.getValue(), hisEx);*/
                    ex = compute(ex, measure, hisData.getKey(), toBigDecimalMap(hisData.getValue()), toBigDecimalMap(hisEx));
                }
            }
        } catch (Exception e) {
            LOG.error("evaluate error!", e);
            throw e;
        }

        return toDoubleMap(ex);
    }

    private Map<String, BigDecimal> toBigDecimalMap(Map<String, Double> map) {
        if (null == map)
            return null;
        Map<String, BigDecimal> newMap = new HashMap<>();
        for (Map.Entry<String, Double> en : map.entrySet()) {
            newMap.put(en.getKey(), BigDecimal.valueOf(en.getValue()));
        }
        return newMap;
    }

    private Map<String, Double> toDoubleMap(Map<String, BigDecimal> map) {
        if (null == map)
            return null;
        Map<String, Double> newMap = new HashMap<>();
        for (Map.Entry<String, BigDecimal> en : map.entrySet()) {
            newMap.put(en.getKey(), en.getValue().doubleValue());
        }
        return newMap;
    }
}
