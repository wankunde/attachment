package com.paic.data.hive.common.udf.uds;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;

@Description(name = "uds_trans_gender", value = "_FUNC_(String value) - Returns String")
public class UDS_TransGender extends UDF  {
	public String evaluate(String value) {
		if (value == null) {
			return "";
		}
		
		String v = value.trim().toLowerCase();
		if ("f".equals(v) || "female".equals(v) || "女".equals(v) || "1".equals(v)) {
			return "1"; // 女
		}
		
		if ("m".equals(v) || "male".equals(v) || "男".equals(v) || "0".equals(v)) {
			return "0"; // 男
		}
		
		if ("2".equals(v)) {
			return "2"; // 其它
		} else {
			return "";	
		}
	}
	
	public String evaluate(Integer value) {
		if (value == null) {
			return "";
		}
		
		if (1 == value) {
			return "1"; // 女
		} else if (0 == value) {
			return "0"; // 男
		} else if (2 == value) {
			return "2"; // 其它
		} else {
			return "";	
		}
	}
}
