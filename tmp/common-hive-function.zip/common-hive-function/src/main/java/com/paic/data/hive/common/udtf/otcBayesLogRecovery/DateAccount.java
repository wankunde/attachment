package com.paic.data.hive.common.udtf.otcBayesLogRecovery;

public class DateAccount implements Comparable<DateAccount>{
    public String date;
    public double mkt;
    public double b;
    public double s;
    public double div;
	public DateAccount(String date,double mkt,double b,double s,double div){
    	this.date=date;
    	this.mkt=mkt;
        this.b=b;
        this.s=s;
        this.div=div;
    }
	
	public static DateAccount getAccount(String date,double mkt,double b,double s,double div){
		DateAccount account=new DateAccount(date,mkt,b,s,div);
		return account;		
	}
	
	public String getDate() {  
        return date;  
    } 
	
	@Override
	public int compareTo(DateAccount arg0) {
		// TODO Auto-generated method stub
		return this.getDate().compareTo(arg0.getDate());
		//return 0;
	}
 }