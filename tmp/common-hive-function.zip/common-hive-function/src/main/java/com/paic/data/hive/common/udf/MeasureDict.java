package com.paic.data.hive.common.udf;

import com.paic.data.hive.common.utils.UdfUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.hive.ql.metadata.HiveException;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Description(name = "measure_dict", value = "_FUNC_(col, dict_type) - "
        + "return dict_key if col in dictionary with dict_type ")
public class MeasureDict extends UDF {

    private static final Log LOG = LogFactory.getLog(MeasureDict.class);
    Map<String, List<String>> dictionary = new HashMap<>();

    public String evaluate(String col, String dictType) throws HiveException, IOException {
        if (dictionary == null || dictionary.size() == 0) {
            try {
                dictionary = UdfUtils.loadMeasureDict(dictionary);
            } catch (IOException | HiveException e) {
                LOG.error("load measure dictionary error!", e);
                throw e;
            }
        }
        List<String> dictEnums = dictionary.get(dictType.toString());

        if (dictEnums == null){
            LOG.info("does not find dict type :" + dictType.toString());
            return "#other";
        }

        if (dictEnums.contains(col))
            return col;
        else
            return "#other";
    }
}
