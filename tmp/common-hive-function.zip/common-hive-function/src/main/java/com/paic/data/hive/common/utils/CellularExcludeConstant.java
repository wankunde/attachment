package com.paic.data.hive.common.utils;

import java.io.PrintStream;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public final class CellularExcludeConstant
{
  public static final String[] excludeTelStr = { "13819212265", "15269154353", "13590357537", "13504158168", "13800138000" };

  public static Set excludeTelSet = new HashSet();

  static
  {
    CollectionUtils.putAll(excludeTelSet, excludeTelStr);
  }

  public static void main(String[] args)
  {
    Iterator it = excludeTelSet.iterator();

    while (it.hasNext())
      System.out.println(it.next());
  }
}
