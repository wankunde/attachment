package com.paic.data.hive.common.udf;

import com.google.common.base.Joiner;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.exec.UDFArgumentLengthException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDF;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorConverters;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import redis.clients.jedis.Connection;
import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.*;

/**
 * Created by wankun603 on 2018-03-21.
 *
 * Paic redis Client : mvn install:install-file -Dfile=D:\tmp\jedis-3.0.0-20180612.085950-1.jar -DgroupId=redis.clients -DartifactId=jedis -Dversion=3.0.0-SNAPSHOT -Dpackaging=jar
 */
@Description(name = "redis_set", value = "_FUNC_(cluster, key, value) - set kv to redis cluster")
public class RedisSet extends GenericUDF {
  private static final Log LOG = LogFactory.getLog(RedisSet.class);

  private transient ObjectInspectorConverters.Converter[] converters;

  @Override
  public ObjectInspector initialize(ObjectInspector[] arguments) throws UDFArgumentException {
    if (arguments.length == 3) {
      converters = new ObjectInspectorConverters.Converter[arguments.length];
      for (int i = 0; i < arguments.length; i++) {
        converters[i] = ObjectInspectorConverters.getConverter(arguments[i],
                PrimitiveObjectInspectorFactory.writableStringObjectInspector);
      }
    } else if (arguments.length == 4) {
      converters = new ObjectInspectorConverters.Converter[arguments.length];
      for (int i = 0; i < arguments.length; i++) {
        if (i != 2)
          converters[i] = ObjectInspectorConverters.getConverter(arguments[i],
                  PrimitiveObjectInspectorFactory.writableStringObjectInspector);
        else
          converters[i] = ObjectInspectorConverters.getConverter(arguments[i],
                  PrimitiveObjectInspectorFactory.writableIntObjectInspector);
      }
    } else {
      throw new UDFArgumentLengthException(
              "The function redis_set(cluster, key, value) takes 3 or 4 arguments.");
    }

    return ObjectInspectorFactory
            .getStandardListObjectInspector(PrimitiveObjectInspectorFactory
                    .writableStringObjectInspector);
  }

  @Override
  public Object evaluate(DeferredObject[] arguments) throws HiveException {
    String clusterId = (converters[0].convert(arguments[0].get())).toString();
    JedisCluster cluster = RedisUtils.initJedisCluster(clusterId);
    String key = (converters[1].convert(arguments[1].get())).toString();
    ArrayList<Text> result = new ArrayList<Text>();
    if (arguments.length == 3) {
      String value = (converters[2].convert(arguments[2].get())).toString();
      cluster.set(key, value);
      result.add(new Text(key));
      result.add(new Text(value));
      return result;
    } else {
      int seconds = ((IntWritable) converters[2].convert(arguments[2].get())).get();
      String value = (converters[3].convert(arguments[3].get())).toString();
      cluster.setex(key, seconds, value);
      result.add(new Text(key));
      result.add(new Text("" + seconds));
      result.add(new Text(value));
      return result;
    }
  }

  @Override
  public String getDisplayString(String[] children) {
    return "redis_set(" + Joiner.on(",").join(children) + ")";
  }
}
