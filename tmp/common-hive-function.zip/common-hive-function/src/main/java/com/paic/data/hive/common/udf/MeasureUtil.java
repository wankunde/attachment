package com.paic.data.hive.common.udf;

import com.paic.data.hive.common.udf.bean.ColBean;
import com.paic.data.hive.common.udf.bean.ColsBean;
import com.paic.data.hive.common.udf.bean.ColsGroupsBean;
import com.paic.data.hive.common.udf.bean.MeasureBean;
import com.paic.data.hive.common.utils.UdfUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.hive.ql.metadata.HiveException;

import java.io.IOException;
import java.text.ParseException;
import java.util.*;

/**
 * Created by WANKUN603 on 2016-05-30.
 */
public class MeasureUtil {

    private static Log LOG = LogFactory.getLog(MeasureUtil.class.getName());

    public static final String KEY_DELIMITER_1 = "$";
    public static final String KEY_DELIMITER_2 = ":";
    public static final String KEY_DELIMITER_3 = "&";
    public static final String KEY_DELIMITER_4 = "_";

    public static final String KEY_EXTENDS_TIME = "time";
    public static final String KEY_EXTENDS_INIT = "init";
    public static final String KEY_EXTENDS_LAST = "last";
    public static final String KEY_EXTENDS_CURT = "curt";

    public static int DATE_BEFORE = -1;
    public static int DATE_AFTER = 1;

    public static final String INDEX_KEY_DELIMITER = "-";
    
    /**
     * function meta data
     */
    public static Map<String, List<MeasureBean>> measureMap = new HashMap<>();
    public static Map<String, String> minDateMap = new HashMap<>();
    public static Map<String, List<List<String>>> colNamesMap = new HashMap<>();


    public static List<MeasureBean> parseMeasure(String measures, String dt) throws ParseException, HiveException, IOException {
        measures = measures.toLowerCase();
        String mapkey = dt + measures;
        if (measureMap.containsKey(mapkey))
            return measureMap.get(mapkey);

        /*if (LOG.isDebugEnabled())
            LOG.debug("start parse measures.  " + new ToStringBuilder(MeasureUtil.class)
                    .append("measures", measures)
                    .append("dt", dt));*/
        List<MeasureBean> res = new ArrayList<>();
        if (StringUtils.isNotBlank(measures)) {
            String[] tmp = measures.split(",");
            for (String tmp2 : tmp) {
                String[] tmp3 = tmp2.split("_");
                String startDate = UdfUtils.shiftDate(tmp3[0], dt, DATE_BEFORE);
                String endDate = dt;

                // startDate 开始日期
                // endDate 结束日期
                // tmp3[1] 计算规则
                // tmp3[2] 首次值
                // tmp2 日期_计算规则
                MeasureBean mb = null;
                if (tmp3.length == 3)
                    mb = new MeasureBean(startDate, endDate, tmp3[1], tmp3[2], tmp2, tmp3[0]);
                else if (tmp3.length == 2)
                    mb = new MeasureBean(startDate, endDate, tmp3[1], null, tmp2, tmp3[0]);
                /*if (LOG.isDebugEnabled())
                    LOG.debug("got measure : " + mb.toString());*/
                res.add(mb);
            }
        }
        measureMap.put(mapkey, res);
        return res;
    }

    public static String getMinDate(String measures, String dt) throws ParseException, HiveException, IOException {
        String cachedKey = dt + measures;
        if (minDateMap.containsKey(cachedKey))
            return minDateMap.get(cachedKey);

        List<MeasureBean> measureList = parseMeasure(measures, dt);
        if (measureList == null || measureList.size() == 0) {
            minDateMap.put(cachedKey, "19700000");
            return "19700000";
        } else {
            String minDate = "99990000";
            for (MeasureBean measure : measureList) {
                if (minDate.compareTo(measure.getStartDate()) > 0)
                    minDate = measure.getStartDate();
            }
            minDateMap.put(cachedKey, minDate);
            return minDate;
        }
    }

    public static <T> Map<String, Map<String, T>> mergeHisMap(Map<String, Map<String, T>> his, String dt,
                                                              Map<String, T> todayMeasureMap,
                                                              String measureText) throws ParseException, IOException, HiveException {
        /*if (LOG.isDebugEnabled()) {
            String debug = new ToStringBuilder("")
                    .append("his", his)
                    .append("dt", dt)
                    .append("todayMap", todayMeasureMap)
                    .append("measureText", measureText).toString();
        }*/
        if (his == null)
            his = new HashMap<>();
        if (todayMeasureMap == null)
            return his;

        for (Map.Entry<String, T> en : todayMeasureMap.entrySet()) {
            String key = en.getKey();
            T value = en.getValue();
            Map<String, T> hisMap = his.get(key);
            if (hisMap == null)
                hisMap = new HashMap<>();
            hisMap.put(dt, value);

            /*// clear expired data
            String minDate = getMinDate(measureText, dt);
            if (minDate.compareTo(dt) < 0) {
                Set<String> keyset = hisMap.keySet();
                String[] arr = keyset.toArray(new String[]{});
                Arrays.sort(arr);
                for (int i = 0; i < arr.length && arr[i].compareTo(minDate) < 0 && hisMap.size() > 1; i++) {
                    hisMap.remove(arr[i]);
                }
            }*/
            
            // clear expired data
            if(StringUtils.isEmpty(measureText) == true){
            	hisMap.clear();
            }else{
            	String minDate = getMinDate(measureText, dt);
                if (minDate.compareTo(dt) < 0) {
                	Iterator<Map.Entry<String, T>> it = hisMap.entrySet().iterator();
                    
                    while(it.hasNext()){
                    	Map.Entry<String, T> entry = it.next();
                    	String tmpKey = entry.getKey();
                    	if(tmpKey.compareTo(minDate) < 0){
                    		it.remove();
                    	}
                    }
                }
            }

            his.put(key, hisMap);
        }

        return his;
    }

    public static List<List<String>> parseColNames(String colsGroups) {
        if (colNamesMap.containsKey(colsGroups))
            return colNamesMap.get(colsGroups);

        ColsGroupsBean colsGroupsBean = ColsGroupsBean.getColsGroupBean(colsGroups);
        List<List<String>> colsNames = new ArrayList<>();
        List<ColsBean> group = colsGroupsBean.getColsGroup();
        for (int i = 0; i < group.size(); i++) {
            List<ColBean> colBeanList = group.get(i).getCols();
            List<String> tmp = new ArrayList<>();
            for (int j = 0; j < colBeanList.size(); j++)
                tmp.add(colBeanList.get(j).getName());

            colsNames.add(tmp);
        }

        colNamesMap.put(colsGroups, colsNames);
//        LOG.debug("parseColNames : " + colNamesMap);
        return colsNames;
    }


    public static <T> Map<String, Map<String, T>> getColHis(Map<String, Map<String, T>> his, String indexName, String colsGroups) {
        Map<String, Map<String, T>> hisDataMap = new HashMap<>();

        List<List<String>> colsNames = parseColNames(colsGroups);

        for (String mapKeyStr : his.keySet()) {
            Object[] mapKey = ColsGroupsBean.parseMapKey(mapKeyStr);
            List<String> list2 = Arrays.asList((String[]) mapKey[1]); // colName list

            if (list2.size() == 0)  // 优先计算指标当前值
                hisDataMap.put(mapKeyStr, his.get(mapKeyStr));
            else {
                for (List<String> colNames : colsNames) {
                    if (indexName.equals(mapKey[0]) && colNames.size() == list2.size() && colNames.containsAll(list2)) {
                        hisDataMap.put(mapKeyStr, his.get(mapKeyStr));
                    }
                }
            }
        }

        return hisDataMap;
    }

    public static String getTimeKey(String key) {
        String tmp = new String(key.substring(0, key.length() - 5));
        int p = tmp.indexOf(INDEX_KEY_DELIMITER);
        p = p == -1 ? tmp.length() : p;
        return KEY_EXTENDS_TIME + key.substring(p);
    }

    public static Map<String, String> mergeExtMap(Map<String, String> src, Map<String, String> dest) {
        if (src == null)
            return dest;
        if (dest != null) {
            for (Map.Entry<String, String> en : dest.entrySet()) {
                String key = en.getKey();
                String timeKey = getTimeKey(key);
//                if (LOG.isDebugEnabled())
//                    LOG.debug(" merge in . key : " + key + " value : " + dest.get(timeKey) + " timeKey : " +
//                            timeKey + " time value : " + src.get(timeKey));
                if (!src.containsKey(key))
                    src.put(key, en.getValue());
                else if (dest.get(timeKey) != null) {
                    if (src.get(timeKey) == null
                            || (key.endsWith(KEY_EXTENDS_INIT) && dest.get(timeKey).compareTo(src.get(timeKey)) <= 0)
                            || (key.endsWith(KEY_EXTENDS_LAST) && dest.get(timeKey).compareTo(src.get(timeKey)) >= 0)
                            || (key.endsWith(KEY_EXTENDS_CURT) && dest.get(timeKey).compareTo(src.get(timeKey)) >= 0))
                        src.put(key, en.getValue());
                }
            }
        }
        return src;
    }

    public static Set<String>[] measureDiffDays(MeasureBean measure1, MeasureBean measure2) throws HiveException, IOException {
        Set<String> diff1 = new TreeSet<>();
        Set<String> diff2 = new TreeSet<>();

        String[] dts1 = measure1.getDts();
        String[] dts2 = measure2.getDts();
        boolean checkTradeDay = measure1.getSperiod().endsWith("t");
        int i = 0, j = 0;
        while (i < dts1.length || j < dts2.length) {
            if (i >= dts1.length) {
                while (j < dts2.length) {
                    if (UdfUtils.isTradeDay(dts2[j]) || !checkTradeDay)
                        diff2.add(dts2[j]);
                    j++;
                }
            } else if (j >= dts2.length) {
                while (i < dts1.length) {
                    if (UdfUtils.isTradeDay(dts1[i]) || !checkTradeDay)
                        diff1.add(dts1[i]);
                    i++;
                }
            } else {
                int cmp = dts1[i].compareTo(dts2[j]);
                if (cmp < 0) {
                    if (UdfUtils.isTradeDay(dts1[i]) || !checkTradeDay)
                        diff1.add(dts1[i]);
                    i++;
                } else if (cmp > 0) {
                    if (UdfUtils.isTradeDay(dts2[j]) || !checkTradeDay)
                        diff2.add(dts2[j]);
                    j++;
                } else {
                    i++;
                    j++;
                }
            }
        }
        return new Set[]{diff1, diff2};
    }

}
