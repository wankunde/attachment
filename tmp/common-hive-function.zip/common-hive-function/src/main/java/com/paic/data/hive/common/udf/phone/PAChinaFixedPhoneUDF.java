package com.paic.data.hive.common.udf.phone;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.io.Text;

import com.paic.data.hive.common.utils.FixedPhoneUtils;

@Description(name = "uds_format_fixedno", value = "_FUNC_(idno) - 弱校验手机号码。", extended = "Example:\n   > SELECT _FUNC_('867393459870') FROM TABLE ;\n  '07393459870'")
public class PAChinaFixedPhoneUDF extends UDF {
	private final Text result = new Text();

	public static void main(String[] args) {
		Text partyno = new Text();
		partyno.set("867393459870");
		System.out.println(new PAChinaFixedPhoneUDF().evaluate(partyno));
	}

	public Text evaluate(Text fixedphoneno) {
		if ((fixedphoneno == null) || (fixedphoneno.toString().trim().length() == 0)
				|| (fixedphoneno.toString().trim().length() < 11)) {
			return null;
		}

		String restr = FixedPhoneUtils.formatFixedPhoneStrongerNo(fixedphoneno.toString());
		if (StringUtils.isEmpty(restr)) {
			return null;
		}
		this.result.set(restr);
		return this.result;
	}
}