package com.paic.data.hive.common.udf;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Created by WANKUN603 on 2016-07-02.
 */
@Description(name = "measure_obj_ex_map",
        value = "_FUNC_(exMap,todayMap) - merge two map,and reutrn init value,last value in map")
public class MeasureObjExMap extends UDF {

    private static Log LOG = LogFactory.getLog(MeasureObjExMap.class.getName());

    public Map<String, String> evaluate(Map<String, String> exMap, Map<String, String> todayMap) {
        Set<String> curtKeys = new HashSet<>();
        if (exMap != null) {
            for (String key : exMap.keySet()) {
                if (key.endsWith(MeasureUtil.KEY_EXTENDS_CURT))
                    curtKeys.add(key);
            }

            for (String key : curtKeys) {
                exMap.remove(key);
            }
        }
//        LOG.debug("exMap  " + exMap + " todayMap " + todayMap);
        return MeasureUtil.mergeExtMap(exMap, todayMap);
    }
}
