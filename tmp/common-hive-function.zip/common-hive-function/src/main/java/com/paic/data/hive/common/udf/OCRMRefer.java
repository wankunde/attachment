package com.paic.data.hive.common.udf;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import jodd.util.StringUtil;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cloudera.org.apache.http.ParseException;

/**
 * @author YANCHAO750
 * @date 2016年8月17日
 */
@Description(name = "ocrm_refer", value = "_FUNC_(originInfo, claimResult, preResult, historyDate, initFlag) - Returns new referrer")
public class OCRMRefer extends UDF {
	protected static final Logger logger = LoggerFactory.getLogger(OCRMRefer.class);

	public final static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

	public final static Integer PROTECT_DAYS = 30;

	// 取资金户开户推荐人
	public final static Integer CUST_RESULT_NO = 1;
	// 取理财户首入金推荐人
	public final static Integer OMM_RESULT_NO = 2;
	
	// 异常状态
	public final static String STATUS_ERR = null;
	// 理财户过了保护期的初始化状态
	public final static String STATUS_OMM_INIT = "-2";
	// 开了资金户的初始化状态
	public final static String STATUS_CUST_INIT = "-1";
	// 新增客户状态
	public final static String STATUS_NEW_CUST = "0";
	// 初始化再认领状态
	public final static String STATUS_INIT_CLAIM = "1";
	// 非-1状态的认领修改
	public final static String STATUS_CLAIM = "2";
	// 变更推荐人状态
	public final static String STATUS_CHG_REF = "3";
	// 变更考核营业部状态
	public final static String STATUS_CHG_DEPT = "4";

	// 全量匹配信息的相关key
	public final static String CUST_CODE = "cust_code";// 客户代码

	public final static String CUST_OPEN_DATE = "cust_open_date";// 资金户开户日期
	public final static String CUST_OPEN_RCMD_INIT = "cust_rmd_init";// 资金户推荐人原始信息
	public final static String CUST_OPEN_RCMD = "cust_rmd_ygbh";// 资金户推荐人编号
	public final static String CUST_OPEN_RCMD_TYPE = "cust_rmd_type";// 资金户推荐人类型
	public final static String CUST_OPEN_RCMD_ZY = "cust_ygbh";// 资金户推荐人对应专员
	public final static String CUST_OPEN_RCMD_STATUS = "cust_ygbh_valid";// 资金户推荐人员工状态

	public final static String OMM_OPEN_DATE = "omm_open_date";// 理财户开户日期
	public final static String OMM_OPEN_RCMD_INIT = "omm_rmd_init";// 理财户推荐人原始信息
	public final static String OMM_OPEN_RCMD = "omm_rmd_ygbh";// 理财户推荐人编号
	public final static String OMM_OPEN_RCMD_TYPE = "omm_rmd_type";// 理财户推荐人类型
	public final static String OMM_OPEN_RCMD_ZY = "omm_ygbh";// 理财户推荐人对应专员
	public final static String OMM_OPEN_RCMD_STATUS = "omm_ygbh_valid";// 理财户推荐人员工状态

	public final static String OMM_FST_TRD_DATE = "omm_first_trd_date";// 理财首次购买日期
	public final static String OMM_FST_TRD_RCMD_INIT = "omm_first_trd_rcmd_init";// 理财首次购买推荐人原始信息
	public final static String OMM_FST_TRD_RCMD = "omm_first_trd_rcmd_ygbh";// 理财首次购买推荐人
	public final static String OMM_FST_TRD_RCMD_TYPE = "omm_first_trd_rcmd_type";// 理财首次购买推荐人类型
	public final static String OMM_FST_TRD_RCMD_ZY = "omm_first_trd_ygbh";// 理财首次购买推荐人对应专员
	public final static String OMM_FST_TRD_RCMD_STATUS = "omm_first_trd_valid";// 理财首次购买推荐人员工状态

	public final static String OMM_FST_RCD_DATE = "omm_first_recharge_date";// 理财首次充值日期
	public final static String OMM_FST_RCD_RCMD_INIT = "omm_first_recharge_rcmd_init";// 理财首次充值推荐人原始信息
	public final static String OMM_FST_RCD_RCMD = "omm_first_recharge_rcmd_ygbh";// 理财首次充值推荐人
	public final static String OMM_FST_RCD_RCMD_TYPE = "omm_first_recharge_rcmd_type";// 理财首次充值推荐人类型
	public final static String OMM_FST_RCD_RCMD_ZY = "omm_first_recharge_ygbh";// 理财首次充值推荐人对应专员
	public final static String OMM_FST_RCD_RCMD_STATUS = "omm_first_recharge_valid";// 理财首次充值推荐人员工状态

	public final static String OMM_SUM_TSD_DATE = "omm_sum_1000_date";// 理财千元净入金日期

	// 认领结果的相关key
	public final static String RL_CUST_CODE = "cust_code";// 客户代码
	public final static String RL_RECMD = "recmd";// 员工编码
	public final static String RL_RECMD_TYPE = "recmd_type";// 员工类型（0：证券；1：综拓）

	// 返回结果的相关key
	public final static String RST_CUST_CODE = "cust_code";// 客户代码
	public final static String RST_CUST_OPEN_DT = "cust_open_dt";// 资金户开户日期
	public final static String RST_CUST_OPEN_RECMD_INIT = "cust_open_recmd_init";// 资金户开户推荐人原始信息
	public final static String RST_CUST_OPEN_RECMD = "cust_open_recmd";// 资金户开户推荐人
	public final static String RST_CUST_OPEN_RECMD_TYPE = "cust_open_recmd_type";// 资金户开户推荐人类型
	
	public final static String RST_OMM_OPEN_DT = "omm_open_dt";// 理财户开户日期
	public final static String RST_OMM_FIRST_INCOME_DT = "omm_first_income_dt";// 理财首次入金日期
	public final static String RST_OMM_FIRST_INCOME_RECMD_INIT = "omm_first_income_recmd_init";// 理财首次入金推荐人原始信息
	public final static String RST_OMM_FIRST_INCOME_RECMD = "omm_first_income_recmd";// 理财首次入金推荐人
	public final static String RST_OMM_FIRST_INCOME_RECMD_TYPE = "omm_first_income_recmd_type";// 理财首次入金推荐人类型
	public final static String RST_OMM_TOTAL_INCOME_DT = "omm_total_income_dt";// 理财千元净入金日期
	public final static String RST_RECMD_INIT = "recmd_init";// 最终的推荐人原始信息
	public final static String RST_RECMD = "recmd";// 最终的推荐人编号
	public final static String RST_RECMD_TYPE = "recmd_type";// 最终的推荐人类型
	public final static String RST_RECMD_ZY = "recmd_zy";// 最终的推荐人对应专员
	public final static String RST_STAFF_STATUS = "staff_status";// 最终的推荐人员工状态
	public final static String RST_RECMD_UPDATE_STATUS = "recmd_update_status";// 推荐人变更状态。-1:OCRM初始化；0：新增客户；1：初始化再认领；2：认领修改；3：变更推荐人；4：变更考核营业部
	public final static String RST_ADD_DATE = "add_date";// 记录新增日期
	public final static String RST_UPDATE_DATE = "update_date";// 记录修改日期

	private HashMap<Integer, HashMap<String, String>> resultMap = null;

	private Integer convertInteger(String value) {
		Integer i = null;
		if (!StringUtils.isEmpty(value)) {
			i = Integer.valueOf(value);
		}
		return i;
	}
	
	private void initBasicInfo(Map<String, String> params, Map<String, String> resultNew){
		
		resultNew.put(RST_CUST_CODE, params.get(CUST_CODE));// 初始化cust_code
		resultNew.put(RST_CUST_OPEN_DT, params.get(CUST_OPEN_DATE));// 初始化“资金户开户日期”
		
		resultNew.put(RST_CUST_OPEN_RECMD_INIT, params.get(CUST_OPEN_RCMD_INIT));// 初始化“资金户开户推荐人原始信息”
		resultNew.put(RST_CUST_OPEN_RECMD, params.get(CUST_OPEN_RCMD));// 初始化“资金户开户推荐人”
		resultNew.put(RST_CUST_OPEN_RECMD_TYPE, params.get(CUST_OPEN_RCMD_TYPE));// 初始化“资金户开户推荐人类型”
		
		resultNew.put(RST_OMM_OPEN_DT, params.get(OMM_OPEN_DATE));// 初始化“理财户开户日期”
		
		resultMap = new HashMap<Integer, HashMap<String, String>>();
		// 取资金户开户推荐人
		HashMap result_cust = new HashMap<String, String>();
		result_cust.put(RST_RECMD_INIT, params.get(CUST_OPEN_RCMD_INIT));
		result_cust.put(RST_RECMD, params.get(CUST_OPEN_RCMD));
		result_cust.put(RST_RECMD_TYPE, params.get(CUST_OPEN_RCMD_TYPE));
		result_cust.put(RST_RECMD_ZY, params.get(CUST_OPEN_RCMD_ZY));
		result_cust.put(RST_STAFF_STATUS, params.get(CUST_OPEN_RCMD_STATUS));
		resultMap.put(CUST_RESULT_NO, result_cust);

		// 取理财户首次入金推荐人
		HashMap result_omm = new HashMap<String, String>();
		//先用空来初始化，后面判断完再填充
		result_omm.put(RST_RECMD_INIT, null);
		result_omm.put(RST_RECMD, null);
		result_omm.put(RST_RECMD_TYPE, null);
		result_omm.put(RST_RECMD_ZY, null);
		result_omm.put(RST_STAFF_STATUS, null);

		Integer ommFstTrdDate = convertInteger(params.get(OMM_FST_TRD_DATE));
		Integer ommFstRcdDate = convertInteger(params.get(OMM_FST_RCD_DATE));
		
		Map<String, String> frstTmp = new HashMap<String, String>();
		frstTmp.put(RST_OMM_FIRST_INCOME_DT, null);
		frstTmp.put(RST_OMM_FIRST_INCOME_RECMD_INIT, null);
		frstTmp.put(RST_OMM_FIRST_INCOME_RECMD, null);
		frstTmp.put(RST_OMM_FIRST_INCOME_RECMD_TYPE, null);
		if (ommFstTrdDate != null || ommFstRcdDate != null) {// 有入金动作
			if (ommFstTrdDate != null && ommFstRcdDate != null) {// 两个入金动作都有，取较早的那个。如果推荐人信息没有，则取开户人推荐人信息
				if (ommFstTrdDate < ommFstRcdDate) {
					frstTmp.put(RST_OMM_FIRST_INCOME_DT, params.get(OMM_FST_TRD_DATE));
					if( !StringUtil.isEmpty(params.get(OMM_FST_TRD_RCMD)) ){
						frstTmp.put(RST_OMM_FIRST_INCOME_RECMD_INIT, params.get(OMM_FST_TRD_RCMD_INIT));
						frstTmp.put(RST_OMM_FIRST_INCOME_RECMD, params.get(OMM_FST_TRD_RCMD));
						frstTmp.put(RST_OMM_FIRST_INCOME_RECMD_TYPE, params.get(OMM_FST_TRD_RCMD_TYPE));
						//用首次购买推荐人填充“首入金推荐人”信息
						result_omm.put(RST_RECMD_INIT, params.get(OMM_FST_TRD_RCMD_INIT));
						result_omm.put(RST_RECMD, params.get(OMM_FST_TRD_RCMD));
						result_omm.put(RST_RECMD_TYPE, params.get(OMM_FST_TRD_RCMD_TYPE));
						result_omm.put(RST_RECMD_ZY, params.get(OMM_FST_TRD_RCMD_ZY));
						result_omm.put(RST_STAFF_STATUS, params.get(OMM_FST_TRD_RCMD_STATUS));
					}else{
						frstTmp.put(RST_OMM_FIRST_INCOME_RECMD_INIT, params.get(OMM_OPEN_RCMD_INIT));
						frstTmp.put(RST_OMM_FIRST_INCOME_RECMD, params.get(OMM_OPEN_RCMD));
						frstTmp.put(RST_OMM_FIRST_INCOME_RECMD_TYPE, params.get(OMM_OPEN_RCMD_TYPE));
						//用理财账户开户推荐人填充“首入金推荐人”信息
						result_omm.put(RST_RECMD_INIT, params.get(OMM_OPEN_RCMD_INIT));
						result_omm.put(RST_RECMD, params.get(OMM_OPEN_RCMD));
						result_omm.put(RST_RECMD_TYPE, params.get(OMM_OPEN_RCMD_TYPE));
						result_omm.put(RST_RECMD_ZY, params.get(OMM_OPEN_RCMD_ZY));
						result_omm.put(RST_STAFF_STATUS, params.get(OMM_OPEN_RCMD_STATUS));
					}
				} else if(ommFstTrdDate > ommFstRcdDate){
					frstTmp.put(RST_OMM_FIRST_INCOME_DT, params.get(OMM_FST_RCD_DATE));
					if( !StringUtil.isEmpty(params.get(OMM_FST_RCD_RCMD)) ){
						frstTmp.put(RST_OMM_FIRST_INCOME_RECMD_INIT, params.get(OMM_FST_RCD_RCMD_INIT));
						frstTmp.put(RST_OMM_FIRST_INCOME_RECMD, params.get(OMM_FST_RCD_RCMD));
						frstTmp.put(RST_OMM_FIRST_INCOME_RECMD_TYPE, params.get(OMM_FST_RCD_RCMD_TYPE));
						//用首次充值推荐人填充“首入金推荐人”信息
						result_omm.put(RST_RECMD_INIT, params.get(OMM_FST_RCD_RCMD_INIT));
						result_omm.put(RST_RECMD, params.get(OMM_FST_RCD_RCMD));
						result_omm.put(RST_RECMD_TYPE, params.get(OMM_FST_RCD_RCMD_TYPE));
						result_omm.put(RST_RECMD_ZY, params.get(OMM_FST_RCD_RCMD_ZY));
						result_omm.put(RST_STAFF_STATUS, params.get(OMM_FST_RCD_RCMD_STATUS));
					}else{
						frstTmp.put(RST_OMM_FIRST_INCOME_RECMD_INIT, params.get(OMM_OPEN_RCMD_INIT));
						frstTmp.put(RST_OMM_FIRST_INCOME_RECMD, params.get(OMM_OPEN_RCMD));
						frstTmp.put(RST_OMM_FIRST_INCOME_RECMD_TYPE, params.get(OMM_OPEN_RCMD_TYPE));
						//用理财账户开户推荐人填充“首入金推荐人”信息
						result_omm.put(RST_RECMD_INIT, params.get(OMM_OPEN_RCMD_INIT));
						result_omm.put(RST_RECMD, params.get(OMM_OPEN_RCMD));
						result_omm.put(RST_RECMD_TYPE, params.get(OMM_OPEN_RCMD_TYPE));
						result_omm.put(RST_RECMD_ZY, params.get(OMM_OPEN_RCMD_ZY));
						result_omm.put(RST_STAFF_STATUS, params.get(OMM_OPEN_RCMD_STATUS));
					}
				}else{//"首次充值" 和”次充值“是都一天，哪个推荐人有就取哪个
					frstTmp.put(RST_OMM_FIRST_INCOME_DT, params.get(OMM_FST_RCD_DATE));//取哪个都一样，因为相等
					if( !StringUtil.isEmpty(params.get(OMM_FST_RCD_RCMD)) ){//"首次充值推荐人"非空
						frstTmp.put(RST_OMM_FIRST_INCOME_RECMD_INIT, params.get(OMM_FST_RCD_RCMD_INIT));
						frstTmp.put(RST_OMM_FIRST_INCOME_RECMD, params.get(OMM_FST_RCD_RCMD));
						frstTmp.put(RST_OMM_FIRST_INCOME_RECMD_TYPE, params.get(OMM_FST_RCD_RCMD_TYPE));
						//用首次充值推荐人填充“首入金推荐人”信息
						result_omm.put(RST_RECMD_INIT, params.get(OMM_FST_RCD_RCMD_INIT));
						result_omm.put(RST_RECMD, params.get(OMM_FST_RCD_RCMD));
						result_omm.put(RST_RECMD_TYPE, params.get(OMM_FST_RCD_RCMD_TYPE));
						result_omm.put(RST_RECMD_ZY, params.get(OMM_FST_RCD_RCMD_ZY));
						result_omm.put(RST_STAFF_STATUS, params.get(OMM_FST_RCD_RCMD_STATUS));
					}else if(!StringUtil.isEmpty(params.get(OMM_FST_TRD_RCMD))){//"首次购买推荐人"非空
						frstTmp.put(RST_OMM_FIRST_INCOME_RECMD_INIT, params.get(OMM_FST_TRD_RCMD_INIT));
						frstTmp.put(RST_OMM_FIRST_INCOME_RECMD, params.get(OMM_FST_TRD_RCMD));
						frstTmp.put(RST_OMM_FIRST_INCOME_RECMD_TYPE, params.get(OMM_FST_TRD_RCMD_TYPE));
						//用首次购买推荐人填充“首入金推荐人”信息
						result_omm.put(RST_RECMD_INIT, params.get(OMM_FST_TRD_RCMD_INIT));
						result_omm.put(RST_RECMD, params.get(OMM_FST_TRD_RCMD));
						result_omm.put(RST_RECMD_TYPE, params.get(OMM_FST_TRD_RCMD_TYPE));
						result_omm.put(RST_RECMD_ZY, params.get(OMM_FST_TRD_RCMD_ZY));
						result_omm.put(RST_STAFF_STATUS, params.get(OMM_FST_TRD_RCMD_STATUS));
					}else{//两个都为空，就用开户推荐人
						frstTmp.put(RST_OMM_FIRST_INCOME_RECMD_INIT, params.get(OMM_OPEN_RCMD_INIT));
						frstTmp.put(RST_OMM_FIRST_INCOME_RECMD, params.get(OMM_OPEN_RCMD));
						frstTmp.put(RST_OMM_FIRST_INCOME_RECMD_TYPE, params.get(OMM_OPEN_RCMD_TYPE));
						//用理财账户开户推荐人填充“首入金推荐人”信息
						result_omm.put(RST_RECMD_INIT, params.get(OMM_OPEN_RCMD_INIT));
						result_omm.put(RST_RECMD, params.get(OMM_OPEN_RCMD));
						result_omm.put(RST_RECMD_TYPE, params.get(OMM_OPEN_RCMD_TYPE));
						result_omm.put(RST_RECMD_ZY, params.get(OMM_OPEN_RCMD_ZY));
						result_omm.put(RST_STAFF_STATUS, params.get(OMM_OPEN_RCMD_STATUS));
					}
				}
			} else if (ommFstTrdDate != null && ommFstRcdDate == null) {// 只有购买的入金动作，则取购买作为首入金。如果推荐人信息没有，则取开会人推荐人信息
				frstTmp.put(RST_OMM_FIRST_INCOME_DT, params.get(OMM_FST_TRD_DATE));
				if( !StringUtil.isEmpty(params.get(OMM_FST_TRD_RCMD)) ){
					frstTmp.put(RST_OMM_FIRST_INCOME_RECMD_INIT, params.get(OMM_FST_TRD_RCMD_INIT));
					frstTmp.put(RST_OMM_FIRST_INCOME_RECMD, params.get(OMM_FST_TRD_RCMD));
					frstTmp.put(RST_OMM_FIRST_INCOME_RECMD_TYPE, params.get(OMM_FST_TRD_RCMD_TYPE));
					//用首次购买推荐人填充“首入金推荐人”信息
					result_omm.put(RST_RECMD_INIT, params.get(OMM_FST_TRD_RCMD_INIT));
					result_omm.put(RST_RECMD, params.get(OMM_FST_TRD_RCMD));
					result_omm.put(RST_RECMD_TYPE, params.get(OMM_FST_TRD_RCMD_TYPE));
					result_omm.put(RST_RECMD_ZY, params.get(OMM_FST_TRD_RCMD_ZY));
					result_omm.put(RST_STAFF_STATUS, params.get(OMM_FST_TRD_RCMD_STATUS));
				}else{
					frstTmp.put(RST_OMM_FIRST_INCOME_RECMD_INIT, params.get(OMM_OPEN_RCMD_INIT));
					frstTmp.put(RST_OMM_FIRST_INCOME_RECMD, params.get(OMM_OPEN_RCMD));
					frstTmp.put(RST_OMM_FIRST_INCOME_RECMD_TYPE, params.get(OMM_OPEN_RCMD_TYPE));
					//用理财账户开户推荐人填充“首入金推荐人”信息
					result_omm.put(RST_RECMD_INIT, params.get(OMM_OPEN_RCMD_INIT));
					result_omm.put(RST_RECMD, params.get(OMM_OPEN_RCMD));
					result_omm.put(RST_RECMD_TYPE, params.get(OMM_OPEN_RCMD_TYPE));
					result_omm.put(RST_RECMD_ZY, params.get(OMM_OPEN_RCMD_ZY));
					result_omm.put(RST_STAFF_STATUS, params.get(OMM_OPEN_RCMD_STATUS));
				}
			} else if (ommFstTrdDate == null && ommFstRcdDate != null) {// 只有充值的入金动作，则取充值作为首入金。如果推荐人信息没有，则取开会人推荐人信息
				frstTmp.put(RST_OMM_FIRST_INCOME_DT, params.get(OMM_FST_RCD_DATE));
				if( !StringUtil.isEmpty(params.get(OMM_FST_RCD_RCMD)) ){
					frstTmp.put(RST_OMM_FIRST_INCOME_RECMD_INIT, params.get(OMM_FST_RCD_RCMD_INIT));
					frstTmp.put(RST_OMM_FIRST_INCOME_RECMD, params.get(OMM_FST_RCD_RCMD));
					frstTmp.put(RST_OMM_FIRST_INCOME_RECMD_TYPE, params.get(OMM_FST_RCD_RCMD_TYPE));
					//用首次充值推荐人填充“首入金推荐人”信息
					result_omm.put(RST_RECMD_INIT, params.get(OMM_FST_RCD_RCMD_INIT));
					result_omm.put(RST_RECMD, params.get(OMM_FST_RCD_RCMD));
					result_omm.put(RST_RECMD_TYPE, params.get(OMM_FST_RCD_RCMD_TYPE));
					result_omm.put(RST_RECMD_ZY, params.get(OMM_FST_RCD_RCMD_ZY));
					result_omm.put(RST_STAFF_STATUS, params.get(OMM_FST_RCD_RCMD_STATUS));
				}else{
					frstTmp.put(RST_OMM_FIRST_INCOME_RECMD_INIT, params.get(OMM_OPEN_RCMD_INIT));
					frstTmp.put(RST_OMM_FIRST_INCOME_RECMD, params.get(OMM_OPEN_RCMD));
					frstTmp.put(RST_OMM_FIRST_INCOME_RECMD_TYPE, params.get(OMM_OPEN_RCMD_TYPE));
					//用理财账户开户推荐人填充“首入金推荐人”信息
					result_omm.put(RST_RECMD_INIT, params.get(OMM_OPEN_RCMD_INIT));
					result_omm.put(RST_RECMD, params.get(OMM_OPEN_RCMD));
					result_omm.put(RST_RECMD_TYPE, params.get(OMM_OPEN_RCMD_TYPE));
					result_omm.put(RST_RECMD_ZY, params.get(OMM_OPEN_RCMD_ZY));
					result_omm.put(RST_STAFF_STATUS, params.get(OMM_OPEN_RCMD_STATUS));
				}
			}
		}
		resultNew.putAll(frstTmp);
		resultMap.put(OMM_RESULT_NO, result_omm);

		resultNew.put(RST_OMM_TOTAL_INCOME_DT, params.get(OMM_SUM_TSD_DATE));// 初始化“理财户净入金满足要求的日期”
	}

	/**
	 * 计算oldDate和newDate的相隔天数,newDate-oldDate得到的天数，有正有负 oldDate：老一点的时间
	 * newDate：新一点的时间
	 */
	private Integer daysBetween(String oldDate, String newDate)
			throws ParseException {
		if (oldDate == null || newDate == null) {
			return null;
		}

		Calendar cal = Calendar.getInstance();
		try {
			cal.setTime(sdf.parse(oldDate));
			long time1 = cal.getTimeInMillis();
			cal.setTime(sdf.parse(newDate));
			long time2 = cal.getTimeInMillis();
			long between_days = (time2 - time1) / (1000 * 3600 * 24);

			return (int) between_days;
		} catch (java.text.ParseException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * 变更推荐人
	 * @param resultNew
	 * @param preResult
	 * @param resultTmp
	 * @param todayDate
	 * @param force : 强制变更（这样就能忽略认领条件了，即使被认领了也可以被变更）
	 */
	private void changeRMDInfo(Map<String, String> resultNew, Map<String, String> preResult, Map<String, String> resultTmp, String todayDate, Boolean force){
		if(resultTmp != null && (mapIsNull(preResult) 
						|| (force != null && force == true && !mapIsNull(preResult) ) //忽略认领条件
							
						|| ( !mapIsNull(preResult) && !preResult.get(RST_RECMD_UPDATE_STATUS).equalsIgnoreCase(STATUS_CLAIM) 
								&& !preResult.get(RST_RECMD_UPDATE_STATUS).equalsIgnoreCase(STATUS_INIT_CLAIM) )
					)
			){//说明推荐人有变化，且之前没被认领过
			Map<String, String> tmp = new HashMap<String, String>();
			tmp.putAll(resultTmp);
			if(resultTmp.get(RST_RECMD) != null && StringUtil.isEmpty(resultTmp.get(RST_RECMD)) ){
				tmp = null;
			}
			fillRMDInfo(resultNew, preResult, tmp);
			
			resultNew.put(RST_RECMD_UPDATE_STATUS, STATUS_CHG_REF);//变更推荐人
			if(!mapIsNull(preResult)){
				resultNew.put(RST_ADD_DATE, preResult.get(RST_ADD_DATE));
			}else{
				resultNew.put(RST_ADD_DATE, todayDate);
			}
			resultNew.put(RST_UPDATE_DATE, todayDate);
			
		}else{//保持原有数据
			fillPreInfo(resultNew, preResult);
		}
	}
	
	/**
	 * 填充空的推荐人信息
	 * @param resultNew
	 */
	private void fillVoidRMDInfo(Map<String, String> resultNew){
		resultNew.put(RST_RECMD_INIT, null);
		resultNew.put(RST_RECMD, null);
		resultNew.put(RST_RECMD_TYPE, null);
		resultNew.put(RST_RECMD_ZY, null);
		resultNew.put(RST_STAFF_STATUS, null);
	}
	
	private void fillPreInfo(Map<String, String> resultNew, Map<String, String> preResult){
		if(!mapIsNull(preResult)){
			resultNew.put(RST_RECMD_UPDATE_STATUS, preResult.get(RST_RECMD_UPDATE_STATUS));
			resultNew.put(RST_ADD_DATE, preResult.get(RST_ADD_DATE));
			resultNew.put(RST_UPDATE_DATE, preResult.get(RST_UPDATE_DATE));
			resultNew.put(RST_RECMD_INIT, preResult.get(RST_RECMD_INIT));
			resultNew.put(RST_RECMD, preResult.get(RST_RECMD));
			resultNew.put(RST_RECMD_TYPE, preResult.get(RST_RECMD_TYPE));
			resultNew.put(RST_RECMD_ZY, preResult.get(RST_RECMD_ZY));
			resultNew.put(RST_STAFF_STATUS, preResult.get(RST_STAFF_STATUS));
		}else{//异常数据
			resultNew.put(RST_RECMD_UPDATE_STATUS, null);
			resultNew.put(RST_ADD_DATE, null);
			resultNew.put(RST_UPDATE_DATE, null);
			resultNew.put(RST_RECMD_INIT, null);
			resultNew.put(RST_RECMD, null);
			resultNew.put(RST_RECMD_TYPE, null);
			resultNew.put(RST_RECMD_ZY, null);
			resultNew.put(RST_STAFF_STATUS, null);
		}
	}
	
	private void fillRMDInfo(Map<String, String> resultNew, Map<String, String> preResult, Map<String, String> resultTmp){
		if(resultTmp != null){
			resultNew.putAll(resultTmp);
		}else if(resultTmp == null && !mapIsNull(preResult)){//如果新的数据没有的话，为了不改变之前的数据，就用旧数据填充
			resultNew.put(RST_RECMD_INIT, preResult.get(RST_RECMD_INIT));
			resultNew.put(RST_RECMD, preResult.get(RST_RECMD));
			resultNew.put(RST_RECMD_TYPE, preResult.get(RST_RECMD_TYPE));
			resultNew.put(RST_RECMD_ZY, preResult.get(RST_RECMD_ZY));
			resultNew.put(RST_STAFF_STATUS, preResult.get(RST_STAFF_STATUS));
		}else{
			fillVoidRMDInfo(resultNew);
		}
	}
	
	/**
	 * 填充认领数据
	 * @param resultNew
	 * @param claimResult
	 * @param preResult
	 * @param todayDate
	 */
	private void fillClaimInfo(Map<String, String> resultNew, Map<String, String> claimResult, Map<String, String> preResult, String todayDate){
		if(!mapIsNull(preResult) && preResult.get(RST_RECMD_UPDATE_STATUS) != null 
				&& preResult.get(RST_RECMD_UPDATE_STATUS).equalsIgnoreCase(STATUS_CUST_INIT)){//说明被初始化过了
			resultNew.put(RST_RECMD_UPDATE_STATUS, STATUS_INIT_CLAIM);
			resultNew.put(RST_ADD_DATE, preResult.get(RST_ADD_DATE));
		}else if(!mapIsNull(preResult)){//说明没有被初始化过
			resultNew.put(RST_RECMD_UPDATE_STATUS, STATUS_CLAIM);
			resultNew.put(RST_ADD_DATE, preResult.get(RST_ADD_DATE));
		}else{//新增的，又被认领了
			resultNew.put(RST_RECMD_UPDATE_STATUS, STATUS_CLAIM);
			resultNew.put(RST_ADD_DATE, todayDate);
		}
		resultNew.put(RST_UPDATE_DATE, todayDate);
		resultNew.put(RST_RECMD_INIT, null);
		resultNew.put(RST_RECMD, claimResult.get(RL_RECMD));
		resultNew.put(RST_RECMD_TYPE, claimResult.get(RL_RECMD_TYPE));
		resultNew.put(RST_RECMD_ZY, null);
		resultNew.put(RST_STAFF_STATUS, null);
	}
	
	/**
	 * 填充异常数据
	 * @param resultNew
	 */
	private void fillExceptionInfo(Map<String, String> resultNew, Map<String, String> preResult, String todayDate){
		if(!mapIsNull(preResult)){
			resultNew.put(RST_RECMD_UPDATE_STATUS, null);
			resultNew.put(RST_ADD_DATE, preResult.get(RST_ADD_DATE));
			resultNew.put(RST_UPDATE_DATE, todayDate);
			resultNew.put(RST_RECMD_INIT, preResult.get(RST_RECMD_INIT));
			resultNew.put(RST_RECMD, preResult.get(RST_RECMD));
			resultNew.put(RST_RECMD_TYPE, preResult.get(RST_RECMD_TYPE));
			resultNew.put(RST_RECMD_ZY, preResult.get(RST_RECMD_ZY));
			resultNew.put(RST_STAFF_STATUS, preResult.get(RST_STAFF_STATUS));
		}else{
			resultNew.put(RST_RECMD_UPDATE_STATUS, null);
			resultNew.put(RST_ADD_DATE, todayDate);
			resultNew.put(RST_UPDATE_DATE, todayDate);
			resultNew.put(RST_RECMD_INIT, null);
			resultNew.put(RST_RECMD, null);
			resultNew.put(RST_RECMD_TYPE, null);
			resultNew.put(RST_RECMD_ZY, null);
			resultNew.put(RST_STAFF_STATUS, null);
		}
	}
	
	/**
	 * 保护期内的数据匹配
	 */
	private void autoMatchInSafe(Map<String, String> params, Map<String, String> claimResult, Map<String, String> preResult, Map<String, String> resultNew, String todayDate){
		Integer custOpenDate = convertInteger(params.get(CUST_OPEN_DATE));// 资金户开户日期
		Integer ommOpenDate = convertInteger(params.get(OMM_OPEN_DATE));// 理财户开户日期
		Integer ommSumTsdDate = convertInteger(params.get(OMM_SUM_TSD_DATE));// 理财户净入金满足要求的日期
		Integer exctDate = convertInteger(todayDate);// 执行日期
		if(!mapIsNull(claimResult)){//说明被认领了(保护期内“认领优先”)
			fillClaimInfo(resultNew, claimResult, preResult, todayDate);
			return;
		}
		if(!mapIsNull(preResult) && (preResult.get(RST_RECMD_UPDATE_STATUS).equalsIgnoreCase(STATUS_CUST_INIT) 
				|| preResult.get(RST_RECMD_UPDATE_STATUS).equalsIgnoreCase(STATUS_INIT_CLAIM)
				|| preResult.get(RST_RECMD_UPDATE_STATUS).equalsIgnoreCase(STATUS_CLAIM))){//说明之前的记录被认领过，就不能调整了，因为“认领优先”
			//保持原有数据
			fillPreInfo(resultNew, preResult);
			return;
		}
		if(custOpenDate != null && 
				(ommOpenDate == null || (ommOpenDate != null && custOpenDate <= ommOpenDate)) ){//理财户为空，或，资金户在理财户之前开的。就用资金推荐人
			if(ommOpenDate == null){//理财户为空，纯资金账户
				if(mapIsNull(preResult) && custOpenDate.equals(exctDate)){//说明是当天开的资金户
					resultNew.put(RST_RECMD_UPDATE_STATUS, STATUS_NEW_CUST);
					resultNew.put(RST_ADD_DATE, todayDate);
					resultNew.put(RST_UPDATE_DATE, todayDate);
					Map<String, String> resultTmp = resultMap.get(CUST_RESULT_NO);
					fillRMDInfo(resultNew, preResult, resultTmp);
				}else if(!mapIsNull(preResult)){ //是初始化之后、当天之前开的，就不变
					fillPreInfo(resultNew, preResult);
				}else{ //异常数据
					fillExceptionInfo(resultNew, preResult, todayDate);
				}
			}else{//资金户在理财户之前开的
				if(!mapIsNull(preResult) && preResult.get(RST_RECMD_UPDATE_STATUS) != null 
						&& preResult.get(RST_RECMD_UPDATE_STATUS).equalsIgnoreCase(STATUS_CUST_INIT)){//说明被初始化过了。说明只能被认领
					fillPreInfo(resultNew, preResult);
				}else if(ommOpenDate != null && custOpenDate <= ommOpenDate){ //说明没有被初始化，且资金户在理财户之前开的
					if(exctDate.equals(custOpenDate)){//说明是新增用户
						resultNew.put(RST_RECMD_UPDATE_STATUS, STATUS_NEW_CUST);
						resultNew.put(RST_ADD_DATE, todayDate);
						resultNew.put(RST_UPDATE_DATE, todayDate);
						Map<String, String> resultTmp = resultMap.get(CUST_RESULT_NO);
						fillRMDInfo(resultNew, preResult, resultTmp);
					}else if(!mapIsNull(preResult)){//说明是旧数据，不用处理
						fillPreInfo(resultNew, preResult);
					}else{//异常数据
						fillExceptionInfo(resultNew, preResult, todayDate);
					}
				}else{//异常数据
					fillExceptionInfo(resultNew, preResult, todayDate);
				}
			}
		}else if(ommOpenDate != null){//理财用户，要走新规判断
			if(exctDate.equals(ommOpenDate)){//说明是新增用户
				resultNew.put(RST_RECMD_UPDATE_STATUS, STATUS_NEW_CUST);
				resultNew.put(RST_ADD_DATE, todayDate);
				resultNew.put(RST_UPDATE_DATE, todayDate);
			}
			if(ommSumTsdDate != null){//完成了千元净入金
				if(!mapIsNull(preResult) && (preResult.get(RST_RECMD_UPDATE_STATUS).equalsIgnoreCase(STATUS_CUST_INIT) 
						|| preResult.get(RST_RECMD_UPDATE_STATUS).equalsIgnoreCase(STATUS_INIT_CLAIM)
						|| preResult.get(RST_RECMD_UPDATE_STATUS).equalsIgnoreCase(STATUS_CLAIM))){//说明被认领过，就不能调整了，因为“认领优先”
					//保持原有数据
					fillPreInfo(resultNew, preResult);
				}else {
					if(custOpenDate == null){//未开资金户
						if(ommSumTsdDate.equals(exctDate)){//当天完成的千元入金
							Map<String, String> resultTmp = resultMap.get(OMM_RESULT_NO);
							changeRMDInfo(resultNew, preResult, resultTmp, todayDate, false);
						}else{
							//保持原有数据
							fillPreInfo(resultNew, preResult);
						}
					}else{
						if(ommSumTsdDate < custOpenDate && custOpenDate.equals(exctDate)){//当天开的资金户，且先千元入金再开资金户
							Map<String, String> resultTmp = resultMap.get(OMM_RESULT_NO);
							changeRMDInfo(resultNew, preResult, resultTmp, todayDate, false);
						}else if(ommSumTsdDate >= custOpenDate && ommSumTsdDate.equals(exctDate)){//当天完成的千元入金，且先开资金户再千元入金
							Map<String, String> resultTmp = resultMap.get(CUST_RESULT_NO);
							changeRMDInfo(resultNew, preResult, resultTmp, todayDate, false);
						}else{
							//保持原有数据
							fillPreInfo(resultNew, preResult);
						}
					}
				}
			}else{//未完成千元净入金			
				
				if(custOpenDate != null){//开了资金户，可以挂开发关系，取资金开户推荐人
					Map<String, String> resultTmp = resultMap.get(CUST_RESULT_NO);
					changeRMDInfo(resultNew, preResult, resultTmp, todayDate, false);
				}else{//没开资金户
					
					if(!mapIsNull(preResult)){//前一日的数据存在
						
						Integer ommFrtTrdDate = convertInteger(resultNew.get(RST_OMM_FIRST_INCOME_DT));// 理财户首入金日期
						if( ommFrtTrdDate != null && ommFrtTrdDate.equals(exctDate)){//完成首入金，算有效户。且是当日入金的，则要挂考核营业部
							resultNew.put(RST_RECMD_INIT, null);
							resultNew.put(RST_RECMD, null);
							resultNew.put(RST_RECMD_TYPE, null);
							resultNew.put(RST_RECMD_ZY, null);
							resultNew.put(RST_STAFF_STATUS, null);
							resultNew.put(RST_ADD_DATE, preResult.get(RST_ADD_DATE));
							resultNew.put(RST_UPDATE_DATE, todayDate);
							resultNew.put(RST_RECMD_UPDATE_STATUS, STATUS_CHG_DEPT);
						}else{
							//保持原有数据
							fillPreInfo(resultNew, preResult);
						}
					}else{//新客户
						resultNew.put(RST_RECMD_INIT, null);
						resultNew.put(RST_RECMD, null);
						resultNew.put(RST_RECMD_TYPE, null);
						resultNew.put(RST_RECMD_ZY, null);
						resultNew.put(RST_STAFF_STATUS, null);
						resultNew.put(RST_ADD_DATE, todayDate);
						resultNew.put(RST_UPDATE_DATE, todayDate);
						if( StringUtil.isEmpty(resultNew.get(RST_OMM_FIRST_INCOME_DT)) ){//没有完成首入金，不算有效户，则不能挂考核营业部
							resultNew.put(RST_RECMD_UPDATE_STATUS, STATUS_NEW_CUST);
						}else{
							resultNew.put(RST_RECMD_UPDATE_STATUS, STATUS_CHG_DEPT);
						}
					}
				}

			}
		}else{//异常数据
			fillExceptionInfo(resultNew, preResult, todayDate);
		}
	}
	
	
	
	private void autoMatchInSafeInit(Map<String, String> params, Map<String, String> claimResult, Map<String, String> preResult, Map<String, String> resultNew, String todayDate){
		Integer custOpenDate = convertInteger(params.get(CUST_OPEN_DATE));// 资金户开户日期
		Integer ommOpenDate = convertInteger(params.get(OMM_OPEN_DATE));// 理财户开户日期
		Integer ommSumTsdDate = convertInteger(params.get(OMM_SUM_TSD_DATE));// 理财户净入金满足要求的日期
		Integer exctDate = convertInteger(todayDate);// 执行日期
		Integer ommFrtTrdDate = convertInteger(resultNew.get(RST_OMM_FIRST_INCOME_DT));// 理财户首入金日期
		
		if(!mapIsNull(claimResult)){//说明被认领了(保护期内“认领优先”)
			fillClaimInfo(resultNew, claimResult, preResult, todayDate);
			return;
		}
		if(!mapIsNull(preResult) && !StringUtil.isEmpty(preResult.get(RST_RECMD)) ){//如果之前已经挂了关系了，则要保持
			fillPreInfo(resultNew, preResult);
			return;
		}
		if(mapIsNull(preResult)){//说明是新初始化的客户
			resultNew.put(RST_RECMD_UPDATE_STATUS, STATUS_OMM_INIT);
			resultNew.put(RST_ADD_DATE, todayDate);
		}else{
			resultNew.put(RST_RECMD_UPDATE_STATUS, preResult.get(RST_RECMD_UPDATE_STATUS));
			resultNew.put(RST_ADD_DATE, preResult.get(RST_ADD_DATE));
		}
		resultNew.put(RST_UPDATE_DATE, todayDate);
		
		Map<String, String> resultTmp = null;
		if(custOpenDate != null && 
				(ommOpenDate == null || (ommOpenDate != null && custOpenDate <= ommOpenDate)) ){//理财户为空，或，资金户在理财户之前开的
			resultTmp = resultMap.get(CUST_RESULT_NO);
			resultNew.putAll(resultTmp);
		}else if(ommOpenDate != null){//纯理财用户，或者，理财户在资金户前面开的，要走新规判断

			if(ommSumTsdDate != null){//完成了千元净入金
				
				if(custOpenDate == null){//未开资金户
					resultTmp = resultMap.get(OMM_RESULT_NO);
					resultNew.putAll(resultTmp);
				}else{
					if(ommSumTsdDate < custOpenDate){//先千元入金再开资金户
						resultTmp = resultMap.get(OMM_RESULT_NO);
						resultNew.putAll(resultTmp);
					}else if(ommSumTsdDate >= custOpenDate){//先开资金户再千元入金
						resultTmp = resultMap.get(CUST_RESULT_NO);
						resultNew.putAll(resultTmp);
					}
				}

			}else{//未完成千元净入金		
				
				if(custOpenDate != null){//开了资金户，可以挂开发关系，取资金开户推荐人
					resultTmp = resultMap.get(CUST_RESULT_NO);
					resultNew.putAll(resultTmp);
				}else{//没开资金户
					
					resultNew.put(RST_RECMD_INIT, null);
					resultNew.put(RST_RECMD, null);
					resultNew.put(RST_RECMD_TYPE, null);
					resultNew.put(RST_RECMD_ZY, null);
					resultNew.put(RST_STAFF_STATUS, null);
					
					if( ommFrtTrdDate != null){//完成首入金，算有效户。要挂考核营业部
						resultNew.put(RST_RECMD_UPDATE_STATUS, STATUS_CHG_DEPT);
					}
				}

			}
		}else{//异常数据
			fillExceptionInfo(resultNew, preResult, todayDate);
		}
	}
	
	
	
	private boolean mapIsNull(Map<String, String> mp){
		boolean result = false;
		if(mp == null || !mp.containsKey("cust_code") || mp.get("cust_code") == null || StringUtil.isEmpty(mp.get("cust_code")) ){
			result = true;
		}
		return result;
	}
	
	/**
	 * 校验原始数据的正确性
	 * @param params
	 * @param preResult
	 * @param today
	 */
	private void cleanOriginInfo(Map<String, String> params, Map<String, String> preResult, Integer today){
		if(today == null){
			return;
		}
		if(!mapIsNull(params)){
			Integer custOpenDate = convertInteger(params.get(CUST_OPEN_DATE));// 资金户开户日期
			Integer ommOpenDate = convertInteger(params.get(OMM_OPEN_DATE));// 理财户开户日期
			Integer ommFrtTrdDate = convertInteger(params.get(OMM_FST_TRD_DATE));// 理财首次购买日期
			Integer ommFrtRcgDate = convertInteger(params.get(OMM_FST_RCD_DATE));// 理财首次充值日期
			Integer ommSumTsdDate = convertInteger(params.get(OMM_SUM_TSD_DATE));// 理财千元净入金日期
			
			if(custOpenDate == null || custOpenDate > today){
				params.put(CUST_OPEN_DATE,"");
				params.put(CUST_OPEN_RCMD_INIT,"");
				params.put(CUST_OPEN_RCMD,"");
				params.put(CUST_OPEN_RCMD_TYPE,"");
				params.put(CUST_OPEN_RCMD_ZY,"");
				params.put(CUST_OPEN_RCMD_STATUS,"");
			}
			if(ommOpenDate == null || ommOpenDate > today){
				params.put(OMM_OPEN_DATE,"");
				params.put(OMM_OPEN_RCMD_INIT,"");
				params.put(OMM_OPEN_RCMD,"");
				params.put(OMM_OPEN_RCMD_TYPE,"");
				params.put(OMM_OPEN_RCMD_ZY,"");
				params.put(OMM_OPEN_RCMD_STATUS,"");
			}
			if(ommFrtTrdDate == null || ommFrtTrdDate > today){
				params.put(OMM_FST_TRD_DATE,"");
				params.put(OMM_FST_TRD_RCMD_INIT,"");
				params.put(OMM_FST_TRD_RCMD,"");
				params.put(OMM_FST_TRD_RCMD_TYPE,"");
				params.put(OMM_FST_TRD_RCMD_ZY,"");
				params.put(OMM_FST_TRD_RCMD_STATUS,"");
			}
			if(ommFrtRcgDate == null || ommFrtRcgDate > today){
				params.put(OMM_FST_RCD_DATE,"");
				params.put(OMM_FST_RCD_RCMD_INIT,"");
				params.put(OMM_FST_RCD_RCMD,"");
				params.put(OMM_FST_RCD_RCMD_TYPE,"");
				params.put(OMM_FST_RCD_RCMD_ZY,"");
				params.put(OMM_FST_RCD_RCMD_STATUS,"");
			}
			if(ommSumTsdDate == null || ommSumTsdDate > today){
				params.put(OMM_SUM_TSD_DATE,"");
			}
		}
		if(!mapIsNull(preResult)){
			Integer custOpenDate = convertInteger(preResult.get(RST_CUST_OPEN_DT));// 资金户开户日期
			Integer ommOpenDate = convertInteger(preResult.get(RST_OMM_OPEN_DT));// 理财户开户日期
			Integer ommFrtDate = convertInteger(preResult.get(RST_OMM_FIRST_INCOME_DT));// 理财首次入金日期
			Integer ommSumTsdDate = convertInteger(preResult.get(RST_OMM_TOTAL_INCOME_DT));// 理财千元净入金日期
			Integer addDate = convertInteger(preResult.get(RST_ADD_DATE));// 添加日期
			Integer updateDate = convertInteger(preResult.get(RST_UPDATE_DATE));// 修改日期
			
			if( (custOpenDate != null && custOpenDate > today)
					|| (ommOpenDate != null && ommOpenDate > today)
					|| (ommFrtDate != null && ommFrtDate > today)
					|| (ommSumTsdDate != null && ommSumTsdDate > today)
					|| (addDate != null && addDate > today)
					|| (updateDate != null && updateDate > today)
				)
				preResult = new HashMap<String,String>();
		}
	}
	
	public Map<String, String> evaluate(Map<String, String> params, String historyDate)
			throws ParseException, HiveException, IOException, java.text.ParseException {
		Map<String, String> result = new HashMap<String, String>();
		
		String today_str="";
		if(historyDate != null && !historyDate.trim().equals("")){
			today_str = historyDate;
		}else{
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DATE, -1);//因为计算都是取T-1的数据
		    today_str = sdf.format(cal.getTime());
		}
		
	    Integer today = convertInteger(today_str);// 当天的日期
	    //清理无效数据
	    cleanOriginInfo(params, null, today);
		
		initBasicInfo(params, result);
		return result;
	}

	public Map<String, String> evaluate(Map<String, String> params,
			Map<String, String> claimResult, Map<String, String> preResult, String historyDate, String initFlag)
			throws ParseException, HiveException, IOException, java.text.ParseException {
		Map<String, String> result = new HashMap<String, String>();
		
		boolean init_flag = false;
		if(initFlag != null && (initFlag.trim().equals("1") || initFlag.trim().equalsIgnoreCase("true"))){
			init_flag = true;
		}
		
		String today_str="";
		if(historyDate != null && !historyDate.trim().equals("")){
			today_str = historyDate;
		}else{
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DATE, -1);//因为计算都是取T-1的数据
		    today_str = sdf.format(cal.getTime());
		}
		
	    Integer today = convertInteger(today_str);// 当天的日期
	    //清理无效数据
	    cleanOriginInfo(params, preResult, today);
	    
		Integer custOpenDate = convertInteger(params.get(CUST_OPEN_DATE));// 资金户开户日期
		Integer ommOpenDate = convertInteger(params.get(OMM_OPEN_DATE));// 理财户开户日期

		//理财户开户与当天的时间间隔，用于判断是否过了保护期
		Integer realSafeDays = null;
		if(ommOpenDate != null){
			realSafeDays = daysBetween(params.get(OMM_OPEN_DATE), today_str);
		}
		
		initBasicInfo(params, result);
		
		result.put(RST_RECMD_UPDATE_STATUS, null);// 初始化“推荐人变更状态”
		result.put(RST_ADD_DATE, null);// 初始化“记录新增日期”
		result.put(RST_UPDATE_DATE, null);// 初始化“记录修改日期”
		
		if(init_flag){//首次初始化
			if(custOpenDate != null){//只要开了资金户，就用原始信息，状态置为“-1”	
				result.put(RST_RECMD_UPDATE_STATUS, STATUS_CUST_INIT);
				result.put(RST_ADD_DATE, today_str);
				result.put(RST_UPDATE_DATE, today_str);
				result.put(RST_RECMD_INIT, null);
				if(!mapIsNull(preResult)){
					result.put(RST_RECMD, preResult.get(RST_RECMD));
					result.put(RST_RECMD_TYPE, preResult.get(RST_RECMD_TYPE));
				}else{
					result.put(RST_RECMD, null);
					result.put(RST_RECMD_TYPE, null);
				}
				result.put(RST_RECMD_ZY, null);
				result.put(RST_STAFF_STATUS, null);
				
			}else if(ommOpenDate != null && custOpenDate == null){//纯理财户，对于30天之内的数据要初始化（有关系的就当认领过的），超过30天就不处理了
				if(!mapIsNull(preResult) && !StringUtil.isEmpty(preResult.get(RST_RECMD)) ){//说明之前被认领过，就用认领过的关系
					result.put(RST_RECMD_UPDATE_STATUS, STATUS_CLAIM);
					result.put(RST_ADD_DATE, today_str);
					result.put(RST_UPDATE_DATE, today_str);
					result.put(RST_RECMD_INIT, null);
					result.put(RST_RECMD, preResult.get(RST_RECMD));
					result.put(RST_RECMD_TYPE, preResult.get(RST_RECMD_TYPE));
					result.put(RST_RECMD_ZY, null);
					result.put(RST_STAFF_STATUS, null);
				}else{
					if(realSafeDays <= PROTECT_DAYS){//在保护期内，按新规处理
						autoMatchInSafeInit(params, claimResult, preResult, result, today_str);
					}else{//超过保护期了、且没被认领过，则不能推送到OCRM
						//为了不让OCRM去更新考核营业部信息,把首入金的信息都置为空
						result.put(RST_OMM_FIRST_INCOME_DT, null);
						result.put(RST_OMM_FIRST_INCOME_RECMD_INIT, null);
						result.put(RST_OMM_FIRST_INCOME_RECMD, null);
						result.put(RST_OMM_FIRST_INCOME_RECMD_TYPE, null);
						//为了不推送到OCRM
						result.put(RST_RECMD_UPDATE_STATUS, STATUS_CLAIM);
						result.put(RST_ADD_DATE, today_str);
						result.put(RST_UPDATE_DATE, today_str);
						result.put(RST_RECMD_INIT, null);
						if(!mapIsNull(preResult)){
							result.put(RST_RECMD, preResult.get(RST_RECMD));
							result.put(RST_RECMD_TYPE, preResult.get(RST_RECMD_TYPE));
						}else{
							result.put(RST_RECMD, null);
							result.put(RST_RECMD_TYPE, null);
						}
						result.put(RST_RECMD_ZY, null);
						result.put(RST_STAFF_STATUS, null);
					}
				}
			}else{
				if(claimResult != null){
					fillPreInfo(result, preResult);
				}else if(preResult != null){
					fillPreInfo(result, preResult);
				}else{ //异常数据
					fillExceptionInfo(result, preResult, today_str);
				}
			}
		}else{//正常运行
			if(ommOpenDate == null || (ommOpenDate != null && realSafeDays <= PROTECT_DAYS)){//在保护期内，或者，没开理财户，按新规处理
				autoMatchInSafe(params, claimResult, preResult, result, today_str);
			}else{//超过保护期了
				if(custOpenDate != null && custOpenDate.equals(today)){//没开资金户的开了资金户，关联资金户推荐人（过了保护期，这个关系比认领要优先）
					Map<String, String> resultTmp = resultMap.get(CUST_RESULT_NO);
					changeRMDInfo(result, preResult, resultTmp, today_str, true);
				}else if(!mapIsNull(claimResult)){//认领
					fillClaimInfo(result, claimResult, preResult, today_str);
				}else{//不变
					fillPreInfo(result, preResult);
				}
			}
		}
		return result;
	}

	public static void main(String[] argc) throws Exception {

		OCRMRefer rf = new OCRMRefer();
		
		Map<String, String> params = new HashMap<String, String>();
		params.put("cust_code", "18512345");
		params.put("cust_open_date", "20160902");
		params.put("cust_rmd_init", "123");
		params.put("cust_rmd_ygbh", "123");
		params.put("cust_rmd_type", "1");
		params.put("cust_ygbh", "");
		params.put("cust_ygbh_valid", "");
		params.put("omm_open_date", "20160902");
		params.put("omm_rmd_init", "1111");
		params.put("omm_rmd_ygbh", "1234");
		params.put("omm_rmd_type", "1");
		params.put("omm_ygbh", "");
		params.put("omm_ygbh_valid", "2");
		params.put("omm_first_trd_date", "20160904");
		params.put("omm_first_trd_rcmd_init", "2222");
		params.put("omm_first_trd_rcmd_ygbh", "4321");
		params.put("omm_first_trd_rcmd_type", "2");
		params.put("omm_first_trd_ygbh", "22");
		params.put("omm_first_trd_valid", "1");
		params.put("omm_first_recharge_date", "");
		params.put("omm_first_recharge_rcmd_init", "");
		params.put("omm_first_recharge_rcmd_ygbh", "");
		params.put("omm_first_recharge_rcmd_type", "");
		params.put("omm_first_recharge_ygbh", "");
		params.put("omm_first_recharge_valid", "");
		params.put("omm_sum_1000_date", "20160912");
		
		String historyDate = null;
		
/*		Map<String, String> claimResult = new HashMap<String, String>();
		claimResult.put("cust_code", "");
		claimResult.put("recmd", "");
		claimResult.put("recmd_type", "");
		
		Map<String, String> preResult = new HashMap<String, String>();
		preResult.put("cust_code", "18512345");
		preResult.put("cust_open_dt", "");
		preResult.put("cust_open_recmd_init", "2222");
		preResult.put("cust_open_recmd", "4321");
		preResult.put("cust_open_recmd_type", "2");
		
		preResult.put("omm_open_dt", "20160902");
		
		preResult.put("omm_first_income_dt", "20160904");
		preResult.put("omm_first_income_recmd_init", "2222");
		preResult.put("omm_first_income_recmd", "4321");
		preResult.put("omm_first_income_recmd_type", "2");
		preResult.put("omm_total_income_dt", "");
		preResult.put("recmd_init", "");
		preResult.put("recmd", "11112");
		preResult.put("recmd_type", "11");
		preResult.put("recmd_zy", "");
		preResult.put("staff_status", "");
		preResult.put("recmd_update_status", "2");
		preResult.put("add_date", "20160902");
		preResult.put("update_date", "20160905");
		
		
		String initFlag = null;
		rf.evaluate(params, claimResult, preResult, historyDate, initFlag);*/
		rf.evaluate(params, historyDate);
	}
}