package com.paic.data.hive.common.udf.template.node;

import java.util.Collection;

import com.paic.data.hive.common.udf.template.TNode;
import com.paic.data.hive.common.udf.template.TPushData;
import com.paic.data.hive.common.udf.template.TUserData;


public class TFixNode extends TNode {

	private final String text;
	
	public TFixNode(String text) {
		this.text = text;
	}

	@Override
	public void params(Collection<String> params) {
		
	}

	@Override
	public void toString(StringBuffer output, String channel, TUserData userData, TPushData pushData) {
		output.append(text);
	}
	
	public String toString(String channel, TUserData userData, TPushData pushData) {
		return text;
	}
	
	@Override
	public String toString() {
		return text;
	}
}
