package com.paic.data.hive.common.udf.template;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.paic.data.hive.common.udf.template.node.TFixNode;
import com.paic.data.hive.common.udf.template.node.TListNode;
import com.paic.data.hive.common.udf.template.node.TParamNode;
import com.paic.data.hive.common.udf.template.node.TSellUrlNode;
import com.paic.data.hive.common.udf.template.node.TTextNode;
import com.paic.data.hive.common.udf.template.node.TVarNode;
import com.paic.data.hive.common.udf.template.node.func.TDateFuncNode;
import com.paic.data.hive.common.udf.template.node.func.TIfFuncNode;
import com.paic.data.hive.common.udf.template.node.func.TShortFuncNode;
import com.paic.data.hive.common.udf.template.node.func.TSubstrFuncNode;




public class TParser {

	private static class Cursor {
		public final char[] input;
		public int offset;
		public Cursor(char[] input) {
			this.input = input;
			this.offset = 0;
		}
		public boolean EOF() {
			return offset >= input.length;
		}
		public char curr() {
			return input[offset];
		}
		public char prev() {
			return input[offset-1];
		}
	}

	private Map<String, Map<Integer, Constructor<?>>> funcNodeConstructors = new HashMap<String, Map<Integer, Constructor<?>>>();

	public void loadFuncNodeClass(String name, Class<?> clazz) {
		Map<Integer, Constructor<?>> constructors = new HashMap<Integer, Constructor<?>>();
		for (Constructor<?> constructor : clazz.getConstructors()) {
			boolean check = true;
			for (Class<?> pc : constructor.getParameterTypes()) {
				if (pc.equals(TNode.class) == false) {
					check = false;
					break;
				}
			}
			if (check) {
				constructors.put(constructor.getParameterTypes().length, constructor);
			}
		}
		funcNodeConstructors.put(name, constructors);
	}

	public List<TNode> parseTemplate(String template, TSellData sellData) {
		List<TNode> ret = new ArrayList<TNode>();
		if (template == null) return ret;
		Cursor cursor = new Cursor(template.toCharArray());
		int from = 0;
		while (cursor.EOF() == false) {
			if (cursor.curr() == '$') {
				if (from < cursor.offset) {
					ret.add(new TFixNode(new String(cursor.input, from, cursor.offset - from)));
				}
				ret.add(parseOutVar(cursor, ++cursor.offset, sellData));
				from = cursor.offset;
			} else {
				cursor.offset ++;
			}
		}
		if (from < cursor.offset) {
			ret.add(new TFixNode(new String(cursor.input, from, cursor.offset - from)));
		}
		return ret;
	}
	
	public TNode parseInputParam(String input, TSellData sellData) {
		if (input == null) return new TTextNode("");
		List<TNode> ret = new ArrayList<TNode>();
		Cursor cursor = new Cursor(input.toCharArray());
		int from = 0;
		while (cursor.EOF() == false) {
			if (cursor.curr() == '{') {
				if (cursor.offset > 0 && cursor.prev() == '#') {		// 内部变量：#{}
					if (from < cursor.offset-1) {
						ret.add(new TTextNode(new String(cursor.input, from, cursor.offset-1 - from)));
					}
					ret.add(parseInParam(cursor, ++cursor.offset));
					from = cursor.offset;
				} else {	// 函数解析：{funcName}
					int tempOffset = cursor.offset;
					TNode func = parseFunc(cursor, ++ cursor.offset, sellData);
					if (func != null) {
						if (from < tempOffset) {
							ret.add(new TTextNode(new String(cursor.input, from, tempOffset - from)));
						}
						ret.add(func);
						from = cursor.offset;
					}
				}
			} else {
				cursor.offset ++;
			}
		}
		if (ret.size() == 0) {
			return new TTextNode(input);
		} else if (from < cursor.offset) {
			ret.add(new TTextNode(new String(cursor.input, from, cursor.offset - from)));
		}
		return ret.size() == 1 ? ret.get(0) : new TListNode(ret);
	}

	// $$
	private TVarNode parseOutVar(Cursor cursor, int from, TSellData sellData) {
		TListNode ret = new TListNode();
		boolean fixed = cursor.input[from] == '=';
		while (cursor.EOF() == false) {
			if (cursor.curr() == '$') {		// 外部变量结束
				if (ret.size() == 0) {
					if (fixed) {
						return new TTextNode(new String(cursor.input, from+1, cursor.offset++ - from-1));
					} else {
						return new TParamNode(new String(cursor.input, from, cursor.offset++ - from));
					}
				} else if (from < cursor.offset) {
					ret.add(new TTextNode(new String(cursor.input, from, cursor.offset++ - from)));
				} else {
					cursor.offset++;
				}
				return ret.size() == 1 ? (TVarNode) (ret.nodes().get(0)) : ret;
			} else if (!fixed && cursor.curr() == '{') {
				if (cursor.prev() == '#') {		// 内部变量：#{}
					if (from < cursor.offset-1) {
						ret.add(new TTextNode(new String(cursor.input, from, cursor.offset-1 - from)));
					}
					ret.add(parseInParam(cursor, ++cursor.offset));
					from = cursor.offset;
				} else {	// 函数解析：{funcName}
					int tempOffset = cursor.offset;
					TNode func = parseFunc(cursor, ++ cursor.offset, sellData);
					if (func != null) {
						if (from < tempOffset) {
							ret.add(new TTextNode(new String(cursor.input, from, tempOffset - from)));
						}
						ret.add(func);
						from = cursor.offset;
					}
				}
			} else {
				cursor.offset ++;
			}
		}
		throw new IllegalArgumentException("Unexpected reach end! Not found '$'!");
	}

	// #{}
	private TParamNode parseInParam(Cursor cursor, int from) {
		TParamNode ret = null;
		while (cursor.EOF() == false) {
			if (cursor.curr() == '}') {
				ret = new TParamNode(new String(cursor.input, from, cursor.offset - from));
				cursor.offset ++;
				return ret;
			}
			cursor.offset++;
		}
		throw new IllegalArgumentException("Unexpected reach end! Not found '}'!");
	}

	// {funcName:}
	private TNode parseFunc(Cursor cursor, int from, TSellData sellData) {
		int to = -1;
		for (int i = from + 1; i < cursor.input.length; i ++) {
			if (cursor.input[i] == ':' || cursor.input[i] == '}') {
				to = i;
				break;
			}
		}
		if (to > 0) {
			cursor.offset = to+1;
			String name = new String(cursor.input, from, to - from);
			Map<Integer, Constructor<?>> constructors = funcNodeConstructors.get(name);
			if (constructors == null) {
				return null;
			}
			List<TNode> params = new ArrayList<>();
			while (cursor.prev() != '}') {
				TNode param = parseFuncParam(cursor, cursor.offset, sellData);
				param.trim();
				params.add(param);
			}
			Constructor<?> constructor = constructors.get(params.size());
			if (constructor == null) {
				throw new IllegalArgumentException(String.format("TFuncNode({}) hasn't {} arguments constructor!", name, params.size()));
			}
			try {
				if (sellData.isSellTemplate && name.equals("short")) {
					sellData.hasSellUrl = true;
					return new TShortFuncNode(new TSellUrlNode(params.get(0)));
				} else {
					return (TNode) constructor.newInstance(params.toArray());
				}
			} catch (Exception e) {
				throw new IllegalArgumentException(String.format("TFuncNode({}) new instance failed!", name));
			}
		}
		return null;
	}

	// {funcName:param1,param2}
	private TNode parseFuncParam(Cursor cursor, int from, TSellData sellData) {
		TListNode ret = new TListNode();
		while (cursor.EOF() == false) {
			char curr = cursor.curr();
			if (curr == '}' || curr == ',') {		// 参数结束
				if (ret.size() == 0) {
					return new TTextNode(new String(cursor.input, from, cursor.offset++ - from));
				} else if (from < cursor.offset) {
					ret.add(new TTextNode(new String(cursor.input, from, cursor.offset++ - from)));
				} else {
					cursor.offset ++;
				}
				return ret.size() == 1 ? ret.nodes().get(0) : ret;
			} else if (curr == '{') {
				if (cursor.prev() == '#') {		// 内部变量：#{}
					if (from < cursor.offset-1) {
						ret.add(new TTextNode(new String(cursor.input, from, cursor.offset-1 - from)));
					}
					ret.add(parseInParam(cursor, ++cursor.offset));
					from = cursor.offset;
				} else {	// 函数解析：{funcName}
					int tempOffset = cursor.offset;
					TNode func = parseFunc(cursor, ++ cursor.offset, sellData);
					if (func != null) {
						if (from < tempOffset) {
							ret.add(new TTextNode(new String(cursor.input, from, tempOffset - from)));
						}
						ret.add(func);
						from = cursor.offset;
					}
				}
			} else {
				cursor.offset ++;
			}
		}
		throw new IllegalArgumentException("Unexpected reach end! Not found '}'!");
	}
	
	

	public static void main(String[] args) throws Exception {
		TParser parser = new TParser();
		TSellData sellData = new TSellData();
		sellData.isSellTemplate = true;
		
		parser.loadFuncNodeClass("if", TIfFuncNode.class);
		parser.loadFuncNodeClass("date", TDateFuncNode.class);
		parser.loadFuncNodeClass("short", TShortFuncNode.class);
		parser.loadFuncNodeClass("substr", TSubstrFuncNode.class);
		
		List<TNode> nodes = parser.parseTemplate("您的客户$cust_namexx#{cust_name}xxx$，$order_time$赎回$ord_qty$份（市值$asset_amt$元）$fund_name$，资金预计在$into_account_date$可用。请知悉并及时做好客户维护工作。$remark$", sellData);
		Set<String> params = new HashSet<String>();
		for (TNode node : nodes) {
			node.params(params);
		}
		System.out.println(params);
		
		TUserData userData = new TUserData();
		userData.mobile = "mobile";
		userData.um = "um";
		userData.userCode = "uc";
		userData.userId = "ui";
		userData.params = new HashMap<String, String>();
		userData.params.put("3", "p3");
		userData.params.put("dt", "20161019");
		userData.inputs = new HashMap<String, Object>();
		userData.inputs.put("url", parser.parseInputParam("{short:http://hello.com/{date:#{dt},yyyyMMdd,yyyy-MM-dd}}", sellData));
		TPushData pushData = new TPushData();
		pushData.pushId = "pid";
		TListNode list = new TListNode(nodes);
		System.out.println(list.toString("sms", userData, pushData));
	}
}
