package com.paic.data.hive.common.udf;

import java.text.ParseException;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;

@Description(name = "remove_repeat", value = "_FUNC_(string...) - Returns a string with remove repeat item and join items with comma(,).")
public class RemoveRepeat extends UDF {
    public String evaluate(String... arr)  throws ParseException {
        if (arr==null || arr.length == 0){
            return null;
        }
        
        Set<String> set = new HashSet<String>();
        for (String s : arr){
            if (StringUtils.isNotEmpty(s)){
                set.add(s);
            }
        }
        
        return StringUtils.join(set, ",");
        
    }

}
