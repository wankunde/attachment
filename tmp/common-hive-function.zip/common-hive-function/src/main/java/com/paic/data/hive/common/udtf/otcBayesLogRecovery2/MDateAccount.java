package com.paic.data.hive.common.udtf.otcBayesLogRecovery2;

import com.paic.data.hive.common.udtf.otcBayesLogRecovery2.MDateAccount;

public class MDateAccount {
	 public String date;
	 public double mkt;
	 public double b;
	 public double s;
	 public double div;
	 public int[] moved={0,0};
	 public MDateAccount(String date,double mkt,double b,double s,double div,int[] moved){
	    	this.date=date;
	    	this.mkt=mkt;
	        this.b=b;
	        this.s=s;
	        this.div=div;
	        this.moved=moved;
	    }
	 
	 public static MDateAccount getAccount(String date,double mkt,double b,double s,double div,int[] moved){
		 MDateAccount account=new MDateAccount(date,mkt,b,s,div,moved);
			return account;		
		}
	 public int[] getMoved(){
		 return moved;
	 }
	 
	 @Override
	 public String toString() {
		 return String.format("date=%s,mkt=%.2f,b=%.2f,s=%.2f,div=%.2f,moved=%d", date,mkt,b,s,div,moved);
	 }
}
