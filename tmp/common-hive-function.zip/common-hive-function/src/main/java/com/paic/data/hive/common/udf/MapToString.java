package com.paic.data.hive.common.udf;

import java.util.Map;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;

@Description(name = "map_to_str", value = "_FUNC_(map) - Returns a string")
public class MapToString extends UDF {

	public String evaluate(Map<String, String> map) {
		String result = toString(map);
		return result;
	}

	private String toString(Map map) {
		StringBuilder sb = new StringBuilder();
		sb.append("{");
		for (Object key : map.keySet()) {
			sb.append("\"").append(key).append("\"").append(":").append("\"").append(map.get(key)).append("\"")
					.append(",");
		}

		return sb.substring(0, sb.length() - 1) + "}";
	}

}
