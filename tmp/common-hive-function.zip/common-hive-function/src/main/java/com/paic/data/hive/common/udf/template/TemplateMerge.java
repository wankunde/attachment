package com.paic.data.hive.common.udf.template;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;

import com.alibaba.fastjson.JSONObject;
import com.paic.data.hive.common.udf.template.node.TListNode;
import com.paic.data.hive.common.udf.template.node.func.TDateFuncNode;
import com.paic.data.hive.common.udf.template.node.func.TIfFuncNode;
import com.paic.data.hive.common.udf.template.node.func.TShortFuncNode;
import com.paic.data.hive.common.udf.template.node.func.TSubstrFuncNode;


@Description(name = "template_merge", value = "_FUNC_(params,content) - Returns a template_content")
public class TemplateMerge extends UDF{

	public String evaluate(String params,String  content) {
		if(params == null || params.length() < 0){
			return content;
		}
		if(content == null || content.length() < 0){
			return content;
		}
		TParser parser = new TParser();
		TSellData sellData = new TSellData();
		sellData.isSellTemplate = true;
		
		parser.loadFuncNodeClass("if", TIfFuncNode.class);
		parser.loadFuncNodeClass("date", TDateFuncNode.class);
		parser.loadFuncNodeClass("short", TShortFuncNode.class);
		parser.loadFuncNodeClass("substr", TSubstrFuncNode.class);
		
		List<TNode> nodes = parser.parseTemplate(content, sellData);
		Set<String> set = new HashSet<String>();
		for (TNode node : nodes) {
			node.params(set);
		}
		JSONObject object = JSONObject.parseObject(params);
		TPushData pushData = new TPushData();
		TUserData userData = new TUserData();
		userData.params = new HashMap<String, String>();
		for(String key : object.keySet() ){
			String objKey = key.toLowerCase();
			userData.params.put(objKey, object.getString(key));
		}
		userData.inputs = new HashMap<String, Object>();
		TListNode list = new TListNode(nodes);
		return list.toString(null, userData, pushData);
	}
	
}
