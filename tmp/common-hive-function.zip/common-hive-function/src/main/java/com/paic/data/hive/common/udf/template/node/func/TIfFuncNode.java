package com.paic.data.hive.common.udf.template.node.func;

import java.util.Collection;

import com.paic.data.hive.common.udf.template.TNode;
import com.paic.data.hive.common.udf.template.TPushData;
import com.paic.data.hive.common.udf.template.TUserData;
import com.paic.data.hive.common.udf.template.node.TFuncNode;


public class TIfFuncNode extends TFuncNode {
	
	private final TNode condition;
	private final TNode tvalue;
	private final TNode fvalue;
	
	public TIfFuncNode(TNode condition, TNode tvalue, TNode fvalue) {
		this.condition = condition;
		this.tvalue = tvalue;
		this.fvalue = fvalue;
	}

	@Override
	public void params(Collection<String> params) {
		condition.params(params);
		tvalue.params(params);
		fvalue.params(params);
	}

	@Override
	public void toString(StringBuffer output, String channel, TUserData userData, TPushData pushData) {
		String cond = condition.toString(channel, userData, pushData);
		Boolean ret = null;
		char[] data = cond.toCharArray();
		int from = 0;
		String left = null, right = null;
		for (int i = 0; i < data.length; i ++) {
			if (data[i] == '>' || data[i] == '=' || data[i] == '<' || data[i] == '!') {
				left = new String(data, from, i - from).trim();
				if (i+1 < data.length && data[i+1] == '=') {
					right = new String(data, i + 2, data.length - i - 2).trim();
					if (data[i] == '>') {
						ret = left.compareTo(right) >= 0;
					} else if (data[i] == '=') {
						ret = left.compareTo(right) == 0;
					} else if (data[i] == '<') {
						ret = left.compareTo(right) <= 0;
					} else if (data[i] == '!') {
						ret = left.compareTo(right) != 0;
					}
				} else {
					right = new String(data, i + 1, data.length - i - 1).trim();
					if (data[i] == '>') {
						ret = left.compareTo(right) > 0;
					} else if (data[i] == '=') {
						ret = left.compareTo(right) == 0;
					} else if (data[i] == '<') {
						ret = left.compareTo(right) < 0;
					}
				}
				break;
			}
		}
		if (ret == true) {
			tvalue.toString(output, channel, userData, pushData);
		} else if (ret == false) {
			fvalue.toString(output, channel, userData, pushData);
		}
	}

}
