package com.paic.data.hive.common.udf.template.node;

import com.paic.data.hive.common.udf.template.TNode;

public abstract class TVarNode extends TNode {

	// 原始参数名
	private String oname;
	private Integer oiname;

	public String getOname() {
		return oname;
	}

	public void setOname(String oname) {
		this.oname = oname;
		this.oiname = null;
	}

	public Integer getOiname() {
		if (oiname == null) {
			try {
				oiname = Integer.parseInt(oname);
			} catch (Exception e) {
				oiname = -1;
			}
		}
		return oiname;
	}
}
