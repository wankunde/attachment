package com.paic.data.hive.common.udf.bean;

/**
 * Created by wangyi422 on 2018/3/22.
 */
public class CipherTelReq {
    private String sysID;
    private String userID;
    private int type;
    private String plainText;
    private long timestamp;

    public CipherTelReq(String sysID, String userID, int type, String plainText, long timestamp) {
        this.sysID = sysID;
        this.userID = userID;
        this.type = type;
        this.plainText = plainText;
        this.timestamp = timestamp;
    }

    public String getSysID() {
        return sysID;
    }

    public String getUserID() {
        return userID;
    }

    public int getType() {
        return type;
    }

    public String getPlainText() {
        return plainText;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setSysID(String sysID) {
        this.sysID = sysID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public void setType(int type) {
        this.type = type;
    }

    public void setPlainText(String plainText) {
        this.plainText = plainText;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
}
