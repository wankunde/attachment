package com.paic.data.hive.common.udf.profite;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.hive.common.type.HiveDecimal;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.parse.SemanticException;
import org.apache.hadoop.hive.ql.udf.generic.AbstractGenericUDAFResolver;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDAFEvaluator;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDAFParameterInfo;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.PrimitiveObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.StandardListObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.StructField;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorUtils;
import org.apache.hadoop.hive.serde2.typeinfo.TypeInfo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Created by wankun603 on 2018-06-15.
 */
@Description(name = "max_input", value = "_FUNC_(mkt_val,b_amt,s_amt,dt) - max input money.\n")
public class MaxInput extends AbstractGenericUDAFResolver {

  private static final Log LOG = LogFactory.getLog(PeriodCost.class.getName());

  @Override
  public GenericUDAFEvaluator getEvaluator(GenericUDAFParameterInfo paramInfo) throws SemanticException {
    TypeInfo[] parameters = paramInfo.getParameters();

    assert !paramInfo.isDistinct() : "DISTINCT not supported with *";
    assert !paramInfo.isAllColumns() : "One argument are needed!";
    if (parameters.length != 4) {
      throw new UDFArgumentException("Argument expected");
    }
    return new MaxInputEvaluator();
  }

  @Override
  public GenericUDAFEvaluator getEvaluator(TypeInfo[] parameters) throws SemanticException {
    return new MaxInputEvaluator();
  }

  public static class MaxInputEvaluator extends GenericUDAFEvaluator {

    @AggregationType(estimable = false)
    static class MaxInputBuf extends AbstractAggregationBuffer {
      List<HiveDecimal> mktVals;
      List<HiveDecimal> bAmts;
      List<HiveDecimal> sAmts;
      List<String> dts;
    }

    @Override
    public AggregationBuffer getNewAggregationBuffer() throws HiveException {
      MaxInputBuf agg = new MaxInputBuf();
      reset(agg);
      return agg;
    }

    @Override
    public void reset(AggregationBuffer agg) throws HiveException {
      ((MaxInputBuf) agg).mktVals = new ArrayList<>();
      ((MaxInputBuf) agg).bAmts = new ArrayList<>();
      ((MaxInputBuf) agg).sAmts = new ArrayList<>();
      ((MaxInputBuf) agg).dts = new ArrayList<>();

    }

    public static final String MKT_VAL_NAME = "mktVal";
    public static final String B_AMT_NAME = "bAmt";
    public static final String S_AMT_NAME = "sAmt";
    public static final String DT_NAME = "dt";
    public static final String MAX_INPUT_NAME = "max_input";

    private transient ObjectInspector[] poi;
    private transient StructObjectInspector soi;
    private transient Object[] partialResult;
    private transient Object[] result;

    private transient StructField mktValField;
    private transient StandardListObjectInspector mktValOI;
    private transient StructField bAmtField;
    private transient StandardListObjectInspector bAmtOI;
    private transient StructField sAmtField;
    private transient StandardListObjectInspector sAmtOI;
    private transient StructField dtField;
    private transient StandardListObjectInspector dtOI;


    @Override
    public ObjectInspector init(Mode m, ObjectInspector[] parameters) throws HiveException {
      super.init(m, parameters);
      this.poi = parameters;
      partialResult = new Object[4];
      result = new Object[2];
      if (m == Mode.PARTIAL1 || m == Mode.PARTIAL2) {
        List<String> fname = Arrays.asList(MKT_VAL_NAME, B_AMT_NAME, S_AMT_NAME, DT_NAME);
        List<ObjectInspector> retOIs = Arrays.asList(
                ObjectInspectorFactory.getStandardListObjectInspector(
                        PrimitiveObjectInspectorFactory.javaHiveDecimalObjectInspector),
                ObjectInspectorFactory.getStandardListObjectInspector(
                        PrimitiveObjectInspectorFactory.javaHiveDecimalObjectInspector),
                ObjectInspectorFactory.getStandardListObjectInspector(
                        PrimitiveObjectInspectorFactory.javaHiveDecimalObjectInspector),
                (ObjectInspector) ObjectInspectorFactory.getStandardListObjectInspector(
                        PrimitiveObjectInspectorFactory.javaStringObjectInspector));
        return ObjectInspectorFactory.getStandardStructObjectInspector(fname, retOIs);
      } else {
        soi = (StructObjectInspector) parameters[0];

        mktValField = soi.getStructFieldRef(MKT_VAL_NAME);
        mktValOI = (StandardListObjectInspector) mktValField.getFieldObjectInspector();
        bAmtField = soi.getStructFieldRef(B_AMT_NAME);
        bAmtOI = (StandardListObjectInspector) bAmtField.getFieldObjectInspector();
        sAmtField = soi.getStructFieldRef(S_AMT_NAME);
        sAmtOI = (StandardListObjectInspector) sAmtField.getFieldObjectInspector();
        dtField = soi.getStructFieldRef(DT_NAME);
        dtOI = (StandardListObjectInspector) dtField.getFieldObjectInspector();

        List<String> fname = Arrays.asList(DT_NAME, MAX_INPUT_NAME);
        List<ObjectInspector> retOIs = Arrays.asList(
                (ObjectInspector) PrimitiveObjectInspectorFactory.javaStringObjectInspector,
                PrimitiveObjectInspectorFactory.javaHiveDecimalObjectInspector);
        return ObjectInspectorFactory.getStandardStructObjectInspector(fname, retOIs);
      }
    }

    @Override
    public void iterate(AggregationBuffer agg, Object[] parameters) throws HiveException {
      HiveDecimal mktVal = PrimitiveObjectInspectorUtils.getHiveDecimal(parameters[0], (PrimitiveObjectInspector) poi[0]);
      HiveDecimal bAmt = PrimitiveObjectInspectorUtils.getHiveDecimal(parameters[1], (PrimitiveObjectInspector) poi[1]);
      HiveDecimal sAmt = PrimitiveObjectInspectorUtils.getHiveDecimal(parameters[2], (PrimitiveObjectInspector) poi[2]);
      String dt = PrimitiveObjectInspectorUtils.getString(parameters[3], (PrimitiveObjectInspector) poi[3]);
      ((MaxInputBuf) agg).mktVals.add(mktVal);
      ((MaxInputBuf) agg).bAmts.add(bAmt);
      ((MaxInputBuf) agg).sAmts.add(sAmt);
      ((MaxInputBuf) agg).dts.add(dt);
    }

    @Override
    public Object terminatePartial(AggregationBuffer agg) throws HiveException {
      partialResult[0] = ((MaxInputBuf) agg).mktVals;
      partialResult[1] = ((MaxInputBuf) agg).bAmts;
      partialResult[2] = ((MaxInputBuf) agg).sAmts;
      partialResult[3] = ((MaxInputBuf) agg).dts;
      return partialResult;
    }

    @Override
    public void merge(AggregationBuffer agg, Object partial) throws HiveException {
      if (partial != null) {
        PrimitiveObjectInspector eoi;
        List<Object> mktVals2 = (List<Object>) mktValOI.getList(soi.getStructFieldData(partial, mktValField));
        eoi = (PrimitiveObjectInspector) mktValOI.getListElementObjectInspector();
        for (Object obj : mktVals2)
          ((MaxInputBuf) agg).mktVals.add(PrimitiveObjectInspectorUtils.getHiveDecimal(obj, eoi));

        List<Object> bAmts2 = (List<Object>) bAmtOI.getList(soi.getStructFieldData(partial, bAmtField));
        eoi = (PrimitiveObjectInspector) bAmtOI.getListElementObjectInspector();
        for (Object obj : bAmts2)
          ((MaxInputBuf) agg).bAmts.add(PrimitiveObjectInspectorUtils.getHiveDecimal(obj, eoi));

        List<Object> sAmts2 = (List<Object>) sAmtOI.getList(soi.getStructFieldData(partial, sAmtField));
        eoi = (PrimitiveObjectInspector) sAmtOI.getListElementObjectInspector();
        for (Object obj : sAmts2)
          ((MaxInputBuf) agg).sAmts.add(PrimitiveObjectInspectorUtils.getHiveDecimal(obj, eoi));

        List<Object> dts2 = (List<Object>) dtOI.getList(soi.getStructFieldData(partial, dtField));
        eoi = (PrimitiveObjectInspector) dtOI.getListElementObjectInspector();
        for (Object obj : dts2)
          ((MaxInputBuf) agg).dts.add(PrimitiveObjectInspectorUtils.getString(obj, eoi));
      }
    }

    @Override
    public Object terminate(AggregationBuffer agg) throws HiveException {
      if (agg == null || ((MaxInputBuf) agg).mktVals.size() == 0)
        return null;

      List<HiveDecimal> mktVals = ((MaxInputBuf) agg).mktVals;
      List<HiveDecimal> bAmts = ((MaxInputBuf) agg).bAmts;
      List<HiveDecimal> sAmts = ((MaxInputBuf) agg).sAmts;
      List<String> dts = ((MaxInputBuf) agg).dts;

      List<StockShare> stockShares = new ArrayList<>(mktVals.size());

      for (int i = 0; i < mktVals.size(); i++) {
        String dt = dts.get(i);
        if (dt == null || dt.length() == 0)
          continue;
        stockShares.add(
                new StockShare(mktVals.get(i).bigDecimalValue(),
                        bAmts.get(i).bigDecimalValue(),
                        sAmts.get(i).bigDecimalValue(),
                        dts.get(i)));
      }

      Collections.sort(stockShares, new Comparator<StockShare>() {
        @Override
        public int compare(StockShare o1, StockShare o2) {
          return o1.dt.compareTo(o2.dt);
        }
      });

      BigDecimal maxInput = null;
      String dt = null;
      BigDecimal curInput = null;
      for (StockShare stockShare : stockShares) {
        if (maxInput == null) {
          maxInput = stockShare.mktVal;
          dt = stockShare.dt;
          curInput = stockShare.mktVal;
        } else {
          BigDecimal maxInput2 = curInput.add(stockShare.bAmt);
          if (maxInput2.compareTo(maxInput) > 0) {
            maxInput = maxInput2;
            dt = stockShare.dt;
          }
          curInput = curInput.add(stockShare.bAmt).subtract(stockShare.sAmt);
        }
      }
      result[0] = dt;
      result[1] = HiveDecimal.create(maxInput);
      return result;
    }

    class StockShare {
      BigDecimal mktVal;
      BigDecimal bAmt;
      BigDecimal sAmt;
      String dt;

      public StockShare(BigDecimal mktVal, BigDecimal bAmt, BigDecimal sAmt, String dt) {
        this.mktVal = mktVal;
        this.bAmt = bAmt;
        this.sAmt = sAmt;
        this.dt = dt;
      }


    }
  }

}
