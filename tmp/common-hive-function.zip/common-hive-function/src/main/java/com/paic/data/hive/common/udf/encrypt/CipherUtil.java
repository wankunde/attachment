package com.paic.data.hive.common.udf.encrypt;

import java.io.UnsupportedEncodingException;
import java.util.BitSet;

import jodd.util.StringUtil;

public class CipherUtil {
	private static final String[][] SEEDS = new String[][] { "public static String encrypt code to do".split("\\s+"), "com.paic.data.jobs.common.util.CipherUtil".split("[.]"), "This is a cypher test ok good".split("[.]") };
	private static final int ROW = SEEDS.length;
	private static final int COLUMN = SEEDS[0].length;
	private static final String[][] SEEDS_MASK = new String[ROW][COLUMN];
	public static String CHINESE = "[\u4E00-\u9FA5]+";
	public static String UREG = "\\\\u[0-9a-zA-Z]{4}";

	static {
		for (int i = 0; i < ROW; i++) {
			for (int j = 0; j < COLUMN; j++) {
				SEEDS_MASK[i][j] = findSeeds(i * ROW + j);
			}
		}
	}

	private static int SEED_USE = 15;
	private static String SEED = SEEDS_MASK[Math.max(0, SEED_USE / COLUMN - 1)][Math.max(0, SEED_USE % COLUMN - 1)];

	private static final String FILL = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

	public static String toUnicode(String string) {
		StringBuilder sb = new StringBuilder();
		for (char c : string.toCharArray()) {
			sb.append(toUnicode(c));
		}
		return sb.toString();
	}

	public static char[] encrypt(char[] src) {
		Object[] obj = determineSeed();
		return encrypt(src, obj);
	}

	public static String toUnicode(char ch) {
		if (ch < 0x10) {
			return "\\u000" + Integer.toHexString(ch);
		} else if (ch < 0x100) {
			return "\\u00" + Integer.toHexString(ch);
		} else if (ch < 0x1000) {
			return "\\u0" + Integer.toHexString(ch);
		}
		return "\\u" + Integer.toHexString(ch);
	}

	public static char[] encrypt(char[] src, Object[] seed) {
		int seedsNumber = (int) seed[0];
		String seeds = (String) seed[1];

		char[] d = new char[src.length];
		int len = seeds.length();
		int sl = src.length;
		BitSet bs = new BitSet(sl);
		for (int i = 0; i < sl; i++) {
			int c = src[sl - i - 1];
			int s = seeds.charAt(len - i % len - 1);
			int t = c + s;
			int x = t / 2;
			if (t % 2 != 0) {

				bs.set(i);
			}

			d[i] = (char) x;
		}
		String str = toString(seedsNumber, bs.toLongArray());

		return merge(d, str.toCharArray(), seed);
	}

	private static char[] merge(char[] a, char[] b, Object[] seed) {
		int len = b.length > a.length ? b.length * 2 : a.length + b.length;
		char[] c = new char[len];

		int i = 0, j = 0, k = 0;

		while (i != c.length) {
			char t = ((i % 2 == 0) || k > b.length - 1) ? (j <= a.length - 1) ? a[j++] : '#' : b[k++];
			c[(i + (int) seed[0]) % len] = t;
			i++;
		}
		return c;
	}

	public static String encrypt(String src) {
		String ret = "";
		if (!StringUtil.isEmpty(src)) {
			char[] cs = translateUnicode(src.trim(), false).toCharArray();
			Object[] seed = determineSeed();
			ret = encode(new String(encrypt(cs, seed)));
		}
		return ret;
	}

	public static String decrypt(String src) {
		String ret = null;
		if (StringUtil.isEmpty(src)) {
			ret = "";
		} else {
			src = decode(src);
			Object[] seed = determineSeed();
			int len = src.length();
			int pos = (int) seed[0] % len;
			String original = src.substring(pos).concat(src.substring(0, pos));
			char[] cs = original.toCharArray();
			ret = translateUnicode(new String(decrypt(cs, seed)), true);
		}
		return ret;
	}

	public static String decode(String src) {
		try {
			return new String(org.apache.commons.codec.binary.Base64.decodeBase64(src.getBytes("UTF-8")));
		} catch (UnsupportedEncodingException e) {
			return new String(org.apache.commons.codec.binary.Base64.decodeBase64(src.getBytes()));
		}
	}

	public static String encode(String src) {
		try {
			return new String(org.apache.commons.codec.binary.Base64.encodeBase64(src.getBytes("UTF-8")), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			return new String(org.apache.commons.codec.binary.Base64.encodeBase64(src.getBytes()));
		}
	}

	private static String toString(int n, long[] ls) {
		StringBuilder sb = new StringBuilder("|");
		if (ls.length != 0) {
			for (long l : ls) {

				sb.append(Long.toHexString(l)).append("|");
			}
		}
		sb.insert(0, Integer.toHexString(Math.max(0, sb.length() - 1)));
		return sb.toString();
	}

	private static Object[] determineSeed() {
		return new Object[] { SEED_USE, SEED };
	}

	public static String findSeeds(int n) {
		String seeds = SEEDS[Math.max(0, n / COLUMN - 1)][Math.max(0, n % COLUMN - 1)];
		int m = FILL.length();
		if (seeds.length() > m) {
			seeds = seeds.substring(0, m);
		} else if (seeds.length() < m) {
			int sl = seeds.length();
			String fill = FILL.substring(0, m - sl);
			char[] cs = new char[m];
			int k = 0;
			int j = 0;
			for (int i = 0; i < m; i++) {
				if (i % 2 == 0 && k < sl) {
					cs[i] = seeds.charAt(k++);
				} else {
					cs[i] = fill.charAt(j++);
				}
			}
			seeds = String.valueOf(cs);
		}
		return shift(seeds, n % seeds.length());
	}

	private static String shift(String user, int n) {
		char[] ss = user.toCharArray();
		char[] cs = new char[user.length()];
		for (int i = 0; i < cs.length; i++) {
			cs[i] = ss[(i + n) % cs.length];
		}
		for (int i = 0; i < cs.length / 2; i++) {
			char x = cs[i];
			cs[i] = cs[cs.length - i - 1];
			cs[cs.length - i - 1] = x;
		}
		return String.valueOf(cs);
	}

	public static char[] decrypt(char[] src, Object[] seed) {
		StringBuilder lenb = new StringBuilder();
		StringBuilder longsb = new StringBuilder();
		StringBuilder eb = new StringBuilder();
		boolean inLen = true;
		boolean only = false;
		int len = -1;
		for (int i = 0; i < src.length; i++) {
			char c = src[i];
			if (!only && i % 2 == 1) {
				if (inLen) {
					if (c == '|') {
						inLen = false;
						len = Integer.valueOf(lenb.toString(), 16);
						continue;
					}
				}
				if (inLen) {
					lenb.append(c);
					continue;
				} else {
					if (longsb.length() < len) {
						longsb.append(c);
						continue;
					} else {
						only = true;
					}
				}
			}
			eb.append(c);
		}
		BitSet bs = toBitSet(longsb.toString());

		String seeds = (String) seed[1];
		int lenSeed = seeds.length();

		char[] enc = eb.toString().replaceAll("#", "").toCharArray();
		int sl = enc.length;
		char[] ret = new char[enc.length];
		for (int i = 0; i < enc.length; i++) {
			// int c = src[sl - i - 1];
			// int s = seeds.charAt(lenSeed - i % lenSeed - 1);
			// int t = c + s;
			// int x = t / 2;
			// if (x % 2 != 0) {
			// bs.set(i);
			// }
			// //
			// d[i] = (char) x;
			char x = enc[i];
			int t = x * 2;
			if (bs.get(i)) {
				t += 1;
			}
			int s = seeds.charAt(lenSeed - i % lenSeed - 1);
			int c = t - s;
			ret[sl - i - 1] = (char) c;

		}
		return ret;
	}

	private static BitSet toBitSet(String bsStr) {
		if (bsStr.endsWith("|")) {
			bsStr = bsStr.substring(0, bsStr.length() - 1);
		}
		BitSet ret = null;
		if (bsStr.trim().equals("")) {
			ret = new BitSet();
		} else {
			String[] str = bsStr.split("[|]");
			long[] longs = new long[str.length];
			for (int i = 0; i < str.length; i++) {
				longs[i] = Long.valueOf(str[i], 16);
			}
			ret = BitSet.valueOf(longs);
		}
		return ret;
	}

	public static String translateUnicode(String str, final boolean fromU) {
		return str;
		// String ret = str;
		// boolean nt = fromU && !str.contains("\\");
		// if (!nt) {
		// final StringBuilder sb = new StringBuilder();
		// RegExProcessor rp = new RegExProcessor(fromU ? UREG : CHINESE, new
		// Callback<String>() {
		//
		// @Override
		// public void process(String t) {
		// if (t.matches(fromU ? UREG : CHINESE)) {
		// sb.append(fromU ? toChar(t) : toUnicode(t));
		// } else {
		// sb.append(t);
		// }
		//
		// }
		// });
		// rp.process(str);
		// ret = sb.toString();
		// }
		// return ret;
	}

	public static String toChar(String s) {
		s = s.startsWith("\\u") ? s.substring(2) : s;
		int v = Integer.valueOf(s, 16);
		return String.valueOf((char) v);
	}

	public static void main(String[] args) {
		int SEED_USE = 11;
		String SEED = SEEDS_MASK[Math.max(0, SEED_USE / COLUMN - 1)][Math.max(0, SEED_USE % COLUMN - 1)];
		System.out.println(SEED_USE + ":" + SEED);
		String src = "Hello看了了";
		String pwd = encrypt(src);
		System.out.println(src.length() + ":" + pwd.length());
		String o = decrypt(pwd);
		System.out.println(src + "->" + pwd + "->" + o);
	}

}
