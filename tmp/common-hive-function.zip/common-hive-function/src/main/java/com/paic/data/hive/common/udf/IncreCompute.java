package com.paic.data.hive.common.udf;

import com.paic.data.hive.common.udf.bean.MeasureBean;
import com.paic.data.hive.common.udf.bean.MeasureType;
import com.paic.data.hive.common.utils.UdfUtils;
import com.paic.data.hive.common.utils.date.DateUnit;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.hive.ql.metadata.HiveException;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.paic.data.hive.common.udf.PreMeasureHis.DAYS_POSTFIX;

/**
 * Created by WANGYI422 on 2018/9/10.
 */
public class IncreCompute extends UDF{
    private static final Log LOG = LogFactory.getLog(IncreCompute.class);

    public Map<String, Double> evaluate(Map<String, Map<String, Double>> his, String dt,
                                        Map<String, Double> todayMeasureMap,
                                        String measureText, String indexName, String colsGroups,
                                        Map<String, Double> hisEx) throws ParseException, IOException, HiveException {
        if (his == null) {
            his = new HashMap<>();
        }

        if (todayMeasureMap == null) todayMeasureMap = new HashMap<>();

        Set<String> allKeys = new HashSet<>();
        allKeys.addAll(his.keySet());
        allKeys.addAll(todayMeasureMap.keySet());

        if (measureText.contains("0d_sum_")) measureText = measureText + ",0d_sum";
        List<MeasureBean> measures = MeasureUtil.parseMeasure(measureText, dt);
        Map<String, BigDecimal> ex = new HashMap<>();

        try {
            for (String iteratorKey : allKeys) {

                if (his.get(iteratorKey) == null) his.put(iteratorKey, new HashMap<String, Double>());

                for (MeasureBean measure : measures) {
                    ex = increCompute(ex, measure, iteratorKey, toBigDecimalMap(his.get(iteratorKey)),
                            toBigDecimalMap(hisEx), toBigDecimalMap(todayMeasureMap), dt);
                }
            }
        } catch (Exception e) {
            LOG.error("evaluate error!", e);
            throw e;
        }
        return toDoubleMap(ex);
    }

    private Map<String, BigDecimal> increCompute(Map<String, BigDecimal> res, MeasureBean measure,
                                                 String exKeyPre,
                                                 Map<String, BigDecimal> hisData,
                                                 Map<String, BigDecimal> hisEx,
                                                 Map<String, BigDecimal> todayMeasureMap,
                                                 String dt) throws ParseException, HiveException, IOException {

        boolean shouldFirst = measure.getFirstValue() != null;
        BigDecimal firstValue = shouldFirst ? BigDecimal.valueOf(measure.getFirstValue()) : null;
        String measureText = measure.getMeasureText();
        String key = exKeyPre + MeasureUtil.KEY_DELIMITER_4 + measureText;
        String kswitch = key;

        if (hisEx.get(key) == null && todayMeasureMap.get(exKeyPre) == null)
            return res;

        if (shouldFirst && hisEx.get(key) != null) {
            res.put(key, hisEx.get(key));
            return res;
        } else if (shouldFirst) {
            measureText = measureText.substring(0, measureText.lastIndexOf('_'));
            key = exKeyPre + MeasureUtil.KEY_DELIMITER_4 + measureText;
        }

        String startDate = measure.getStartDate();
        String endDate = measure.getEndDate();
        String speriod = measure.getSperiod();
        MeasureType type = measure.getType();

        BigDecimal hisValue = defaultValue(hisData.get(measureText), type);
        BigDecimal hisExValue = defaultValue(hisEx.get(key), type);
        BigDecimal todayValue = defaultValue(todayMeasureMap.get(exKeyPre), type);
        BigDecimal length = hisData.get(measureText + DAYS_POSTFIX);
        BigDecimal tmp = null;

        if (measureText.startsWith("0d_sum")) {
            tmp = hisExValue.add(todayValue);
            /*tmp = BigDecimal.ZERO;
            if (measureText.equals("0d_sum")) tmp = hisExValue.add(todayValue);
            else tmp = tmp.add(hisValue).add(todayValue);*/

        } else if (speriod.endsWith("t") && !UdfUtils.isTradeDay(dt)) {
            tmp = hisExValue;
        } else {
            if (type.compareTo(MeasureType.MAX) == 0 || type.compareTo(MeasureType.MIN) == 0) {
                if (hisValue == null) {
                    tmp = todayValue;
                } else if (todayValue != null && type.compareTo(MeasureType.MAX) == 0) {
                    tmp = todayValue.compareTo(hisValue) > 0 ? todayValue : hisValue;
                } else if (todayValue != null && type.compareTo(MeasureType.MIN) == 0) {
                    tmp = todayValue.compareTo(hisValue) > 0 ? hisValue : todayValue;
                } else {
                    tmp = hisValue;
                }
            } else if ((measure.getDts().length == 1 && type.compareTo(MeasureType.TAVG) != 0 && !speriod.endsWith("t")) ||
                    (measure.getTradeDays() == 1 && UdfUtils.isTradeDay(dt) && (type.compareTo(MeasureType.TAVG) == 0 || speriod.endsWith("t")))) {
                tmp = todayValue;

            } else if (type.compareTo(MeasureType.SUM) == 0) {
                tmp = hisExValue.add(todayValue);
                tmp = tmp.subtract(hisValue);

            } else if (type.compareTo(MeasureType.AVG) == 0) {
                BigDecimal dts = BigDecimal.valueOf(measure.getDts().length == 0 ? 1 : measure.getDts().length);
                BigDecimal lastDts = length.compareTo(BigDecimal.ZERO) == 0 ? BigDecimal.ONE : length;
                tmp = hisExValue.multiply(lastDts).add(todayValue);
                tmp = tmp.subtract(hisValue);
                tmp = tmp.divide(dts, 4, BigDecimal.ROUND_HALF_UP);

            } else if (type.compareTo(MeasureType.TAVG) == 0) {
                BigDecimal dts = BigDecimal.valueOf(measure.getTradeDays() == 0 ? 1 : measure.getTradeDays());
                BigDecimal lastDts = length.compareTo(BigDecimal.ZERO) == 0 ? BigDecimal.ONE : length;
                tmp = hisExValue.multiply(lastDts);
                if (UdfUtils.isTradeDay(dt)) tmp = tmp.add(todayValue);
                tmp = tmp.subtract(hisValue);
                tmp = tmp.divide(dts, 4, BigDecimal.ROUND_HALF_UP);

            }
        }

        if ((tmp != null) && shouldFirst && (tmp.compareTo(firstValue) >= 0)) {
            key = kswitch;
            res.put(key, BigDecimal.valueOf(Double.valueOf(dt)));
        } else if (tmp != null && !shouldFirst) {
            res.put(key, tmp);
        }
        return res;
    }

    private BigDecimal defaultValue(BigDecimal value, MeasureType type) {
        if (value == null && type.compareTo(MeasureType.MAX) != 0 && type.compareTo(MeasureType.MIN) != 0) {
            return BigDecimal.ZERO;
        } else {
            return value;
        }
    }

    private Map<String, BigDecimal> toBigDecimalMap(Map<String, Double> map) {
        if (null == map)
            return new HashMap<>();
        Map<String, BigDecimal> newMap = new HashMap<>();
        for (Map.Entry<String, Double> en : map.entrySet()) {
            newMap.put(en.getKey(), BigDecimal.valueOf(en.getValue()));
        }
        return newMap;
    }

    private Map<String, Double> toDoubleMap(Map<String, BigDecimal> map) {
        if (null == map)
            return new HashMap<>();
        Map<String, Double> newMap = new HashMap<>();
        for (Map.Entry<String, BigDecimal> en : map.entrySet()) {
            newMap.put(en.getKey(), en.getValue().doubleValue());
        }
        return newMap;
    }

}
