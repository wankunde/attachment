package com.paic.data.hive.common.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * 与xstream一样，反序列化时，遇到未知的field，会抛异常。必须设置
 * 
 * objectMapper线程安全
 * 
 * @author tianhui
 * @date 2013-6-21
 */
public class JsonUtil {

	private static final ObjectMapper objectMapper;
	static {
		objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);  
		objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
	}

	public static String getPropertiesFromJson(String str, String[] keys) {
		String allKeys = Arrays.toString(keys);
		try {
			JsonParser parser = objectMapper.getFactory().createParser(str);
			JsonNode node = parser.readValueAsTree();
			for (String key : keys) {
				if (node.has(key)) {
					node = node.findValue(key);
				} else {
					throw new RuntimeException(
							"key not exist in json str, keys:" + allKeys);
				}
			}
			return node.toString();
		} catch (JsonParseException e) {
			throw new RuntimeException("parse json error, json="
					+ str + ", keys:" + allKeys, e);
		} catch (IOException e) {
			throw new RuntimeException("parse json error, json="
					+ str + ", keys:" + allKeys, e);
		}
	}
	

	public static String writeEntity2Json(Object object) {
		if(object == null){
			return null;
		}
		try {
			return objectMapper.writeValueAsString(object);
		} catch (JsonGenerationException e) {
			throw new RuntimeException("get json error", e);
		} catch (JsonMappingException e) {
			throw new RuntimeException("get json error", e);
		} catch (IOException e) {
			throw new RuntimeException("get json error", e);
		}
	}

	public static <T> T readStream2Entity(InputStream instream, Class<T> cls) {
		try {
			JsonParser parser = objectMapper.getFactory().createParser(instream);
			
			return objectMapper.readValue(parser, cls);
		} catch (JsonParseException e) {
			throw new RuntimeException("parse json error", e);
		} catch (IOException e) {
			throw new RuntimeException("parse json error", e);
		} finally {
			try {
				instream.close();
			} catch (Exception ignore) {

			}
		}
	}

	public static <T> T readJson2Entity(String str, Class<T> cls) {
		try {
			if(StringUtils.isEmpty(str)){
				return null;
			}
			
			JsonParser parser = objectMapper.getFactory().createParser(str);
			T t = objectMapper.readValue(parser, cls);
			return t;
		} catch (JsonParseException e) {
			throw new RuntimeException("parse json error, json="
					+ str + ", class=" + cls.getName(), e);
		} catch (IOException e) {
			throw new RuntimeException("parse json error, json="
					+ str + ", class=" + cls.getName(), e);
		}
	}


	public static <T> List<T> readStream2List(InputStream instream, Class<T> clsT) {
		try {
			JsonParser parser = objectMapper.getFactory().createParser(instream);
			
			List<T> list = new LinkedList<T>();
			Iterator<T> iter = parser.readValuesAs(clsT);
			while(iter.hasNext()){
				list.add(iter.next());
			}
			return list;
		} catch (JsonParseException e) {
			throw new RuntimeException("parse json error", e);
		} catch (IOException e) {
			throw new RuntimeException("parse json error", e);
		} finally {
			try {
				instream.close();
			} catch (Exception ignore) {

			}
		}
	}
	
	public static JavaType getCollectionType(Class<?> collectionClass, Class<?>... elementClasses) {   
		return objectMapper.getTypeFactory().constructParametricType(collectionClass, elementClasses);        
	}  

	public static <T> List<T> readJson2List(String str, Class<T> clsT) {
		try {
			JavaType javaType = getCollectionType(ArrayList.class, clsT); 
			
			return objectMapper.readValue(str, javaType); 
			
//			if(StringUtil.isEmpty(str)){
//				return null;
//			}
//			JsonParser parser = objectMapper.getFactory().createParser(str);
//			List<T> list = new LinkedList<T>();
//			Iterator<T> iter = parser.readValuesAs(clsT);
//			while(iter.hasNext()){
//				iter.next();
//				//list.add(iter.next());
//			}
//			return list;
		} catch (JsonParseException e) {
			throw new RuntimeException("parse json error str:"
					+ str, e);
		} catch (IOException e) {
			throw new RuntimeException("parse json error str:"
					+ str, e);
		}
	}
	
//	public static <T> T parseJson(String str, TypeReference<T> tr){
//		try {
//			
//			if(StringUtil.isEmpty(str)){
//				return null;
//			}
//			JsonParser parser = objectMapper.getFactory().createParser(str);
//			return parser.readValueAs(tr);
//		} catch (JsonParseException e) {
//			throw new RuntimeException("parse json error str:"
//					+ str, e);
//		} catch (IOException e) {
//			throw new RuntimeException("parse json error str:"
//					+ str, e);
//		}
//	}

	public static <T> LinkedHashMap<String, T> readJson2Map(String str,
			Class<T> clsT) {
		LinkedHashMap<String, T> map = new LinkedHashMap<String, T>();
		try {
			
			JsonParser parser = objectMapper.getFactory().createParser(str);

			JsonToken current;

			current = parser.nextToken();
			if (current != JsonToken.START_OBJECT) {
				throw new RuntimeException(
						"parse json error: root should be object, quiting.");
			}

			while (parser.nextToken() != JsonToken.END_OBJECT) {
				String fieldName = parser.getCurrentName();
				current = parser.nextToken();
				T obj = parser.readValueAs(clsT);
				map.put(fieldName, obj);
			}

			return map;
		} catch (JsonParseException e) {
			throw new RuntimeException("parse json error str:"
					+ str, e);
		} catch (IOException e) {
			throw new RuntimeException("parse json error str:"
					+ str, e);
		}
	}
	
	public static <T> Map<Integer, T> readJson2IntegerMap(String str,
			Class<T> clsT) {
		Map<Integer, T> map = new LinkedHashMap<Integer, T>();
		try {
			
			JsonParser parser = objectMapper.getFactory().createParser(str);

			JsonToken current;

			current = parser.nextToken();
			if (current != JsonToken.START_OBJECT) {
				throw new RuntimeException(
						"parse json error: root should be object, quiting.");
			}

			while (parser.nextToken() != JsonToken.END_OBJECT) {
				String fieldName = parser.getCurrentName();
				current = parser.nextToken();
				T obj = parser.readValueAs(clsT);
				map.put(Integer.valueOf(fieldName), obj);
			}

			return map;
		} catch (JsonParseException e) {
			throw new RuntimeException("parse json error str:"
					+ str, e);
		} catch (IOException e) {
			throw new RuntimeException("parse json error str:"
					+ str, e);
		}
	}

	public static <T extends Enum<T>> EnumSet<T> readJson2EntityEnum(String str,
			Class<T> clsT) {
		try {
			JavaType javaType = getCollectionType(EnumSet.class, clsT); 
			
			return objectMapper.readValue(str, javaType); 
			
//			JsonParser parser = objectMapper.getFactory().createParser(str);
//			EnumSet<T> enumSet = EnumSet.noneOf(clsT);
//			Iterator<T> iter = parser.readValuesAs(clsT);
//			while(iter.hasNext()){
//				enumSet.add(iter.next());
//			}
//			return enumSet;
		} catch (JsonParseException e) {
			throw new RuntimeException("parse json error str:"
					+ str, e);
		} catch (IOException e) {
			throw new RuntimeException("parse json error str:"
					+ str, e);
		}
	}

	/**
	 * 当格式不对，抛出异常422
	 * @param request
	 * @param cls
	 * @return
	 */
	public static <T> T jsonConvert(HttpServletRequest request, Class<T> cls) {
		try {
			return readStream2Entity(request.getInputStream(), cls);
		} catch (Exception e) {
			throw new RuntimeException("json error", e);
		}
	}
	
	public static <T> List<T> jsonsConvert(HttpServletRequest request, Class<T> cls) {
		try {
			return readStream2List(request.getInputStream(), cls);
		} catch (IOException e) {
			throw new RuntimeException("json io error", e);
		} catch (Exception e) {
			throw new RuntimeException("json error", e);
		}
	}
	
	public static void main(String[] args){
		List<String> list = new ArrayList<>();
		list.add("1");
		list.add("2");
		list.add("3");
		System.out.println(JsonUtil.writeEntity2Json(list));
		
		String result = JsonUtil.writeEntity2Json(list);
		List<String> lt = JsonUtil.readJson2List(result, String.class);
		System.out.println(lt);
		System.out.println(JsonUtil.writeEntity2Json(JsonUtil.readJson2List(result, String.class)));
		
		System.out.println("1");
		
		String[] strs = new String[]{"2", "3"};
		
		System.out.println(JsonUtil.writeEntity2Json(strs));
		
		String result2 = JsonUtil.writeEntity2Json(strs);
		List<String> lt2 = JsonUtil.readJson2List(result2, String.class);
		System.out.println(lt2);
		System.out.println(JsonUtil.writeEntity2Json(JsonUtil.readJson2List(result2, String.class)));
		
		Map<String, Long> mapResult = new HashMap<>();
		mapResult.put("a", 1L);
		mapResult.put("b", 2L);
		System.out.println(JsonUtil.writeEntity2Json(mapResult));
		
	}
}
