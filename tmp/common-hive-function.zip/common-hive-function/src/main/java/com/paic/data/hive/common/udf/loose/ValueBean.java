package com.paic.data.hive.common.udf.loose;

import org.apache.hadoop.hive.common.type.HiveDecimal;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Created by WANKUN603 on 2018-05-22.
 */
public class ValueBean {
  private String dt;
  private HiveDecimal value;

  public ValueBean(String dt, HiveDecimal value) {
    this.dt = dt;
    this.value = value;
  }

  public String getDt() {
    return dt;
  }

  public void setDt(String dt) {
    this.dt = dt;
  }

  public HiveDecimal getValue() {
    return value;
  }

  public void setValue(HiveDecimal value) {
    this.value = value;
  }

  @Override
  public String toString() {
    return "{" + dt + ":" + value + "}";
  }

  public static ValueBean[] loose(List<ValueBean> list) {
    if (list == null || list.size() == 0) {
      return null;
    } else if (list.size() == 1) {
      return new ValueBean[]{list.get(0), list.get(0)};
    }


    Collections.sort(list, new Comparator<ValueBean>() {
      @Override
      public int compare(ValueBean o1, ValueBean o2) {
        if (o1 == null || o1.dt == null)
          return -1;
        else if (o2 == null || o2.dt == null)
          return 1;
        else
          return o1.dt.compareTo(o2.dt);
      }
    });
    ValueBean start = list.get(0);
    ValueBean end = list.get(1);
    for (int j = 1; j < list.size(); j++) {
      if (end.value.compareTo(list.get(j).value) > 0)
        end = list.get(j);
    }
    for (int i = 0; i < list.size() - 1; i++) {
      ValueBean nstart = list.get(i);
      if (nstart.value.compareTo(start.value) > 0) {
        if (nstart.dt.compareTo(end.dt) < 0) {
          start = nstart;
        } else {
          ValueBean nend = list.get(i + 1);
          for (int j = i + 1; j < list.size(); j++) {
            if (nend.value.compareTo(list.get(j).value) > 0)
              nend = list.get(j);
          }
          if (nstart.value.subtract(nend.value).compareTo(
                  start.value.subtract(end.value)) > 0) {
            start = nstart;
            end = nend;
          }
        }
      }
    }
    return new ValueBean[]{start, end};
  }
}
