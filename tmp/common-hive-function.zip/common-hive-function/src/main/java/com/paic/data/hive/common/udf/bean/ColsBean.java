package com.paic.data.hive.common.udf.bean;

import org.apache.hadoop.hive.ql.udf.generic.GenericUDAFEvaluator;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import static com.paic.data.hive.common.udf.MeasureUtil.KEY_DELIMITER_2;

/**
 * Created by WANKUN603 on 2016-06-01.
 */
@GenericUDAFEvaluator.AggregationType(estimable = true)
public class ColsBean extends GenericUDAFEvaluator.AbstractAggregationBuffer {

    private List<ColBean> cols;
    private Map<String, Integer> colMap;

    public ColsBean(String colsStr, Map<String, Integer> colMap) {
        List<ColBean> cols = new LinkedList<>();
        for (String colStr : Arrays.asList(colsStr.split(KEY_DELIMITER_2))) {
            if (!colMap.containsKey(colStr))
                colMap.put(colStr, colMap.size());

            cols.add(new ColBean(colStr, colMap.get(colStr)));
        }
        setCols(cols);
        setColMap(colMap);
    }

    @Override
    public String toString() {
        return "ColsBean{" +
                "cols=" + cols +
                ", colMap=" + colMap +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ColsBean colsBean = (ColsBean) o;
        return cols != null ? cols.equals(colsBean.cols) : colsBean.cols == null;

    }

    @Override
    public int hashCode() {
        int result = cols != null ? cols.hashCode() : 0;
        return result;
    }

    public List<ColBean> getCols() {
        return cols;
    }

    public void setCols(List<ColBean> cols) {
        this.cols = cols;
    }


    public Map<String, Integer> getColMap() {
        return colMap;
    }

    public void setColMap(Map<String, Integer> colMap) {
        this.colMap = colMap;
    }
}
