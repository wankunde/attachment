package com.paic.data.hive.common.udf;

import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Description(name = "multi_like", value = "_FUNC_(col, 'patterns'...) - Returns pattern match result")
public class MultiLike extends UDF {
  public Map<String, Boolean> evaluate(String col, String... patterns) {
    Map<String, Boolean> result = new HashMap<>(patterns.length);
    if (StringUtils.isBlank(col))
      return result;

    int patternsHashCode = 0;
    for (String pattern : patterns) {
      if (StringUtils.isNotBlank(pattern)) {
        patternsHashCode += pattern.hashCode();
      }
    }
    Map<Integer, Object[]> cache = cachedPatternParser.get();
    Object[] objs = cache.get(patternsHashCode);
    List<String> prePatterns;
    List<String> subPatterns;
    Node root;
    if (objs == null || objs.length != 3) {
      prePatterns = new ArrayList<>();
      subPatterns = new ArrayList<>();
      List<String> filterPatterns = new ArrayList<>();

      for (String pattern : patterns) {
        if (StringUtils.isNotBlank(pattern)) {
          int len = pattern.length();
          char s = pattern.charAt(0);
          char e = pattern.charAt(pattern.length() - 1);
          if (s == '%' && e != '%')
            subPatterns.add(pattern.substring(1, len));
          else if (s != '%' && e == '%')
            prePatterns.add(pattern.substring(0, len - 1));
          else if (s == '%' && e == '%')
            filterPatterns.add(pattern.substring(1, len - 1));
          else
            filterPatterns.add(pattern);
        }
      }
      root = buildPatternTree(filterPatterns.toArray(new String[filterPatterns.size()]));
      cache.put(patternsHashCode, new Object[]{prePatterns, subPatterns, root});
      cachedPatternParser.set(cache);
    } else {
      prePatterns = (ArrayList<String>) objs[0];
      subPatterns = (ArrayList<String>) objs[1];
      root = (Node) objs[2];
    }

    for (String prePattern : prePatterns) {
      if (col.startsWith(prePattern))
        result.put(prePattern, true);
    }
    for (String subPattern : subPatterns) {
      if (col.endsWith(subPattern))
        result.put(subPattern, true);
    }

    for (int i = 0; i < col.length(); i++) {
      int j = 0;
      Node toVisit = root;
      while (i + j < col.length() && toVisit != null) {
        toVisit = toVisit.children.get(col.charAt(i + j));
        if (toVisit != null && toVisit.isLeafNode())
          result.put(toVisit.pattern, true);
        j++;
      }
    }

    return result;
  }


  ThreadLocal<Map<Integer, Object[]>> cachedPatternParser = new ThreadLocal<Map<Integer, Object[]>>() {
    @Override
    protected Map<Integer, Object[]> initialValue() {
      return new HashMap<Integer, Object[]>();
    }
  };

  public Node buildPatternTree(String... patterns) {
    Node root = new Node();
    for (String pattern : patterns) {
      Node parent = root;
      for (int i = 0; i < pattern.length(); i++) {
        char v = pattern.charAt(i);
        Node node = parent.children.get(v);
        if (node == null) {
          node = i < pattern.length() - 1 ? new Node(v) : new Node(v, pattern);
          parent.children.put(v, node);
        }
        parent = node;
      }
    }
    return root;
  }

  class Node {
    Character v = null;
    Map<Character, Node> children = new HashMap<>();
    String pattern = null;

    /**
     * Root Node
     */
    public Node() {

    }

    /**
     * Value Node
     *
     * @param v
     */
    public Node(Character v) {
      this.v = v;
    }

    /**
     * Leaf Node
     *
     * @param v
     */
    public Node(Character v, String pattern) {
      this.v = v;
      this.pattern = pattern;
    }

    public boolean isLeafNode() {
      return pattern != null;
    }

    @Override
    public String toString() {
      return toString(0);
    }

    private String toString(int level) {
      String lpad = "|--";
      StringBuilder sb = new StringBuilder();
      sb.append(v);
      for (Node child : children.values()) {
        sb.append("\n");
        for (int l = 0; l < level; l++) {
          sb.append("  ");
        }
        sb.append(lpad + child.toString(level + 1));
      }
      return sb.toString();
    }
  }
}
