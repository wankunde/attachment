package com.paic.data.hive.common.udf.bean;

import com.paic.data.hive.common.utils.UdfUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.*;

import static com.paic.data.hive.common.udf.MeasureUtil.*;

/**
 * Created by WANKUN603 on 2016-06-01.
 */
public class ColsGroupsExtBean extends ColsGroupsBean {

    public static Map<String, ColsGroupsExtBean> cachedColsGroupBean = new HashMap<>();

    private String[] indexs;

    protected ColsGroupsExtBean(String colsGroupStr, Map<String, Integer> colsMap) {
        super(colsGroupStr, colsMap);
    }

    public static ColsGroupsExtBean getColsGroupBean(String indexGroups, String colsGroupStr) {
        String cachedKey = indexGroups + colsGroupStr;
        if (cachedColsGroupBean.containsKey(cachedKey))
            return cachedColsGroupBean.get(cachedKey);

        String[] indexs = UdfUtils.trimArray(indexGroups.split(KEY_DELIMITER_3));
        Map<String, Integer> colsMap = new HashMap<>();
        for (int i = 0; i < indexs.length; i++) {
            colsMap.put(indexs[i], i);
        }

        ColsGroupsExtBean bean = new ColsGroupsExtBean(colsGroupStr, colsMap);
        String[] extIndexs = new String[indexs.length + 1];
        System.arraycopy(indexs, 0, extIndexs, 0, indexs.length);
        extIndexs[indexs.length] = KEY_EXTENDS_TIME;
        bean.setIndexs(extIndexs);
        cachedColsGroupBean.put(cachedKey, bean);
        return bean;
    }

    public List<String> getMapKeys(String[] title, String colsGroups, String types, Object... parameters) {
        types = types.toLowerCase();
        List<String> mapKeys = new ArrayList<>();
        for (String index : this.getIndexs()) {
            List<String> slist = super.getMapKeys(index, colsGroups, parameters);
            for(String type:types.split("&")){
                if(StringUtils.isNotBlank(type))
                    for (String key : slist) {
                        mapKeys.add(key + KEY_DELIMITER_4 + type);
                    }
            }
        }
        return mapKeys;
    }

    public String[] getIndexs() {
        return indexs;
    }

    public void setIndexs(String[] indexs) {
        this.indexs = indexs;
    }
}
