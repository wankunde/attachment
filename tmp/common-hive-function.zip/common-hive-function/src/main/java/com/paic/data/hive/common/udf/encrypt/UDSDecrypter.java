package com.paic.data.hive.common.udf.encrypt;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.hive.ql.exec.UDFArgumentException;

@Description(name = "uds_decrypt", value = "_FUNC_(token, encryptContent) - validate the token and return raw content")
public class UDSDecrypter extends UDF {
	private boolean valid = false;

	public String evaluate(String token, String content) throws UDFArgumentException {
		if (!valid) {
			String user = TokenUtil.validateToken(token);
			valid = user != null && !user.trim().equals("");
			if (!valid) {
				throw new UDFArgumentException("Authentication failed!");
			}
		}
		return UDSCipherUtil.decrypt(content);
	}

	public static void main(String[] args) throws Exception {
		String x = new UDSDecrypter().evaluate("A11A.FB4T2922C94.F30N64FM661UBC0L91C.29FO68CCA78_C95.2111767E1F5.9E3.41BLB6FB6046F6220C328EBE76B06166049A01E9B929555790EE6E29C7F2", "NCN8OjJafDk=");
		System.out.println(x);
	}

}
