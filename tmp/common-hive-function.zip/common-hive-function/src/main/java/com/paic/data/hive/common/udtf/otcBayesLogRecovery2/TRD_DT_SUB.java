package com.paic.data.hive.common.udtf.otcBayesLogRecovery2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URL;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.NavigableSet;
import java.util.SortedSet;
import java.util.TreeSet;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.FsUrlStreamHandlerFactory;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.io.IOUtils;

public class TRD_DT_SUB {
	static NavigableSet<String> allSet = new TreeSet<String>();
	static {
		try {
			URL.setURLStreamHandlerFactory(new FsUrlStreamHandlerFactory());
		} catch (Throwable e) {
			// ignore
		}
	}

	// SortedSet<String> allSet = new TreeSet<String>();
/*	private NavigableSet<String> loadFromFile(String filename) throws IOException {
		//List<String> expected = new ArrayList<String>();
		NavigableSet<String> allSet = new TreeSet<String>();
		//String filename = "tradecalender.csv";
		BufferedReader reader = new BufferedReader(new FileReader(
		this.getClass().getClassLoader().getResource(filename).getFile()));// 换成你的文件各1�7
		String line = null;
		
		while ((line = reader.readLine()) != null) {
			allSet.add(line);
			
		}
		return (NavigableSet<String>) allSet;
	}*/

	private static NavigableSet<String> loadFromFile(String name) throws HiveException, IOException {

		NavigableSet<String> allSet = new TreeSet<String>();
		Configuration conf = new Configuration();
		String uri = "hdfs:///metadata/dim/tradecalender.csv";
		FSDataInputStream in = null;
		BufferedReader reader = null;
		try {
			FileSystem hdfs = FileSystem.get(URI.create(uri), conf);
			in = hdfs.open(new org.apache.hadoop.fs.Path(uri));
			reader = new BufferedReader(new InputStreamReader(in));
			String line = null;
			while ((line = reader.readLine()) != null) {
				allSet.add(line);
				// System.out.println(line);
			}
			IOUtils.copyBytes(in, System.out, 4096, false);
		} finally {
			IOUtils.closeStream(in);
		}
		
		return (NavigableSet<String>) allSet;
	}

	public String findLTD(String dt) throws HiveException, IOException{
		if (allSet.isEmpty())
			allSet = loadFromFile("hdfs:///metadata/dim/tradecalender.csv");
			//allSet = loadFromFile("tradecalender.csv");
		String LTD = allSet.higher(dt);

		return LTD;
	}



}
