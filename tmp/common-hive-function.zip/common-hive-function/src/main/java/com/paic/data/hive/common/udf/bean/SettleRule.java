package com.paic.data.hive.common.udf.bean;

import java.util.Date;
import java.util.List;
import java.util.Set;


public class SettleRule{

	private Integer ruleId;

	private Integer divisionId;//渠道大类ID
	
	private Integer unifyAid;//渠道二级ID

	private Integer unifySid;//渠道三级ID
	
	private List<Integer> acctType;//股票类账号类型。1 资金户  2 单户  4 双户  8 理财  股票类账号只能选一
	
	private Integer secuPrior;//开户计费开始日期，如2016年1月3日的开始结算，为20160103

	private Integer status;//规则状态
	
	private String appendUrl;//附件地址
	
	private Integer openStartDate;//开户计费开始日期，如2016年1月3日的开始结算，为20160103
	
	private Integer openEndDate;//开户计费结束日期，如2016年1月3日的结束结算，为20160103
	
	private List<SecuSettleDoorSill>  secuSettleDoorsill;//结算门槛。1 开户  2 有交易   3 有效户  4 入金门槛 
	
	private Integer assetSettleDoorsill;//资金户结算门槛，产品购买金额。为null表示没有资金户结算
	
	private Integer ommSettleDoorsill;//理财户结算门槛，产品购买金额。为null表示没有资金户结算

	private Integer openFeeSecu;//股票户结算单价
	
	private Integer openFeeAsset;//资金户结算单价
	
	private Integer openFeeOmm;//理财户结算单价
	
	private Integer commissionStartDate;//分佣计费开始日期 
	
	private Integer custStartDate;//参与分佣的用户开户开始日期
	
	private List<Integer> commissionType;//分佣类型  1 股票  2 基金  4 产品。 如果没有分佣，为null

	private Integer commissionYear;//分佣年限
	
	private Double commissionRatio;//分佣比例。
	
	private Integer secondStartDate;//
	
	private Integer secondEndDate;//
	
	private List<SecondSettle> secondSettle;//二轮结算
	
	private Date createTime;//记录创建时间

	private Date updateTime;//记录更新时间

	private Boolean del;

	public static class SecuSettleDoorSill{//股东户结算门槛
		Integer type;//1 已开户   2 有交易  3 资产峰值   4 入金门槛 
		Integer amt;//金额，单位元
		Integer day;//天数。如果不限制天数，为null。表示day天内，需操作amt金额的type操作。
		
		Set<Integer> trade_types;//1 股票  2 基金 。  type为2时 有效

		public Integer getType() {
			return type;
		}

		public void setType(Integer type) {
			this.type = type;
		}

		public Integer getAmt() {
			return amt;
		}

		public void setAmt(Integer amt) {
			this.amt = amt;
		}

		public Integer getDay() {
			return day;
		}

		public void setDay(Integer day) {
			this.day = day;
		}

		public Set<Integer> getTrade_types() {
			return trade_types;
		}

		public void setTrade_types(Set<Integer> trade_types) {
			this.trade_types = trade_types;
		}
		
	}
	
	public static class SecondSettle{
		Integer type;//1 股东户有交易   2 股东户入金  3 理财户   4资产峰值
		Integer contain_month;//该部分结算是否只包含本月开户的用户 0 否  1包含
		
		Integer amt;//金额，单位元
		Integer fee;//结算单价，单位元

		Integer ratio;//比例。单位1%。 比如25%，填25
		Integer range;//0 全部客户   1 达标客户
		public Integer getType() {
			return type;
		}
		public void setType(Integer type) {
			this.type = type;
		}
		public Integer getContain_month() {
			return contain_month;
		}
		public void setContain_month(Integer contain_month) {
			this.contain_month = contain_month;
		}
		public Integer getAmt() {
			return amt;
		}
		public void setAmt(Integer amt) {
			this.amt = amt;
		}
		public Integer getFee() {
			return fee;
		}
		public void setFee(Integer fee) {
			this.fee = fee;
		}
		public Integer getRatio() {
			return ratio;
		}
		public void setRatio(Integer ratio) {
			this.ratio = ratio;
		}
		public Integer getRange() {
			return range;
		}
		public void setRange(Integer range) {
			this.range = range;
		}
		
	}

	public Integer getRuleId() {
		return ruleId;
	}

	public void setRuleId(Integer ruleId) {
		this.ruleId = ruleId;
	}

	public Integer getDivisionId() {
		return divisionId;
	}

	public void setDivisionId(Integer divisionId) {
		this.divisionId = divisionId;
	}

	public Integer getUnifyAid() {
		return unifyAid;
	}

	public void setUnifyAid(Integer unifyAid) {
		this.unifyAid = unifyAid;
	}

	public Integer getUnifySid() {
		return unifySid;
	}

	public void setUnifySid(Integer unifySid) {
		this.unifySid = unifySid;
	}

	public List<Integer> getAcctType() {
		return acctType;
	}

	public void setAcctType(List<Integer> acctType) {
		this.acctType = acctType;
	}

	public Integer getSecuPrior() {
		return secuPrior;
	}

	public void setSecuPrior(Integer secuPrior) {
		this.secuPrior = secuPrior;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getAppendUrl() {
		return appendUrl;
	}

	public void setAppendUrl(String appendUrl) {
		this.appendUrl = appendUrl;
	}

	public Integer getOpenStartDate() {
		return openStartDate;
	}

	public void setOpenStartDate(Integer openStartDate) {
		this.openStartDate = openStartDate;
	}

	public Integer getOpenEndDate() {
		return openEndDate;
	}

	public void setOpenEndDate(Integer openEndDate) {
		this.openEndDate = openEndDate;
	}

	public List<SecuSettleDoorSill> getSecuSettleDoorsill() {
		return secuSettleDoorsill;
	}

	public void setSecuSettleDoorsill(List<SecuSettleDoorSill> secuSettleDoorsill) {
		this.secuSettleDoorsill = secuSettleDoorsill;
	}

	public Integer getAssetSettleDoorsill() {
		return assetSettleDoorsill;
	}

	public void setAssetSettleDoorsill(Integer assetSettleDoorsill) {
		this.assetSettleDoorsill = assetSettleDoorsill;
	}

	public Integer getOmmSettleDoorsill() {
		return ommSettleDoorsill;
	}

	public void setOmmSettleDoorsill(Integer ommSettleDoorsill) {
		this.ommSettleDoorsill = ommSettleDoorsill;
	}

	public Integer getOpenFeeSecu() {
		return openFeeSecu;
	}

	public void setOpenFeeSecu(Integer openFeeSecu) {
		this.openFeeSecu = openFeeSecu;
	}

	public Integer getOpenFeeAsset() {
		return openFeeAsset;
	}

	public void setOpenFeeAsset(Integer openFeeAsset) {
		this.openFeeAsset = openFeeAsset;
	}

	public Integer getOpenFeeOmm() {
		return openFeeOmm;
	}

	public void setOpenFeeOmm(Integer openFeeOmm) {
		this.openFeeOmm = openFeeOmm;
	}

	public Integer getCommissionStartDate() {
		return commissionStartDate;
	}

	public void setCommissionStartDate(Integer commissionStartDate) {
		this.commissionStartDate = commissionStartDate;
	}

	public Integer getCustStartDate() {
		return custStartDate;
	}

	public void setCustStartDate(Integer custStartDate) {
		this.custStartDate = custStartDate;
	}

	public List<Integer> getCommissionType() {
		return commissionType;
	}

	public void setCommissionType(List<Integer> commissionType) {
		this.commissionType = commissionType;
	}

	public Integer getCommissionYear() {
		return commissionYear;
	}

	public void setCommissionYear(Integer commissionYear) {
		this.commissionYear = commissionYear;
	}

	public Double getCommissionRatio() {
		return commissionRatio;
	}

	public void setCommissionRatio(Double commissionRatio) {
		this.commissionRatio = commissionRatio;
	}

	public Integer getSecondStartDate() {
		return secondStartDate;
	}

	public void setSecondStartDate(Integer secondStartDate) {
		this.secondStartDate = secondStartDate;
	}

	public Integer getSecondEndDate() {
		return secondEndDate;
	}

	public void setSecondEndDate(Integer secondEndDate) {
		this.secondEndDate = secondEndDate;
	}

	public List<SecondSettle> getSecondSettle() {
		return secondSettle;
	}

	public void setSecondSettle(List<SecondSettle> secondSettle) {
		this.secondSettle = secondSettle;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Boolean getDel() {
		return del;
	}

	public void setDel(Boolean del) {
		this.del = del;
	}
	
	
}
