package com.paic.data.hive.common.udf.log;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

@Description(name = "vstock_log_parser", value = "_FUNC_(String message) - Returns DealBehavior")
public class VstockLogParser extends UDF {

    private static final Log logger = LogFactory.getLog(VstockLogParser.class);

    static class DealBehavior {
        String capitalId;
        String buyOrSell;
        String dealTime;
        String productCode;
        String productionName;
        String tradeType;
        Double dealPrice;
    }

    public List<DealBehavior> evaluate(String message) {
        if (StringUtils.isEmpty(message)) {
            return null;
        }

        int startIndex = message.indexOf("<TRACE>");
        int endIndex = message.indexOf("</TRACE>");
        int dzhIndex = message.indexOf("callDZH_Response");
        if (startIndex != -1 && endIndex != -1 && dzhIndex != -1 && endIndex > startIndex) {
            String clearMessage = message.substring(startIndex, endIndex);
            int sepaIndex = clearMessage.lastIndexOf("|");
            if (sepaIndex != -1) {
                String jsonStr = clearMessage.substring(sepaIndex + 1, clearMessage.length()).replace("[\"[", "")
                        .replace("]\",200]", "").replace("\\\"", "\"");

                try {

                    JSONObject jsonData = new JSONObject(jsonStr);
                    List<DealBehavior> dealList = new ArrayList<VstockLogParser.DealBehavior>();
                    JSONObject data = (JSONObject) jsonData.get("Data");
                    JSONArray behaviorList = null;
                    if(data.has("RepDataQueryOrderRsp")) {
                        behaviorList = (JSONArray) data.get("RepDataQueryOrderRsp");
                    } else if(data.has("RepDataQueryDealRsp")) {
                        behaviorList = (JSONArray) data.get("RepDataQueryDealRsp");
                    } else {
                        return null;
                    }
                    for (int i = 0; i < behaviorList.length(); i++) {
                        JSONObject behavior = (JSONObject) behaviorList.get(i);
                        String capitalId = (String) behavior.get("CapitalId");
                        
                        if(behavior.has("OrderList")) {
                            JSONArray orderList = (JSONArray) behavior.get("OrderList");
                            for (int x = 0; x < orderList.length(); x++) {
                                JSONObject order = (JSONObject) orderList.get(x);
                                DealBehavior deal = new DealBehavior();
                                deal.capitalId = capitalId;
                                deal.buyOrSell = order.getString("BuyOrSell");
                                deal.tradeType = "Order";
                                deal.dealTime = order.getString("OrderTime");
                                deal.productCode = order.getString("ProductCode");
                                deal.productionName = order.getString("ProductName");
                                deal.dealPrice = order.getDouble("OrderPrice");
    
                                dealList.add(deal);
                            }
                        } else if(behavior.has("DealList")) {
                            JSONArray orderList = (JSONArray) behavior.get("DealList");
                            for (int x = 0; x < orderList.length(); x++) {
                                JSONObject order = (JSONObject) orderList.get(x);
                                DealBehavior deal = new DealBehavior();
                                deal.capitalId = capitalId;
                                deal.buyOrSell = order.getString("BuyOrSell");
                                deal.tradeType = "Order";
                                deal.dealTime = order.getString("DealTime");
                                deal.productCode = order.getString("ProductCode");
                                deal.productionName = order.getString("ProductName");
                                deal.dealPrice = order.getDouble("DealPrice");
    
                                dealList.add(deal);
                            }
                        }
                        
                    }
                    return dealList;
                } catch (Throwable e) {
                    logger.debug("Content:" + message, e);
                    return null;
                }
            }
        }

        return null;

    }

}
