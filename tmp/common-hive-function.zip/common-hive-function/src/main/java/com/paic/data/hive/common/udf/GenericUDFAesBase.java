package com.paic.data.hive.common.udf;

import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.exec.UDFArgumentTypeException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDF;
import org.apache.hadoop.hive.serde2.objectinspector.*;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorConverters.Converter;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorUtils;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.Text;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import java.security.GeneralSecurityException;
import java.security.NoSuchAlgorithmException;

import static org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorUtils.PrimitiveGrouping.BINARY_GROUP;
import static org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorUtils.PrimitiveGrouping.STRING_GROUP;

public abstract class GenericUDFAesBase extends GenericUDF {
    protected transient PrimitiveObjectInspector.PrimitiveCategory[] inputTypes = new PrimitiveObjectInspector.PrimitiveCategory[2];
    protected transient Converter[] converters = new Converter[2];
    protected transient boolean isStr0;
    protected transient boolean isStr1;
    protected transient Cipher cipher;
    protected transient SecretKey secretKey;
    protected final BytesWritable output = new BytesWritable();

    @Override
    public ObjectInspector initialize(ObjectInspector[] arguments) throws UDFArgumentException {
        checkArgsSize(arguments, 2, 2);
        checkArgPrimitive(arguments, 0);
        checkArgPrimitive(arguments, 1);

        if (canParam0BeStr()) {
            checkArgGroups(arguments, 0, inputTypes, STRING_GROUP, BINARY_GROUP);
        } else {
            checkArgGroups(arguments, 0, inputTypes, BINARY_GROUP);
        }
        checkArgGroups(arguments, 1, inputTypes, STRING_GROUP, BINARY_GROUP);

        if (isStr0 = PrimitiveObjectInspectorUtils.getPrimitiveGrouping(inputTypes[0]) == STRING_GROUP) {
            converters[0] = ObjectInspectorConverters.getConverter(arguments[0],
                    PrimitiveObjectInspectorFactory.writableStringObjectInspector);
        } else {
            converters[0] = ObjectInspectorConverters.getConverter(arguments[0],
                    PrimitiveObjectInspectorFactory.writableBinaryObjectInspector);
        }

        if (isStr1 = PrimitiveObjectInspectorUtils.getPrimitiveGrouping(inputTypes[1]) == STRING_GROUP) {
            converters[1] = ObjectInspectorConverters.getConverter(arguments[1],
                    PrimitiveObjectInspectorFactory.writableStringObjectInspector);
        } else {
            converters[1] = ObjectInspectorConverters.getConverter(arguments[1],
                    PrimitiveObjectInspectorFactory.writableBinaryObjectInspector);
        }

        try {
            cipher = Cipher.getInstance("AES");
        } catch (NoSuchPaddingException | NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }

        ObjectInspector outputOI = PrimitiveObjectInspectorFactory.writableBinaryObjectInspector;
        return outputOI;
    }

    @Override
    public Object evaluate(DeferredObject[] arguments) throws HiveException {
        byte[] input;
        int inputLength;

        if (isStr0) {
            Text n = getTextValue(arguments, 0, converters);
            if (n == null) return null;
            input = n.getBytes();
            inputLength = n.getLength();
        } else {
            BytesWritable bWr = getBinaryValue(arguments, 0, converters);
            if (bWr == null) return null;
            input = bWr.getBytes();
            inputLength = bWr.getLength();
        }

        if (input == null) return null;

        SecretKey secretKey;
        byte[] key;
        int keyLength;
        if (isStr1) {
            Text n = getTextValue(arguments, 1, converters);
            if (n == null) return null;
            key = n.getBytes();
            keyLength = n.getLength();
        } else {
            BytesWritable bWr = getBinaryValue(arguments, 1, converters);
            if (bWr == null) return null;
            key = bWr.getBytes();
            keyLength = bWr.getLength();
        }
        secretKey = getSecretKey(key, keyLength);

        if (secretKey == null) return null;

        byte[] res = aesFunction(input, inputLength, secretKey);
        if (res == null) return null;
        output.set(res, 0, res.length);
        return output;
    }

    @Override
    public String getDisplayString(String[] children) {
        StringBuilder sb = new StringBuilder();
        sb.append(getFuncName()).append("(");
        if (children.length > 0) {
            sb.append(children[0]);
            for (int i = 1; i<children.length; i++) {
                sb.append(", ");
                sb.append(children[i]);
            }
        }
        sb.append(")");
        return sb.toString();
    }

    protected void checkArgPrimitive(ObjectInspector[] argument, int i) throws UDFArgumentTypeException {
        ObjectInspector.Category oiCat = argument[i].getCategory();
        if (oiCat != ObjectInspector.Category.PRIMITIVE) {
            throw new UDFArgumentTypeException(i, getFuncName() + " only takes primitive types as "
                    + (i + 1) + " argument, got " + oiCat);
        }
    }

    protected void checkArgGroups(ObjectInspector[] arguments, int i, PrimitiveObjectInspector.PrimitiveCategory[] inputTypes,
                                PrimitiveObjectInspectorUtils.PrimitiveGrouping... grps) throws UDFArgumentTypeException {
        PrimitiveObjectInspector.PrimitiveCategory inputType = ((PrimitiveObjectInspector) arguments[i]).getPrimitiveCategory();
        for (PrimitiveObjectInspectorUtils.PrimitiveGrouping grp : grps) {
            if (PrimitiveObjectInspectorUtils.getPrimitiveGrouping(inputType) == grp) {
                inputTypes[i] = inputType;
                return;
            }
        }
        StringBuilder sb = new StringBuilder();
        sb.append(getFuncName());
        sb.append(" only takes ");
        sb.append(grps[0]);
        for (int j = 1; j < grps.length; j++) {
            sb.append(", ");
            sb.append(grps[j]);
        }
        sb.append(" types as ");
        sb.append(i + 1);
        sb.append(" argument, got ");
        sb.append(inputType);
        throw new UDFArgumentTypeException(i, sb.toString());
    }

    protected SecretKey getSecretKey(byte[] key, int keyLength) {
        if (keyLength == 16 || keyLength == 32 || keyLength == 24) {
            return new SecretKeySpec(key, 0, keyLength, "AES");
        }
        return null;
    }

    protected byte[] aesFunction(byte[] input, int inputLength, SecretKey secretKey) {
        try {
            cipher.init(getCipherMode(), secretKey);
            byte[] res = cipher.doFinal(input, 0, inputLength);
            return res;
        } catch (GeneralSecurityException e) {
            return null;
        }
    }

    abstract protected int getCipherMode();

    abstract protected boolean canParam0BeStr();

    protected Text getTextValue(DeferredObject[] arguments, int i, Converter[] converters) throws HiveException {
        Object obj;
        if ((obj = arguments[i].get()) == null) return null;
        Object writableValue = converters[i].convert(obj);
        return (Text) writableValue;
    }

    protected BytesWritable getBinaryValue(DeferredObject[] arguments, int i, Converter[] converters) throws HiveException {
        Object obj;
        if ((obj = arguments[i].get()) == null) return null;
        Object writableValue = converters[i].convert(obj);
        return (BytesWritable) writableValue;
    }
}
