package com.paic.data.hive.common.udf;

import com.paic.data.hive.common.udf.bean.MeasureBean;
import com.paic.data.hive.common.udf.bean.MeasureType;
import com.paic.data.hive.common.utils.UdfUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.hive.ql.metadata.HiveException;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by WANGYI422 on 2018/9/10.
 */
public class PreMeasureHis extends UDF{
    public final static String DAYS_POSTFIX = "_DAYS";

    public Map<String, Map<String, Double>> evaluate(Map<String, Map<String, Double>> his, Map<String, Double> hisEx, String dt,
                                                     String measureText) throws HiveException, IOException, ParseException {
        if (his == null) {
            his = new HashMap<>();
            return his;
        }

        Map<String, Map<String, Double>> result = new HashMap<>();
        for (String hisKey : his.keySet()) {
            Map<String, Double> tmpMap = his.get(hisKey);

            result = getFirstData(result, tmpMap, hisEx, dt, measureText, hisKey);
        }

        return result;
    }

    private Map<String, Map<String, Double>> getFirstData(Map<String, Map<String, Double>> result,
                                                          Map<String, Double> his, Map<String, Double> hisEx,
                                                          String dt, String measureText,
                                                          String exKeyPre) throws HiveException, IOException, ParseException {

        if (his == null || his.size() == 0) return result;
        if (measureText.contains("0d_sum_")) measureText = measureText + ",0d_sum";

        List<MeasureBean> measures = MeasureUtil.parseMeasure(measureText, dt);
        Map<String, Double> measureToData = new HashMap<>();

        for (MeasureBean measure : measures) {
            MeasureType type = measure.getType();
            String[] dts = measure.getDts();
            String measureString = measure.getMeasureText();

            String firstMatchString = measure.getFirstValue() != null ? measureString.substring(0, measureString.lastIndexOf('_')) : measureString;
            if (measureToData.get(firstMatchString) != null) continue;
            else measureString = firstMatchString;

            boolean max = type.compareTo(MeasureType.MAX) == 0;
            boolean min = type.compareTo(MeasureType.MIN) == 0;

//            BigDecimal tmp = BigDecimal.valueOf(max ? -Double.MAX_VALUE : min ? Double.MAX_VALUE : 0d);
            BigDecimal tmp = null;

            List<String> diff = diffDts(dt, measure);
            int diffLen = diff == null ? 0 : diff.size();

            if (measureString.startsWith("0d_sum")) {
                if (hisEx == null || hisEx.get(exKeyPre + MeasureUtil.KEY_DELIMITER_4 + measureString) == null) {
                    tmp = BigDecimal.ZERO;
                    for (Double d : his.values()) {
                        tmp = tmp.add(BigDecimal.valueOf(d));
                    }
                    measureToData.put(measureString, tmp.doubleValue());
                }
            } else if (max || min) {

                for (int i = diffLen; i < dts.length; i++) {
                    String idx = dts[i];
                    if (UdfUtils.isTradeDay(idx) || !measure.getSperiod().endsWith("t")) {

                        BigDecimal d = his.get(idx) == null ? null : BigDecimal.valueOf(his.get(idx));

                        if (tmp == null && d != null) {
                            tmp = d;
                        } else if (d != null) {
                            if (max && d.compareTo(tmp) > 0) {
                                tmp = d;
                            } else if (min && d.compareTo(tmp) < 0) {
                                tmp = d;
                            }
                        }
                    }
                }
                if (tmp != null) {
                    measureToData.put(measureString, tmp.doubleValue());
                }
            } else if ((type.compareTo(MeasureType.TAVG) == 0) || measure.getSperiod().endsWith("t")) {
                BigDecimal d;
                tmp = BigDecimal.ZERO;

                for (int i = 0; i < diffLen; i++) {
                    String idx = dts[i];

                    if (UdfUtils.isTradeDay(idx)) {
                        d = his.get(idx) == null ? null : BigDecimal.valueOf(his.get(idx));
                        if (d != null) {
                            tmp = tmp.add(d);
                        }
                    }
                }
                measureToData.put(measureString, tmp.doubleValue());
                if (type.compareTo(MeasureType.SUM) != 0)
                    measureToData.put(measureString + DAYS_POSTFIX, (double) measure.getTradeDays());
            } else {
                BigDecimal d;
                tmp = BigDecimal.ZERO;

                for (int i = 0; i < diffLen; i++) {
                    String idx = dts[i];
                    d = his.get(idx) == null ? null : BigDecimal.valueOf(his.get(idx));
                    if (d != null) {
                        tmp = tmp.add(d);
                    }
                }
                measureToData.put(measureString, tmp.doubleValue());
                if (type.compareTo(MeasureType.SUM) != 0)
                    measureToData.put(measureString + DAYS_POSTFIX, (double) dts.length);
            }
        }

        result.put(exKeyPre, measureToData);

        return result;
    }

    private List<String> diffDts (String dt, MeasureBean mb) throws ParseException, HiveException, IOException {
        Date currentDate = DateUtils.parseDate(dt, "yyyyMMdd");
        Date nextDate = DateUtils.addDays(currentDate, 1);
        String nextDt = DateFormatUtils.format(nextDate, "yyyyMMdd");
        String nextStartDt = UdfUtils.shiftDate(mb.getSperiod(), nextDt, -1);
        String currentStartDt = mb.getStartDate();

        if (StringUtils.equals(nextStartDt, currentStartDt)) {
            return null;
        } else {
            List<String> result = new ArrayList<>();
            String[] dts = mb.getDts();
            int i = 0;
            while (i < dts.length && !StringUtils.equals(dts[i], nextStartDt)) {
                result.add(dts[i]);
                i++;
            }
            return result;
        }
    }

}
