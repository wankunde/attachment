package com.paic.data.hive.common.udf.uclog;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;

@Description(name = "uclogtransfer", value = "_FUNC_(String) - Returns formated value")
public class UcLogTransfer extends UDF {
	private final static String mesage_split = "\r\n";

	public List<String> evaluate(String message) throws IOException {
		String[] meesageList = message.split(mesage_split);
		String[] conent = processFullog(meesageList);
		List<String> result = Arrays.asList(conent);
		return result;
	}

	private String[] processFullog(String[] logList) throws IOException {
		String[] content = new String[15];
		int i = 0;
		String[] logArray0 = null;
		String[] logArray1 = null;
		String[] logArray2 = null;
		for (String log : logList) {
			if (i == 0) {
				logArray0 = log.split(" ");
				if (logArray0.length > 8) {
					content[0] = logArray0[0];

					content[1] = logArray0[1];

					if (logArray0[2].startsWith("IP:")) {
						content[2] = logArray0[2].split(":")[1];
					}
					if (logArray0[3].startsWith("MAC:")) {
						content[3] = logArray0[3].split(":")[1];
					}
					if (logArray0[6].startsWith("事务ID:")) {
						content[4] = logArray0[6].split(":")[1];
						// sb.append("\\u001");
					}
					if (logArray0[7].startsWith("请求:")) {
						content[5] = logArray0[7].split(":")[1];
					}
					if (logArray0[8].startsWith("营业部:") && logArray0[8].split(":").length > 1) {
						content[6] = logArray0[8].split(":")[1];
					}
				}
			}
			if (i == 1) {
				if (log.indexOf("|") != -1) {
					logArray1 = log.split("\\|");
					if (logArray0.length > 8 && logArray0[8].indexOf("匿名") != -1) {
						content[14] = logArray1[0];
					} else {
						if (logArray1.length > 0) {
							content[7] = logArray1[0];
						}
						if (logArray1.length > 1) {
							content[8] = logArray1[1];
						}
					}
				}
			}
			if (i == 2) {
				logArray2 = log.split(" ");
				if (logArray2.length > 11) {
					content[9] = logArray2[0];
					content[10] = logArray2[1];
					if (logArray2[9].startsWith("耗时A") && logArray2[9].split(":").length > 1) {
						content[11] = logArray2[9].split(":")[1];
					}
					if (logArray2[10].startsWith("耗时B") && logArray2[10].split(":").length > 1) {
						content[12] = logArray2[10].split(":")[1];
					}
					if (logArray2[11].startsWith("排队") && logArray2[11].split(":").length > 1) {
						content[13] = logArray2[11].split(":")[1];
					}
				}
			}
			i++;
		}

		return content;
	}

}
