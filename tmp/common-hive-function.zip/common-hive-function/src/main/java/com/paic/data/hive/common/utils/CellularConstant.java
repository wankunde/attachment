package com.paic.data.hive.common.utils;

import java.io.PrintStream;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public final class CellularConstant
{
  public static final String[] cnnet2Gs = { "133", "153", "180", "181", "189" };
  public static final String[] cnnet3Gs = { "133", "153", "180", "181", "189" };
  public static final String[] cnnet4Gs = { "177", "173" };
  public static final String[] cnnetVGs = { "1700", "1701", "1702" };

  public static final String[] cnunion2Gs = { "130", "131", "132", "155", "156" };
  public static final String[] cnunion3Gs = { "185", "186" };
  public static final String[] cnunion4Gs = { "176" };
  public static final String[] cnunionVGs = { "1707", "1708", "1709" };
  public static final String[] cnunionSGs = { "145" };

  public static final String[] cnmobile2Gs = { "134", "135", "136", "137", "138", "139", "150", "151", "152", "158", "159", "182", "183", "184" };
  public static final String[] cnmobile3Gs = { "157", "187", "188" };
  public static final String[] cnmobile4Gs = { "178" };
  public static final String[] cnmobileVGs = { "1705" };
  public static final String[] cnmobileSGs = { "147" };

  public static Set allNetTelSet = new HashSet();
  public static Set allUnionTelSet = new HashSet();
  public static Set allMobileTelSet = new HashSet();

  public static Set all2GTelSet = new HashSet();
  public static Set all3GTelSet = new HashSet();
  public static Set all4GTelSet = new HashSet();
  public static Set allVGTelSet = new HashSet();

  public static Set allCNTelSet = new HashSet();

  static
  {
    CollectionUtils.putAll(allNetTelSet, cnnet2Gs);
    CollectionUtils.putAll(allNetTelSet, cnnet3Gs);
    CollectionUtils.putAll(allNetTelSet, cnnet4Gs);
    CollectionUtils.putAll(allNetTelSet, cnnetVGs);

    CollectionUtils.putAll(allUnionTelSet, cnunion2Gs);
    CollectionUtils.putAll(allUnionTelSet, cnunion3Gs);
    CollectionUtils.putAll(allUnionTelSet, cnunion4Gs);
    CollectionUtils.putAll(allUnionTelSet, cnunionVGs);
    CollectionUtils.putAll(allUnionTelSet, cnunionSGs);

    CollectionUtils.putAll(allMobileTelSet, cnmobile2Gs);
    CollectionUtils.putAll(allMobileTelSet, cnmobile3Gs);
    CollectionUtils.putAll(allMobileTelSet, cnmobile4Gs);
    CollectionUtils.putAll(allMobileTelSet, cnmobileVGs);
    CollectionUtils.putAll(allMobileTelSet, cnmobileSGs);

    CollectionUtils.putAll(allCNTelSet, allNetTelSet);
    CollectionUtils.putAll(allCNTelSet, allUnionTelSet);
    CollectionUtils.putAll(allCNTelSet, allMobileTelSet);

    CollectionUtils.putAll(all2GTelSet, cnnet2Gs);
    CollectionUtils.putAll(all2GTelSet, cnunion2Gs);
    CollectionUtils.putAll(all2GTelSet, cnmobile2Gs);

    CollectionUtils.putAll(all3GTelSet, cnnet3Gs);
    CollectionUtils.putAll(all3GTelSet, cnunion3Gs);
    CollectionUtils.putAll(all3GTelSet, cnmobile3Gs);

    CollectionUtils.putAll(all4GTelSet, cnnet4Gs);
    CollectionUtils.putAll(all4GTelSet, cnunion4Gs);
    CollectionUtils.putAll(all4GTelSet, cnmobile4Gs);

    CollectionUtils.putAll(allVGTelSet, cnnetVGs);
    CollectionUtils.putAll(allVGTelSet, cnunionVGs);
    CollectionUtils.putAll(allVGTelSet, cnmobileVGs);
  }

  public static void main(String[] args)
  {
    Iterator it = allCNTelSet.iterator();

    while (it.hasNext())
      System.out.println(it.next());
  }
}