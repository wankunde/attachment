package com.paic.data.hive.common.udtf.otcBayesLogRecovery2;

public class MovedTable {
	private double value=0;
	private int moved=0;
	
	public MovedTable(double value,int moved)
	{
		this.value=value;
		this.moved=moved;
	}  
	
	public double getValue()
	{
		return value;
	}
	
	public int getMoved()
	{
		return moved;
	}
	
	public void setValue(double value)
	{
		this.value = value;
	}
	
	public void setMoved(int moved)
	{
		this.moved = moved;
	}
	
}
