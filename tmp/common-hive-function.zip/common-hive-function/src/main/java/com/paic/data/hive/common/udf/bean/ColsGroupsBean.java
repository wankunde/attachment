package com.paic.data.hive.common.udf.bean;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDAFEvaluator;

import java.util.*;
import java.util.regex.Pattern;

import static com.paic.data.hive.common.udf.MeasureUtil.KEY_DELIMITER_1;
import static com.paic.data.hive.common.udf.MeasureUtil.KEY_DELIMITER_3;
import static com.paic.data.hive.common.udf.MeasureUtil.INDEX_KEY_DELIMITER;

/**
 * Created by WANKUN603 on 2016-06-01.
 */
@GenericUDAFEvaluator.AggregationType(estimable = true)
public class ColsGroupsBean extends GenericUDAFEvaluator.AbstractAggregationBuffer {

    private static final Log LOG = LogFactory.getLog(ColsGroupsBean.class);

    private List<ColsBean> colsGroup;
    private Map<String, Integer> colsMap;

    public static Map<String, ColsGroupsBean> cachedColsGroupBean = new HashMap<>();

    public static ColsGroupsBean getColsGroupBean(String colsGroupStr) {
        if (cachedColsGroupBean.containsKey(colsGroupStr))
            return cachedColsGroupBean.get(colsGroupStr);
        ColsGroupsBean bean = new ColsGroupsBean(colsGroupStr);
        cachedColsGroupBean.put(colsGroupStr, bean);
        return bean;
    }

    protected ColsGroupsBean(String colsGroupStr) {
        this(colsGroupStr, new HashMap<String, Integer>());
    }

    protected ColsGroupsBean(String colsGroupStr, Map<String, Integer> colsMap) {
        List<ColsBean> colsGroup = new LinkedList<>();
        for (String colsStr : Arrays.asList(colsGroupStr.split(KEY_DELIMITER_3))) {
            if (StringUtils.isNotBlank(colsStr)) {
                ColsBean colsBean = new ColsBean(colsStr, colsMap);
                colsMap = colsBean.getColMap();
                colsGroup.add(colsBean);
            }
        }
        setColsGroup(colsGroup);
        setColsMap(colsMap);
    }

    @Override
    public String toString() {
        return "ColsGroupsBean{" +
                "colsGroup=" + colsGroup +
                ", colsMap=" + colsMap +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ColsGroupsBean that = (ColsGroupsBean) o;

        if (colsGroup != null ? !colsGroup.equals(that.colsGroup) : that.colsGroup != null) return false;
        return colsMap != null ? colsMap.equals(that.colsMap) : that.colsMap == null;

    }

    @Override
    public int hashCode() {
        int result = colsGroup != null ? colsGroup.hashCode() : 0;
        result = 31 * result + (colsMap != null ? colsMap.hashCode() : 0);
        return result;
    }

    public static Map<String, List<String>> cachedMapKeys = new HashMap<>();

    public List<String> getMapKeys(String title, String colsGroups, Object... parameters) {
//        String cachedKey = title + colsGroups + Arrays.toString(parameters);
//        if (cachedMapKeys.containsKey(cachedKey))
//            return cachedMapKeys.get(cachedKey);

        StringBuilder key = new StringBuilder();
        List<String> mapKeys = new LinkedList<>();
        for (ColsBean colsBean : colsGroup) {
            // 去除指标和维度相同的值
            List<ColBean> tmp = colsBean.getCols();
            if (tmp != null &&
                    !(tmp.size() == 1 && tmp.get(0).getName().equals(title))) {
                key.setLength(0);
                key.append(title);
                for (ColBean colBean : tmp) {
                    key.append(INDEX_KEY_DELIMITER);
                    key.append(colBean.getName());
                    key.append(INDEX_KEY_DELIMITER);
                    key.append(parameters[colBean.getIdx()]);
                }
                mapKeys.add(key.toString());
            }
        }
        // 加入当前值map key
        mapKeys.add(title);

//        cachedMapKeys.put(cachedKey, mapKeys);
        return mapKeys;
    }

    public static Map<String, Object[]> mapKeyCache = new HashMap<>();

    /*public static Object[] parseMapKey(String mapKeyStr) {
        if (mapKeyCache.containsKey(mapKeyStr))
            return mapKeyCache.get(mapKeyStr);

        String[] fields = mapKeyStr.split(KEY_DELIMITER_3);

        assert fields.length >= 1;

        String title = fields[0];
        String[] colNames = new String[fields.length - 1];
        String[] colValues = new String[fields.length - 1];
        for (int i = 1; i < fields.length; i++) {
            String[] ss = fields[i].split("\\" + KEY_DELIMITER_1);

            assert ss.length == 2;
            colNames[i - 1] = ss[0];
            if (ss.length >= 2)
                colValues[i - 1] = ss[1];
            else
                colValues[i - 1] = "";
        }

        Object[] res = new Object[]{title, colNames, colValues};
        if (LOG.isDebugEnabled())
            LOG.debug("parseMapKey input :" + mapKeyStr + " title :" + title +
                    " colNames:" + Arrays.toString(colNames) +
                    " colValues :" + Arrays.toString(colValues));
        mapKeyCache.put(mapKeyStr, res);
        return res;
    }*/
    
    private static Pattern NEGATIVE_PATTERN = Pattern.compile(INDEX_KEY_DELIMITER + INDEX_KEY_DELIMITER);
    /**
     * 针对字典值中存在负数的特殊处理
     * @param mapKeyStr
     * @return
     */
    public static Object[] parseMapKey(String mapKeyStr) {
        if (mapKeyCache.containsKey(mapKeyStr))
            return mapKeyCache.get(mapKeyStr);
        
        if(mapKeyStr.contains(INDEX_KEY_DELIMITER + INDEX_KEY_DELIMITER)){
        	return parseMapKeyContainNegative(mapKeyStr);
        }
        
        String[] fields = mapKeyStr.split(INDEX_KEY_DELIMITER);

        assert fields.length % 2 == 1;

        String title = fields[0];
        int cols = fields.length / 2;
        
        String[] colNames = new String[cols];
        String[] colValues = new String[cols];
        for (int i = 1; i < fields.length; i = i + 2) {
            colNames[i/2] = fields[i];
            colValues[i/2] = fields[i + 1];
        }

        Object[] res = new Object[]{title, colNames, colValues};
        /*if (LOG.isDebugEnabled())
            LOG.debug("parseMapKey input :" + mapKeyStr + " title :" + title +
                    " colNames:" + Arrays.toString(colNames) +
                    " colValues :" + Arrays.toString(colValues));*/
        mapKeyCache.put(mapKeyStr, res);
        return res;
    }
    
    private static Object[] parseMapKeyContainNegative(String mapKeyStr){
    	String newMapKeyStr = NEGATIVE_PATTERN.matcher(mapKeyStr).replaceAll(INDEX_KEY_DELIMITER + KEY_DELIMITER_3);
        String[] fields = newMapKeyStr.split(INDEX_KEY_DELIMITER);

        assert fields.length % 2 == 1;

        String title = fields[0];
        int cols = fields.length / 2;
        
        String[] colNames = new String[cols];
        String[] colValues = new String[cols];
        for (int i = 1; i < fields.length; i = i + 2) {
            colNames[i/2] = fields[i];
            
            String colValue = fields[i + 1];
            if(colValue.startsWith(KEY_DELIMITER_3)){
            	colValues[i/2] = colValue.replace(KEY_DELIMITER_3, INDEX_KEY_DELIMITER);
            }else{
            	colValues[i/2] = colValue;
            }
        }

        Object[] res = new Object[]{title, colNames, colValues};
        /*if (LOG.isDebugEnabled())
            LOG.debug("parseMapKey input :" + mapKeyStr + " title :" + title +
                    " colNames:" + Arrays.toString(colNames) +
                    " colValues :" + Arrays.toString(colValues));*/
        mapKeyCache.put(mapKeyStr, res);
        return res;
    }

    public List<ColsBean> getColsGroup() {
        return colsGroup;
    }

    public void setColsGroup(List<ColsBean> colsGroup) {
        this.colsGroup = colsGroup;
    }

    public Map<String, Integer> getColsMap() {
        return colsMap;
    }

    public void setColsMap(Map<String, Integer> colsMap) {
        this.colsMap = colsMap;
    }
}
