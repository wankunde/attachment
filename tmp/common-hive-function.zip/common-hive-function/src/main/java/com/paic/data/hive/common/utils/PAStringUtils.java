package com.paic.data.hive.common.utils;


import java.io.PrintStream;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;

public class PAStringUtils
{
  public static String ToSBC(String input)
  {
    char[] c = input.toCharArray();
    for (int i = 0; i < c.length; i++) {
      if (c[i] == ' ')
        c[i] = '　';
      else if (c[i] < '') {
        c[i] = ((char)(c[i] + 65248));
      }
    }

    return new String(c);
  }

  public static String ToDBC(String input)
  {
    char[] c = input.toCharArray();
    for (int i = 0; i < c.length; i++) {
      if (c[i] == '　')
        c[i] = ' ';
      else if ((c[i] > 65280) && (c[i] < 65375)) {
        c[i] = ((char)(c[i] - 65248));
      }
    }

    String returnString = new String(c);

    return returnString;
  }

  public static String repeatZero(String str, int fixedLength)
  {
    if (StringUtils.isEmpty(str)) {
      return null;
    }

    str = str.trim();
    if (str.length() == fixedLength)
      return str;
    if (str.length() > fixedLength) {
      return str.substring(str.length() - fixedLength);
    }
    int len = str.length();
    for (int i = 0; i < fixedLength - len; i++) {
      str = "0" + str;
    }

    return str;
  }

  public static String repeatZero(int numStr, int fixedLength)
  {
    String str = String.valueOf(numStr);
    return repeatZero(str, fixedLength);
  }

  public static String formatPartyNo(String partyno)
  {
    String ptno = partyno.replaceAll("[^0-9]", "");

    if (ptno.length() > 12) {
      String str = ptno.substring(ptno.length() - 12);
      return str;
    }if (ptno.length() < 12) {
      ptno = repeatZero(ptno, 12);
      return ptno;
    }
    return ptno;
  }

  /**public static boolean isHanzi(String hanziStr)
  {
    String regexpr = "[一-龥]+";
    Pattern p = Pattern.compile(regexpr);
    Matcher m = p.matcher(hanziStr);

    if (m.matches()) {
      return true;
    }
    return false;
  }

  public static boolean isHanzi(char hanziChar)
  {
    return isHanzi(String.valueOf(hanziChar));
  }*/

  public static int getNumDescAscCount(String telno)
  {
    return getDescAscCount(telno, true) > getDescAscCount(telno, false) ? getDescAscCount(telno, true) : getDescAscCount(telno, false);
  }

  private static int getDescAscCount(String telno, boolean isDesc) {
    int max = 0;
    if ((telno == null) || ("".equals(telno.trim()))) {
      return -1;
    }

    int count = 0;
    char[] tlc = telno.toCharArray();
    for (int i = 0; i < tlc.length - 1; i++) {
      if ((isDesc) && (tlc[i] - tlc[(i + 1)] == 1))
        count++;
      else if ((!isDesc) && (tlc[(i + 1)] - tlc[i] == 1)) {
        count++;
      }
      if (count > max) {
        max = count;
      }
    }

    return max;
  }

  public static int getNumCharCount(String telno)
  {
    if ((telno == null) || ("".equals(telno.trim()))) {
      return -1;
    }

    char[] tlc = telno.toCharArray();
    Set charset = new HashSet();
    putAll(charset, tlc);

    return charset.size();
  }

  public static Set putAll(Set destSet, char[] tlc)
  {
    for (int i = 0; i < tlc.length; i++) {
      destSet.add(Character.valueOf(tlc[i]));
    }

    return destSet;
  }

  public static int getNumMaxCharCount(String telno) {
    if ((telno == null) || ("".equals(telno.trim()))) {
      return -1;
    }

    char[] tlc = telno.toCharArray();
    int[] numCnts = new int[10];

    for (int i = 0; i < tlc.length; i++) {
      numCnts[(tlc[i] - '0')] += 1;
    }

    return NumberUtils.max(numCnts);
  }

  public static int getNumMaxConstantCount(String telno)
  {
    if ((telno == null) || ("".equals(telno.trim()))) {
      return -1;
    }

    char[] tlc = telno.toCharArray();
    char prior = '·';
    char curr = '·';

    int maxCnt = 1;
    int currCnt = 0;

    for (int i = 0; i < tlc.length; i++) {
      curr = tlc[i];
      if (curr == prior)
        currCnt++;
      else {
        currCnt = 0;
      }

      if (currCnt >= maxCnt) {
        maxCnt = currCnt;
      }

      prior = curr;
    }

    return maxCnt + 1;
  }

  public static String formatFullArabicStr(String numStr) {
    if (StringUtils.isEmpty(numStr)) {
      return numStr;
    }

    for (int i = 0; i < PAStringFullArabicStrConstant.specialNumbers[0].length; i++) {
      try {
        if (StringUtils.isNotEmpty(PAStringFullArabicStrConstant.specialNumbers[1][i]))
          numStr = numStr.replaceAll(PAStringFullArabicStrConstant.specialNumbers[1][i], PAStringFullArabicStrConstant.specialNumbers[0][i]);
      }
      catch (Exception e) {
        System.out.println("ERROR: " + numStr + "," + PAStringFullArabicStrConstant.specialNumbers[1][i] + ":" + PAStringFullArabicStrConstant.specialNumbers[0][i]);
      }
    }

    return numStr;
  }

  public static String substring2(String src, String splitstr, int startIndex, int endIndex, int thIndex) {
    if ((endIndex < startIndex) || (startIndex < 0) || (splitstr == null)) {
      return null;
    }

    src = src.substring(startIndex, endIndex);

    return substring2(src, splitstr, thIndex);
  }

  public static String substring2(String src, String splitstr, int thIndex) {
    if ((StringUtils.isEmpty(src)) || (splitstr == null)) {
      return src;
    }

    String[] srcStrs = src.split(splitstr);

    StringBuffer result = new StringBuffer();
    if ((srcStrs != null) && (srcStrs.length > thIndex)) {
      for (int i = 0; i < thIndex; i++) {
        result.append(srcStrs[i]).append(splitstr);
      }

      result.deleteCharAt(result.length() - 1);

      return result.toString();
    }

    return src;
  }

  public static void main(String[] args)
  {
    String str = "a,c,z,a,b,m,y,k,c,p,g,l,1,5,2,7,0";
    TreeSet data = new TreeSet();
    data.addAll(Arrays.asList(str.split(",")));

    StringBuilder sb = new StringBuilder();
    Iterator it = data.iterator();
    while (it.hasNext()) {
      sb.append((String)it.next());
    }
    System.out.println(data.toString());
    System.out.println(sb.toString());
  }
}