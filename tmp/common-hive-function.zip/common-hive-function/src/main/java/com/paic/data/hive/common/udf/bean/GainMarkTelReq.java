package com.paic.data.hive.common.udf.bean;

/**
 * Created by wangyi422 on 2018/3/22.
 */
public class GainMarkTelReq {
    private String sysID;
    private String userID;
    private int startIndex;
    private int endIndex;
    private String cipherText;
    private long timestamp;

    public GainMarkTelReq(String sysID, String userID, int startIndex, int endIndex, String cipherText, long timestamp) {
        this.sysID = sysID;
        this.userID = userID;
        this.startIndex = startIndex;
        this.endIndex = endIndex;
        this.cipherText = cipherText;
        this.timestamp = timestamp;
    }

    public String getSysID() {
        return sysID;
    }

    public String getUserID() {
        return userID;
    }

    public int getStartIndex() {
        return startIndex;
    }

    public int getEndIndex() {
        return endIndex;
    }

    public String getCipherText() {
        return cipherText;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setSysID(String sysID) {
        this.sysID = sysID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public void setStartIndex(int startIndex) {
        this.startIndex = startIndex;
    }

    public void setEndIndex(int endIndex) {
        this.endIndex = endIndex;
    }

    public void setCipherText(String cipherText) {
        this.cipherText = cipherText;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
}
