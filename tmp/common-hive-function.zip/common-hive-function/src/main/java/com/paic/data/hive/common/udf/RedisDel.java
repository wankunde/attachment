package com.paic.data.hive.common.udf;

import com.google.common.base.Joiner;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.exec.UDFArgumentLengthException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDF;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorConverters;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.io.Text;
import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.type.TypeFactory;
import org.codehaus.jackson.type.JavaType;
import redis.clients.jedis.JedisCluster;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by wankun603 on 2018-03-21.
 * <p>
 * Paic redis Client : mvn install:install-file -Dfile=D:\tmp\jedis-3.0.0-20180612.085950-1.jar -DgroupId=redis.clients -DartifactId=jedis -Dversion=3.0.0-SNAPSHOT -Dpackaging=jar
 */
@Description(name = "redis_del", value = "_FUNC_(cluster, key, startScore, endScore) _FUNC_(cluster, key, fields)  _FUNC_(cluster, key) - delete redis value by key ,key and score ,key and fields")
public class RedisDel extends GenericUDF {
  private transient ObjectInspectorConverters.Converter[] converters;

  @Override
  public ObjectInspector initialize(ObjectInspector[] arguments) throws UDFArgumentException {
    if (arguments.length == 2) {
      converters = new ObjectInspectorConverters.Converter[arguments.length];
      converters[0] = ObjectInspectorConverters.getConverter(arguments[0],
              PrimitiveObjectInspectorFactory.writableStringObjectInspector);
      converters[1] = ObjectInspectorConverters.getConverter(arguments[1],
              PrimitiveObjectInspectorFactory.writableStringObjectInspector);
    } else if (arguments.length == 3) {
      converters = new ObjectInspectorConverters.Converter[arguments.length];
      converters[0] = ObjectInspectorConverters.getConverter(arguments[0],
              PrimitiveObjectInspectorFactory.writableStringObjectInspector);
      converters[1] = ObjectInspectorConverters.getConverter(arguments[1],
              PrimitiveObjectInspectorFactory.writableStringObjectInspector);
      converters[2] = ObjectInspectorConverters.getConverter(arguments[2],
              PrimitiveObjectInspectorFactory.writableStringObjectInspector);
    } else if (arguments.length == 4) {
      converters = new ObjectInspectorConverters.Converter[arguments.length];
      converters[0] = ObjectInspectorConverters.getConverter(arguments[0],
              PrimitiveObjectInspectorFactory.writableStringObjectInspector);
      converters[1] = ObjectInspectorConverters.getConverter(arguments[1],
              PrimitiveObjectInspectorFactory.writableStringObjectInspector);
      converters[2] = ObjectInspectorConverters.getConverter(arguments[2],
              PrimitiveObjectInspectorFactory.writableStringObjectInspector);
      converters[3] = ObjectInspectorConverters.getConverter(arguments[3],
              PrimitiveObjectInspectorFactory.writableStringObjectInspector);
    } else
      throw new UDFArgumentLengthException(
              "The function _FUNC_(cluster, key, startScore, endScore) _FUNC_(cluster, key, fields)  _FUNC_(cluster, key) takes 2, 3 or 4 arguments.");

    return PrimitiveObjectInspectorFactory.writableStringObjectInspector;
  }

  @Override
  public Object evaluate(DeferredObject[] arguments) throws HiveException {
    String clusterId = (converters[0].convert(arguments[0].get())).toString();
    JedisCluster cluster = RedisUtils.initJedisCluster(clusterId);
    String key = (converters[1].convert(arguments[1].get())).toString();
    if (arguments.length == 2) {
      cluster.del(key);
      return new Text(key);
    } else if(arguments.length == 3) {
      if(arguments[2].get() == null)
        return null;

      String fieldsStr = (converters[2].convert(arguments[2].get())).toString();
      if(fieldsStr==null || fieldsStr.length()==0)
        return null;

      String[] fields = fieldsStr.split("`");
      cluster.hdel(key,fields);
      return new Text(key + "," + fieldsStr);
    } else if (arguments.length == 4) {
      String minScore = (converters[2].convert(arguments[2].get())).toString();
      String maxScore = (converters[3].convert(arguments[3].get())).toString();
      cluster.zremrangeByScore(key, minScore, maxScore);
      return new Text(key + "," + minScore + "," + maxScore);
    }
    return null;
  }

  @Override
  public String getDisplayString(String[] children) {
    return "redis_del(" + Joiner.on(",").join(children) + ")";
  }
}
