package com.paic.data.hive.common.udf.encrypt;

public interface Processor<T> {
	void process(T t);
}
