package com.paic.data.hive.common.udf;

import com.paic.data.hive.common.utils.date.DateUnit;

import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;

import java.text.ParseException;

/**
 * Created by GUSHENG005 on 2015-10-24.
 */
@Description(name = "dt_sub", value = "_FUNC_(YYYYMMDD, num, [D|W|M|Y]) - Returns a shifted dt")
public class DTSub extends UDF {
    public String evaluate(String dt, int diff, String unit) throws ParseException {
    	if(StringUtils.isEmpty(dt) == true){
			return null;
		}
    	
        return DateUnit.getInstance(unit).shift(dt, -1 * diff);
    }
}
