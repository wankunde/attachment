package com.paic.data.hive.common.udf.uds;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;

@Description(name = "uds_trim", value = "_FUNC_(String value) - Returns String")
public class UDS_Trim extends UDF {

	public String evaluate(String value) {
		if (value == null) {
			return "";
		}
		
		String v = value.trim();
		if (v.toLowerCase().equals("null")) {
			return "";
		} else {
			return v;
		}
	}
}
