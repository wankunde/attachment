package com.paic.data.hive.common.udf.profite;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.hive.common.type.HiveDecimal;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.parse.SemanticException;
import org.apache.hadoop.hive.ql.udf.generic.AbstractGenericUDAFResolver;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDAFEvaluator;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDAFParameterInfo;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.PrimitiveObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.StandardListObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.StructField;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorUtils;
import org.apache.hadoop.hive.serde2.typeinfo.TypeInfo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Created by wankun603 on 2018-06-21.
 */
@Description(name = "max_profite",
        value = "_FUNC_(dt, value) - Sort the value by dt and compute the max profite.\n")
public class MaxProfite extends AbstractGenericUDAFResolver {
  private static final Log LOG = LogFactory.getLog(MaxProfite.class.getName());

  @Override
  public GenericUDAFEvaluator getEvaluator(GenericUDAFParameterInfo paramInfo) throws SemanticException {
    TypeInfo[] parameters = paramInfo.getParameters();

    assert !paramInfo.isDistinct() : "DISTINCT not supported with *";
    assert !paramInfo.isAllColumns() : "Two argument are needed!";
    if (parameters.length != 2) {
      throw new UDFArgumentException("2 Argument expected");
    }
    return new MaxProfiteEvaluator();
  }

  @Override
  public GenericUDAFEvaluator getEvaluator(TypeInfo[] parameters) throws SemanticException {
    return new MaxProfiteEvaluator();
  }

  /**
   * GenericUDAFLooseEvaluator.
   */
  public static class MaxProfiteEvaluator extends GenericUDAFEvaluator {

    /**
     * class for storing count value.
     */
    @AggregationType(estimable = false)
    static class StocksBuf extends AbstractAggregationBuffer {
      List<String> dts;
      List<HiveDecimal> values;
      // TODO
//      public int estimate() { return JavaDataModel.; }
    }

    public static final String DTS_NAME = "dts";
    public static final String VALUES_NAME = "values";
    public static final String START_DT_NAME = "start_dt";
    public static final String END_DT_NAME = "end_dt";
    public static final String START_VALUE_NAME = "start_value";
    public static final String END_VALUE_NAME = "end_value";
    public static final String PROFITE_NAME = "profite";
    public static final String PROFITE_PERCENT_NAME = "profite_percent";

    private transient ObjectInspector[] poi;
    private transient StructObjectInspector soi;
    private transient Object[] partialResult;
    private transient Object[] result;

    private transient StructField dtField;
    private transient StandardListObjectInspector dtOI;

    private transient StructField valueField;
    private transient StandardListObjectInspector valueOI;

    @Override
    public ObjectInspector init(Mode m, ObjectInspector[] parameters)
            throws HiveException {
      super.init(m, parameters);

      if (m == Mode.PARTIAL1 || m == Mode.PARTIAL2) {
        this.poi = parameters;
        List<String> fname = Arrays.asList(DTS_NAME, VALUES_NAME);
        List<ObjectInspector> retOIs = Arrays.asList(
                (ObjectInspector) ObjectInspectorFactory.getStandardListObjectInspector(
                        PrimitiveObjectInspectorFactory.javaStringObjectInspector),
                ObjectInspectorFactory.getStandardListObjectInspector(
                        PrimitiveObjectInspectorFactory.javaHiveDecimalObjectInspector));
        return ObjectInspectorFactory.getStandardStructObjectInspector(fname, retOIs);
      } else {
        soi = (StructObjectInspector) parameters[0];

        dtField = soi.getStructFieldRef(DTS_NAME);
        dtOI = (StandardListObjectInspector) dtField.getFieldObjectInspector();

        valueField = soi.getStructFieldRef(VALUES_NAME);
        valueOI = (StandardListObjectInspector) valueField.getFieldObjectInspector();

        List<String> fname = Arrays.asList(START_DT_NAME,
                END_DT_NAME,
                START_VALUE_NAME,
                END_VALUE_NAME,
                PROFITE_NAME,
                PROFITE_PERCENT_NAME);
        List<ObjectInspector> retOIs = Arrays.asList(
                (ObjectInspector) PrimitiveObjectInspectorFactory.javaStringObjectInspector,
                PrimitiveObjectInspectorFactory.javaStringObjectInspector,
                PrimitiveObjectInspectorFactory.javaHiveDecimalObjectInspector,
                PrimitiveObjectInspectorFactory.javaHiveDecimalObjectInspector,
                PrimitiveObjectInspectorFactory.javaHiveDecimalObjectInspector,
                PrimitiveObjectInspectorFactory.javaHiveDecimalObjectInspector);
        return ObjectInspectorFactory.getStandardStructObjectInspector(fname, retOIs);
      }
    }

    @Override
    public AbstractAggregationBuffer getNewAggregationBuffer() throws HiveException {
      StocksBuf agg = new StocksBuf();
      reset(agg);
      return agg;
    }

    @Override
    public void reset(AggregationBuffer agg) throws HiveException {
      ((StocksBuf) agg).dts = new ArrayList<>();
      ((StocksBuf) agg).values = new ArrayList<>();
      partialResult = new Object[2];
      result = new Object[6];
    }

    @Override
    public void iterate(AggregationBuffer agg, Object[] parameters) throws HiveException {
      String dt = PrimitiveObjectInspectorUtils.getString(parameters[0], (PrimitiveObjectInspector) poi[0]);
      HiveDecimal value = PrimitiveObjectInspectorUtils.getHiveDecimal(parameters[1], (PrimitiveObjectInspector) poi[1]);
      if (dt != null && value != null) {
        ((StocksBuf) agg).dts.add(dt);
        ((StocksBuf) agg).values.add(value);
      }
    }

    @Override
    public Object terminatePartial(AggregationBuffer agg) throws HiveException {
      partialResult[0] = ((StocksBuf) agg).dts;
      partialResult[1] = ((StocksBuf) agg).values;
      return partialResult;
    }

    @Override
    public void merge(AggregationBuffer agg, Object partial) throws HiveException {
      List<String> dts = ((StocksBuf) agg).dts;
      List<HiveDecimal> values = ((StocksBuf) agg).values;

      List<Object> dt2 = (List<Object>) dtOI.getList(soi.getStructFieldData(partial, dtField));
      List<Object> values2 = (List<Object>) valueOI.getList(soi.getStructFieldData(partial, valueField));
      PrimitiveObjectInspector eoi;
      eoi = (PrimitiveObjectInspector) dtOI.getListElementObjectInspector();
      for (Object obj : dt2)
        dts.add(PrimitiveObjectInspectorUtils.getString(obj, eoi));
      eoi = (PrimitiveObjectInspector) valueOI.getListElementObjectInspector();
      for (Object obj : values2)
        values.add(PrimitiveObjectInspectorUtils.getHiveDecimal(obj, eoi));
    }

    @Override
    public Object terminate(AggregationBuffer agg) throws HiveException {
      List<String> dts = ((StocksBuf) agg).dts;
      List<HiveDecimal> values = ((StocksBuf) agg).values;
      List<ValueBean> list = new ArrayList<>(dts.size());
      for (int i = 0; i < dts.size(); i++) {
        if (dts.get(i) != null && values.get(i) != null)
          list.add(new ValueBean(dts.get(i), values.get(i)));
      }
      ValueBean[] res = maxProfite(list);
      if (res != null && res.length == 2) {
        result[0] = res[0].getDt();
        result[1] = res[1].getDt();
        result[2] = res[0].getValue();
        result[3] = res[1].getValue();
        result[4] = res[1].getValue().subtract(res[0].getValue());
        if (res[0].getValue().equals(HiveDecimal.ZERO))
          result[5] = HiveDecimal.ZERO;
        else
          result[5] = (res[1].getValue().subtract(res[0].getValue())).divide(res[0].getValue());
      }
      return result;
    }
  }

  private static class ValueBean {
    private String dt;
    private HiveDecimal value;

    public ValueBean(String dt, HiveDecimal value) {
      this.dt = dt;
      this.value = value;
    }

    public String getDt() {
      return dt;
    }

    public void setDt(String dt) {
      this.dt = dt;
    }

    public HiveDecimal getValue() {
      return value;
    }

    public void setValue(HiveDecimal value) {
      this.value = value;
    }

    @Override
    public String toString() {
      return "{" + dt + ":" + value + "}";
    }
  }

  public static ValueBean[] maxProfite(List<ValueBean> list) {
    if (list == null || list.size() == 0) {
      return null;
    } else if (list.size() == 1) {
      return new ValueBean[]{list.get(0), list.get(0)};
    }

    Collections.sort(list, new Comparator<ValueBean>() {
      @Override
      public int compare(ValueBean o1, ValueBean o2) {
        if (o1 == null || o1.dt == null)
          return -1;
        else if (o2 == null || o2.dt == null)
          return 1;
        else
          return o1.dt.compareTo(o2.dt);
      }
    });
    ValueBean min = null;
    ValueBean max = null;

    Boolean[] flags = new Boolean[list.size()];  // true 为高点  false 为低点  null 为过滤值

    for (int i = 0; i < list.size(); i++) {
      Boolean b1 = null;
      for (int j = i - 1; j >= 0; j--) {
        if (list.get(i).value.compareTo(list.get(j).value) == 0)
          continue;
        if (list.get(i).value.compareTo(list.get(j).value) > 0) {
          b1 = true;  // 之前上升
          break;
        }
        if (list.get(i).value.compareTo(list.get(j).value) < 0) {
          b1 = false;  // 之前下降
          break;
        }
      }

      Boolean b2 = null;
      for (int j = i + 1; j < list.size(); j++) {
        if (list.get(i).value.compareTo(list.get(j).value) == 0)
          continue;
        if (list.get(i).value.compareTo(list.get(j).value) > 0) {
          b2 = false;  // 之后下降
          break;
        }
        if (list.get(i).value.compareTo(list.get(j).value) < 0) {
          b2 = true;  // 之后上升
          break;
        }
      }
      if ((b1 == null || b1) && (b2 == null || !b2))
        flags[i] = true; // 高点
      if ((b1 == null || !b1) && (b2 == null || b2))
        flags[i] = false; // 低点
    }

    for (int i = 0; i < list.size(); i++) {
      if (flags[i] != null && flags[i] == false) {
        ValueBean min2 = list.get(i);
        ValueBean max2 = null;
        for (int j = i; j < list.size(); j++) {
          if (flags[j] != null && flags[j] == true && (max2 == null || list.get(j).value.compareTo(max2.getValue()) > 0)) {
            max2 = list.get(j);
          }
        }
        // 如果为最大涨幅，保存max,min
        if (min == null || max == null) {
          min = min2;
          max = max2;

        }
        if (max2 != null && max2.value.subtract(min2.value).compareTo(
                max.value.subtract(min.value)) > 0) {
          min = min2;
          max = max2;
        }
      }
    }

    if (max == null || min == null || max.value.subtract(min.value).compareTo(HiveDecimal.ZERO) <= 0) {
      HiveDecimal diff = HiveDecimal.create(BigDecimal.valueOf(Long.MIN_VALUE));

      for (int j = 0; j < list.size() - 1; j++) {
        if (list.get(j + 1).value.subtract(list.get(j).value).compareTo(diff) > 0) {
          min = list.get(j);
          max = list.get(j + 1);
          diff = max.value.subtract(min.value);
        }
      }
    }
    return new ValueBean[]{min, max};
  }
}
