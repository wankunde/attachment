package com.paic.data.hive.common.udtf.otcBayesLogRecovery2;

import java.util.ArrayList;
import java.util.List;

public class Instance {
	int index;
	List<Double> column = new ArrayList<Double>();
	public Instance(int index,List<Double> column)
	{
		this.index = index;
		this.column = column;
	}
}
