package com.paic.data.hive.common.udf.template.node.func;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.paic.data.hive.common.udf.template.TNode;
import com.paic.data.hive.common.udf.template.TPushData;
import com.paic.data.hive.common.udf.template.TUserData;
import com.paic.data.hive.common.udf.template.node.TFuncNode;




public class TDateFuncNode extends TFuncNode {
	
	private final TNode otext;
	private final TNode ofmt;
	private final TNode fmt;
	
	public TDateFuncNode(TNode fmt) {
		this(null, null, fmt);
	}
	
	public TDateFuncNode(TNode otext, TNode ofmt, TNode fmt) {
		this.otext = otext;
		this.ofmt = ofmt;
		this.fmt = fmt;
	}

	@Override
	public void params(Collection<String> params) {
		if (otext != null) otext.params(params);
	}
	
	@Override
	public void toString(StringBuffer output, String channel, TUserData userData, TPushData pushData) {
		Date date = null;
		if (otext != null) {
			try {
				date = getFormat(ofmt.toString(channel, userData, pushData)).parse(otext.toString(channel, userData, pushData));
			} catch (ParseException e) {
				throw new IllegalArgumentException("Invalid date format!");
			}
		} else {
			date = new Date();
		}
		output.append(getFormat(fmt.toString(channel, userData, pushData)).format(date));
	}
	
	// format cache
	private static final Map<String, DateFormat> fmts = new ConcurrentHashMap<String, DateFormat>();
	private static DateFormat getFormat(String fmt) {
		DateFormat ret = fmts.get(fmt);
		if (ret == null) {
			ret = new SimpleDateFormat(fmt);
			fmts.put(fmt, ret);
		}
		return ret;
	}
}
