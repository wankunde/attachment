package com.paic.data.hive.common.udf.template;

import java.util.Map;


public class TUserData {

	public String um = null;
	public String mobile = null;
	private String vmobile = null;
	public String userId = null;
	public String userCode = null;
	public String wxBindDate = null;
	public String wxFollowDate = null;
	public String riskLvl = null;
	public Map<String, String> params = null;
	public Map<String, Object> inputs = null;
	
	public String getUser(boolean maskMobile) {
		if (maskMobile && mobile != null && mobile.length() > 7) {
			return mobile.substring(0, 3) + "****" + mobile.substring(7);
		}
		return mobile != null ? mobile : userId != null ? userId : userCode != null ? userCode : um != null ? um : "未知";
	}
	
	public Object getParam(String name) {
		Object value = null;
		if (params != null && value == null) {
			value = params.get(name);
		}
		if (inputs != null && value == null) {
			value = inputs.get(name);
		}
		return value;
	}
	
	public String getVMobile() {
		if (vmobile == null && mobile != null && mobile.length() >= 11) {
			vmobile = mobile;
			int pos = vmobile.indexOf("86-");
			if (pos >= 0) {
				vmobile = vmobile.substring(pos+3);
			}
			vmobile = vmobile.replace("-", "").trim();
			if (vmobile.length() > 11) {
				vmobile = vmobile.substring(vmobile.length() - 11);
			}
			if (vmobile.length() != 11 || vmobile.startsWith("1") == false) {
				vmobile = "";
			}
		}
		return vmobile != null && vmobile.isEmpty() == false ? vmobile : null;
	}
}
