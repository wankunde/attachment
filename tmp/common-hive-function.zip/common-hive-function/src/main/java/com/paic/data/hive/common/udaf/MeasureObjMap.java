package com.paic.data.hive.common.udaf;

import com.paic.data.hive.common.udf.MeasureUtil;
import com.paic.data.hive.common.udf.bean.ColsGroupsExtBean;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDAF;
import org.apache.hadoop.hive.ql.exec.UDAFEvaluator;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDAFEvaluator;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.paic.data.hive.common.udf.MeasureUtil.KEY_DELIMITER_3;
import static com.paic.data.hive.common.udf.MeasureUtil.KEY_EXTENDS_TIME;
import static com.paic.data.hive.common.udf.MeasureUtil.INDEX_KEY_DELIMITER;

/**
 * Created by WANKUN603 on 2016-06-29.
 */
@Description(name = "measure_obj_map",
        value = "_FUNC_(dt,trdTime,indexGroups,measureGroups,parameters) - return today init value,last value.")
public class MeasureObjMap extends UDAF {

    private static final Log LOG = LogFactory.getLog(MeasureObjMap.class);

    @GenericUDAFEvaluator.AggregationType(estimable = true)
    public static class StringMapBean extends GenericUDAFEvaluator.AbstractAggregationBuffer {
        public Map<String, String> value;
    }

    public static class MeasureObjMapEvaluator implements UDAFEvaluator {

        StringMapBean countAgg;
        ColsGroupsExtBean colsGroupsExtBean;

        public MeasureObjMapEvaluator() {
            super();
            countAgg = new StringMapBean();
            init();
        }

        @Override
        public void init() {
            countAgg.value = new HashMap<>();
        }

//        public boolean iterate(String dt, Long trdTime, String indexGroups, String measureGroups, String types, Object... parameters) {
//            if (trdTime == null)
//                trdTime = 0l;
//            return doIterate(String.valueOf(trdTime), indexGroups, measureGroups, types, parameters);
//        }

        public boolean iterate(String dt, String trdTime, String indexGroups, String measureGroups, String types, Object... parameters) {
            if (trdTime == null ||
                    (trdTime != null && trdTime.toLowerCase().equals("null")))
                trdTime = "0";
            return doIterate(trdTime, indexGroups, measureGroups, types, parameters);
        }

        private boolean doIterate(String trdTime, String indexGroups, String measureGroups, String types, Object... parameters) {
            if (colsGroupsExtBean == null) {
                indexGroups = indexGroups.toLowerCase();
                measureGroups = measureGroups.toLowerCase();
                colsGroupsExtBean = ColsGroupsExtBean.getColsGroupBean(indexGroups, measureGroups);
            }

            List<String> mapKeys = null;
            mapKeys = colsGroupsExtBean.getMapKeys(colsGroupsExtBean.getIndexs(), measureGroups, types, parameters);

//            LOG.debug("mapKeys : " + mapKeys);
            Map<String, String> row = new HashMap<>();
            for (String mapKey : mapKeys) {
                if (mapKey.startsWith(KEY_EXTENDS_TIME)) {
                    row.put(mapKey, trdTime);
                } else {
                    String tmp = mapKey.substring(0, mapKey.length() - 5);
                    int p = tmp.indexOf(INDEX_KEY_DELIMITER);
                    p = p == -1 ? tmp.length() : p;
                    String indexName = tmp.substring(0, p);
                    Integer indexIdx = colsGroupsExtBean.getColsMap().get(indexName);
                    row.put(new String(mapKey), parameters[indexIdx] == null ? null : String.valueOf(parameters[indexIdx]));
                }
            }

//            LOG.debug("before :" + this + "\t" + countAgg.value.size());
            countAgg.value = MeasureUtil.mergeExtMap(countAgg.value, row);
//            LOG.debug("after :" + this + "\t" + countAgg.value.size());
//            LOG.debug("countAgg.value : " + countAgg.value);
            if (countAgg.value != null)
                return true;
            else
                return false;
        }


        public boolean merge(StringMapBean o) {
//            LOG.debug("merging map : ");
            countAgg.value = MeasureUtil.mergeExtMap(countAgg.value, o.value);
            return true;
        }

        public StringMapBean terminatePartial() {
            return countAgg;
        }

        public Map<String, String> terminate() {
            colsGroupsExtBean = null;
            return countAgg.value;
        }
    }

}
