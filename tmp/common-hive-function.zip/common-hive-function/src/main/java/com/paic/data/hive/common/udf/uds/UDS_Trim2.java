package com.paic.data.hive.common.udf.uds;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;

@Description(name = "uds_trim2", value = "_FUNC_(String value) - Returns String")
public class UDS_Trim2 extends UDF {

	public String evaluate(String value) {
		if (value == null) {
			return null;
		}
		
		String v = value.trim();
		if (v.equalsIgnoreCase("") || v.toLowerCase().equals("null")) {
			return null;
		} else {
			return v;
		}
	}
}
