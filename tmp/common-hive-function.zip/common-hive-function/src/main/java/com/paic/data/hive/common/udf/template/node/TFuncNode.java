package com.paic.data.hive.common.udf.template.node;

public abstract class TFuncNode extends TVarNode {

}
