package com.paic.data.hive.common.udf;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.io.IOUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

@Description(name = "ip_parser2",
        value = "_FUNC_(ip) - Returns a map which contains information of the input ip ")
public class IpParser2 extends UDF {
    private static final Log logger = LogFactory.getLog(IpParser2.class);

    private static final String FILE_URI = "hdfs:///metadata/dim/ipip.datx";

    private static byte[] ipData;
    private static long indexSize;

    private static synchronized String loadIpData() {
        if (ipData != null) {
            return "Had Loaded";
        }

        String errMsg = "Load Success";

        FSDataInputStream in = null;
        BufferedReader reader = null;
        try {
            Configuration conf = new Configuration();
            FileSystem hdfs = FileSystem.get(URI.create(FILE_URI), conf);
            Path path = new Path(FILE_URI);
            FileStatus fs = hdfs.getFileStatus(path);

            if (fs.getLen() < Integer.MAX_VALUE) {
                ipData = new byte[(int) fs.getLen()];
                in = hdfs.open(path);
                in.readFully(ipData);

                indexSize = Util.bytesToLong(ipData[0], ipData[1], ipData[2], ipData[3]);
            } else {
                errMsg = "Ip File is too large";
                throw new Exception(errMsg);
            }
        } catch (IOException e) {
            logger.error(e);
            ipData = null;
            errMsg = e.getMessage();
        } catch (Exception e) {
            logger.error(e);
            ipData = null;
            errMsg = e.getMessage();
        } finally {
            IOUtils.closeStream(in);
        }
        return errMsg;
    }

    public Map<String, String> evaluate(String ipValue) {
        Map<String,String> map = new HashMap<String, String>();
        if (ipData == null) {
            String errMsg = loadIpData();
            if (ipData == null) {
                map.put("error", errMsg);
                return map;
            }
        }

        if (ipData != null && Util.isIPv4Address(ipValue)) {
            long val = Util.ip2long(ipValue);
            int start = 262148;
            int low = 0;
            int mid = 0;
            int high = new Long((indexSize - 262144 - 262148) / 9).intValue() - 1;
            int pos = 0;
            while (low <= high)
            {
                mid = new Double((low + high) / 2).intValue();
                pos = mid * 9;

                long s = 0;
                if (mid > 0)
                {
                    int pos1 = (mid - 1) * 9;
                    s = Util.bytesToLong(ipData[start + pos1], ipData[start + pos1+1], ipData[start + pos1+2], ipData[start + pos1+3]);
                }

                long end = Util.bytesToLong(ipData[start + pos], ipData[start + pos+1], ipData[start + pos+2], ipData[start + pos+3]);
                if (val > end) {
                    low = mid + 1;
                } else if (val < s) {
                    high = mid - 1;
                } else {

                    byte b =0;
                    long off = Util.bytesToLong(b, ipData[start+pos+6],ipData[start+pos+5],ipData[start+pos+4]);
                    long len = Util.bytesToLong(b, b, ipData[start+pos+7], ipData[start+pos+8]);

                    int offset = new Long(off - 262144 + indexSize).intValue();

                    byte[] loc = Arrays.copyOfRange(ipData, offset, offset+new Long(len).intValue());

                    String[] values = new String(loc, Charset.forName("UTF-8")).split("\t", -1);

                    if (values.length >= 1) {
                    	map.put("country","局域网".equals(values[0])?"":values[0]);
                    }
                    if (values.length >= 2) {
                    	map.put("province","局域网".equals(values[1])?"":values[1]);
                    }
                    if (values.length >= 3) {
                    	map.put("city",values[2]);
                    }
                    if (values.length >= 4) {
                    	map.put("ips",values[3]);
                    }
                    break;
                }
            }
        } else {
            if (ipData == null) {
                map.put("error", "Data NOT Loaded");
            }
        }
        return map;
    }


    public static class Util {
        private static final Pattern IPV4_PATTERN = Pattern.compile("^(([1-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\\.){1}(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\\.){2}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$");

        public static boolean isIPv4Address(String input) {
            return IPV4_PATTERN.matcher(input).matches();
        }

        public static long bytesToLong(byte a, byte b, byte c, byte d) {
            return int2long((((a & 0xff) << 24) | ((b & 0xff) << 16) | ((c & 0xff) << 8) | (d & 0xff)));
        }

        private static int str2Ip(String ip)  {
            String[] ss = ip.split("\\.");
            int a, b, c, d;
            a = Integer.parseInt(ss[0]);
            b = Integer.parseInt(ss[1]);
            c = Integer.parseInt(ss[2]);
            d = Integer.parseInt(ss[3]);
            return (a << 24) | (b << 16) | (c << 8) | d;
        }

        public static int str2Ip2(String ip)  {
            try {
                byte[] bytes = java.net.InetAddress.getByName(ip).getAddress();

                return ((bytes[0] & 0xFF) << 24) |
                        ((bytes[1] & 0xFF) << 16) |
                        ((bytes[2] & 0xFF) << 8) |
                        bytes[3];
            } catch (java.net.UnknownHostException e) {
                e.printStackTrace();
            }
            return 0;
        }


        public static long ip2long(String ip)  {
            return int2long(str2Ip(ip));
        }

        private static long int2long(int i) {
            long l = i & 0x7fffffffL;
            if (i < 0) {
                l |= 0x080000000L;
            }
            return l;
        }
    }
}
