package com.paic.data.hive.common.udf;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.FsUrlStreamHandlerFactory;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.io.IOUtils;

import com.cloudera.org.apache.http.ParseException;
import com.paic.data.hive.common.udf.bean.SettleResult;
import com.paic.data.hive.common.udf.bean.SettleResult.AcctType;
import com.paic.data.hive.common.udf.bean.SettleRule;
import com.paic.data.hive.common.udf.bean.SettleRule.SecondSettle;
import com.paic.data.hive.common.udf.bean.SettleRule.SecuSettleDoorSill;
import com.paic.data.hive.common.utils.JsonUtil;
import com.paic.data.hive.common.utils.date.DateUnit;

/**
 * @author TIANHUI868
 * @date 2016年7月28日
 */
@Description(name = "settle", value = "_FUNC_(map, month, preResult) - Returns map contain settle result")
public class Settle extends UDF {
	//protected static final Logger logger = LoggerFactory.getLogger(Settle.class);
	public final static String DIVISION_ID = "division_id";
	public final static String UNIFY_AID = "unify_aid";
	public final static String UNIFY_SID = "unify_sid";
	
	public final static String OMM_DIVISION_ID = "omm_division_id";
	public final static String OMM_UNIFY_AID = "omm_unify_aid";
	public final static String OMM_UNIFY_SID = "omm_unify_sid";
	
	public final static String ASSET_ACCT_DATE = "main_open_date";
	public final static String SHA_ACCT_DATE = "sha_open_date";
	public final static String SZA_ACCT_DATE = "sza_open_date";
	public final static String OMM_ACCT_DATE = "pama_open_date";
	
	public final static String MON_SECU_AMT = "match_amt_trade_cls_1_30n_sum";
	public final static String MON_FUND_AMT = "trd_fund_amt_cls_a566_trd_dir_i_30n_sum";
	public final static String MON_OTC_AMT = "trd_fund_amt_src_id_otc_trd_dir_i_30n_sum";
	public final static String MON_MAX_AMT = "all_aum_30n_max";
	
	public final static String ACCU_SECU_AMT = "accu_match_amt_trade_cls_1_30n_sum";
	public final static String ACCU_OTC_AMT = "accu_trd_fund_amt_src_id_otc_trd_dir_i_30n_sum";
	
	public final static String MON_SECU_COMMISSION = "settle_fee_trade_cls_1_30n_sum";
	public final static String MON_FUND_COMMISSION = "fund_charge_fee_cls_a566_trd_dir_i_30n_sum";
	public final static String MON_OTC_COMMISSION = "fund_charge_fee_src_id_otc_trd_dir_i_30n_sum";
	
	public final static String ALL_TRANSFER_12 = "all_transfer_in_12m_sum";
	
	private Integer convertInteger(String value){
		Integer i = null;
        if(!StringUtils.isEmpty(value)){
        	i = Integer.valueOf(value);
        } 
        
        return i;
	}
	
	private Double convertDouble(String value){
		Double i = null;
        if(!StringUtils.isEmpty(value)){
        	i = Double.valueOf(value);
        } 
        
        return i;
	}
	
   public Map<String, String> evaluate(Map<String, String> params, Integer month, 
    		Map<String, String> preResult) throws ParseException, HiveException, IOException, java.text.ParseException {
	   try {
		   Integer monthFirstDay = month *100 + 1;
		   //logger.info("start:" + JsonUtil.writeEntity2Json(mapRules));
	        loadSettleRules(monthFirstDay.toString());
	        //logger.info("start:" + JsonUtil.writeEntity2Json(mapRules));
	        Integer divisionId = convertInteger(params.get(DIVISION_ID));
	        Integer aid = convertInteger(params.get(UNIFY_AID));
	        Integer sid = convertInteger(params.get(UNIFY_SID));

	        Integer ommDivisionId = convertInteger(params.get(OMM_DIVISION_ID));
	        Integer ommAid = convertInteger(params.get(OMM_UNIFY_AID));
	        Integer ommSid = convertInteger(params.get(OMM_UNIFY_SID));
	        
	        if (divisionId == null && ommDivisionId == null) {
	            return null;
	        }

	        Integer assetAcctDate = convertInteger(params.get(ASSET_ACCT_DATE));
	        Integer shaAcctDate = convertInteger(params.get(SHA_ACCT_DATE)); 
	        Integer szaAcctDate = convertInteger(params.get(SZA_ACCT_DATE));  
	        Integer ommAcctDate = convertInteger(params.get(OMM_ACCT_DATE)); 
	        
	        Double monSecuAmt = convertDouble(params.get(MON_SECU_AMT)) ;
	        //Double accuSecuAmt = convertDouble(params.get(ACCU_SECU_AMT));
	        //Double accuOverAmt = convertDouble(params.get(ACCU_OVER_AMT)); 
	        Double monMaxAmt = convertDouble(params.get(MON_MAX_AMT));
	        
//	        Double monFundAmt = (Double) params.get(MON_FUND_AMT);
//	        Double monOtcAmt = (Double) params.get(MON_OTC_AMT);
	        Double accuOtcAmt = convertDouble(params.get(ACCU_OTC_AMT));
	        
	        
	        Double monSecuCommission = convertDouble(params.get(MON_SECU_COMMISSION));
	        Double monFundCommission = convertDouble(params.get(MON_FUND_COMMISSION)); 
	        Double monOtcCommission = convertDouble(params.get(MON_OTC_COMMISSION));

	        Double allTransferIn12mSum = convertDouble(params.get(ALL_TRANSFER_12));
	        
	        Integer preOpenSecuSettleDate = convertInteger(preResult.get(SettleResult.OPEN_SECU_SETTLE_DATE)); 
	        
	        Integer preOpenOmmSettleDate = convertInteger(preResult.get(SettleResult.OPEN_OMM_SETTLE_DATE));
	        
	        Integer preAssetMaxSettleDate = convertInteger(preResult.get(SettleResult.AWARD_ASSET_MAX_SETTLE_DATE));
	        
	        Integer preOmmTradeSettleDate = convertInteger(preResult.get(SettleResult.AWARD_OMM_TRADE_SETTLE_DATE));
	        
	        Map<String, String> mapResult = new HashMap<>();//作为返回结果
	        if (divisionId != null) {//股东账号结算
	            SettleRule rule = getRule(divisionId, aid, sid);//股东户的规则
	           // logger.info("start rule:" + JsonUtil.writeEntity2Json(rule));
	            if (rule != null  && preOpenSecuSettleDate == null		//未结算过的股东开户用户
	            		&& rule.getAcctType().contains(AcctType.secu_two.getValue()) //股东双户 FIXME:以后需要考虑单户
	            		&& rule.getOpenStartDate() / 100 <= month && rule.getOpenEndDate() / 100 >= month //结算月在规则内
	            		&& rule.getOpenFeeSecu() != null && rule.getOpenFeeSecu() > 0	//有股东开户费用
	                    && shaAcctDate != null && szaAcctDate != null			//双户齐全 
	                    && Math.max(shaAcctDate, szaAcctDate) / 100 <= month	//双户齐全日，小于等于结算月。
	                    && assetAcctDate >= rule.getOpenStartDate() 
	                    && rule.getSecuSettleDoorsill() != null && !rule.getSecuSettleDoorsill().isEmpty() //选择了股东户结算
	                    ) {//股东户开户结算
	            	Integer maxSecuDate = Math.max(shaAcctDate, szaAcctDate);
	            	List<SecuSettleDoorSill> secuDoorSills = rule.getSecuSettleDoorsill();
	                if (secuDoorSills.size() == 1 && secuDoorSills.get(0).getType() == 1) {//双户条件
	                    if (Math.max(shaAcctDate, szaAcctDate) / 100 == month) {
	                        mapResult.put(SettleResult.OPEN_FEE_SECU, rule.getOpenFeeSecu().toString());
	                        mapResult.put(SettleResult.OPEN_SECU_SETTLE_DATE, maxSecuDate.toString());
	                    }
	                } else {
	                    for (SecuSettleDoorSill dsill : secuDoorSills) {//只要满足一个条件即可
	                    	Integer judgeDay = null;
	                    	if(dsill.getDay() != null && dsill.getDay() != 0){//为null或0，不做天数判断
	                    		judgeDay = Integer.valueOf(DateUnit.getInstance("D").shift(monthFirstDay.toString(), -1 * dsill.getDay()));
	                    	}
	                    	
	                    	if(judgeDay != null && maxSecuDate < judgeDay){//满足n天 条件
	                    		continue;
	                    	}
	                    	
	                        if (dsill.getType().equals(2) && monSecuAmt != null && allTransferIn12mSum >= dsill.getAmt()) {//有股票交易
	                        	mapResult.put(SettleResult.OPEN_FEE_SECU_TRADE, rule.getOpenFeeSecu().toString());
	                            mapResult.put(SettleResult.OPEN_SECU_SETTLE_DATE, maxSecuDate.toString());
	                            break;
	                        } else if (dsill.getType().equals(3) && monMaxAmt != null && monMaxAmt > dsill.getAmt() ) {//资产峰值
	                        	 mapResult.put(SettleResult.OPEN_FEE_SECU_MAX, rule.getOpenFeeSecu().toString());
	                             mapResult.put(SettleResult.OPEN_SECU_SETTLE_DATE, monthFirstDay.toString());
	                             break;
	                        } else if (dsill.getType().equals(4) &&allTransferIn12mSum != null && allTransferIn12mSum > dsill.getAmt()) {//入金
	                        	mapResult.put(SettleResult.OPEN_FEE_SECU_OVER, rule.getOpenFeeSecu().toString());
	                            mapResult.put(SettleResult.OPEN_SECU_SETTLE_DATE, monthFirstDay.toString());
	                            break;
	                       	}
	                    }
	                }
	            }
	            //logger.info("asset settle rule:" + JsonUtil.writeEntity2Json(rule));
	            //logger.info("asset settle data:" + preOpenSecuSettleDate+ " " + mapResult + " " + allTransferIn12mSum);
	            if (rule != null  && preAssetMaxSettleDate == null && !mapResult.containsKey(SettleResult.OPEN_SECU_SETTLE_DATE)//未结算过的资金开户用户
	            		&& rule.getOpenStartDate() / 100 <= month && rule.getOpenEndDate() / 100 >= month //结算月在规则内
	            		&& rule.getOpenFeeAsset() != null && rule.getOpenFeeAsset() > 0	//有资金开户结算费用
	            		&& assetAcctDate >= rule.getOpenStartDate() 
	            		&& rule.getAssetSettleDoorsill() != null //选择了资金结算
	                    ) {//资金户开户结算
	            	
	            	if( rule.getAssetSettleDoorsill() == 0){ //为0 表示没有门槛
	            		if( assetAcctDate/100  == month) {
	            			mapResult.put(SettleResult.OPEN_FEE_ASSET, rule.getOpenFeeAsset().toString());//股东和资金户，只结一个
	                		mapResult.put(SettleResult.OPEN_SECU_SETTLE_DATE,  assetAcctDate.toString());
	            		}
	            	} else if (accuOtcAmt >= rule.getAssetSettleDoorsill() ){//产品购买大于门槛值。
	            		mapResult.put(SettleResult.OPEN_FEE_ASSET, rule.getOpenFeeAsset().toString());//股东和资金户，只结一个
	            		mapResult.put(SettleResult.OPEN_SECU_SETTLE_DATE,  monthFirstDay.toString());
	            	}
	            }
	            
	            if(preOpenSecuSettleDate == null && mapResult.containsKey(SettleResult.OPEN_SECU_SETTLE_DATE)){
	            	preOpenSecuSettleDate = Integer.valueOf(mapResult.get(SettleResult.OPEN_SECU_SETTLE_DATE));
	            }
	                        
	            if (rule != null  && preOpenSecuSettleDate != null  //已经结算过的股东或资金开户用户
	            		&& assetAcctDate > rule.getCustStartDate()//参与分佣的用户开户开始日期
	            		&&  rule.getCommissionType() != null && rule.getCommissionType().contains(1) //有股票分佣设置
	            		) {//股票分佣统计
	            	Integer judgeDay = Integer.valueOf(DateUnit.getInstance("D").shift(monthFirstDay.toString(), -1 * rule.getCommissionYear()*365));
	            	if(assetAcctDate>judgeDay && monSecuCommission != null ){
	            		Double commission = monSecuAmt*rule.getCommissionRatio();
	            		Double value = (monSecuCommission-commission)/2.0;
	            		mapResult.put(SettleResult.COMMISSION_SECU, monSecuCommission.toString());
	            		mapResult.put(SettleResult.COMMISSION_FEE_SECU, value.toString());
	            	}
	            }
	            
	            if (rule != null  && preOpenSecuSettleDate != null  //已经结算过的股东或资金开户用户
	            		&& assetAcctDate > rule.getCustStartDate()//参与分佣的用户开户开始日期
	            		&&  rule.getCommissionType() != null && rule.getCommissionType().contains(2) //有基金分佣设置
	            		) {//基金分佣统计
	        		Double value = monFundCommission/2.0;
	        		mapResult.put(SettleResult.COMMISSION_FEE_FUND, value.toString());
	            }
	            
	            if (rule != null  && preOpenSecuSettleDate != null  //已经结算过的股东或资金开户用户
	            		&& assetAcctDate > rule.getCustStartDate()//参与分佣的用户开户开始日期
	            		&&  rule.getCommissionType() != null && rule.getCommissionType().contains(4) //有基金分佣设置
	            		) {//基金分佣统计
	        		Double value = monOtcCommission/2.0;
	        		mapResult.put(SettleResult.COMMISSION_FEE_OTC, value.toString());
	            }
	            
	            //TODO:二轮结算
	            if(rule != null && preAssetMaxSettleDate == null && rule.getSecondSettle() != null){
	            	List<SecondSettle> secondSettles =  rule.getSecondSettle();
	            	for (SecondSettle secondSettle : secondSettles) {//FIXME:现在只管金融界的峰值结算。合同期三年内峰值超过1w
						if(secondSettle.getType() == 4 && monMaxAmt>=secondSettle.getAmt() 
								&& shaAcctDate != null && szaAcctDate != null			//双户齐全 
								&& preOpenSecuSettleDate != null
								){
							mapResult.put(SettleResult.AWARD_ASSET_MAX_SETTLE_DATE, monthFirstDay.toString());
							mapResult.put(SettleResult.AWARD_ASSET_MAX, secondSettle.getFee().toString());
						}
					}
	            }
	        }
	        
	        
	        if (ommDivisionId != null) {//理财账号结算
	        	  SettleRule ommRule = getRule(ommDivisionId, ommAid, ommSid);//理财户规则
	        	//logger.info("omm start:" + JsonUtil.writeEntity2Json(ommRule));
	        	  //理财户和股东户 开户结算有优先级。如果prior=1，做了股东户，就不能做理财户。prior为0，分开结算
	        	  if (ommRule != null  && preOpenOmmSettleDate == null 
	        			  && (ommRule.getSecuPrior() == 0 || preOpenSecuSettleDate == null)//股东户优先情况下，未结算过的股东或资金开户用户。无优先，分开结算
	        			  && ommRule.getOpenStartDate() / 100 <= month && ommRule.getOpenEndDate() / 100 >= month //结算月在规则内
	        			  && ommRule.getOpenFeeOmm() != null && ommRule.getOpenFeeOmm() > 0	//有理财开户结算费用
	        			  && ommRule.getOmmSettleDoorsill() != null //选择了理财结算
	        			  && accuOtcAmt >= ommRule.getOmmSettleDoorsill() //产品购买大于门槛值。为0 表示没有门槛
	        			  ) {//理财户开户结算
	        		  mapResult.put(SettleResult.OPEN_FEE_OMM, ommRule.getOpenFeeOmm().toString());
	        		  mapResult.put(SettleResult.OPEN_OMM_SETTLE_DATE, monthFirstDay.toString());
	        		  
	        		  if( ommRule.getOmmSettleDoorsill() == 0){ //为0 表示没有门槛
	        			  if( ommAcctDate/100  == month) {
	              			mapResult.put(SettleResult.OPEN_FEE_OMM, ommRule.getOpenFeeOmm().toString());
	                  		mapResult.put(SettleResult.OPEN_OMM_SETTLE_DATE,  ommAcctDate.toString());
	        			  }
	        		  } else if (accuOtcAmt >= ommRule.getOmmSettleDoorsill()){//产品购买大于门槛值。
	        			  mapResult.put(SettleResult.OPEN_FEE_OMM, ommRule.getOpenFeeOmm().toString());
	        			  mapResult.put(SettleResult.OPEN_OMM_SETTLE_DATE,  monthFirstDay.toString());
	        		  }
	        	  }
	        	  
	        	  if (ommRule != null && preOpenOmmSettleDate != null
	        			&& preOpenOmmSettleDate > ommRule.getCustStartDate()//参与分佣的用户开户开始日期
	              		&&  ommRule.getCommissionType() != null && ommRule.getCommissionType().contains(2) //有基金分佣设置
	              		&& !mapResult.containsKey(SettleResult.COMMISSION_FEE_FUND)//未做基金分佣
	              		) {//基金分佣统计
	          		  Double value = monFundCommission/2.0;
	        		  mapResult.put(SettleResult.COMMISSION_FEE_FUND, value.toString());
	              }
	        	  
	        	  if (ommRule != null  && preOpenOmmSettleDate != null
	        			&& preOpenOmmSettleDate > ommRule.getCustStartDate()//参与分佣的用户开户开始日期
	                	&&  ommRule.getCommissionType() != null && ommRule.getCommissionType().contains(4) //有产品分佣设置
	                	&& !mapResult.containsKey(SettleResult.COMMISSION_FEE_OTC)//产品分佣
	                		) {//产品分佣统计
	        		  Double value = monOtcCommission/2.0;
	          		  mapResult.put(SettleResult.COMMISSION_FEE_OTC, value.toString());
	              }
	        	  
	        	//理财户二轮结算
	        	  if(ommRule != null && preOmmTradeSettleDate == null && ommRule.getSecondSettle() != null){
		            	List<SecondSettle> secondSettles =  ommRule.getSecondSettle();
		            	for (SecondSettle secondSettle : secondSettles) {
							if(secondSettle.getType() == 3 && allTransferIn12mSum>=secondSettle.getAmt() 
									&& (mapResult.containsKey(SettleResult.OPEN_OMM_SETTLE_DATE) || preOpenOmmSettleDate != null)//理财户		
									){
								mapResult.put(SettleResult.AWARD_OMM_TRADE_SETTLE_DATE, monthFirstDay.toString());
								mapResult.put(SettleResult.AWARD_OMM_TRADE, secondSettle.getFee().toString());
							}
						}
		            }
	        }

	        return mapResult;
	} catch (Exception e) {
		//logger.info("",e);
		throw e;
	}
	   
	  
    }  
    public static void main(String[] argc) throws Exception{
    	Map<String, Object> map = new HashMap<>();
    	map.put("abc", 1L);
    	map.put("bc", 1.1d);
    	map.put("a", null);
    	System.out.println(map);
    	
    	Long i = (Long) map.get("abc");
    	System.out.println(i);
    	Double d = (Double) map.get("dddd");
    	System.out.println(d);
    	System.out.println(DateUnit.getInstance("D").shift("20160600", -1 * 1));
    }

    private static Integer DEFAULT_ID = -100;

    private static SettleRule getRule(Integer divisionId, Integer aid, Integer sid) {
    	if(divisionId == null){//可能理财户渠道和股东户渠道有一个为null
    		return null;
    	}
    	
        Map<Integer, Map<Integer, SettleRule>> mapAidRule = mapRules.get(divisionId);
        if (mapAidRule == null) {
            return null;
        }

        Map<Integer, SettleRule> mapSidRule = mapAidRule.get(aid);
        if (mapSidRule == null) {
            Map<Integer, SettleRule> mapDefaultSidRule = mapAidRule.get(DEFAULT_ID);
            if (mapDefaultSidRule == null) {
                return null;
            }

            return mapDefaultSidRule.get(DEFAULT_ID);
        }

        SettleRule rule = mapSidRule.get(sid);
        if (rule == null) {
            rule = mapSidRule.get(DEFAULT_ID);
        }

        return rule;
    }

    public static Map<Integer, Map<Integer, Map<Integer, SettleRule>>> mapRules = null;

    
    public static Map<Integer, Map<Integer, Map<Integer, SettleRule>>> getMapRules() {
		return mapRules;
	}

	public static void setMapRules(Map<Integer, Map<Integer, Map<Integer, SettleRule>>> mapRules) {
		Settle.mapRules = mapRules;
	}

	/**
     *
     * @param dt 月末日期 yyyyMMdd
     * @throws HiveException
     * @throws IOException
     */
    public synchronized static void loadSettleRules(String dt) throws HiveException, IOException {
        if (mapRules == null || mapRules.isEmpty()) {
            List<SettleRule> rules = new ArrayList<>();
            try {
                URL.setURLStreamHandlerFactory(new FsUrlStreamHandlerFactory());
            } catch (Throwable e) {
                //ignore
            }

            Configuration conf = new Configuration();
            String uri = "hdfs:///user/hive/warehouse/raw.db/dspsettle_settle_rule/dt=" + dt + "/000000_0";
            FSDataInputStream in = null;
            BufferedReader reader = null;
            try {
                FileSystem hdfs = FileSystem.get(URI.create(uri), conf);
                in = hdfs.open(new Path(uri));
                reader = new BufferedReader(new InputStreamReader(in));
                String line;
                while ((line = reader.readLine()) != null) {
                	int i=0;
                	String[] cols = line.split("\u0001");
                	//logger.info("own:" + JsonUtil.writeEntity2Json(cols));
                	SettleRule rule = new SettleRule();
                	
                	rule.setRuleId(Integer.valueOf(cols[i++]));
                
                	rule.setDivisionId(Integer.valueOf(cols[i++]));
                	i++;
                	
                	if(!StringUtils.isEmpty(cols[i]) && !"\\N".equals(cols[i])){
                		rule.setUnifyAid(Integer.valueOf(cols[i++]));
                	} else {
                		i++;
                	}
                	
                	i++;
                	
                	if(!StringUtils.isEmpty(cols[i]) && !"\\N".equals(cols[i])){
                		rule.setUnifySid(Integer.valueOf(cols[i++]));
                	} else {
                		i++;
                	}
                	
                	i++;
                	
                	if(!StringUtils.isEmpty(cols[i]) && !"\\N".equals(cols[i])){
                		rule.setAcctType(JsonUtil.readJson2List(cols[i++], Integer.class));
                	} else {
                		i++;
                	}
                	
                	if(!StringUtils.isEmpty(cols[i]) && !"\\N".equals(cols[i]) && !"null".equals(cols[i]) ){
                		rule.setSecuPrior(Integer.valueOf(cols[i++]));
                	} else {
                		i++;
                	}

                	rule.setAppendUrl(cols[i++]);
                	rule.setStatus(Integer.valueOf(cols[i++]));
                	
                	rule.setOpenStartDate(Integer.valueOf(cols[i++]));
                	rule.setOpenEndDate(Integer.valueOf(cols[i++]));
                	
                	if(!StringUtils.isEmpty(cols[i]) && !"\\N".equals(cols[i])){
                		rule.setSecuSettleDoorsill(JsonUtil.readJson2List(cols[i++], SecuSettleDoorSill.class));
                	} else {
                		i++;
                	}
                	
                	if(!StringUtils.isEmpty(cols[i]) && !"\\N".equals(cols[i])){
                		rule.setAssetSettleDoorsill(Integer.valueOf(cols[i++]));
                	} else {
                		i++;
                	}
                	
                	if(!StringUtils.isEmpty(cols[i]) && !"\\N".equals(cols[i])){
                		rule.setOmmSettleDoorsill(Integer.valueOf(cols[i++]));
                	} else {
                		i++;
                	}
                	
                	if(!StringUtils.isEmpty(cols[i]) && !"\\N".equals(cols[i])){
                		rule.setOpenFeeSecu(Integer.valueOf(cols[i++]));
                	} else {
                		i++;
                	}
                	
                	if(!StringUtils.isEmpty(cols[i]) && !"\\N".equals(cols[i])){
                		rule.setOpenFeeAsset(Integer.valueOf(cols[i++]));
                	} else {
                		i++;
                	}
                	
                	if(!StringUtils.isEmpty(cols[i]) && !"\\N".equals(cols[i])){
                		rule.setOpenFeeOmm(Integer.valueOf(cols[i++]));
                	} else {
                		i++;
                	}
                	
                	i++;
                	
                	if(!StringUtils.isEmpty(cols[i]) && !"\\N".equals(cols[i])){
                		rule.setCommissionStartDate(Integer.valueOf(cols[i++]));
                	} else {
                		i++;
                	}
                	
                	if(!StringUtils.isEmpty(cols[i]) && !"\\N".equals(cols[i])){
                		rule.setCustStartDate(Integer.valueOf(cols[i++]));
                	} else {
                		i++;
                	}
                	
                	if(!StringUtils.isEmpty(cols[i]) && !"\\N".equals(cols[i])){
                		rule.setCommissionType(JsonUtil.readJson2List(cols[i++], Integer.class));
                	} else {
                		i++;
                	}
                	
                	if(!StringUtils.isEmpty(cols[i]) && !"\\N".equals(cols[i])){
                		rule.setCommissionYear(Integer.valueOf(cols[i++]));
                	} else {
                		i++;
                	}
                	
                	if(!StringUtils.isEmpty(cols[i]) && !"\\N".equals(cols[i])){
                		rule.setCommissionRatio(Double.valueOf(cols[i++]));
                	} else {
                		i++;
                	}
                	
                	if(!StringUtils.isEmpty(cols[i]) && !"\\N".equals(cols[i])){
                		rule.setSecondStartDate(Integer.valueOf(cols[i++]));
                	} else {
                		i++;
                	}
                	
                	if(!StringUtils.isEmpty(cols[i]) && !"\\N".equals(cols[i])){
                		rule.setSecondEndDate(Integer.valueOf(cols[i++]));
                	} else {
                		i++;
                	}
                	if(!StringUtils.isEmpty(cols[i]) && !"\\N".equals(cols[i])){
                		rule.setSecondSettle(JsonUtil.readJson2List(cols[i++], SecondSettle.class));
                	} else {
                		i++;
                	}
                    rules.add(rule);
                }
            } finally {
                IOUtils.closeStream(in);
            }
           // logger.info("own:" + JsonUtil.writeEntity2Json(rules));
            mapRules = convert2Map(rules);

        }
    }

    private static Map<Integer, Map<Integer, Map<Integer, SettleRule>>> convert2Map(List<SettleRule> rules) {
        Map<Integer, Map<Integer, Map<Integer, SettleRule>>> mapRules = new HashMap<>();
        for (SettleRule rule : rules) {
            if (rule.getStatus() == 0) {
                continue;
            }

            if (rule.getUnifyAid() == null) {
                rule.setUnifyAid(DEFAULT_ID);
            }

            if (rule.getUnifySid() == null) {
                rule.setUnifySid(DEFAULT_ID);
            }

            Map<Integer, Map<Integer, SettleRule>> mapAidRules = mapRules.get(rule.getDivisionId());
            Map<Integer, SettleRule> mapSidRules = null;
            if (mapAidRules == null) {
                mapAidRules = new HashMap<>();
                mapRules.put(rule.getDivisionId(), mapAidRules);
            } else {
                mapSidRules = mapAidRules.get(rule.getUnifyAid());
            }

            if (mapSidRules == null) {
                mapSidRules = new HashMap<>();
                mapAidRules.put(rule.getUnifyAid(), mapSidRules);
            }

            mapSidRules.put(rule.getUnifySid(), rule);

        }

        return mapRules;
    }
}
