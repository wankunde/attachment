package com.paic.data.hive.common.udf;

import com.google.common.base.Joiner;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.MapredContext;
import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.exec.UDFArgumentLengthException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.session.SessionState;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDF;
import org.apache.hadoop.hive.serde2.objectinspector.*;
import org.apache.hadoop.io.BooleanWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapreduce.Counter;
import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.Pipeline;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import static org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory.writableBooleanObjectInspector;
import static org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory.writableStringObjectInspector;


/**
 * Created by wankun603 on 2018-03-21.
 * <p>
 * Paic redis Client : mvn install:install-file -Dfile=D:\tmp\jedis-3.0.0-20180612.085950-1.jar -DgroupId=redis.clients -DartifactId=jedis -Dversion=3.0.0-SNAPSHOT -Dpackaging=jar
 */
@Description(name = "redis_hmset", value = "_FUNC_(cluster, key, array(string), expireTime,delKey) - set kv to redis cluster")
public class RedisHmset extends GenericUDF {
  private static final Log LOG = LogFactory.getLog(RedisHmset.class);

  private transient ObjectInspectorConverters.Converter[] converters;

  private transient StructObjectInspector soi;
  private transient List<String> fieldNames;
  private transient List<ObjectInspector> fieldInspectors;
  private transient List<ObjectInspectorConverters.Converter> fieldConverters;

  private transient MapObjectInspector moi;
  private transient PrimitiveObjectInspector mkeyoi;
  private transient PrimitiveObjectInspector mvalueoi;

  private transient ObjectInspector expireIo;

  private volatile transient int emitNumbers = 0;

  private volatile transient Long rowsPerSecond;

  private transient Long start;
  private transient Boolean hasStart = false;
  private volatile transient Long records;
  private transient Integer parallel = 1;

  @Override
  public ObjectInspector initializeAndFoldConstants(ObjectInspector[] arguments) throws UDFArgumentException {
    return super.initializeAndFoldConstants(arguments);
  }

  @Override
  public void configure(MapredContext context) {
    Configuration conf = context.getJobConf();
    rowsPerSecond = conf.getLong("redis.writer.rowsPerSecond", 100000);
    start = System.currentTimeMillis();
    super.configure(context);
  }

  @Override
  public ObjectInspector initialize(ObjectInspector[] arguments) throws UDFArgumentException {
    if (arguments.length == 5) {
      converters = new ObjectInspectorConverters.Converter[arguments.length];
      converters[0] = ObjectInspectorConverters.getConverter(arguments[0], writableStringObjectInspector);
      converters[1] = ObjectInspectorConverters.getConverter(arguments[1], writableStringObjectInspector);
      if (arguments[2] instanceof StructObjectInspector) {
        soi = (StructObjectInspector) arguments[2];
        fieldNames = new ArrayList<>();
        fieldInspectors = new ArrayList<>();
        fieldConverters = new ArrayList<>();
        for (StructField sf : soi.getAllStructFieldRefs()) {
          fieldNames.add(sf.getFieldName());
          fieldInspectors.add(sf.getFieldObjectInspector());
          fieldConverters.add(ObjectInspectorConverters.getConverter(sf.getFieldObjectInspector(), writableStringObjectInspector));
        }
      } else if (arguments[2] instanceof MapObjectInspector) {
        moi = (MapObjectInspector) arguments[2];
        mkeyoi = (PrimitiveObjectInspector) moi.getMapKeyObjectInspector();
        mvalueoi = (PrimitiveObjectInspector) moi.getMapValueObjectInspector();
      }

      expireIo = arguments[3];
      converters[4] = ObjectInspectorConverters.getConverter(arguments[4], writableBooleanObjectInspector);
    } else
      throw new UDFArgumentLengthException(
          "The function redis_hmset(cluster, key, array(string), expireTime,delKey) takes 5 arguments.");

    return ObjectInspectorFactory.getStandardListObjectInspector(writableStringObjectInspector);
  }


  @Override
  public Object evaluate(DeferredObject[] arguments) throws HiveException {
    String clusterId = (converters[0].convert(arguments[0].get())).toString();
    String key = (converters[1].convert(arguments[1].get())).toString();

    JedisCluster jedisCluster = RedisUtils.initJedisCluster(clusterId);
    Pipeline pipeline = (SessionState.get() != null && SessionState.get().getMapRedStats().size() == 0)
        ? null : RedisUtils.getPipeline(key);
    BooleanWritable delKey = (BooleanWritable) (converters[4].convert(arguments[4].get()));

    if (delKey.get())
      if (pipeline != null)
        pipeline.del(key);
      else
        jedisCluster.del(key);

    ArrayList<Text> result = new ArrayList<>();
    Map<String, String> map = new HashMap<>();
    if (soi != null) {
      List structObjs = soi.getStructFieldsDataAsList(arguments[2].get());
      for (int i = 0; i < fieldNames.size(); i++) {
        String field = fieldNames.get(i);
        if (structObjs.get(i) != null && fieldConverters.get(i) != null) {
          PrimitiveObjectInspector poi = (PrimitiveObjectInspector) fieldInspectors.get(i);
          Object obj = poi.getPrimitiveJavaObject(structObjs.get(i));
          formatKV(key, result, map, field, obj);
        }
      }
    } else {
      Map<? extends Object, ? extends Object> omap = moi.getMap(arguments[2].get());
      for (Map.Entry en : omap.entrySet()) {
        String field = mkeyoi.getPrimitiveJavaObject(en.getKey()).toString();
        Object obj = mvalueoi.getPrimitiveJavaObject(en.getValue());
        formatKV(key, result, map, field, obj);
      }
    }

    if (pipeline != null)
      pipeline.hmset(key, map);
    else
      jedisCluster.hmset(key, map);

    Long expire = RedisUtils.parseExpire(arguments[3], expireIo);
    if (expire != null)
      if (pipeline != null)
        pipeline.expireAt(key, expire);
      else
        jedisCluster.expireAt(key, expire);

    if (pipeline != null && emitNumbers++ > 10000) {
      RedisUtils.syncPipeline();
      emitNumbers = 0;
    }

    if (MapredContext.get() != null && MapredContext.get().getReporter() != null) {
      MapredContext context = MapredContext.get();
      if (!hasStart) {
        Iterator<Map.Entry<String, String>> jobConfIter = context.getJobConf().iterator();
        while(jobConfIter.hasNext()) {
          Map.Entry<String, String> en = jobConfIter.next();
          LOG.info(en.getKey()+" : "+en.getValue());
        }
        if(context.isMap()) {
          parallel = context.getJobConf().getNumMapTasks();
        } else {
          parallel = context.getJobConf().getNumReduceTasks();
        }
        hasStart = true;
      }

      Counter recordsCounter = MapredContext.get().getReporter().getCounter(RedisUtils.REDIS_WRITER_GROUP, RedisUtils.REDIS_WRITER_RECOREDS);
      recordsCounter.increment(1L);
      records = recordsCounter.getValue();
    } else
      records = records + 1;

    Long ts = 1000L * records / rowsPerSecond / parallel;

    Long cost = System.currentTimeMillis() - start;
    LOG.info("redisWriters : " + parallel);
    LOG.info("ts : " + ts);
    LOG.info("worker sleep : " + (ts - cost));
    if (ts > cost) {
      try {
        Thread.currentThread().sleep(ts - cost);
      } catch (InterruptedException e) {
        e.printStackTrace();
      }
    }
    return result;
  }

  private void formatKV(String key, ArrayList<Text> result, Map<String, String> map, String field, Object obj) {
    if (obj == null)
      obj = "";

    String value;
    if (obj instanceof Double) {
      value = formatDouble((Double) obj);
    } else
      value = obj.toString();
    map.put(field, value);
    result.add(new Text(key + "->" + field + ":" + value));

  }

  private static final DecimalFormat df = new DecimalFormat("##0");

  /**
   * Double to String format
   *
   * @param d
   * @return
   */
  public static String formatDouble(Double d) {
    if (d == null)
      return "";
    else if (d % 10 == 0)
      return df.format(d);
    else
      return BigDecimal.valueOf(d).toString();
  }

  @Override
  public String getDisplayString(String[] children) {
    return "redis_hmset(" + Joiner.on(",").join(children) + ")";
  }

  @Override
  public void close() throws IOException {
    super.close();
    RedisUtils.close();
  }
}
