package com.paic.data.hive.common.udf;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.exec.UDFArgumentLengthException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDF;
import org.apache.hadoop.hive.serde2.objectinspector.MapObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.StringObjectInspector;
import org.apache.hadoop.io.Text;

import java.util.HashMap;
import java.util.Map;

@Description(name = "replace_map",
        value = "_FUNC_(map,src1,dest1,src2,dest2...) - Returns map.Replace string src in map key string using dest")
public class ReplaceMap extends GenericUDF {

    private static final Log LOG = LogFactory.getLog(ReplaceMap.class);

    MapObjectInspector mapOI;
    StringObjectInspector textOI;

    @Override
    public ObjectInspector initialize(ObjectInspector[] arguments) throws UDFArgumentException {
        if (arguments.length % 2 != 1) {
            throw new UDFArgumentLengthException("_FUNC_ must have odd arguments: Map<String, T>, String,String...");
        }
        // 1. Check we received the right object types.
        ObjectInspector c1 = arguments[0];
        ObjectInspector c2 = arguments[1];

        if (!(c1 instanceof MapObjectInspector)
                || !(c2 instanceof StringObjectInspector)) {
            throw new UDFArgumentException("argument type error");
        }
        this.mapOI = (MapObjectInspector) c1;
        this.textOI = (StringObjectInspector) c2;

        return ObjectInspectorFactory.getStandardMapObjectInspector(
                mapOI.getMapKeyObjectInspector(),
                mapOI.getMapValueObjectInspector()
        );
    }

    @Override
    public Object evaluate(DeferredObject[] arguments) throws HiveException {
        Map map = this.mapOI.getMap(arguments[0].get());
        String[] parameters = new String[arguments.length - 1];

        for (int i = 0; i < parameters.length; i++) {
            parameters[i] = this.textOI.getPrimitiveJavaObject(arguments[i + 1].get());
        }
        return doReplace(map, parameters);
    }

    @Override
    public String getDisplayString(String[] args) {
        return "replace map key ";
    }


    private <K, T> Map<K, T> doReplace(Map<K, T> map, String... parameters) {
        Map<K, T> res = new HashMap<>();
        if (map == null)
            return map;
        for (K key : map.keySet()) {
            String newKey = key.toString();
            if (parameters.length > 0 && parameters.length % 2 == 0) {
                for (int i = 0; i < parameters.length; i = i + 2) {
                    if (StringUtils.isNotBlank(parameters[i + 1]))
                        newKey = newKey.replaceAll(parameters[i], parameters[i + 1]);
                }
            }
            if (key instanceof String)
                res.put((K) newKey, map.get(key));
            else if (key instanceof Text)
                res.put((K) new Text(newKey), map.get(key));
            LOG.debug("new map: " + res);
        }
        return res;
    }
}
