package com.paic.data.hive.common.udf.encrypt;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegExProcessor implements Processor<String> {
	private Pattern pattern;
	private final Callback<String> callback;

	public RegExProcessor(String regex, Callback<String> callback) {
		super();
		this.callback = callback;
		this.pattern = Pattern.compile(regex);
	}

	public void process(String t) {
		Matcher m = pattern.matcher(t);
		int pstart = 0;
		while (m.find(pstart)) {
			String s = t.substring(pstart, m.start());
			if (s.length() != 0) {
				callback.process(s);
			}
			callback.process(m.group());
			pstart = m.end();
			if (pstart >= t.length()) {
				break;
			}
		}
		if (pstart < t.length()) {
			String s = t.substring(pstart);
			if (s.length() != 0)
				callback.process(s);
		}
	}

	public static void main(String[] args) {
		new RegExProcessor("[a-z]+", new Callback<String>() {

			public void process(String t) {
				System.out.println(t);
			}
		}).process("abc123abc3234defabc23 adf2 df a 212 a 12");
	}

}
