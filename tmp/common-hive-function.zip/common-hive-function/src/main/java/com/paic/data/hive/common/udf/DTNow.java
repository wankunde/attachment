package com.paic.data.hive.common.udf;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;

import com.paic.data.hive.common.udf.date.DTNowBase;
import com.paic.data.hive.common.udf.date.NowDayEnd;
import com.paic.data.hive.common.udf.date.NowDayStart;
import com.paic.data.hive.common.udf.date.NowMonthEnd;
import com.paic.data.hive.common.udf.date.NowMonthStart;
import com.paic.data.hive.common.udf.date.NowWeekEnd;
import com.paic.data.hive.common.udf.date.NowWeekStart;
import com.paic.data.hive.common.udf.date.NowYearEnd;
import com.paic.data.hive.common.udf.date.NowYearStart;

@Description(name = "dt_now", value = "_FUNC_(YYYYMMDD, num, [D|W|M|Y], [S|E]) - Returns a shifted dt")
public class DTNow extends UDF {
	
	private Map<String, DTNowBase> udfs = new HashMap<String, DTNowBase>();
	
	public DTNow() {
		udfs.put("DS", new NowDayStart());
		udfs.put("DE", new NowDayEnd());
		udfs.put("WS", new NowWeekStart());
		udfs.put("WE", new NowWeekEnd());
		udfs.put("MS", new NowMonthStart());
		udfs.put("ME", new NowMonthEnd());
		udfs.put("YS", new NowYearStart());
		udfs.put("YE", new NowYearEnd());
	}
	
    public String evaluate(String format, int diff, String unit, String type) throws ParseException {
    	DTNowBase dt = udfs.get((unit + type).toUpperCase());
    	if (dt != null) {
    		return dt.evaluate(format, diff);
    	}
    	return null;
    }
}
