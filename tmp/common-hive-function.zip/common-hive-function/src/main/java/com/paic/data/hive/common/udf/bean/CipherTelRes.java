package com.paic.data.hive.common.udf.bean;

/**
 * Created by wangyi422 on 2018/3/22.
 */
public class CipherTelRes {
    private int retCode;
    private String retMsg = null;
    private String cipherText = null;

    public CipherTelRes() {
    }

    public int getRetCode() {
        return retCode;
    }

    public String getRetMsg() {
        return retMsg;
    }

    public String getCipherText() {
        return cipherText;
    }

    public void setRetCode(int retCode) {
        this.retCode = retCode;
    }

    public void setRetMsg(String retMsg) {
        this.retMsg = retMsg;
    }

    public void setCipherText(String cipherText) {
        this.cipherText = cipherText;
    }
}
