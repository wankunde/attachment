package com.paic.data.hive.common.udf.date;

import java.text.ParseException;

public interface DTNowBase {
	public String evaluate(String format, int diff) throws ParseException;
}
