package com.paic.data.hive.common.udf.profite;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.hive.common.type.HiveDecimal;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.parse.SemanticException;
import org.apache.hadoop.hive.ql.udf.generic.AbstractGenericUDAFResolver;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDAFEvaluator;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDAFParameterInfo;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.PrimitiveObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorUtils;
import org.apache.hadoop.hive.serde2.typeinfo.TypeInfo;

import java.math.BigDecimal;

/**
 * Created by wankun603 on 2018-06-14.
 */
@Description(name = "all_profite_rate",
        value = "_FUNC_(profite) - \n")
public class AllProfiteRate extends AbstractGenericUDAFResolver {
  private static final Log LOG = LogFactory.getLog(AllProfiteRate.class.getName());

  @Override
  public GenericUDAFEvaluator getEvaluator(GenericUDAFParameterInfo paramInfo) throws SemanticException {
    TypeInfo[] parameters = paramInfo.getParameters();

    assert !paramInfo.isDistinct() : "DISTINCT not supported with *";
    assert !paramInfo.isAllColumns() : "One argument are needed!";
    if (parameters.length != 1) {

      throw new UDFArgumentException("Argument expected");
    }
    return new AllProfiteRateEvaluator();
  }

  @Override
  public GenericUDAFEvaluator getEvaluator(TypeInfo[] parameters) throws SemanticException {
    return new AllProfiteRateEvaluator();
  }

  public static class AllProfiteRateEvaluator extends GenericUDAFEvaluator {

    /**
     * class for storing count value.
     */
    @AggregationType(estimable = false)
    static class ProfiteRateBuf extends AbstractAggregationBuffer {
      HiveDecimal value;
    }

    private transient ObjectInspector[] poi;

    @Override
    public ObjectInspector init(Mode m, ObjectInspector[] parameters) throws HiveException {
      super.init(m, parameters);
      this.poi = parameters;
      return PrimitiveObjectInspectorFactory.javaHiveDecimalObjectInspector;
    }

    @Override
    public AbstractAggregationBuffer getNewAggregationBuffer() throws HiveException {
      ProfiteRateBuf buf = new ProfiteRateBuf();
      reset(buf);
      return buf;
    }

    @Override
    public void reset(AggregationBuffer buf) throws HiveException {
//      LOG.info("reset buf value : " + ((ProfiteRateBuf) buf).value);
      ((ProfiteRateBuf) buf).value = HiveDecimal.ONE;
    }

    @Override
    public void iterate(AggregationBuffer buf, Object[] parameters) throws HiveException {
      HiveDecimal values2 = PrimitiveObjectInspectorUtils.getHiveDecimal(parameters[0], (PrimitiveObjectInspector) poi[0]);
      // LOG.info("iterate value : " + ((ProfiteRateBuf) buf).value + "  values2: " + values2);
      if (((ProfiteRateBuf) buf).value.multiply(values2.add(HiveDecimal.ONE)) == null)
        throw new HiveException("ArithmeticExecption 位数溢出! value 1 : " + ((ProfiteRateBuf) buf).value +
                " value 2 : " + values2);
      ((ProfiteRateBuf) buf).value = ((ProfiteRateBuf) buf).value.multiply(values2.add(HiveDecimal.ONE))
              .setScale(10, BigDecimal.ROUND_HALF_UP);
    }

    @Override
    public Object terminatePartial(AggregationBuffer buf) throws HiveException {
//      LOG.debug("terminatePartial value : " + ((ProfiteRateBuf) buf).value);
      return ((ProfiteRateBuf) buf).value;
    }

    @Override
    public void merge(AggregationBuffer buf, Object partial) throws HiveException {
      if (partial != null) {
        HiveDecimal values2 = PrimitiveObjectInspectorUtils.getHiveDecimal(partial, (PrimitiveObjectInspector) poi[0]);
        if (((ProfiteRateBuf) buf).value.multiply(values2) == null)
          throw new HiveException("ArithmeticExecption 位数溢出! value 1 : " + ((ProfiteRateBuf) buf).value +
                  " value 2 : " + values2);
        ((ProfiteRateBuf) buf).value = ((ProfiteRateBuf) buf).value.multiply(values2)
                .setScale(10, BigDecimal.ROUND_HALF_UP);
      }
    }

    @Override
    public Object terminate(AggregationBuffer buf) throws HiveException {
//      LOG.info("terminate value : " + ((ProfiteRateBuf) buf).value);
      return ((ProfiteRateBuf) buf).value.subtract(HiveDecimal.ONE);
    }
  }
}
