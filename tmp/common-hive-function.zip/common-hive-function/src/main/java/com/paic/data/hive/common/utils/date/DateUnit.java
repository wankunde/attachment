package com.paic.data.hive.common.utils.date;

import org.apache.commons.lang3.time.DateUtils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by GUSHENG005 on 2015-10-24.
 */
public enum DateUnit {
    D {
        @Override
        protected int toCalendarUnit() {
            return Calendar.DATE;
        }
    },

    W {
        @Override
        protected int toCalendarUnit() {
            return Calendar.WEEK_OF_MONTH;
        }
    },

    M {
        @Override
        protected int toCalendarUnit() {
            return Calendar.MONTH;
        }
    },

    Y {
        @Override
        protected int toCalendarUnit() {
            return Calendar.YEAR;
        }
    };

    abstract protected int toCalendarUnit();

    public static DateUnit getInstance(String unit) {
        return DateUnit.valueOf(unit.toUpperCase());
    }

    private static DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
    private static Calendar calendar = Calendar.getInstance();

    public String shift(String dt, int diff) throws ParseException {
        Date date = DateUtils.parseDate(dt,"yyyyMMdd");
        synchronized (calendar) {
            calendar.setTime(date);
            calendar.add(this.toCalendarUnit(), diff);
            date = calendar.getTime();
        }
        return dateFormat.format(date);
    }
}
