package com.paic.data.hive.common.udf.template;

public class TSellData {

	public boolean isSellTemplate;
	public boolean hasSellUrl;
	public boolean isOriginSms = false;
}
