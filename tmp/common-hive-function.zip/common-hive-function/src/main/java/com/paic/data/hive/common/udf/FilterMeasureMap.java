package com.paic.data.hive.common.udf;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;

import com.paic.data.hive.common.utils.ReadDimFileUtil;

/**
 * @author shidawen768
 *
 */
@Description(name = "filter_measure_map", value = "_FUNC_(Map<String, Double>, curKey, period) - "
		+ "Returns partial values, period:Current,Week,Month,Quarter,Year")
public class FilterMeasureMap extends UDF {

	private static Map<String, Set<String>> INCLUDE_INDEX_EXTEND = null;

	public Map<String, Double> evaluate(Map<String, Double> indexNumber, String curKey, String period)
			throws IOException {
		if (indexNumber == null || indexNumber.isEmpty()) {
			return indexNumber;
		}

		if (period == null || StringUtils.isEmpty(period)) {
			throw new RuntimeException("period is null or empty");
		}
		Period tmpPeriod = Period.valueOfIgnoreCase(period);
		if (tmpPeriod == Period.Action) {
			throw new RuntimeException("period=Action, please call evaluate(Map<String,String>, curKey)");
		}

		this.loadIncludeIndexExtend();
		Set<String> includeIndexSet = INCLUDE_INDEX_EXTEND.get(curKey);

		Map<String, Double> data = new HashMap<>();
		for (Map.Entry<String, Double> entry : indexNumber.entrySet()) {
			if (includeIndexSet == null) {
				if (tmpPeriod.match(entry.getKey()) == true) {
					data.put(entry.getKey(), entry.getValue());
				}
			} else {
				if (includeIndexSet.contains(entry.getKey().toLowerCase()) == true) { // FIX 20170706 : 所有扩展指标名匹配都使用小写匹配
					data.put(entry.getKey(), entry.getValue());
				}
			}
		}

		return data;
	}

	public Map<String, String> evaluate(Map<String, String> indexIL, String curKey) throws IOException {
		if (indexIL == null || indexIL.isEmpty()) {
			return indexIL;
		}

		Period tmpPeriod = Period.Action;

		this.loadIncludeIndexExtend();
		Set<String> includeIndexSet = INCLUDE_INDEX_EXTEND.get(curKey);

		Map<String, String> data = new HashMap<>();
		for (Map.Entry<String, String> entry : indexIL.entrySet()) {
			if (includeIndexSet == null) {
				if (tmpPeriod.match(entry.getKey()) == true) {
					data.put(entry.getKey(), entry.getValue());
				}
			} else {
				if (includeIndexSet.contains(entry.getKey().toLowerCase()) == true) { // FIX 20170706 : 所有扩展指标名匹配都使用小写匹配
					data.put(entry.getKey(), entry.getValue());
				}
			}
		}

		return data;
	}

	private synchronized void loadIncludeIndexExtend() throws IOException {
		if (INCLUDE_INDEX_EXTEND == null) {
			Map<String, Set<String>> data = ReadDimFileUtil.getIndexNameAndExtendName();

			INCLUDE_INDEX_EXTEND = data;
		}
	}

	static enum Period {
		Current(".*"), Week("[-_a-zA-Z0-9&$]+(7n_sum|7n_avg|7n_tavg|7n_max|7n_min)$"), Month(
				"[-_a-zA-Z0-9&$]+(30n_sum|30n_avg|30n_tavg|30n_max|30n_min)$"), Quarter(
						"[-_a-zA-Z0-9&$]+(90n_sum|90n_avg|90n_tavg|90n_max|90n_min)$"), Year(
								"[-_a-zA-Z0-9&$]+(360n_sum|360n_avg|360n_tavg|360n_max|360n_min)$"), Action(
										"[-_a-zA-Z0-9]+(init|last|curt)$");

		private final Pattern pattern;

		private Period(String regex) {
			this.pattern = Pattern.compile(regex);
		}

		public boolean match(String key) {
			return this.pattern.matcher(key).matches();
		}

		public static Period valueOfIgnoreCase(String item) {
			for (Period entry : values()) {
				if (entry.name().equalsIgnoreCase(item)) {
					return entry;
				}
			}

			throw new RuntimeException("Unsupported type:" + item);
		}

	}

}
