package com.paic.data.hive.common.udf.encrypt;

import java.text.ParseException;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.tools.ant.Evaluable;

@Description(name = "uds_encrypt", value = "_FUNC_(raw content) - Returns encrypt content")
public class UDSEncrypter extends UDF {

    public String evaluate(String content) throws ParseException {
        return UDSCipherUtil.encrypt(content);
    }
    public static void main(String[] args)throws Exception {
    	String str = new UDSEncrypter().evaluate("ABC");
    	System.out.println(str);
	}

}
