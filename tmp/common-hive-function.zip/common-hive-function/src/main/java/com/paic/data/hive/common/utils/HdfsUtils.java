package com.paic.data.hive.common.utils;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.NavigableMap;
import java.util.TreeMap;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.FsUrlStreamHandlerFactory;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IOUtils;

public class HdfsUtils {
	
	private static HashMap<String, List<String>> mobileLocationMap=new  HashMap<String, List<String>>();

    static {
        try {
            URL.setURLStreamHandlerFactory(new FsUrlStreamHandlerFactory());
            getMobileLocation2();
        } catch (Throwable e) {
            // ignore
        }
    }

    public static NavigableMap<String, String> getMobileLocation(NavigableMap<String, String> mobileLocationMap) {
        if (mobileLocationMap == null || mobileLocationMap.size() == 0) {
            mobileLocationMap = new TreeMap<String, String>();
            Configuration conf = new Configuration();
            String uri = "hdfs://pasc/user/hive/warehouse/dim.db/uds_mobile_info/000000_0";
            FSDataInputStream in = null;
            BufferedReader reader = null;
            try {
                FileSystem hdfs = FileSystem.get(URI.create(uri), conf);
                in = hdfs.open(new Path(uri));
                reader = new BufferedReader(new InputStreamReader(in));
                String line = null;
                while ((line = reader.readLine()) != null) {
                    String[] cols = line.split("\u0001");
                    if (cols.length >= 3) {
                        mobileLocationMap.put(cols[0] + "-" + cols[1], cols[2]);
                    }
                }
            } catch (Throwable e) {
                throw new RuntimeException("Fail to load mobile info from hdfs,", e);
            } finally {
                IOUtils.closeStream(in);
            }
        }
        return mobileLocationMap;
    }
    
    public static HashMap<String, List<String>> getMobileLocation2() {
        if (mobileLocationMap == null || mobileLocationMap.size() == 0) {
            mobileLocationMap = new HashMap<String, List<String>>();
            Configuration conf = new Configuration();
            SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
            String dt = df.format(new Date());
            String uri = "hdfs://pasc/user/hive/warehouse/tmp.db/zn_mapping_phonecity_bak/000000_0";
            FSDataInputStream in = null;
            BufferedReader reader = null;
            try {
                FileSystem hdfs = FileSystem.get(URI.create(uri), conf);
                in = hdfs.open(new Path(uri));
                reader = new BufferedReader(new InputStreamReader(in,"UTF-8"));
                String line = null;
                while ((line = reader.readLine()) != null) {
                    String[] cols = line.split("\t");
                    if (cols.length >= 3) {
                        mobileLocationMap.put(cols[0],Arrays.asList(cols));
                    }
                }
            } catch (Throwable e) {
                throw new RuntimeException("Fail to load mobile info from hdfs,", e);
            } finally {
                IOUtils.closeStream(in);
            }
        }
        return mobileLocationMap;
    }
    
    public static HashMap<String, List<String>> getMobileMap(){
    	return mobileLocationMap;
    }

}
