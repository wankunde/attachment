package com.paic.data.hive.common.udf.encrypt;

import java.util.Date;

public class TokenUtil {
	public static final int EXPIRED_SECONDS = 180000;

	public static String generateTokenTimeout(String user, int timeoutSeconds) {
		int n = (int) (user.length() * Math.random());
		return generateToken(user, n, timeoutSeconds);
	}

	public static String generateToken(String user, int n, int timeoutSeconds) {
		String seed = shift(user, n);
		String md5 = MD5Util.md5Hex(seed);
		seed = shift(md5, n);
		seed = AESUtils.parseByte2HexStr(seed);
		return insertUser(insertTime(seed, timeoutSeconds), user);
	}

	private static String removeTime(String str) {
		return removeString(str, 13, 5);

	}

	private static String removeString(String str, int len, int x) {
		StringBuilder sb = new StringBuilder(str);
		for (int i = 0; i < len; i++) {
			int p = i * x - i;
			sb.deleteCharAt(p);
		}
		return sb.toString();
	}

	private static String getTime(String str) {
		return getString(str, 13, 5);

	}

	private static String getString(String str, int len, int x) {
		char[] cs = new char[len];
		char[] ss = str.toCharArray();
		for (int i = 0; i < len; i++) {
			int p = i * x;
			cs[i] = ss[p];
		}
		return new String(cs);
	}

	private static String removeUser(String str) {
		return removeString(str, 20, 4);
	}

	private static String getUser(String str) {
		return getString(str, 20, 4).replaceAll("[.]", "");
	}

	private static String insertUser(String str, String user) {
		int n = (int) (Math.random() * user.length());
		String v = fill(shift(user, n), 20, ".");
		return insertString(str, v, 4);
	}

	private static String fill(String str, int len, String f) {
		if (str.length() >= len) {
			return str;
		}
		StringBuilder sb = new StringBuilder(str);
		while (sb.length() != len) {
			sb.insert((int) (sb.length() * Math.random()), f);
		}
		return sb.toString();
	}

	private static String insertTime(String str, int timeoutSeconds) {
		int x = timeoutSeconds == -1 ? EXPIRED_SECONDS : timeoutSeconds;
		String time = String.valueOf(System.currentTimeMillis() + x * 1000);
		return insertString(str, time, 5);
	}

	private static String insertString(String origin, String inserts, int x) {
		StringBuilder sb = new StringBuilder(origin);
		char[] cs = inserts.toCharArray();
		for (int i = 0; i < cs.length; i++) {
			int p = i * x;
			sb.insert(p, cs[i]);
		}
		return sb.toString();
	}

	private static String shift(String user, int n) {
		char[] ss = user.toCharArray();
		char[] cs = new char[user.length()];
		for (int i = 0; i < cs.length; i++) {
			cs[i] = ss[(i + n) % cs.length];
		}
		for (int i = 0; i < cs.length / 2; i++) {
			char x = cs[i];
			cs[i] = cs[cs.length - i - 1];
			cs[cs.length - i - 1] = x;
		}
		return String.valueOf(cs);
	}

	public static String validateToken(String token) {
		try {
			if (isEmpty(token)) {
				return null;
			}
			String user = getUser(token);
			token = removeUser(token);
			String time = getTime(token);
			if (System.currentTimeMillis() >= Long.valueOf(time)) {
				return null;
			}
			String rest = removeTime(token);
			for (int i = 0; i < user.length(); i++) {
				for (int j = 0; j < user.length(); j++) {
					String v = shift(user, j);
					String nt = generateToken(v, i, -1);
					String nr = removeTime(removeUser(nt));
					if (nr.equals(rest)) {
						return v;
					}
				}
			}
			return null;
		} catch (Exception e) {
			return null;
		}
	}

	private static boolean isEmpty(String str) {
		return str == null || str.trim().equals("");
	}

	public static void main(String[] args) {
		System.out.println(new Date());
		String key = "TABLE1_COLUMN2";
		String token = generateTokenTimeout(key, 1800000);
		System.out.println(token);
		System.out.println(validateToken(token));
	}

}
