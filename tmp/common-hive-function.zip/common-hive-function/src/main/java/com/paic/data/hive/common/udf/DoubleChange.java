package com.paic.data.hive.common.udf;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;

@Description(name = "double2str", value = "_FUNC_(Double) - Returns string")
public class DoubleChange extends UDF {

	public String evaluate(Double value) throws ParseException {
		if (value == null) {
			return "0";
		}

		BigDecimal db = new BigDecimal(value);
		String ii = db.toPlainString();
		return ii;
	}

	public String evaluate(Double value, int precise) throws ParseException {
		if (value == null) {
			return "0";
		}

		BigDecimal db = BigDecimal.valueOf(value).setScale(precise, RoundingMode.HALF_UP);

		String ii = db.toPlainString();
		return ii;
	}

}
