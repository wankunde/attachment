package com.paic.data.hive.common.udf;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;

@Description(name = "pdate_format", value = "_FUNC_(long) - Returns yyyyMMddHHmmss default")
public class PDateFormat extends UDF {
	private static final String default_pattern = "yyyyMMddHHmmss";

	public Long evaluate(java.sql.Date date) throws ParseException {
		return evaluate(date, default_pattern);
	}

	public Long evaluate(java.sql.Date date, String pattern) throws ParseException {
		if (date == null) {
			return null;
		}
		String value = new SimpleDateFormat(pattern).format(new java.util.Date(date.getTime()));
		return Long.valueOf(value);
	}

	public Long evaluate(java.sql.Date date, String pattern, boolean catchException) {
		Long result = 0l;
		try {
			result = evaluate(date);
		} catch (Throwable e) {
			if (!catchException) {
				throw new RuntimeException(e);
			}
			return null;
		}
		return result;
	}

	public Long evaluate(Timestamp timestamp) throws ParseException {
		return evaluate(timestamp, default_pattern);
	}

	public Long evaluate(Timestamp timestamp, String pattern) throws ParseException {
		if (timestamp == null) {
			return null;
		}
		String value = new SimpleDateFormat(pattern).format(timestamp);
		return Long.valueOf(value);
	}

	public Long evaluate(Timestamp timestamp, String pattern, boolean catchException) {
		Long result = 0l;
		try {
			result = evaluate(timestamp, pattern);
		} catch (Throwable e) {
			if (!catchException) {
				throw new RuntimeException(e);
			}
			return null;
		}
		return result;
	}

	public Long evaluate(Long timestamp) throws ParseException {
		return evaluate(timestamp, default_pattern);
	}

	public Long evaluate(Long timestamp, String pattern) throws ParseException {
		if (timestamp == null) {
			return null;
		}
		java.util.Date date = new java.util.Date(timestamp);
		String value = new SimpleDateFormat(pattern).format(date);
		return Long.valueOf(value);
	}

	public Long evaluate(Long timestamp, String pattern, boolean catchException) {
		Long result = 0l;
		try {
			result = evaluate(timestamp, pattern);
		} catch (Throwable e) {
			if (!catchException) {
				throw new RuntimeException(e);
			}
			return null;
		}
		return result;
	}

	public String evaluate(String dateStr, String sourcePattern, String destPattern) throws ParseException {
		if (dateStr == null) {
			return null;
		}
		java.util.Date date = new SimpleDateFormat(sourcePattern).parse(dateStr);
		String result = new SimpleDateFormat(destPattern).format(date);
		return result;
	}

	public String evaluate(String dateStr, String sourcePattern, String destPattern, boolean catchException) {
		String result = null;
		try {
			result = evaluate(dateStr, sourcePattern, destPattern);
		} catch (Throwable e) {
			if (!catchException) {
				throw new RuntimeException(e);
			}
			return null;
		}
		return result;
	}

	public String evaluate(String dateStr, String destPattern, String... sourcePatternArray) {
		String result = null;
		for (String sourcePattern : sourcePatternArray) {
			result = evaluate(dateStr, sourcePattern, destPattern, true);
			if (result != null) {
				return result;
			}
		}

		return result;
	}
}
