package com.paic.data.hive.common.udf.bean;

/**
 * Created by wangyi422 on 2018/3/22.
 */
public class DecipherTelReq {
    private String sysID;
    private String userID;
    private int type;
    private String cipherText;
    private long timestamp;

    public DecipherTelReq(String sysID, String userID, int type, String cipherText, long timestamp) {
        this.sysID = sysID;
        this.userID = userID;
        this.type = type;
        this.cipherText = cipherText;
        this.timestamp = timestamp;
    }

    public String getSysID() {
        return sysID;
    }

    public String getUserID() {
        return userID;
    }

    public int getType() {
        return type;
    }

    public String getCipherText() {
        return cipherText;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setSysID(String sysID) {
        this.sysID = sysID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public void setType(int type) {
        this.type = type;
    }

    public void setCipherText(String cipherText) {
        this.cipherText = cipherText;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
}
