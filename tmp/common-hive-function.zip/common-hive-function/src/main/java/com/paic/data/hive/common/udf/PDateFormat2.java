package com.paic.data.hive.common.udf;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;

@Description(name = "pdate_format2", value = "_FUNC_(long) - Returns yyyyMMddHHmmss default")
public class PDateFormat2 extends UDF {

  public String evaluate(String dateStr, String sourcePattern, String destPattern) {
    if (sourcePattern == null || dateStr == null) {
      return null;
    }

    java.util.Date date = null;
    try {
      date = new SimpleDateFormat(sourcePattern).parse(dateStr);
    } catch (ParseException e) {
      return null;
    }
    return new SimpleDateFormat(destPattern).format(date);
  }

  public String evaluate(java.sql.Date date, String destPattern) {
    if (date == null)
      return null;
    return new SimpleDateFormat(destPattern).format(date);
  }

  public String evaluate(Timestamp timestamp, String destPattern) {
    if (timestamp == null)
      return null;
    return new SimpleDateFormat(destPattern).format(timestamp);
  }

}
