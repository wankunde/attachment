package com.paic.data.hive.common.udtf.otcBayesLogRecovery2;

import com.paic.data.hive.common.udtf.otcBayesLogRecovery2.OffsetData;

public class OffsetData {
	 public int b_step;
	 public int s_step;
	 public double value;
	 
	 public OffsetData(int b_step,int s_step,double value){
		 this.b_step=b_step;
		 this.s_step=s_step;
		 this.value=value;
	 }
	 
	 public static OffsetData getData(int b,int s,double value){
		 OffsetData data=new OffsetData(b,s,value);
		 return data;
	 }
}
