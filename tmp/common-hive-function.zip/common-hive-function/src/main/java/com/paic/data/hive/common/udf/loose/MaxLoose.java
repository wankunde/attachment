package com.paic.data.hive.common.udf.loose;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.hive.common.type.HiveDecimal;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.parse.SemanticException;
import org.apache.hadoop.hive.ql.udf.generic.AbstractGenericUDAFResolver;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDAFEvaluator;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDAFParameterInfo;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.PrimitiveObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.StandardListObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.StructField;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorUtils;
import org.apache.hadoop.hive.serde2.typeinfo.TypeInfo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by WANKUN603 on 2018-05-21.
 */
@Description(name = "max_loose",
        value = "_FUNC_(dt, value) - Sort the value by dt and compute the max loose.\n")
public class MaxLoose extends AbstractGenericUDAFResolver {

  private static final Log LOG = LogFactory.getLog(MaxLoose.class.getName());

  @Override
  public GenericUDAFEvaluator getEvaluator(GenericUDAFParameterInfo paramInfo) throws SemanticException {
    TypeInfo[] parameters = paramInfo.getParameters();

    assert !paramInfo.isDistinct() : "DISTINCT not supported with *";
    assert !paramInfo.isAllColumns() : "Two argument are needed!";
    if (parameters.length != 2) {

      throw new UDFArgumentException("Argument expected");
    }
    return new GenericUDAFLooseEvaluator();
  }

  @Override
  public GenericUDAFEvaluator getEvaluator(TypeInfo[] parameters) throws SemanticException {
    return new GenericUDAFLooseEvaluator();
  }

  /**
   * GenericUDAFLooseEvaluator.
   */
  public static class GenericUDAFLooseEvaluator extends GenericUDAFEvaluator {

    /**
     * class for storing count value.
     */
    @AggregationType(estimable = false)
    static class LooseBuf extends AbstractAggregationBuffer {
      List<String> dts;
      List<HiveDecimal> values;
      // TODO
//      public int estimate() { return JavaDataModel.; }
    }

    public static final String DTS_NAME = "dts";
    public static final String VALUES_NAME = "values";
    public static final String START_DT_NAME = "start_dt";
    public static final String END_DT_NAME = "end_dt";
    public static final String START_VALUE_NAME = "start_value";
    public static final String END_VALUE_NAME = "end_value";
    public static final String LOOSE_NAME = "loose";
    public static final String LOOSE_PERCENT_NAME = "loose_percent";

    private transient ObjectInspector[] poi;
    private transient StructObjectInspector soi;
    private transient Object[] partialResult;
    private transient Object[] result;

    private transient StructField dtField;
    private transient StandardListObjectInspector dtOI;

    private transient StructField valueField;
    private transient StandardListObjectInspector valueOI;

    @Override
    public ObjectInspector init(Mode m, ObjectInspector[] parameters)
            throws HiveException {
      super.init(m, parameters);

      partialResult = new Object[2];
      result = new Object[6];
      if (m == Mode.PARTIAL1 || m == Mode.PARTIAL2) {
        this.poi = parameters;
        List<String> fname = Arrays.asList(DTS_NAME, VALUES_NAME);
        List<ObjectInspector> retOIs = Arrays.asList(
                (ObjectInspector) ObjectInspectorFactory.getStandardListObjectInspector(
                        PrimitiveObjectInspectorFactory.javaStringObjectInspector),
                ObjectInspectorFactory.getStandardListObjectInspector(
                        PrimitiveObjectInspectorFactory.javaHiveDecimalObjectInspector));
        return ObjectInspectorFactory.getStandardStructObjectInspector(fname, retOIs);
      } else {
        // if (m == Mode.FINAL || m == Mode.COMPLETE)
//        StandardListObjectInspector   StandardListObjectInspector getStandardListObjectInspector(ObjectInspector listElementObjectInspector)
        soi = (StructObjectInspector) parameters[0];

        dtField = soi.getStructFieldRef(DTS_NAME);
        dtOI = (StandardListObjectInspector) dtField.getFieldObjectInspector();

        valueField = soi.getStructFieldRef(VALUES_NAME);
        valueOI = (StandardListObjectInspector) valueField.getFieldObjectInspector();

        List<String> fname = Arrays.asList(START_DT_NAME,
                END_DT_NAME,
                START_VALUE_NAME,
                END_VALUE_NAME,
                LOOSE_NAME,
                LOOSE_PERCENT_NAME);
        List<ObjectInspector> retOIs = Arrays.asList(
                (ObjectInspector) PrimitiveObjectInspectorFactory.javaStringObjectInspector,
                PrimitiveObjectInspectorFactory.javaStringObjectInspector,
                PrimitiveObjectInspectorFactory.javaHiveDecimalObjectInspector,
                PrimitiveObjectInspectorFactory.javaHiveDecimalObjectInspector,
                PrimitiveObjectInspectorFactory.javaHiveDecimalObjectInspector,
                PrimitiveObjectInspectorFactory.javaHiveDecimalObjectInspector);
        return ObjectInspectorFactory.getStandardStructObjectInspector(fname, retOIs);
      }
    }

    @Override
    public AbstractAggregationBuffer getNewAggregationBuffer() throws HiveException {
      LooseBuf looseBuf = new LooseBuf();
      reset(looseBuf);
      return looseBuf;
    }

    @Override
    public void reset(AggregationBuffer looseBuf) throws HiveException {
      ((LooseBuf) looseBuf).dts = new ArrayList<>();
      ((LooseBuf) looseBuf).values = new ArrayList<>();
    }

    @Override
    public void iterate(AggregationBuffer looseBuf, Object[] parameters) throws HiveException {
      String dt = PrimitiveObjectInspectorUtils.getString(parameters[0], (PrimitiveObjectInspector) poi[0]);
      HiveDecimal value = PrimitiveObjectInspectorUtils.getHiveDecimal(parameters[1], (PrimitiveObjectInspector) poi[1]);
      if(dt!=null && value!=null) {
        ((LooseBuf) looseBuf).dts.add(dt);
        ((LooseBuf) looseBuf).values.add(value);
      }
    }

    @Override
    public Object terminatePartial(AggregationBuffer looseBuf) throws HiveException {
      partialResult[0] = ((LooseBuf) looseBuf).dts;
      partialResult[1] = ((LooseBuf) looseBuf).values;
      return partialResult;
    }

    @Override
    public void merge(AggregationBuffer looseBuf, Object partial) throws HiveException {
      List<String> dts = ((LooseBuf) looseBuf).dts;
      List<HiveDecimal> values = ((LooseBuf) looseBuf).values;

      List<Object> dt2 = (List<Object>) dtOI.getList(soi.getStructFieldData(partial, dtField));
      List<Object> values2 = (List<Object>) valueOI.getList(soi.getStructFieldData(partial, valueField));
      PrimitiveObjectInspector eoi;
      eoi = (PrimitiveObjectInspector) dtOI.getListElementObjectInspector();
      for (Object obj : dt2)
        dts.add(PrimitiveObjectInspectorUtils.getString(obj, eoi));
      eoi = (PrimitiveObjectInspector) valueOI.getListElementObjectInspector();
      for (Object obj : values2)
        values.add(PrimitiveObjectInspectorUtils.getHiveDecimal(obj, eoi));
    }

    @Override
    public Object terminate(AggregationBuffer looseBuf) throws HiveException {
      List<String> dts = ((LooseBuf) looseBuf).dts;
      List<HiveDecimal> values = ((LooseBuf) looseBuf).values;
      List<ValueBean> list = new ArrayList<>(dts.size());
      for (int i = 0; i < dts.size(); i++) {
        if (dts.get(i) != null && values.get(i) != null)
          list.add(new ValueBean(dts.get(i), values.get(i)));
      }
      ValueBean[] res = ValueBean.loose(list);
      if (res != null && res.length == 2) {
        result[0] = res[0].getDt();
        result[1] = res[1].getDt();
        result[2] = res[0].getValue();
        result[3] = res[1].getValue();
        result[4] = res[0].getValue().subtract(res[1].getValue());
        if (res[0].getValue().equals(HiveDecimal.ZERO))
          result[5] = HiveDecimal.ZERO;
        else
          result[5] = (res[0].getValue().subtract(res[1].getValue())).divide(res[0].getValue());
      }
      return result;
    }
  }
}
