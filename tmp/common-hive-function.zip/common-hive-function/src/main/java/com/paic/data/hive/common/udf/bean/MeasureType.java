package com.paic.data.hive.common.udf.bean;

/**
 * Created by WANKUN603 on 2016-06-23.
 */
public enum MeasureType {
    MAX, MIN, SUM, AVG, TAVG, OLD, NEW, COUNT;

}
