package com.paic.data.hive.common.udf.bean;

import com.paic.data.hive.common.udf.MeasureUtil;
import com.paic.data.hive.common.utils.UdfUtils;
import com.paic.data.hive.common.utils.date.DateUnit;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.hive.ql.metadata.HiveException;

import java.io.IOException;
import java.text.ParseException;

/**
 * Created by WANKUN603 on 2016-06-23.
 */
public class MeasureBean {

    private static Log LOG = LogFactory.getLog(MeasureBean.class);

    private String startDate;
    private String endDate;
    private MeasureType type;
    private Double firstValue;
    private String measureText;
    private String period;
    private String speriod;

    private int tradeDays; // 交易日天数
    private String[] dts;

    public MeasureBean(String startDate, String endDate, String type, String firstValue, String measureText, String speriod)
            throws ParseException, IOException, HiveException {
        this(startDate, endDate, MeasureType.valueOf(type.toUpperCase()),
                firstValue == null ? null : Double.parseDouble(firstValue), measureText, speriod);
    }

    private MeasureBean(String startDate, String endDate, MeasureType type, Double firstValue, String measureText, String speriod)
            throws HiveException, IOException, ParseException {
        if (LOG.isDebugEnabled())
            LOG.debug(new ToStringBuilder(this)
                    .append("startDate", startDate)
                    .append("endDate", endDate)
                    .append("type", type)
                    .append("firstValue", firstValue)
                    .append("measureText", measureText)
                    .toString());
        this.startDate = startDate;
        this.endDate = endDate;
        this.type = type;
        this.firstValue = firstValue;
        this.measureText = measureText;
        this.period = measureText.substring(0, measureText.indexOf("_"));
        this.tradeDays = UdfUtils.tradeDaysLength(startDate, endDate);
        this.dts = UdfUtils.getDays(startDate, endDate);
        this.speriod = speriod == null ? "" : speriod;
    }

    public static MeasureBean updateByPeriod(MeasureBean bean, int diff) throws ParseException, HiveException, IOException {
        char periodType = bean.getPeriod().charAt(bean.getPeriod().length() - 1);
        if (periodType == 'n' || periodType == 'N' || diff <0) {
            String endDate = DateUnit.getInstance("D").shift(bean.getEndDate(), diff);
            String startDate = UdfUtils.shiftDate(bean.getPeriod(), endDate, MeasureUtil.DATE_BEFORE);
            bean = new MeasureBean(startDate, endDate, bean.getType(), bean.getFirstValue(), bean.getMeasureText(), bean.getSperiod());
            return bean;
        } else {
            String startDate = DateUnit.getInstance("D").shift(bean.getStartDate(), diff);
            String endDate = UdfUtils.shiftDate(bean.getPeriod(), startDate, MeasureUtil.DATE_AFTER);
            bean = new MeasureBean(startDate, endDate, bean.getType(), bean.getFirstValue(), bean.getMeasureText(), bean.getSperiod());
            return bean;
        }
    }

    @Override
    public String toString() {
        if (this == null)
            return null;
        else
            return new ToStringBuilder(this)
                    .append("startDate", startDate)
                    .append("endDate", endDate)
                    .append("type", type)
                    .append("firstValue", firstValue)
                    .append("measureText", measureText)
                    .append("tradeDays", tradeDays)
                    .toString();
    }

    public String simpleString() {
        return "{[" + startDate + "-" +endDate +"],"+measureText+",trds="+tradeDays+"}";
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public MeasureType getType() {
        return type;
    }

    public void setType(MeasureType type) {
        this.type = type;
    }

    public Double getFirstValue() {
        return firstValue;
    }

    public void setFirstValue(Double firstValue) {
        this.firstValue = firstValue;
    }

    public String getMeasureText() {
        return measureText;
    }

    public void setMeasureText(String measureText) {
        this.measureText = measureText;
    }

    public int getTradeDays() {
        return tradeDays;
    }

    public void setTradeDays(int tradeDays) {
        this.tradeDays = tradeDays;
    }

    public String[] getDts() {
        return dts;
    }

    public void setDts(String[] dts) {
        this.dts = dts;
    }

    public String getPeriod() {
        return period;
    }

    public void setPeriod(String period) {
        this.period = period;
    }

    public String getSperiod() {
        return speriod;
    }

    public void setSperiod(String speriod) {
        this.speriod = speriod;
    }
}
