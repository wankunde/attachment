package com.paic.data.hive.common.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URL;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.FsUrlStreamHandlerFactory;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IOUtils;

public class ReadDimFileUtil {
	private static final String SPLIT_FIELD = "\\x01";
	
	public static Map<String, Set<String>> getIndexNameAndExtendName() throws IOException{
		Map<String, Set<String>> data = new HashMap<>();
		
		try {
            URL.setURLStreamHandlerFactory(new FsUrlStreamHandlerFactory());
        } catch (Throwable e) {
            //ignore
        }

        Configuration conf = new Configuration();
        String uri = "hdfs:///user/hive/warehouse/dim.db/dim_module_index_extend_name/000000_0";
        FSDataInputStream in = null;
        BufferedReader reader = null;
        try {
            FileSystem hdfs = FileSystem.get(URI.create(uri), conf);
            in = hdfs.open(new Path(uri));
            reader = new BufferedReader(new InputStreamReader(in));
            String line = null;
            while ((line = reader.readLine()) != null) {
            	String[] fields = line.split(SPLIT_FIELD);
            	
            	if(fields.length >= 3){
            		String indexName = fields[1].trim();
            		String indexExtendName = fields[2].trim().toLowerCase();  // FIX 20170706 : 所有扩展指标名匹配都使用小写匹配
            		
            		if(data.containsKey(indexName)){
            			Set<String> extendSet =data.get(indexName);
            			extendSet.add(indexExtendName);
            			
            			data.put(indexName, extendSet);
            		}else{
            			Set<String> extendSet = new HashSet<>();
            			extendSet.add(indexExtendName);
            			
            			data.put(indexName, extendSet);
            		}
            	}
            }
        } finally {
            IOUtils.closeStream(in);
        }
        
        return data;
	}

}
