package com.paic.data.hive.common.udf.phone;

import java.util.Map.Entry;
import java.util.NavigableMap;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;

import com.paic.data.hive.common.utils.HdfsUtils;

@Description(name = "phone_geo", value = "_FUNC_(String phone_number) - Returns location info")
public class PAChinaPhoneGeo extends UDF {

    private Pattern pattern = Pattern.compile(
            ".*((130|131|132|133|134|135|136|137|138|139|140|145|147|148|149|150|151|152|153|154|155|156|157|158|159|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189)[0-9]{8}).*");

    static class Location {
        String province;
        String city;
    }

    public Location evaluate(String phoneNo) {
        Location location = new Location();
        if (StringUtils.isEmpty(phoneNo)) {
            return location;
        }

        Matcher matcher = pattern.matcher(phoneNo);
        if (matcher.matches()) {
            String phone = matcher.group(1).substring(0, 7);
            NavigableMap<String, String> locationMap = new TreeMap<String, String>();
            locationMap = HdfsUtils.getMobileLocation(locationMap);
            Entry<String, String> lowerEntry = locationMap.lowerEntry(getKey(phone));
            Entry<String, String> higherEntry = locationMap.higherEntry(getKey(phone));
            if (inTheEntry(lowerEntry, Integer.valueOf(phone))) {
                location.province = getStandardProvince(lowerEntry.getValue());
                return location;
            } else if (inTheEntry(higherEntry, Integer.valueOf(phone))) {
                location.province = getStandardProvince(higherEntry.getValue());
                return location;
            }

            return location;
        }

        return location;
    }

    private String getStandardProvince(String value) {
        if (value.endsWith("省") || value.endsWith("市") || value.endsWith("自治区")) {
            return value;
        }
        if (value.equals("上海") || value.equals("北京") || value.equals("天津") || value.equals("重庆")) {
            return value + "市";
        } else if (value.equals("内蒙古") || value.equals("新疆维吾尔") || value.equals("宁夏回族")) {
            return value + "自治区";
        } else if (value.equals("新疆")) {
            return value + "维吾尔自治区";
        } else if (value.equals("宁夏")) {
            return value + "回族自治区";
        } else if (value.equals("全国")) {
            return value;
        } else {
            return value + "省";
        }
    }

    private boolean inTheEntry(Entry<String, String> entry, int phone) {
        if (entry == null) {
            return false;
        }
        String key = entry.getKey();
        String[] array = key.split("-");
        int start = Integer.valueOf(array[0]);
        int end = Integer.valueOf(array[1]);
        if (phone >= start && phone <= end) {
            return true;
        }
        return false;
    }

    private String getKey(String phoneNo) {
        return phoneNo + "-" + phoneNo;
    }

}
