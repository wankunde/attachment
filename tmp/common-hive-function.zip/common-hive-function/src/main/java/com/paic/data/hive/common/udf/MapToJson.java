package com.paic.data.hive.common.udf;

import java.util.Map;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;

@Description(name = "map_to_json", value = "_FUNC_(map) - Returns a json string")
public class MapToJson extends UDF {

	public String evaluate(Map<String, String> map) {
		String result = toString(map);
		return result;
	}
	
	private boolean nullValues(Map map){
		if (map != null) {
			for(Object value:map.values()){
				if (value != null) {
					return false;
				}
			}
		}
		return true;
	}

	private String toString(Map map) {
		StringBuilder sb = new StringBuilder();
		if (!nullValues(map)) {
			sb.append("{");
			for (Object key : map.keySet()) {
				String value = (String)map.get(key);
				if (value == null) {
					continue;
				}
				if(value.startsWith("{")){
					sb.append("\"").append(key).append("\"").append(":").append(value)
					.append(",");
				}else {
					sb.append("\"").append(key).append("\"").append(":").append("\"").append(value).append("\"")
					.append(",");
				}
			}
			
			return sb.substring(0, sb.length() - 1) + "}";
		}
		return null;
	}
}
