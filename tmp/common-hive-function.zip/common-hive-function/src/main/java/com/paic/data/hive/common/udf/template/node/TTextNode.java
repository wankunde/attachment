package com.paic.data.hive.common.udf.template.node;

import java.util.Collection;

import com.paic.data.hive.common.udf.template.TPushData;
import com.paic.data.hive.common.udf.template.TUserData;



public class TTextNode extends TVarNode {

	private String text;
	
	public TTextNode(String text) {
		this.text = text;
	}

	@Override
	public void params(Collection<String> params) {
		
	}

	@Override
	public void toString(StringBuffer output, String channel, TUserData userData, TPushData pushData) {
		output.append(text);
	}
	
	public String toString(String channel, TUserData userData, TPushData pushData) {
		return text;
	}
	
	@Override
	public String toString() {
		return text;
	}
	
	@Override
	public void trim() {
		text = text.trim();
	}
	
	public void trimFirst() {
		int len = text.length();
		int st = 0;
		char[] val = text.toCharArray();    /* avoid getfield opcode */

		while ((st < len) && (val[st] <= ' ')) {
			st++;
		}
		if (st > 0) {
			text = text.substring(st);
		}
	}
	
	public void trimLast() {
		int len = text.length();
		int st = 0;
		char[] val = text.toCharArray();    /* avoid getfield opcode */

		while ((st < len) && (val[len - 1] <= ' ')) {
			len--;
		}
		if (len < text.length()) {
			text = text.substring(0, len);
		}
	}
	
	public static void main(String[] args) {
		TTextNode node = new TTextNode("  hhh ");
		node.trimLast();
		System.out.println("{"+node+"}");
	}
}
