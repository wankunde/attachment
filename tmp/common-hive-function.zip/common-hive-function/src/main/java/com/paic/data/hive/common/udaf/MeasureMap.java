package com.paic.data.hive.common.udaf;

import com.paic.data.hive.common.udf.bean.ColsGroupsBean;
import com.paic.data.hive.common.utils.UdfUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDFArgumentLengthException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.parse.SemanticException;
import org.apache.hadoop.hive.ql.udf.generic.AbstractGenericUDAFResolver;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDAFEvaluator;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDAFParameterInfo;
import org.apache.hadoop.hive.serde2.io.DoubleWritable;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorConverters;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorUtils;
import org.apache.hadoop.hive.serde2.objectinspector.StandardMapObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.typeinfo.TypeInfo;
import org.apache.hadoop.io.Text;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Description(name = "measure_map",
        value = "_FUNC_(asset,title,colsGroups [, expr...]) - Returns map. The key is col group value,and value is sum(asset). ")
public class MeasureMap extends AbstractGenericUDAFResolver {

    private static final Log LOG = LogFactory.getLog(MeasureMap.class);

    @Override
    public GenericUDAFEvaluator getEvaluator(GenericUDAFParameterInfo parameters) throws SemanticException {
        ObjectInspector[] paramOIs = parameters.getParameterObjectInspectors();
        if (paramOIs.length < 3) {
            throw new UDFArgumentLengthException("Incorrect invocation of : _FUNC_(asset,title,colsGroups [, expr...])");
        }
        return new MeasureMapDoubleEvaluator();
    }

    @Override
    public GenericUDAFEvaluator getEvaluator(TypeInfo[] parameters) throws SemanticException {
        return new MeasureMapDoubleEvaluator();
    }

    public static class MeasureMapDoubleEvaluator extends GenericUDAFEvaluator {

        // For PARTIAL1 and COMPLETE: ObjectInspectors for original data
        private transient ObjectInspector[] inputOIs;

        private transient ObjectInspectorConverters.Converter doubleConverter = null;

        // For PARTIAL2 and FINAL: ObjectInspectors for partial aggregations (map of objs)
        private transient StandardMapObjectInspector moi;

        private transient StandardMapObjectInspector internalMergeOI;

        @Override
        public ObjectInspector init(Mode m, ObjectInspector[] parameters) throws HiveException {
            super.init(m, parameters);

            if (m == Mode.PARTIAL1) {
                inputOIs = parameters;
                doubleConverter = ObjectInspectorConverters.getConverter(parameters[0],
                        PrimitiveObjectInspectorFactory.javaDoubleObjectInspector);

                internalMergeOI = ObjectInspectorFactory.getStandardMapObjectInspector(
                        PrimitiveObjectInspectorFactory.writableStringObjectInspector,
                        PrimitiveObjectInspectorFactory.writableDoubleObjectInspector);

                return ObjectInspectorFactory.getStandardMapObjectInspector(
                        PrimitiveObjectInspectorFactory.writableStringObjectInspector,
                        PrimitiveObjectInspectorFactory.writableDoubleObjectInspector);
            } else {
                if (!(parameters[0] instanceof StandardMapObjectInspector)) {
                    // TODO no map aggregation ??? why ...
                    inputOIs = parameters;
                    doubleConverter = ObjectInspectorConverters.getConverter(parameters[0],
                            PrimitiveObjectInspectorFactory.javaDoubleObjectInspector);
                    return ObjectInspectorFactory.getStandardMapObjectInspector(
                            PrimitiveObjectInspectorFactory.writableStringObjectInspector,
                            PrimitiveObjectInspectorFactory.writableDoubleObjectInspector
                    );
                } else {
                    internalMergeOI = (StandardMapObjectInspector) parameters[0];
                    moi = (StandardMapObjectInspector) ObjectInspectorUtils.getStandardObjectInspector(internalMergeOI);
                    return moi;
                }
            }

        }

        public static class DoubleMapBean extends AbstractAggregationBuffer {
            public Map<String, Double> value;

            public DoubleMapBean() {
                value = new HashMap<>();
            }
        }

        @Override
        public AggregationBuffer getNewAggregationBuffer() throws HiveException {
            return new DoubleMapBean();
        }

        @Override
        public void reset(AggregationBuffer agg) throws HiveException {
            ((DoubleMapBean) agg).value.clear();
        }

        //        StopWatch watch = new StopWatch();
        ColsGroupsBean colsGroupsBean;

        @Override
        public void iterate(AggregationBuffer agg, Object[] parameters) throws HiveException {
            if (parameters[0] != null) {
                for (int i = 1; i < parameters.length; i++) {
                    parameters[i] = ObjectInspectorUtils.copyToStandardJavaObject(parameters[i], this.inputOIs[i]);
                }
                Double asset = (Double) doubleConverter.convert(parameters[0]);
                String title = (String) parameters[1];
                String colsGroups = (String) parameters[2];
                Object[] funcParameters = new Object[parameters.length - 3];
                System.arraycopy(parameters, 3, funcParameters, 0, funcParameters.length);

                DoubleMapBean myagg = (DoubleMapBean) agg;

                /*if (LOG.isDebugEnabled())
                LOG.debug(new ToStringBuilder(this)
                        .append("countAgg.value", value)
                        .append("asset", asset)
                        .append("title", title)
                        .append("colsGroups", colsGroups)
                        .append("parameters", parameters));*/
//
//            LOG.debug("watch 1 test : "+watch.getNanoTime());
                if (colsGroupsBean == null) {
                    colsGroups = colsGroups.toLowerCase();
                    colsGroupsBean = ColsGroupsBean.getColsGroupBean(colsGroups);
                }
//            LOG.debug("watch 2 : "+watch.getNanoTime());
                List<String> mapKeys = colsGroupsBean.getMapKeys(title, colsGroups, funcParameters);
//            LOG.debug("watch 3 : "+watch.getNanoTime());
                for (String mapKey : mapKeys) {
                    Double data = (Double) myagg.value.get(mapKey);
                    data = (Double) (data == null ? asset : UdfUtils.addData(asset, data));
                    if (data != null)
                        myagg.value.put(mapKey, data);
                }
//            LOG.debug("watch 4 : "+watch.getNanoTime());
//            watch.stop();
            /*if (LOG.isDebugEnabled())
                LOG.debug(new ToStringBuilder(this)
                        .append("parameters", Arrays.toString(parameters))
                        .append("agg.value", value));*/

            }
        }

        @Override
        public Object terminatePartial(AggregationBuffer agg) throws HiveException {
            return doTerminate(agg);
        }

        @Override
        public void merge(AggregationBuffer agg, Object partial) throws HiveException {
            DoubleMapBean myagg = (DoubleMapBean) agg;
            Map<String, Double> partialResult = (Map<String, Double>) ObjectInspectorUtils.copyToStandardJavaObject(partial, internalMergeOI);
            if (partialResult != null) {
                myagg.value = doMerge(myagg.value, partialResult);
            }
        }

        @Override
        public Object terminate(AggregationBuffer agg) throws HiveException {
            return doTerminate(agg);
        }

        public Map<Text, DoubleWritable> doTerminate(AggregationBuffer agg) {
            DoubleMapBean myagg = (DoubleMapBean) agg;
            if (myagg.value == null)
                return new HashMap<>();

//            Map<Text, DoubleWritable> ret = (Map<Text, DoubleWritable>) ObjectInspectorUtils.copyToStandardObject(myagg.value, internalMergeOI);
            Map<Text, DoubleWritable> ret = new HashMap<>(myagg.value.size());
            for (Map.Entry<String, Double> en : myagg.value.entrySet()) {
                ret.put(new Text(en.getKey()), new DoubleWritable(en.getValue()));
            }
            return ret;
        }


        public Map<String, Double> doMerge(Map<String, Double> v1, Map<String, Double> v2) {
            for (Map.Entry<String, Double> en : v2.entrySet()) {
                String key = en.getKey();
                Double value = en.getValue();
                if (v1.containsKey(key))
                    v1.put(key, (Double) UdfUtils.addData(value, v1.get(key)));
                else
                    v1.put(key, value);
            }
            return v1;
        }
    }
}
