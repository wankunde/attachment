package com.paic.data.hive.common.udf.bean;

import java.util.Map;

/**
 * Created by WANKUN603 on 2017-04-13.
 */
public class IpBean {
    private Long start;
    private Long end;
    private Map<String, String> data;

    public Long getStart() {
        return start;
    }

    public void setStart(Long start) {
        this.start = start;
    }

    public Long getEnd() {
        return end;
    }

    public void setEnd(Long end) {
        this.end = end;
    }

    public Map<String, String> getData() {
        return data;
    }

    public void setData(Map<String, String> data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return data.toString();
    }
}
