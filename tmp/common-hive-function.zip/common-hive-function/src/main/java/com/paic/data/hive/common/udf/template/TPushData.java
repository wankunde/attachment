package com.paic.data.hive.common.udf.template;

import java.util.Date;

public class TPushData {
	// require
	public String pushId;
	public String batchNo;
	
	// option
	public int taskId;
	public String taskSubId;
	public Date createTime;
}
