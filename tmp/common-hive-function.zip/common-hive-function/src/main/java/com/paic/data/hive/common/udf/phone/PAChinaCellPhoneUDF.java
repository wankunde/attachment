package com.paic.data.hive.common.udf.phone;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.io.Text;

import com.paic.data.hive.common.utils.CellularUtils;

@Description(name = "uds_format_telno", value = "_FUNC_(idno) - 弱校验手机号码。", extended = "Example:\n   > SELECT _FUNC_('8617823459870') FROM TABLE ;\n  '17823459870'")
public class PAChinaCellPhoneUDF extends UDF {
	private final Text result = new Text();

	public static void main(String[] args) {
		Text partyno = new Text();
		partyno.set("18617823459870");
		System.out.println(new PAChinaCellPhoneUDF().evaluate(partyno));
	}

	public Text evaluate(Text telno) {
		if ((telno == null) || (telno.toString().trim().length() < 11)) {
			return null;
		}

		String restr = CellularUtils.formatTelNo(telno.toString());
		if (StringUtils.isEmpty(restr)) {
			return null;
		}
		this.result.set(restr);
		return this.result;
	}
}