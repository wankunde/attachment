package com.paic.data.hive.common.udf;

import com.paic.data.hive.common.udf.bean.MeasureBean;
import com.paic.data.hive.common.udf.bean.MeasureType;
import com.paic.data.hive.common.utils.UdfUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.hive.ql.metadata.HiveException;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Description(name = "measure_ex_map2",
    value = "_FUNC_(his,dt,today_measure_map,measureText,measure_name,colsGroup,his_ex) - Returns map. The key is col group value,and value is sum(asset). ")
public class MeasureExMap2 extends UDF {

  private static final Log LOG = LogFactory.getLog(MeasureExMap2.class);

  private Map<String, BigDecimal> compute(Map<String, BigDecimal> res, MeasureBean measure,
                                          String exKeyPre,
                                          Map<String, BigDecimal> hisData,
                                          Map<String, BigDecimal> hisEx) throws ParseException, HiveException, IOException {

    BigDecimal firstValue = measure.getFirstValue() == null ? null : BigDecimal.valueOf(measure.getFirstValue()); // 首次达到目标
    MeasureType type = measure.getType();
    String measureText = measure.getMeasureText();
    String key = exKeyPre + MeasureUtil.KEY_DELIMITER_4 + measureText;
    boolean checkTradeDay = measure.getSperiod().endsWith("t");

    // 0d_sum 单独处理
    if (measureText.startsWith("0d_sum")) {
      String endDate = measure.getEndDate();

      if (measureText.equals("0d_sum")) {
        BigDecimal hisValue = hisEx == null ? null : hisEx.get(key);
        if (hisValue == null) {
          hisValue = BigDecimal.ZERO;
          for (BigDecimal d : hisData.values()) {
            hisValue = UdfUtils.safeAdd(hisValue, d);
          }
        } else {
          hisValue = UdfUtils.safeAdd(hisValue, hisData.get(endDate));
        }
        res.put(key, hisValue);
        return res;
      } else {
        // 从历史数据中取数
        if (hisEx != null) {
          BigDecimal hisValue = hisEx.get(key);
          if (hisValue != null) {
            res.put(key, hisValue);
            return res;
          }
        }
        // 0d_sum 特殊处理
        String sumKey = exKeyPre + MeasureUtil.KEY_DELIMITER_4 + "0d_sum";
        BigDecimal hisValue = hisEx == null ? null : hisEx.get(sumKey);
        BigDecimal sumValue = BigDecimal.ZERO;
        if (hisValue == null) {
          String[] dts = hisData.keySet().toArray(new String[]{});
          Arrays.sort(dts);
          int i = 0;
          String dt = null;
          while (i < dts.length) {
            dt = dts[i++];
            if (!checkTradeDay || UdfUtils.isTradeDay(dt)) {
              sumValue = UdfUtils.safeAdd(sumValue, hisData.get(dt));
              if (sumValue.compareTo(firstValue) >= 0)
                break;
            }
          }
          if (sumValue.compareTo(firstValue) >= 0 && dt != null) {
            res.put(key, new BigDecimal(dt));
            return res;
          }
        } else {
          sumValue = UdfUtils.safeAdd(hisValue, hisData.get(endDate));
          if (sumValue.compareTo(firstValue) >= 0) {
            res.put(key, new BigDecimal(endDate));
            return res;
          }
        }
        res.put(sumKey, sumValue);
        return res;
      }
    }
    // 首次值指标计算
    else if (firstValue != null) {
      // 从历史数据中取数
      if (hisEx != null) {
        BigDecimal hisValue = hisEx.get(key);
        if (hisValue != null) {
          res.put(key, hisValue);
          return res;
        }
      }

      String[] alldts = hisData.keySet().toArray(new String[]{});
      if (alldts.length == 0)
        return res;

      Arrays.sort(alldts);
      if (type == MeasureType.MAX) {
        for (String dt : alldts) {
          if (hisData.get(dt).compareTo(firstValue) >= 0) {
            res.put(key, new BigDecimal(dt));
            return res;
          }
        }
      } else if (type == MeasureType.MIN) {
        for (String dt : alldts) {
          if (hisData.get(dt).compareTo(firstValue) <= 0) {
            res.put(key, new BigDecimal(dt));
            return res;
          }
        }
      } else if (type == MeasureType.SUM) {
        int diff = UdfUtils.daysBetween(alldts[0], measure.getEndDate());
        measure = MeasureBean.updateByPeriod(measure, -diff);
        BigDecimal sumValue = hisData.get(alldts[0]);
        while (sumValue.compareTo(firstValue) < 0 && measure.getEndDate().compareTo(alldts[alldts.length - 1]) < 0) {
          MeasureBean newMeasure = MeasureBean.updateByPeriod(measure, 1);
          Set<String>[] diffDays = MeasureUtil.measureDiffDays(measure, newMeasure);
          for (String dt : diffDays[0]) {
            sumValue = UdfUtils.safeSubtract(sumValue, hisData.get(dt));
          }
          for (String dt : diffDays[1]) {
            sumValue = UdfUtils.safeAdd(sumValue, hisData.get(dt));
          }
          measure = newMeasure;
        }
        if (sumValue.compareTo(firstValue) >= 0) {
          res.put(key, new BigDecimal(measure.getEndDate()));
          return res;
        }
      } else if (type == MeasureType.AVG) {
        BigDecimal daysLen = BigDecimal.valueOf(measure.getDts().length == 0 ? 1 : measure.getDts().length);

        int diff = UdfUtils.daysBetween(alldts[0], measure.getEndDate());
        measure = MeasureBean.updateByPeriod(measure, -diff);
        BigDecimal sumValue = hisData.get(alldts[0]);
        while (sumValue.divide(daysLen, 4, BigDecimal.ROUND_HALF_UP).compareTo(firstValue) < 0
            && measure.getEndDate().compareTo(alldts[alldts.length - 1]) < 0) {
          MeasureBean newMeasure = MeasureBean.updateByPeriod(measure, 1);
          Set<String>[] diffDays = MeasureUtil.measureDiffDays(measure, newMeasure);
          for (String dt : diffDays[0]) {
            sumValue = UdfUtils.safeSubtract(sumValue, hisData.get(dt));
          }
          for (String dt : diffDays[1]) {
            sumValue = UdfUtils.safeAdd(sumValue, hisData.get(dt));
          }
          measure = newMeasure;
          daysLen = BigDecimal.valueOf(measure.getDts().length == 0 ? 1 : measure.getDts().length);
        }
        if (sumValue.divide(daysLen, 4, BigDecimal.ROUND_HALF_UP).compareTo(firstValue) >= 0) {
          res.put(key, new BigDecimal(measure.getEndDate()));
          return res;
        }
      } else if (type == MeasureType.TAVG) {
        BigDecimal daysLen = BigDecimal.valueOf(measure.getTradeDays() == 0 ? 1 : measure.getTradeDays());

        int diff = UdfUtils.daysBetween(alldts[0], measure.getEndDate());
        measure = MeasureBean.updateByPeriod(measure, -diff);
        BigDecimal sumValue = hisData.get(alldts[0]);
        while (sumValue.divide(daysLen, 4, BigDecimal.ROUND_HALF_UP).compareTo(firstValue) < 0
            && measure.getEndDate().compareTo(alldts[alldts.length - 1]) < 0) {
          MeasureBean newMeasure = MeasureBean.updateByPeriod(measure, 1);
          Set<String>[] diffDays = MeasureUtil.measureDiffDays(measure, newMeasure);
          for (String dt : diffDays[0]) {
            sumValue = UdfUtils.safeSubtract(sumValue, hisData.get(dt));
          }
          for (String dt : diffDays[1]) {
            sumValue = UdfUtils.safeAdd(sumValue, hisData.get(dt));
          }
          measure = newMeasure;
          daysLen = BigDecimal.valueOf(measure.getTradeDays() == 0 ? 1 : measure.getTradeDays());
        }
        if (sumValue.divide(daysLen, 4, BigDecimal.ROUND_HALF_UP).compareTo(firstValue) >= 0) {
          res.put(key, new BigDecimal(measure.getEndDate()));
          return res;
        }
      }
    } else {
      BigDecimal aggregateValue = null;
      for (String idx : measure.getDts()) {
        if (!checkTradeDay || UdfUtils.isTradeDay(idx)) {
          BigDecimal d = hisData.get(idx);
          if (d != null) {
            if (aggregateValue == null) {
              if ((type.compareTo(MeasureType.TAVG) == 0 && UdfUtils.tradeDayIdx(idx) > 0)
                  || type.compareTo(MeasureType.TAVG) != 0)
                aggregateValue = d;
            } else {
              if (type.compareTo(MeasureType.MAX) == 0) {
                aggregateValue = d.compareTo(aggregateValue) > 0 ? d : aggregateValue;
              } else if (type.compareTo(MeasureType.MIN) == 0) {
                aggregateValue = d.compareTo(aggregateValue) < 0 ? d : aggregateValue;
              } else if (type.compareTo(MeasureType.SUM) == 0
                  || type.compareTo(MeasureType.AVG) == 0) {
                aggregateValue = UdfUtils.safeAdd(aggregateValue, d);
              } else if (type.compareTo(MeasureType.TAVG) == 0 && UdfUtils.tradeDayIdx(idx) > 0) {
                aggregateValue = UdfUtils.safeAdd(aggregateValue, d);
              }
            }
          }
        }
      }

      if (aggregateValue == null)
        return res;

      // 计算普通指标(max,min,sum,avg,tavg),添加结果并返回
      if (type.compareTo(MeasureType.TAVG) == 0)
        aggregateValue = aggregateValue.divide(BigDecimal.valueOf(measure.getTradeDays() == 0 ? 1 : measure.getTradeDays()), 4, BigDecimal.ROUND_HALF_UP);
      else if (type.compareTo(MeasureType.AVG) == 0)
        aggregateValue = aggregateValue.divide(BigDecimal.valueOf(measure.getDts().length == 0 ? 1 : measure.getDts().length), 4, BigDecimal.ROUND_HALF_UP);

      res.put(key, aggregateValue);
    }
    return res;
  }

  public Map<String, Double> evaluate(Map<String, Map<String, Double>> his, String dt,
                                      String measureText,
                                      String indexName, String colsGroups) throws HiveException, IOException, ParseException {
    return evaluate(his, dt, new HashMap<>(), measureText, indexName, colsGroups, new HashMap<>());
  }

  public Map<String, Double> evaluate(Map<String, Map<String, Double>> his, String dt,
                                      String measureText,
                                      String indexName, String colsGroups,
                                      Map<String, Double> hisEx) throws HiveException, IOException, ParseException {
    return evaluate(his, dt, new HashMap<>(), measureText, indexName, colsGroups, hisEx);
  }

  public Map<String, Double> evaluate(Map<String, Map<String, Double>> his, String dt,
                                      Map<String, Double> todayMeasureMap, String measureText,
                                      String indexName, String colsGroups,
                                      Map<String, Double> hisEx) throws HiveException, IOException, ParseException {
    his = MeasureUtil.mergeHisMap(his, dt, todayMeasureMap, measureText);
    List<MeasureBean> measures = MeasureUtil.parseMeasure(measureText, dt);
    Map<String, BigDecimal> ex = new HashMap<>();
    try {
      Map<String, Map<String, Double>> hisDataMap = MeasureUtil.getColHis(his, indexName, colsGroups);
      for (Map.Entry<String, Map<String, Double>> hisData : hisDataMap.entrySet()) {
        for (MeasureBean measure : measures) {
          ex = compute(ex, measure, hisData.getKey(), toBigDecimalMap(hisData.getValue()), toBigDecimalMap(hisEx));
        }
      }
    } catch (Exception e) {
      LOG.error("evaluate error!", e);
      throw e;
    }

    return toDoubleMap(ex);
  }

  private Map<String, BigDecimal> toBigDecimalMap(Map<String, Double> map) {
    if (null == map)
      return null;
    Map<String, BigDecimal> newMap = new HashMap<>();
    for (Map.Entry<String, Double> en : map.entrySet()) {
      newMap.put(en.getKey(), BigDecimal.valueOf(en.getValue()));
    }
    return newMap;
  }

  private Map<String, Double> toDoubleMap(Map<String, BigDecimal> map) {
    if (null == map)
      return null;
    Map<String, Double> newMap = new HashMap<>();
    for (Map.Entry<String, BigDecimal> en : map.entrySet()) {
      newMap.put(en.getKey(), en.getValue().doubleValue());
    }
    return newMap;
  }
}
