package com.paic.data.hive.common.udf;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDF;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.JavaLongObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.JavaStringObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.WritableLongObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.WritableStringObjectInspector;
import redis.clients.jedis.*;
import redis.clients.jedis.util.JedisClusterCRC16;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by wankun603 on 2018-07-03.
 */
public class RedisUtils {
  private static final Log LOG = LogFactory.getLog(RedisUtils.class);

  private static final String uri = "hdfs://pasc/metadata/dim/redis_cluster";

  public static ThreadLocal<JedisCluster> clusterLocal = new ThreadLocal<>();
  public static ThreadLocal<TreeMap<Long, String>> slotHostMapLocal = new ThreadLocal<>();
  public static ThreadLocal<Map<String, Pipeline>> hostPipelineMapLocal = new ThreadLocal<>();

  public static transient SimpleDateFormat format = null;
  public static transient SimpleDateFormat format8 = new SimpleDateFormat("yyyyMMdd");
  public static transient SimpleDateFormat format14 = new SimpleDateFormat("yyyyMMddhhmmss");
  public static transient SimpleDateFormat format15 = new SimpleDateFormat("yyyyMMdd hhmmss");
  public static transient SimpleDateFormat format16 = new SimpleDateFormat("yyyyMMddhh:mm:ss");
  public static transient SimpleDateFormat format17 = new SimpleDateFormat("yyyyMMdd hh:mm:ss");

  public static final String REDIS_WRITER_GROUP = "redis.writer";
  public static final String REDIS_WRITER_PARALLEL =  "redis.writer.parallel";
  public static final String REDIS_WRITER_RECOREDS = "redis.writer.recoreds";


  private static Set<HostAndPort> parseNodes(String clusterId) throws HiveException, IOException {
    Set<HostAndPort> nodes = new HashSet<>();

    if (StringUtils.isBlank(clusterId))
      throw new HiveException("cluster cannot be null!");
    LOG.debug("load redis cluster configuration.");

    FileSystem hdfs = FileSystem.get(URI.create(uri), new Configuration());
    try (BufferedReader reader = new BufferedReader(new InputStreamReader(hdfs.open(new Path(uri)), "UTF-8"))) {
      String line;
      while ((line = reader.readLine()) != null) {
        String[] cols = line.split("=");
        if (cols.length == 2 && clusterId.equals(cols[0])) {
          for (String ipPortString : cols[1].split(";")) {
            String[] ipPorts = ipPortString.split(":");
            nodes.add(new HostAndPort(ipPorts[0], Integer.parseInt(ipPorts[1])));
          }
          LOG.debug("load redis cluster configuration success");
          break;
        }
      }
    }
    return nodes;
  }

  private static TreeMap<Long, String> getSlotHostMap(String host, int port) {
    TreeMap<Long, String> tree = new TreeMap<>();
    Jedis jedis = null;
    try {
      jedis = new Jedis(host, port);
      List<Object> slots = jedis.clusterSlots();
      for (Object obj : slots) {
        List<Object> slotRange = (List<Object>) obj;
        List<Object> master = (List<Object>) slotRange.get(2);
        String hostAndPort = new String((byte[]) master.get(0)) + ":" + master.get(1);
        tree.put((Long) slotRange.get(0), hostAndPort);
        tree.put((Long) slotRange.get(1), hostAndPort);
      }
    } finally {
      if (jedis != null)
        jedis.close();
    }
    return tree;
  }

  public static JedisCluster initJedisCluster(String clusterId) throws HiveException {
    JedisCluster cluster = clusterLocal.get();
    if (cluster == null) {
      synchronized (RedisUtils.class) {
        cluster = clusterLocal.get();
        if (cluster == null) {
          try {
            Set<HostAndPort> nodes = parseNodes(clusterId);
            if (nodes == null || nodes.size() == 0)
              throw new HiveException("redis nodes not correct!");
            cluster = new JedisCluster(nodes);
            Connection.setImMap("10.17.144.101:172.16.50.53,10.17.144.102:172.16.50.54,10.17.145.24:172.16.50.55,10.17.145.25:172.16.50.56,10.17.144.65:172.16.50.57,10.17.144.66:172.16.50.58,10.17.144.67:172.16.50.59,10.17.144.68:172.16.50.60");
            clusterLocal.set(cluster);

            HostAndPort hostAndPort = nodes.iterator().next();
            TreeMap<Long, String> slotHostMap = getSlotHostMap(hostAndPort.getHost(), hostAndPort.getPort());
            slotHostMapLocal.set(slotHostMap);

            Map<String, JedisPool> hostClientMap = cluster.getClusterNodes();
            Map<String, Pipeline> hostPipelineMap = new HashMap<>();
            for (Map.Entry<String, JedisPool> en : hostClientMap.entrySet()) {
              hostPipelineMap.put(en.getKey(), en.getValue().getResource().pipelined());
            }
            hostPipelineMapLocal.set(hostPipelineMap);

            Runtime.getRuntime().addShutdownHook(new Thread() {
              @Override
              public void run() {
                synchronized (hostPipelineMapLocal) {
                  syncPipeline();
                  closePipeline();
                }
              }
            });
          } catch (IOException e) {
            throw new HiveException("io error!", e);
          }
        }
        if (cluster == null)
          throw new HiveException("bad redis cluster id found!");
      }
    }
    return cluster;
  }

  public static Pipeline getPipeline(String key) {
    int slot = JedisClusterCRC16.getSlot(key);
    Map.Entry<Long, String> entry = slotHostMapLocal.get().floorEntry(Long.valueOf(slot));
    Pipeline pipeline = hostPipelineMapLocal.get().get(entry.getValue());
    return pipeline;
  }

  public static void syncPipeline() {
    Map<String, Pipeline> hostPipelineMap = hostPipelineMapLocal.get();
    if (hostPipelineMap != null) {
      if (LOG.isDebugEnabled())
        LOG.debug("sync pipeline :" + hostPipelineMap);
      for (Pipeline pipeline : hostPipelineMap.values()) {
        pipeline.sync();
      }
    }
  }

  public static void closePipeline() {
    Map<String, Pipeline> hostPipelineMap = hostPipelineMapLocal.get();
    if (hostPipelineMap != null) {
      if (LOG.isDebugEnabled())
        LOG.debug("closing pipeline :" + hostPipelineMap);
      for (Pipeline pipeline : hostPipelineMap.values()) {
        pipeline.close();
      }
    }
  }

  public static void close() {
    Map<String, Pipeline> hostPipelineMap = hostPipelineMapLocal.get();
    if (hostPipelineMap != null) {
      synchronized (hostPipelineMapLocal) {
        syncPipeline();
        closePipeline();
      }
    }
  }

  public static void main(String[] args) throws Exception {
    JedisCluster cluster = initJedisCluster("");
    int slot = JedisClusterCRC16.getSlot("key");
    Map.Entry<Long, String> entry = slotHostMapLocal.get().lowerEntry(Long.valueOf(slot));
    Pipeline pipeline = hostPipelineMapLocal.get().get(entry.getValue());
//    pipeline.hmset()

    pipeline.sync();
    pipeline.close();
  }


  public static Long parseExpire(GenericUDF.DeferredObject arg, ObjectInspector expireIo) throws HiveException {
    Long expire = null;

    if (expireIo instanceof WritableLongObjectInspector) {
      expire = (Long) ((WritableLongObjectInspector) expireIo).getPrimitiveJavaObject(arg.get());
    } else if (expireIo instanceof JavaLongObjectInspector) {
      expire = ((JavaLongObjectInspector) expireIo).get(arg.get());
    } else if (expireIo instanceof WritableStringObjectInspector ||
            expireIo instanceof JavaStringObjectInspector) {
      String expireString = null;
      if (expireIo instanceof WritableStringObjectInspector)
        expireString = ((WritableStringObjectInspector) expireIo).getPrimitiveWritableObject(arg.get()).toString();
      else if (expireIo instanceof JavaStringObjectInspector)
        expireString = ((JavaStringObjectInspector) expireIo).getPrimitiveJavaObject(arg.get());

      if (expireString != null) {
        switch (expireString.length()) {
          case 8:
            format = format8;
            break;
          case 14:
            format = format14;
            break;
          case 15:
            format = format15;
            break;
          case 16:
            format = format16;
            break;
          case 17:
            format = format17;
            break;
          default:
            format = null;
        }
        if (format != null) {
          try {
            Date d = format.parse(expireString);
            expire = d.getTime() / 1000;
          } catch (ParseException e) {
            e.printStackTrace();
          }
        }
      }
    }
    return expire;
  }
}
