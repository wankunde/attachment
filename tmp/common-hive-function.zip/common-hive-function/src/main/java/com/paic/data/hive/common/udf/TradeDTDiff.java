package com.paic.data.hive.common.udf;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.text.ParseException;
import java.util.NavigableSet;
import java.util.SortedSet;
import java.util.TreeSet;

import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.io.IOUtils;

@Description(name = "trd_dt_diff", value = "_FUNC_(yyyyMMdd, yyyyMMdd) - Returns diff")
public class TradeDTDiff extends UDF {
    static NavigableSet<String> allSet = new TreeSet<String>();

    private static NavigableSet<String> loadFromFile() throws HiveException, IOException {
        NavigableSet<String> allSet = new TreeSet<String>();
        Configuration conf = new Configuration();
        String uri = "hdfs:///metadata/dim/tradecalender.csv";
        FSDataInputStream in = null;
        BufferedReader reader = null;
        try {
            FileSystem hdfs = FileSystem.get(URI.create(uri), conf);
            in = hdfs.open(new org.apache.hadoop.fs.Path(uri));
            reader = new BufferedReader(new InputStreamReader(in));
            String line = null;
            while ((line = reader.readLine()) != null) {
                allSet.add(line);
            }
            IOUtils.copyBytes(in, System.out, 4096, false);
        } finally {
            IOUtils.closeStream(in);
        }
        return (NavigableSet<String>) allSet;
    }

    public Integer evaluate(String startDate, String endDate) throws ParseException, HiveException, IOException {
        if (StringUtils.isEmpty(startDate) || StringUtils.isEmpty(endDate)) {
            return null;
        }
        if(startDate.matches("\\d{4}-\\d{2}-\\d{2}")){
            startDate = startDate.replaceAll("-","");
        }
        if(endDate.matches("\\d{4}-\\d{2}-\\d{2}")){
            endDate = endDate.replaceAll("-","");
        }
//        if(!allSet.contains(startDate)||!allSet.contains(endDate)){
//            System.out.println("Invalid startDate or endDate,please use the format \"yyyyMMdd\" or format \"yyyy-MM-dd\"");
//            throw new RuntimeException("Invalid startDate or endDate,please use the format \"yyyyMMdd\" or format \"yyyy-MM-dd\"");
//        }
        if (allSet.isEmpty()) {
            allSet = loadFromFile();
        }
        if (Integer.valueOf(endDate) < Integer.valueOf(startDate)) {
            SortedSet<String> subSet = allSet.subSet(endDate, startDate);
            return -1*subSet.size();
        }
        SortedSet<String> subSet = allSet.subSet(startDate, endDate);
        return subSet.size();
    }

}
