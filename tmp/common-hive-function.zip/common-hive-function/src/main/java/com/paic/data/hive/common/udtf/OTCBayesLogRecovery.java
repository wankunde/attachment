package com.paic.data.hive.common.udtf;

import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDTF;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.StringObjectInspector;

import com.paic.data.hive.common.udtf.otcBayesLogRecovery.DateAccount;
import com.paic.data.hive.common.udtf.otcBayesLogRecovery.OTCBayesLogRecoveryProcessor;
import com.paic.data.hive.common.udtf.otcBayesLogRecovery.RDateAccount;





@Description(name = "otc_bayes_log_recovery",
value = "_FUNC_(a) - recover otc-asset-log,"
  + " on account-inst level")
public class OTCBayesLogRecovery extends GenericUDTF {

	
	private transient ObjectInspector inputOI = null;
	
	@Override
	public StructObjectInspector initialize(ObjectInspector[] args) throws UDFArgumentException {
		inputOI = args[0];
		ArrayList<String> fieldNames = new ArrayList<String>();
	    ArrayList<ObjectInspector> fieldOIs = new ArrayList<ObjectInspector>();
	    
	    //TODO output define
	      fieldNames.add("dt");
	      fieldOIs.add(PrimitiveObjectInspectorFactory.javaStringObjectInspector);
	      fieldNames.add("mkt_val");
	      fieldOIs.add(PrimitiveObjectInspectorFactory.javaDoubleObjectInspector);
	      fieldNames.add("b_amt");
	      fieldOIs.add(PrimitiveObjectInspectorFactory.javaDoubleObjectInspector);
	      fieldNames.add("s_amt");
	      fieldOIs.add(PrimitiveObjectInspectorFactory.javaDoubleObjectInspector);
	      fieldNames.add("div_amt");
	      fieldOIs.add(PrimitiveObjectInspectorFactory.javaDoubleObjectInspector);
	      fieldNames.add("h_b_amt");
	      fieldOIs.add(PrimitiveObjectInspectorFactory.javaDoubleObjectInspector);
	      fieldNames.add("h_s_amt");
	      fieldOIs.add(PrimitiveObjectInspectorFactory.javaDoubleObjectInspector);
	      fieldNames.add("confidence");
	      fieldOIs.add(PrimitiveObjectInspectorFactory.javaDoubleObjectInspector);
	      //fieldOIs.add(((MapObjectInspector)inputOI).getMapKeyObjectInspector());
	      //fieldOIs.add(((MapObjectInspector)inputOI).getMapValueObjectInspector());*/
	      
	    return ObjectInspectorFactory.getStandardStructObjectInspector(fieldNames,fieldOIs);
	}
	
	@Override
	public void close() throws HiveException {
		// TODO Auto-generated method stub
		
	}
	
	//TODO col-num
	//private transient final Object[] forwardListObj = new Object[8];
	
	@Override
	public void process(Object[] arg0) throws HiveException {
		StringObjectInspector oi = (StringObjectInspector)inputOI;
		String input = oi.getPrimitiveJavaObject(arg0[0]);
		//TODO call function
	      if (input == null) {
	        return;
	      }
	      
	      try {
		      List<DateAccount> Linitial = OTCBayesLogRecoveryProcessor.read(input); 
		      List<RDateAccount> Lrectify = OTCBayesLogRecoveryProcessor.Recover(Linitial);
		      for(int k=0;k<Lrectify.size();++k)
		      {
		    	  Object[] forwardListObj = new Object[8];
		    		  forwardListObj[0]=Linitial.get(k).date;
		    		  forwardListObj[1]=Linitial.get(k).mkt;
		    		  forwardListObj[2]=Linitial.get(k).b;
		    		  forwardListObj[3]=Linitial.get(k).s;
		    		  forwardListObj[4]=Linitial.get(k).div;
		    		  forwardListObj[5]=Lrectify.get(k).b;
			    	  forwardListObj[6]=Lrectify.get(k).s;
			    	  forwardListObj[7]=Lrectify.get(k).probability;
			      forward(forwardListObj);
		      }
	      } catch(Exception e) {
	    	  throw new RuntimeException(input);
	      }

	}
	

   
}

