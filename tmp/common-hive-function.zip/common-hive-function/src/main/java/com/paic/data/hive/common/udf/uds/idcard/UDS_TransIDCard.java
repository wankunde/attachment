package com.paic.data.hive.common.udf.uds.idcard;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;

@Description(name = "uds_trans_idcard", value = "_FUNC_(String idCard) - Returns String newIdCard")
public class UDS_TransIDCard extends UDF {
	public String evaluate(String _idCard) {
		if (_idCard != null) {
			String idCard = _idCard.trim();
            if (!UDS_IsValidIdCard.isValidIdCard(idCard)) {
            	return idCard;
            }
			if (idCard.length() == 15) {
	            StringBuilder sb = new StringBuilder();  
	            sb.append(idCard.substring(0, 6)).append("19").append(idCard.substring(6));
	            try {
					sb.append(getVerifyCode(sb.toString()));
				} catch (Exception e) {
					return idCard;
				}
	            return sb.toString();
			} else if (idCard.length() == 18) {
				// 将小写 x 转换成 大写X
				if (idCard.endsWith("x")) {
					try {
						char verifyCode = getVerifyCode(idCard);
						if ('X' == verifyCode) {
							return idCard.toUpperCase();
						} else {
							return idCard;
						}
					} catch (Exception e) {
						return idCard;
					}
				}
				return idCard;
			} else {
				return idCard;
			}
		} else {
            return "";
        }
    }

    public static char getVerifyCode(String idCardNumber) throws Exception{  
        if(idCardNumber == null || idCardNumber.length() < 17) {  
            throw new Exception("不合法的身份证号码");
        }  
        char[] Ai = idCardNumber.toCharArray();  
        int[] Wi = {7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2};  
        char[] verifyCode = {'1','0', 'X', '9', '8', '7', '6', '5', '4', '3', '2'};  
        int S = 0;  
        int Y;  
        for(int i = 0; i < Wi.length; i++) {
            S += (Ai[i] - '0') * Wi[i];  
        }
        Y = S % 11;
        return verifyCode[Y];
    }
    
//    public static boolean isValidDate(String idCard) {
//		try {
//			if (idCard.length() < 2) {
//				return false;
//			}
//			
//			String identityId = idCard.trim();
//			int month = -1;
//			int day = -1;
//			if (identityId.length() == 15) {
//				month = Integer.parseInt(identityId.substring(8, 10));
//				day = Integer.parseInt(identityId.substring(10, 12));
//			}
//			else if (identityId.length() == 18) {
//				month = Integer.parseInt(identityId.substring(10, 12));
//				day = Integer.parseInt(identityId.substring(12, 14));
//			} else {
//				return false;
//			}
//			
//			if (month < 1 || month > 12) {
//				return false;
//			}
//			if (day < 1 || day > 31) {
//				return false;
//			} else {
//				return true;
//			}
//		} catch (Exception ex) {
//			return false;
//		}
//    }
}
