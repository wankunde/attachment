package com.paic.data.hive.common.udaf;

import com.paic.data.hive.common.udf.bean.ColsGroupsBean;
import com.paic.data.hive.common.utils.UdfUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDAF;
import org.apache.hadoop.hive.ql.exec.UDAFEvaluator;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDAFEvaluator;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Description(name = "measure_all_map",
        value = "_FUNC_(value,dt,indexName,colsGroups [, expr...]) - Returns map. The key is col group value,and value is sum(value). ")
public class MeasureAllMap extends UDAF {

    private static final Log LOG = LogFactory.getLog(MeasureAllMap.class);

    @GenericUDAFEvaluator.AggregationType(estimable = true)
    public static class DoubleMapBean extends GenericUDAFEvaluator.AbstractAggregationBuffer {
        public Map<String, Map<String, Double>> value;
    }

    public static abstract class MeasureMapEvaluator<T> implements UDAFEvaluator {
        ColsGroupsBean colsGroupsBean;
//        StopWatch watch = new StopWatch();

        public Map<String, Map<String, T>> doIterate(Map<String, Map<String, T>> value, T asset, String dt, String title, String colsGroups, Object... parameters) {
            /*if (LOG.isDebugEnabled())
                LOG.debug(new ToStringBuilder(this)
                        .append("countAgg.value", value)
                        .append("asset", asset)
                        .append("title", title)
                        .append("colsGroups", colsGroups)
                        .append("parameters", parameters));*/
//
//            LOG.debug("watch 1 test : "+watch.getNanoTime());
            if (colsGroupsBean == null) {
                colsGroups = colsGroups.toLowerCase();
                colsGroupsBean = ColsGroupsBean.getColsGroupBean(colsGroups);
            }
//            LOG.debug("watch 2 : "+watch.getNanoTime());
            List<String> mapKeys = colsGroupsBean.getMapKeys(title, colsGroups, parameters);
//            LOG.debug("watch 3 : "+watch.getNanoTime());
            for (String mapKey : mapKeys) {
                Map<String, T> dayMap = value.get(mapKey);
                if (dayMap == null)
                    dayMap = new HashMap<>();
                T data = dayMap.get(dt);
                data = (T) (data == null ? asset : UdfUtils.addData(asset, data));
                if (data != null)
                    dayMap.put(dt, data);
                value.put(mapKey, dayMap);
            }
//            LOG.debug("watch 4 : "+watch.getNanoTime());
//            watch.stop();
            /*if (LOG.isDebugEnabled())
                LOG.debug(new ToStringBuilder(this)
                        .append("parameters", Arrays.toString(parameters))
                        .append("agg.value", value));*/
            return value;
        }

        public Map<String, Map<String, T>> doMerge(Map<String, Map<String, T>> v1, Map<String, Map<String, T>> v2) {
//            watch.reset();
//            watch.start();
//            LOG.debug(" merge. v1 : " + v1 + " v2 : " + v2);
            for (Map.Entry<String, Map<String, T>> en : v2.entrySet()) {
                String key = en.getKey();
                Map<String, T> cmap2 = en.getValue();
                Map<String, T> cmap1 = v1.get(key);
                if (cmap1 == null)
                    cmap1 = new HashMap<>();
                if (cmap2 != null) {
                    //merge cmap1 and cmap2
                    for (Map.Entry<String, T> en2 : cmap2.entrySet()) {
                        String dt = en2.getKey();
                        T todayValue = en2.getValue();
                        if (cmap1.containsKey(dt))
                            cmap1.put(dt, (T) UdfUtils.addData(todayValue, cmap1.get(dt)));
                        else
                            cmap1.put(dt, todayValue);
                    }

                    v1.put(key, cmap1);
                }
            }
//            LOG.debug("watch 1 : "+watch.getNanoTime());
//            watch.stop();
//            LOG.debug(" merge. result : " + v1);
            return v1;
        }
    }


    public static class MeasureMapDoubleEvaluator extends MeasureMapEvaluator<Double> {
        DoubleMapBean countAgg;

        public MeasureMapDoubleEvaluator() {
            super();
            countAgg = new DoubleMapBean();
            init();
        }

        @Override
        public void init() {
            countAgg.value = new HashMap<>();
        }

        public boolean iterate(Double asset, String dt, String title, String colsGroups, Object... parameters) {
            countAgg.value = super.doIterate(countAgg.value, asset, dt, title, colsGroups, parameters);
            if (countAgg.value != null)
                return true;
            else
                return false;
        }

        public boolean merge(DoubleMapBean o) {
            if (o != null && o.value != null)
                countAgg.value = doMerge(countAgg.value, o.value);
            return true;
        }

        public DoubleMapBean terminatePartial() {
            return countAgg;
        }

        public Map<String, Map<String, Double>> terminate() {
            return countAgg.value;
        }
    }
}
