package com.paic.data.hive.common.udf.date;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;

@Description(name = "now_week_start", value = "_FUNC_(YYYYMMDD, diff) - Returns a shifted dt")
public class NowWeekStart extends UDF implements DTNowBase {
	
	public static int translateDayOfWeek(int dayOfWeek) {
		switch (dayOfWeek) {
		case Calendar.MONDAY: return 0;
		case Calendar.TUESDAY: return 1;
		case Calendar.WEDNESDAY: return 2;
		case Calendar.THURSDAY: return 3;
		case Calendar.FRIDAY: return 4;
		case Calendar.SATURDAY: return 5;
		case Calendar.SUNDAY: return 6;
		default: return 0;
		}
	}
	
	@Override
	public String evaluate(String format, int diff) throws ParseException {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, diff * 7 - translateDayOfWeek(calendar.get(Calendar.DAY_OF_WEEK)));
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		return new SimpleDateFormat(format).format(calendar.getTime());
    }
	
	public static void main(String[] args) throws ParseException {
		System.out.println(new NowWeekStart().evaluate("yyyyMMddHHmm", -1));
		System.out.println(new NowWeekStart().evaluate("yyyyMMddHHmm", 0));
		System.out.println(new NowWeekStart().evaluate("yyyyMMddHHmm", 1));
	}
}
