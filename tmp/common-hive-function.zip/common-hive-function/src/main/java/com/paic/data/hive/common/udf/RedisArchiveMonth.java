package com.paic.data.hive.common.udf;

import com.google.common.base.Joiner;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.exec.UDFArgumentLengthException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDF;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorConverters;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.Tuple;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * Created by wankun603 on 2018-03-21.
 * <p>
 * Paic redis Client : mvn install:install-file -Dfile=D:\tmp\jedis-3.0.0-20180612.085950-1.jar -DgroupId=redis.clients -DartifactId=jedis -Dversion=3.0.0-SNAPSHOT -Dpackaging=jar
 */
@Description(name = "redis_archive_month", value = "_FUNC_(cluster, key, month, header, expireSeconds) - archive a month values to a archive value in redis .")
public class RedisArchiveMonth extends GenericUDF {
  private transient ObjectInspectorConverters.Converter[] converters;

  @Override
  public ObjectInspector initialize(ObjectInspector[] arguments) throws UDFArgumentException {
    if (arguments.length == 5) {
      converters = new ObjectInspectorConverters.Converter[arguments.length];
      converters[0] = ObjectInspectorConverters.getConverter(arguments[0],
              PrimitiveObjectInspectorFactory.writableStringObjectInspector);
      converters[1] = ObjectInspectorConverters.getConverter(arguments[1],
              PrimitiveObjectInspectorFactory.writableStringObjectInspector);
      converters[2] = ObjectInspectorConverters.getConverter(arguments[2],
              PrimitiveObjectInspectorFactory.writableIntObjectInspector);
      converters[3] = ObjectInspectorConverters.getConverter(arguments[3],
              PrimitiveObjectInspectorFactory.writableStringObjectInspector);
      converters[4] = ObjectInspectorConverters.getConverter(arguments[4],
              PrimitiveObjectInspectorFactory.writableIntObjectInspector);
    } else
      throw new UDFArgumentLengthException(
              "The function _FUNC_(cluster, key, month, header, expireSeconds) takes 5 arguments.");
    return PrimitiveObjectInspectorFactory.writableLongObjectInspector;
  }

  @Override
  public Object evaluate(DeferredObject[] arguments) throws HiveException {
    String clusterId = (converters[0].convert(arguments[0].get())).toString();
    JedisCluster cluster = RedisUtils.initJedisCluster(clusterId);
    String key = (converters[1].convert(arguments[1].get())).toString();
    int month = ((IntWritable) converters[2].convert(arguments[2].get())).get();
    String header = (converters[3].convert(arguments[3].get())).toString();
    int expireSeconds = ((IntWritable) converters[4].convert(arguments[4].get())).get();
    final String NEW_LINE = "\n";
    final String SPLIT_STRING = "`";

    int begin = month * 100 + 1;
    int end = month * 100 + 31;
    StringBuilder archive = new StringBuilder();

    for (Tuple s : cluster.zrangeByScoreWithScores(key, begin, end)) {
      archive.append(s.getElement()).append(NEW_LINE);
    }
    if (archive.length() <= 0) {
      return new LongWritable(0);
    } else {//删除最后一个换行符
      archive.delete(archive.length() - NEW_LINE.length(), archive.length());
    }


    StringBuilder result = new StringBuilder();
    result.append(header);
    if (archive.length() > 0) {
      result.append(NEW_LINE).append(compress(archive.toString()));
    }

    //先刪除月度归档数据，再次归档
    int score = month * 100;
    cluster.zremrangeByScore(key, score, score);
    long count = cluster.zadd(key, score, result.toString());
    cluster.expire(key, expireSeconds);
    cluster.zremrangeByScore(key, begin, end);

    return new LongWritable(count);

  }

  /**
   * 压缩
   *
   * @param str
   * @return
   */
  public static String compress(String str) {
    if (str == null || str.length() == 0) {
      return null;
    }
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    GZIPOutputStream gzip;
    try {
      gzip = new GZIPOutputStream(out);
      gzip.write(str.getBytes("ISO-8859-1"));
      gzip.close();
    } catch (Exception e) {
      e.printStackTrace();
    }

    try {
      return out.toString("ISO-8859-1");
    } catch (UnsupportedEncodingException e) {
      e.printStackTrace();
    }
    return null;
  }


  /**
   * 对数据体进行解压
   *
   * @param fullData
   * @return 解压后的数据
   */
  private static String uncompress(String fullData) {
    byte[] bytes = new byte[0];
    try {
      bytes = fullData.getBytes("ISO-8859-1");
    } catch (UnsupportedEncodingException e) {
      e.printStackTrace();
    }

    if (bytes == null || bytes.length == 0) {
      return null;
    }

    ByteArrayOutputStream out = new ByteArrayOutputStream();
    ByteArrayInputStream in = new ByteArrayInputStream(bytes);
    try {
      GZIPInputStream ungzip = new GZIPInputStream(in);
      byte[] buffer = new byte[256];
      int n;
      while ((n = ungzip.read(buffer)) >= 0) {
        out.write(buffer, 0, n);
      }
      return out.toString();
    } catch (Exception e) {
      e.printStackTrace();
    }
    return null;
  }

  @Override
  public String getDisplayString(String[] children) {
    return "redis_archive_month(" + Joiner.on(",").join(children) + ")";
  }
}
