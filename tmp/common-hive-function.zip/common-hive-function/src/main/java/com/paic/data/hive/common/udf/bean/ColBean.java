package com.paic.data.hive.common.udf.bean;

import org.apache.hadoop.hive.ql.udf.generic.GenericUDAFEvaluator;

/**
 * Created by WANKUN603 on 2016-06-01.
 */
@GenericUDAFEvaluator.AggregationType(estimable = true)
public class ColBean extends GenericUDAFEvaluator.AbstractAggregationBuffer {

    private String name;
    private int idx;

    public ColBean(String name, int idx) {
        this.name = name;
        this.idx = idx;
    }

    @Override
    public String toString() {
        return "ColBean{" +
                "name='" + name + '\'' +
                ", idx=" + idx +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ColBean colBean = (ColBean) o;

        if (idx != colBean.idx) return false;
        return name.equals(colBean.name);

    }

    @Override
    public int hashCode() {
        int result = name.hashCode();
        result = 31 * result + idx;
        return result;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getIdx() {
        return idx;
    }

    public void setIdx(int idx) {
        this.idx = idx;
    }
}
