package com.paic.data.hive.common.utils;


import java.util.Iterator;
import java.util.Set;
import org.apache.commons.lang.StringUtils;

public class CollectionUtils
{
  public static Set putAll(Set destSet, String[] srcs)
  {
    for (int i = 0; i < srcs.length; i++) {
      destSet.add(srcs[i]);
    }

    return destSet;
  }

  public static Set putAll(Set destSet, Iterator it)
  {
    while (it.hasNext()) {
      destSet.add(it.next());
    }
    return destSet;
  }

  public static Set putAll(Set destSet, Set srcSet) {
    return putAll(destSet, srcSet.iterator());
  }

  public static int isStart(Iterator it, String telno)
  {
    String tmp = "";

    if (StringUtils.isEmpty(telno)) {
      return -1;
    }

    while (it.hasNext()) {
      tmp = (String)it.next();
      if (telno.startsWith(tmp)) {
        return 0;
      }
    }

    return -1;
  }

  public static String getStart(Iterator it, String telno) {
    String tmp = "";

    if (StringUtils.isEmpty(telno)) {
      return tmp;
    }

    while (it.hasNext()) {
      tmp = (String)it.next();
      if (telno.startsWith(tmp)) {
        return tmp;
      }
    }

    return "";
  }
}