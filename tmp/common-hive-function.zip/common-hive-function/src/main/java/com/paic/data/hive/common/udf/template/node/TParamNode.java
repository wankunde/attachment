package com.paic.data.hive.common.udf.template.node;

import java.util.Collection;

import com.paic.data.hive.common.udf.template.TNode;
import com.paic.data.hive.common.udf.template.TPushData;
import com.paic.data.hive.common.udf.template.TUserData;



public class TParamNode extends TVarNode {
	
	private final String param;
	private final String lowerParam;
	
	public TParamNode(String param) {
		this.param = param.trim();
		this.lowerParam = this.param.toLowerCase();
	}
	
	public String getName() {
		return param;
	}

	@Override
	public void params(Collection<String> params) {
		params.add(lowerParam);
	}

	@Override
	public void toString(StringBuffer output, String channel, TUserData userData, TPushData pushData) {
		Object ret = userData.getParam(lowerParam);
		if (ret instanceof TNode) {
			((TNode) ret).toString(output, channel, userData, pushData);
		} else {
			output.append(ret != null ? ret.toString() : "");
		}
	}
	
	@Override
	public String toString(String channel, TUserData userData, TPushData pushData) {
		Object ret = userData.getParam(lowerParam);
		if (ret instanceof TNode) {
			return ((TNode) ret).toString(channel, userData, pushData);
		} else {
			return ret != null ? ret.toString() : "";
		}
	}
	
	@Override
	public String toString() {
		return "#{"+param+"}";
	}
}
