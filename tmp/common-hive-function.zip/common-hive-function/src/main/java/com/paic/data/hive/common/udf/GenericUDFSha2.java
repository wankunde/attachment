package com.paic.data.hive.common.udf;

import org.apache.commons.codec.binary.Hex;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.exec.UDFArgumentTypeException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDF;
import org.apache.hadoop.hive.serde2.objectinspector.ConstantObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorConverters;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorConverters.Converter;
import org.apache.hadoop.hive.serde2.objectinspector.PrimitiveObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.PrimitiveObjectInspector.PrimitiveCategory;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorUtils;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorUtils.PrimitiveGrouping;
import org.apache.hadoop.io.*;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Created by WANGYI422 on 2018/9/26.
 */
@Description(name = "sha2", value = "_FUNC_(string,binary, len) - Calculates the SHA-2 family of hash functions"
        + "(SHA-224, SHA-256, SHA-384, and SHA-512).",
        extended = "The first argument is the string or binary to be hashed. "
        + "The second argument indicates the desired bit length of the result, "
        + "which must have a value of 224, 256, 384, 512, or 0 (which is equivalent to 256). "
        + "SHA-224 is supported starting from Java8. "
        + "If either argument is NULL or the hash length is not one of the permitted values, the return value is NULL.\n"
        + "Example: > SELECT _FUNC_('ABC',256);\n 'b5d4045c3f466fa91fe2cc6abe79232a1a57cdf104f7a26e716e0a1e2789df78'")
public class GenericUDFSha2  extends GenericUDF{
    private static final String[] ORDINAL_SUFFIXES = new String[]{"th", "st", "nd", "rd", "th", "th", "th", "th", "th", "th"};

    private transient Converter[] converters = new Converter[2];
    private transient PrimitiveCategory[] inputTypes = new PrimitiveCategory[2];
    private transient boolean isStr;
    private transient MessageDigest digest;
    private final Text output = new Text();

    @Override
    public ObjectInspector initialize(ObjectInspector[] arguments) throws UDFArgumentException {
        checkArgsSize(arguments, 2,2);

        checkArgPrimitive(arguments, 0);
        checkArgPrimitive(arguments, 1);

        checkArgGroups(arguments, 0, inputTypes, PrimitiveGrouping.STRING_GROUP, PrimitiveGrouping.BINARY_GROUP);
        checkArgGroups(arguments, 1, inputTypes, PrimitiveGrouping.NUMERIC_GROUP);

        if (PrimitiveObjectInspectorUtils.getPrimitiveGrouping(inputTypes[0]) == PrimitiveGrouping.STRING_GROUP) {
            obtainStringConverter(arguments, 0, inputTypes, converters);
            isStr = true;
        } else {
            obtainBinaryConverter(arguments, 1, inputTypes, converters);
            isStr = false;
        }

        if (arguments[1] instanceof ConstantObjectInspector) {
            Integer lenObj = getConstantIntValue(arguments, 1);
            if (lenObj != null) {
                int len = lenObj.intValue();
                if (len == 0) {
                    len = 256;
                }
                try {
                    digest = MessageDigest.getInstance("SHA-" + len);
                } catch (NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }
            }
        } else {
            throw new UDFArgumentTypeException(1, getFuncName() + " only takes constant as "
                    + getArgOrder(1) + " argument");
        }

        ObjectInspector outputOi = PrimitiveObjectInspectorFactory.writableStringObjectInspector;
        return outputOi;
    }

    @Override
    public Object evaluate(DeferredObject[] arguments) throws HiveException {
        if (digest == null) {
            return null;
        }

        digest.reset();
        if (isStr) {
            Text n = getTextValue(arguments, 0, converters);
            if (n == null) return null;
            digest.update(n.getBytes(), 0, n.getLength());
        } else {
            BytesWritable bWr = getBinaryValue(arguments, 0, converters);
            if (bWr == null) return null;
            digest.update(bWr.getBytes(), 0, bWr.getLength());
        }

        byte[] resBin = digest.digest();
        String resStr = Hex.encodeHexString(resBin);
        output.set(resStr);
        return output;
    }

    @Override
    public String getDisplayString(String[] children) {
        StringBuilder sb = new StringBuilder();
        sb.append(getFuncName()).append("(");
        if (children.length > 0) {
            sb.append(children[0]);
            for (int i = 1; i<children.length; i++) {
                sb.append(", ");
                sb.append(children[i]);
            }
        }
        sb.append(")");
        return sb.toString();
    }

    @Override
    protected String getFuncName() {
        return "sha2";
    }

    private void checkArgPrimitive(ObjectInspector[] argument, int i) throws UDFArgumentTypeException {
        ObjectInspector.Category oiCat = argument[i].getCategory();
        if (oiCat != ObjectInspector.Category.PRIMITIVE) {
            throw new UDFArgumentTypeException(i, getFuncName() + " only takes primitive types as "
                    + getArgOrder(i) + " argument, got " + oiCat);
        }
    }

    private void checkArgGroups(ObjectInspector[] arguments, int i, PrimitiveCategory[] inputTypes,
                                PrimitiveGrouping... grps) throws UDFArgumentTypeException {
        PrimitiveCategory inputType = ((PrimitiveObjectInspector) arguments[i]).getPrimitiveCategory();
        for (PrimitiveGrouping grp : grps) {
            if (PrimitiveObjectInspectorUtils.getPrimitiveGrouping(inputType) == grp) {
                inputTypes[i] = inputType;
                return;
            }
        }
        StringBuilder sb = new StringBuilder();
        sb.append(getFuncName());
        sb.append(" only takes ");
        sb.append(grps[0]);
        for (int j = 1; j < grps.length; j++) {
            sb.append(", ");
            sb.append(grps[j]);
        }
        sb.append(" types as ");
        sb.append(getArgOrder(i));
        sb.append(" argument, got ");
        sb.append(inputType);
        throw new UDFArgumentTypeException(i, sb.toString());
    }

    private Integer getConstantIntValue(ObjectInspector[] arguments, int i) throws UDFArgumentTypeException{
        Object constValue = ((ConstantObjectInspector) arguments[i]).getWritableConstantValue();
        if (constValue == null) return null;

        int v;
        if (constValue instanceof IntWritable) {
            v = ((IntWritable) constValue).get();
        } else if (constValue instanceof ShortWritable) {
            v = ((ShortWritable) constValue).get();
        } else if (constValue instanceof ByteWritable) {
            v = ((ByteWritable) constValue).get();
        } else {
            throw new UDFArgumentTypeException(i, getFuncName() + " only takes INT/SHORT/BYTE types as"
                    + getArgOrder(i) + " argument, got " + constValue.getClass());
        }
        return v;
    }

    private String getArgOrder(int i) {
        i++;
        switch (i % 100) {
            case 11:
            case 12:
            case 13:
                return i + "th";
            default:
                return i + ORDINAL_SUFFIXES[i % 10];
        }
    }

    private void obtainStringConverter(ObjectInspector[] arguments, int i, PrimitiveCategory[] inputTypes,
                                       Converter[] converters) throws UDFArgumentTypeException {
        PrimitiveObjectInspector inOi = (PrimitiveObjectInspector) arguments[i];
        PrimitiveCategory inputType = inOi.getPrimitiveCategory();

        Converter converter = ObjectInspectorConverters.getConverter(arguments[i],
                PrimitiveObjectInspectorFactory.writableStringObjectInspector);
        converters[i] = converter;
        inputTypes[i] = inputType;
    }

    private void obtainBinaryConverter(ObjectInspector[] arguments, int i, PrimitiveCategory[] inputTypes,
                                       Converter[] converters) throws UDFArgumentTypeException {
        PrimitiveObjectInspector inOi = (PrimitiveObjectInspector) arguments[i];
        PrimitiveCategory inputType = inOi.getPrimitiveCategory();

        Converter converter = ObjectInspectorConverters.getConverter(arguments[i],
                PrimitiveObjectInspectorFactory.writableBinaryObjectInspector);
        converters[i] = converter;
        inputTypes[i] = inputType;
    }

    private Text getTextValue(DeferredObject[] arguments, int i, Converter[] converters) throws HiveException {
        Object obj;
        if ((obj = arguments[i].get()) == null) return null;

        Object writableValue = converters[i].convert(obj);
        return (Text) writableValue;
    }

    private BytesWritable getBinaryValue(DeferredObject[] arguments, int i, Converter[] converters) throws HiveException {
        Object obj;
        if ((obj = arguments[i].get()) == null) return null;

        Object writableValue = converters[i].convert(obj);
        return (BytesWritable) writableValue;
    }
}
