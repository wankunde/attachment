package com.paic.data.hive.common.udf;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.exec.UDFArgumentLengthException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDF;
import org.apache.hadoop.hive.serde2.lazy.LazyDouble;
import org.apache.hadoop.hive.serde2.lazy.LazyMap;
import org.apache.hadoop.hive.serde2.lazy.LazyString;
import org.apache.hadoop.hive.serde2.objectinspector.MapObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.StringObjectInspector;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;

import java.util.HashMap;
import java.util.Map;

@Description(name = "measure_get_map",
        value = "_FUNC_(his,dt) - Returns map. Get the dt map values.")

public class MeasureGetMap extends GenericUDF {

    private static final Log LOG = LogFactory.getLog(MeasureGetMap.class);

/*
    private transient ObjectInspectorConverters.Converter soi_text;
*/
    MapObjectInspector mapOI;
    StringObjectInspector textOI;

    @Override
    public ObjectInspector initialize(ObjectInspector[] arguments) throws UDFArgumentException {
        if (arguments.length != 2) {
            throw new UDFArgumentLengthException("_FUNC_ must have odd arguments: Map<String, T>, String");
        }
        // 1. Check we received the right object types.
        ObjectInspector c1 = arguments[0];
        ObjectInspector c2 = arguments[1];

        if (!(c1 instanceof MapObjectInspector)
                || !(c2 instanceof StringObjectInspector)) {
            throw new UDFArgumentException("argument type error");
        }
        /*this.soi_text = ObjectInspectorConverters.getConverter(arguments[0],
                ObjectInspectorFactory.getStandardMapObjectInspector(
                        PrimitiveObjectInspectorFactory.writableStringObjectInspector,
                        ObjectInspectorFactory.getStandardMapObjectInspector(
                                PrimitiveObjectInspectorFactory.writableStringObjectInspector,
                                PrimitiveObjectInspectorFactory.writableDoubleObjectInspector)));*/
        this.mapOI = (MapObjectInspector) c1;
        this.textOI = (StringObjectInspector) c2;

        return ObjectInspectorFactory.getStandardMapObjectInspector(
                PrimitiveObjectInspectorFactory.writableStringObjectInspector,
                PrimitiveObjectInspectorFactory.writableDoubleObjectInspector);
    }

    @Override
    public Object evaluate(DeferredObject[] arguments) throws HiveException {
//        Map map = (Map)this.soi_text.convert(arguments[0].get());
        Map map = this.mapOI.getMap(arguments[0].get());
        Text dt = this.textOI.getPrimitiveWritableObject(arguments[1].get());

        return doEvaluate(map, dt);
    }

    @Override
    public String getDisplayString(String[] args) {
        return "get today map values  ";
    }

    public Map<Text, DoubleWritable> doEvaluate(Map<Object, Object> his, Text dt) throws HiveException {
        Map<Text, DoubleWritable> res = new HashMap<>();
        for (Map.Entry<Object, Object> en : his.entrySet()) {
            if (en.getKey() instanceof LazyString) {
                Text key = ((LazyString) en.getKey()).getWritableObject();

                LazyDouble v = (LazyDouble) ((LazyMap) en.getValue()).getMapValueElement(dt);
                if (v != null)
                    res.put(key, v.getWritableObject());
            }
            else if (en.getKey() instanceof String) {
                Text key = new Text((String) en.getKey());
                Map<String, Double> value = (Map<String, Double>) en.getValue();
                if (value != null && value.containsKey(dt.toString()) && value.get(dt.toString())!=null) {
                    res.put(key, new DoubleWritable(value.get(dt.toString())));
                }
            }
        }
        return res;
    }
}
