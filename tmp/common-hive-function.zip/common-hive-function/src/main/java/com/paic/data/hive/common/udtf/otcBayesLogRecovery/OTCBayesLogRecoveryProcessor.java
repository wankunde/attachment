package com.paic.data.hive.common.udtf.otcBayesLogRecovery;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.math3.distribution.NormalDistribution;



public class OTCBayesLogRecoveryProcessor {

	public static double M = 0.001;
	public static double E = 0.03;

	public static List<RDateAccount> Recover(List<DateAccount> Linitial) {
		OffsetData data= new OffsetData(0,0,1);
    	int last_s=-1,last_b=-1;	
    	List<RDateAccount> Lrectify = new ArrayList<RDateAccount>();
    	for(DateAccount da:Linitial)
    	{
    		RDateAccount account = new RDateAccount(da.date,da.mkt,da.b,da.s,da.div,1);
    		Lrectify.add(account);
    	}
    	int[] next=find(Lrectify,last_b,last_s);
    	while(next[0]!=last_b||next[1]!=last_s)
    	{		
			int index = next[0] != last_b ? next[0] : next[1];
			data = bayes(Lrectify, index, last_b, last_s);
			if (data.b_step != 0 && data.s_step != data.b_step) {
				next[0]=data.b_step+index;
				RDateAccount latest = new RDateAccount(Lrectify.get(index + data.b_step).date,
						Lrectify.get(index + data.b_step).mkt, Lrectify.get(index).b,
						Lrectify.get(index + data.b_step).s, Lrectify.get(index + data.b_step).div, data.value);
				Lrectify.set(index + data.b_step, latest);
				RDateAccount old = new RDateAccount(Lrectify.get(index).date, Lrectify.get(index).mkt, 0,
						Lrectify.get(index).s, Lrectify.get(index).div, data.value);
				Lrectify.set(index, old);
			} else if (data.s_step != 0 && data.s_step != data.b_step) {
				next[1]=index+data.s_step;
				RDateAccount latest = new RDateAccount(Lrectify.get(index + data.s_step).date,
						Lrectify.get(index + data.s_step).mkt, Lrectify.get(index + data.s_step).b,
						Lrectify.get(index).s, Lrectify.get(index + data.s_step).div, data.value);
				Lrectify.set(index + data.s_step, latest);
				RDateAccount old = new RDateAccount(Lrectify.get(index).date, Lrectify.get(index).mkt,
						Lrectify.get(index).b, 0, Lrectify.get(index).div, data.value);
				Lrectify.set(index, old);
			} else if (data.b_step != 0 && data.s_step == data.b_step) {
				next[0]=index+data.b_step;
				next[1]=index+data.s_step;
				RDateAccount latest = new RDateAccount(Lrectify.get(index + data.b_step).date,
						Lrectify.get(index + data.b_step).mkt, Lrectify.get(index).b, Lrectify.get(index).s,
						Lrectify.get(index + data.b_step).div, data.value);
				Lrectify.set(index + data.b_step, latest);
				RDateAccount old = new RDateAccount(Lrectify.get(index).date, Lrectify.get(index).mkt, 0, 0,
						Lrectify.get(index).div, data.value);
				Lrectify.set(index, old);
			}
			last_b = next[0];
			last_s = next[1];
			next = find(Lrectify, last_b, last_s);
    	}	
/*    	for(RDateAccount i:Lrectify)
    	{
    		System.out.println(i.date+"    "+i.mkt+"    "+i.b+"    "+i.s+"    "+i.div+"    "+i.probability);
    	}*/
    	return Lrectify;
      }
	
	 public static int[] find(List<RDateAccount> input,int last_b,int last_s) //确保输入合法,到底了則返回last_b,last_s。
	{
		int next_b = last_b, next_s = last_s, k = 0;
		int[] location = { 0, 0 };
		if ((last_b > last_s ? last_b : last_s) < input.size())
			k = (last_b > last_s) ? last_b : last_s;
		else if (last_b == input.size() && last_s < input.size())
			k = last_s;
		else if (last_s == input.size() && last_b < input.size())
			k = last_b;
		else {
			location[0] = last_b;
			location[1] = last_s;
			return location;
		}

		for (int i = k + 1; i < input.size(); ++i) {
			if (input.get(i).b != 0.0 && input.get(i).s == 0) {
				next_b = i;
				next_s = last_s;
				break;
			} else if (input.get(i).s != 0 && input.get(i).b == 0) {
				next_s = i;
				next_b = last_b;
				break;
			} else if (input.get(i).b != 0 && input.get(i).s != 0) {
				next_b = i;
				next_s = i;
				break;
			}

		}
		location[0] = next_b;
		location[1] = next_s;
		return location;
	}
	
	

	public static List<DateAccount> read(String line) {
		List<DateAccount> list = new ArrayList<DateAccount>();
		try {
			// BufferedReader reader = new BufferedReader(new
			// FileReader("D:\\Users\\LIJUN124\\Desktop\\Bayes23.csv"));//换成你的文件名
			// reader.readLine();//第一行信息，为标题信息，不用,如果需要，注释掉
			// String line = null;
			// while((line=reader.readLine())!=null){
			String item[] = line.split("\"@|@|\"");
			// String item[] = line.split(",");//CSV格式文件为逗号分隔符文件，这里根据逗号切分
			String str[] = new String[4];
			for (int i = 1; i < item.length; i++) {
				if (item[i].length() != 0) {
					str = item[i].split("=|,");
					List<Double> a = StringToDouble(str);
					DateAccount da = new DateAccount(str[1], a.get(1), a.get(2), a.get(3), a.get(4));
					list.add(da);
				}
			}
			// }
		} catch (Exception e) {
			e.printStackTrace();
		}
		Collections.sort(list);
		// for(int i=0;i<list.size();i++)
		// System.out.println(list.get(i).date+" "+list.get(i).mkt+"
		// "+list.get(i).b+" "+list.get(i).s+" "+list.get(i).div);
		return list;
	}

	public static OffsetData bayes(List<RDateAccount> list, int index, int last_b, int last_s) { // return the best location and probability calculate by bayes 
		NormalDistribution normalDistributioin = new NormalDistribution(0, 1);
		HashMap<String, Double> p = new HashMap<String, Double>();
		HashMap<String, Double> map = new HashMap<String, Double>();
		initial(map);
		OffsetData data = new OffsetData(0, 0, 1);
		double D = 0;
		if (index > 0 && index <= list.size()) {
			if (list.get(index).b != 0 && list.get(index).s != 0) {
				for (int b = (last_b - index + 1 > -2) ? last_b - index + 1 : -2; b <= 0; ++b)
					for (int s = (last_s - index + 1 > -2) ? last_s - index + 1 : -2; s <= 0; ++s) {
						// double
						// pbs=profitrate(list,index+b,list.get(index).b,list.get(index+b).s);
						// double
						// pss=profitrate(list,index+s,list.get(index+s).b,list.get(index).s);

						double P, x;
						/*if (b != s) {
							double pbs = profitrate(list, index + b, list.get(index).b, 0.0);
							double pss = profitrate(list, index + s, 0.0, list.get(index).s);
							x = (Math.abs(pbs - M) > Math.abs(pss - M)) ? pbs : pss;
						} else {
							double pp = profitrate(list, index + b, list.get(index).b, list.get(index).s);
							x = pp;
						}

						double z = (x - M) / E;
						double S1 = normalDistributioin.cumulativeProbability(z);
						if (z < 0)
							P = 2 * S1;
						else
							P = 2 - 2 * S1;*/
						int b_top=((last_b - index + 1 > -2) ? last_b - index + 1 : -2)+index;
						int s_top=((last_s - index + 1 > -2) ? last_s - index + 1 : -2)+index;
						int top=b_top<s_top?b_top:s_top;
						P = totalprofitrate(list,index,top,b,s);
						p.put(b + " " + s, map.get(b + " " + s) * P);
						D = D + map.get(b + " " + s) * P;
					}
				if (D>0.0001) {
					double probability = max(p).value / D;
					data = data.getData(max(p).b_step, max(p).s_step, probability);
				} else
					data = data.getData(0, 0, 1);
			} else if (list.get(index).b != 0 && list.get(index).s == 0) {
				for (int b = (last_b - index + 1 > -2) ? last_b - index + 1 : -2; b <= 0; ++b) {
					double P;
/*					double pbs = profitrate(list, index + b, list.get(index).b, list.get(index + b).s);
					double z = (pbs - M) / E;
					double S1 = normalDistributioin.cumulativeProbability(z);
					if (z < 0)
						P = 2 * S1;
					else
						P = 2 - 2 * S1;*/
					P = totalprofitrate(list, index,((last_b - index + 1 > -2) ? last_b - index + 1 : -2)+index,b,0);
					p.put(b + " " + 0, map.get(b + "") * P);
					D = D + map.get(b + "") * P;
				}
				if (D>0.0001) {
					double probability = max(p).value / D;
					data = data.getData(max(p).b_step, max(p).s_step, probability);
				} else
					data = data.getData(0, 0, 1);
			} else if (list.get(index).b == 0 && list.get(index).s != 0) {
				for (int s = (last_s - index + 1 > -2) ? last_s - index + 1 : -2; s <= 0; ++s) {
					double P;
					/*double pss = profitrate(list, index + s, list.get(index + s).b, list.get(index).s);
					// double x=(Math.abs(pbs-M)>Math.abs(pss-M))?pbs:pss;
					double z = (pss - M) / E;
					double S1 = normalDistributioin.cumulativeProbability(z);
					if (z < 0)
						P = 2 * S1;
					else
						P = 2 - 2 * S1;*/
					P = totalprofitrate(list,index,((last_s - index + 1 > -2) ? last_s - index + 1 : -2)+index,0,s);
					p.put(0 + " " + s, map.get(s + "") * P);
					D = D + map.get(s + "") * P;
				}
				if (D>0.0001) {
					double probability = max(p).value / D;
					data = data.getData(max(p).b_step, max(p).s_step, probability);
				} else
					data = data.getData(0, 0, 1);
			}
		}
/*		System.err.println(index);
		for(Entry<String, Double> e : p.entrySet()) {
			System.err.println(String.format("%s=%f", e.getKey(), e.getValue()));
		}*/
		return data;
	}

	public static Double profitrate(List<RDateAccount> list, int index, double buy, double sell) { //calculate profitrate of each item in capitallog
		Double profitrate;
		if (index != 0)
			profitrate = (list.get(index).mkt + sell + list.get(index).div - list.get(index - 1).mkt - buy)
					/ (list.get(index - 1).mkt + buy);
		else
			profitrate = (list.get(index).mkt + sell + list.get(index).div - buy) / (buy);
		return profitrate;
	}

	public static double totalprofitrate(List<RDateAccount> list, int index, int top,int b_step, int s_step){   //计算连续3天收益率的乘积
		NormalDistribution normalDistributioin = new NormalDistribution(0, 1);
		int k=index-top+1;      //top的位置也算在内
		double[][] capital=new double[k][2];
		double P;
		boolean flag=false;
		double p = 1;
		double pw=0;
		double w=0;
		for(int i=0;i<k;i++)
		{
			capital[i][0]=list.get(top+i).b;
		    capital[i][1]=list.get(top+i).s;
		}
		if(b_step!=0)
		{
			capital[index-top+b_step][0]=capital[index-top][0];
			capital[index-top][0]=0;
		}
		if(s_step!=0)
		{
			capital[index-top+s_step][1]=capital[index-top][1];
			capital[index-top][1]=0;
		}
		for(int i=top;i<=index;i++)
		{
				double rate=profitrate(list,i,capital[i-top][0],capital[i-top][1]);
				double z = (rate - M) / E;
				double S = normalDistributioin.cumulativeProbability(z);
				if (z < 0)
					P = 2 * S;
				else
					P = 2 - 2 * S;
			/*if(list.get(i).mkt<100&&capital[i-top][0]==0&&capital[i-top][1]==0)
			{
					P=1;
			}*/
			
			double wi=0;
			if (i > top) {
				wi = Math.log(1 + (list.get(i).mkt + list.get(i-1).mkt) / 2);
			} else {
				wi = Math.log(1 + list.get(i).mkt);
			}
																
			pw += Math.log(P + Math.exp(-20)) * wi;
			w += wi;
			//p *= P;
		}
				
		return Math.exp(pw / w);
		
	}
	public static void initial(HashMap<String, Double> map) { // initialize
																// p(H-2),p(H-1),p(H0),p(H1),p(H2)
		map.put(0+" "+0, 0.94);
	    map.put(0+" "+-1, 0.01);
	    map.put(0+" "+-2, 0.01);
	    map.put(-1+" "+0, 0.01);
	    map.put(-1+" "+-1, 0.01/2);
	    map.put(-1+" "+-2, 0.01/2);
	    map.put(-2+" "+0, 0.01);
	    map.put(-2+" "+-1, 0.01/2);
	    map.put(-2+" "+-2, 0.01/2);
		map.put(0+"", 0.97);
		map.put(-1+"",0.02);
		map.put(-2+"", 0.01);  
	}

	public static OffsetData max(HashMap<String, Double> map) {
		// TODO Auto-generated method stub
		double maxV = -1;
		// int[] maxK=new int[2];
		String maxK = null;
		Iterator keys = map.keySet().iterator();
		for (Map.Entry<String, Double> entry : map.entrySet()) {
			double value = entry.getValue();
			if (value > maxV) {
				maxV = value;
				maxK = entry.getKey().toString();
			}
		}
		int[] value = new int[2];
		String[] str = maxK.split("\\s+");
		value = StringToInt(str);
		OffsetData data = new OffsetData(value[0], value[1], maxV);
		return data;
	}

	public static int[] StringToInt(String[] str) {
		// String str = "100 200 33 55";//字符串
		int[] result = new int[2];// int类型数组
		int i = 0;
		for (String a : str) {
			result[i] = Integer.parseInt(a);
			i++;
		}
		return result;
	}

	public static List<Double> StringToDouble(String[] arrs) {
		List<Double> list = new ArrayList<Double>();
		for (int i = 0; i < arrs.length; i++) {
			if (isNumeric(arrs[i]))
				list.add(Double.parseDouble(arrs[i]));
		}
		return list;
	}

	public static boolean isNumeric(String str) {
		Pattern pattern = Pattern.compile("[0-9]+\\.?[0-9]*");
		Matcher isNum = pattern.matcher(str);
		if (!isNum.matches()) {
			return false;
		}
		return true;
	}

}
