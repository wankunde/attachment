package com.paic.data.hive.common.utils;

import com.paic.data.hive.common.utils.date.DateUnit;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.FsUrlStreamHandlerFactory;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.common.type.HiveDecimal;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.serde2.io.DoubleWritable;
import org.apache.hadoop.io.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.net.URI;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by WANKUN603 on 2016-05-26.
 */
public class UdfUtils {

    private static final Log LOG = LogFactory.getLog(UdfUtils.class);
    public static final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

    public static Object getMinKey(Map map) {
        if (map == null)
            return null;
        Set set = map.keySet();
        Object[] obj = set.toArray();
        Arrays.sort(obj);
        return obj[0];
    }

    public static Object getMaxKey(Map map) {
        if (map == null)
            return null;
        Set set = map.keySet();
        Object[] obj = set.toArray();
        Arrays.sort(obj);
        return obj[obj.length - 1];
    }

    public static int daysBetween(String startDate, String endDate) throws ParseException {
        Calendar cal = Calendar.getInstance();
        cal.setTime(sdf.parse(startDate));
        long time1 = cal.getTimeInMillis();
        cal.setTime(sdf.parse(endDate));
        long time2 = cal.getTimeInMillis();
        long between_days = (time2 - time1) / (1000 * 3600 * 24);

        return Integer.parseInt(String.valueOf(between_days));
    }

    /**
     * @param period 日期推移的描述
     * @param sdate  输入日期
     * @param type   -1：向前推移 1：向后推移
     * @return
     * @throws ParseException
     * @throws HiveException
     * @throws IOException
     */
    public static String shiftDate(String period, String sdate, int type) throws ParseException, HiveException, IOException {
        if (StringUtils.isBlank(period) || period.length() < 1) {
            LOG.error("period is null or incorrectly formatted data");
            return null;
        }
        int len = period.length();
        String unit = period.substring(len - 1);
        Integer diff = Integer.parseInt(period.substring(0, len - 1));
        return shiftDate(unit, diff, sdate, type);
    }

    private static NavigableSet<String> allSet = null;

    /**
     * @param unit  日期推移单位
     * @param diff  日期推移数量
     * @param sdate 输入日期
     * @param type  -1：向前推移 1：向后推移
     * @return 移动后的日期
     * @throws ParseException
     */
    public static String shiftDate(String unit, Integer diff, String sdate, int type) throws ParseException, HiveException, IOException {
        allSet = new UdfUtils().loadFromFile(allSet);
        assert allSet != null;

        String odate = "";
        switch (unit.toUpperCase()) {
            case "D":
            case "W":
            case "M":
            case "Y":
                odate = DateUnit.getInstance(unit).shift(sdate, type * diff);
                break;
            case "C":
                // 对1c_sum_firstValue 特殊处理
                odate = DateUnit.getInstance("D").shift(sdate, type * diff);
                break;
            case "T":
                Integer i = diff;
                // update endDate to last trade day.
                while (!allSet.contains(sdate))
                    sdate = DateUnit.getInstance("D").shift(sdate, type);

                // compute startDate by endDate,diff
                odate = sdate;
                while (i > 0) {
                    odate = DateUnit.getInstance("D").shift(odate, type);
                    if (allSet.contains(odate))
                        i--;
//                            LOG.debug("parse measures. i :" + i + " startDate :" + startDate);
                }
                break;
            case "N":
                // 自然年，自然半年，自然季度，自然月，自然周
                odate = UdfUtils.getCalendarStart(sdate, -type * diff);
                odate = DateUnit.getInstance("D").shift(odate, type);
                break;
        }

        // 对所有startDate 进行 +1
        odate = DateUnit.getInstance("D").shift(odate, -1 * type);
        return odate;
    }

    /**
     * @param dt
     * @param diff 360 自然年 180 自然半年 90 自然季度  30 自然月 7 自然周
     * @return
     * @throws ParseException
     */
    public static String getCalendarStart(String dt, Integer diff) throws ParseException {
        Calendar cal = Calendar.getInstance();
        cal.setTime(sdf.parse(dt));
        int mon = cal.get(Calendar.MONTH);

        if (diff == 360)
            return UdfUtils.sdf.format(DateUtils.setMonths(DateUtils.setDays(cal.getTime(), 1), 0));
        else if (diff == 180) {
            return UdfUtils.sdf.format(DateUtils.setMonths(DateUtils.setDays(cal.getTime(), 1), mon / 6 * 6));
        } else if (diff == 90) {
            return UdfUtils.sdf.format(DateUtils.setMonths(DateUtils.setDays(cal.getTime(), 1), mon / 3 * 3));
        } else if (diff == 30) {
            return UdfUtils.sdf.format(DateUtils.setDays(cal.getTime(), 1));
        } else if (diff == 7) {
            // 周一为一周的第二天 2 代表周一
            cal.set(Calendar.DAY_OF_WEEK, 2);
            return UdfUtils.sdf.format(cal.getTime());
        } else if (diff == -360)
            return UdfUtils.sdf.format(DateUtils.setDays(DateUtils.setMonths(cal.getTime(), 11), 31)); // yyyy1231
        else if (diff == -180) {
            mon = mon / 6 * 6 + 5;
            return UdfUtils.sdf.format(DateUtils.setDays(DateUtils.setMonths(DateUtils.setDays(cal.getTime(), 1), mon), mon <= 5 ? 30 : 31)); // yyyy0630 或 yyyy1231
        } else if (diff == -90) {
            mon = mon / 3 * 3 + 2;
            LOG.info("mon : " + mon);
            return UdfUtils.sdf.format(DateUtils.setDays(DateUtils.setMonths(DateUtils.setDays(cal.getTime(), 1), mon), mon <= 2 || mon >= 10 ? 31 : 30)); // yyyy0331 或 yyyy0630 或 yyyy0930 或 yyyy1231
        } else if (diff == -30) {
            return UdfUtils.sdf.format(DateUtils.setDays(cal.getTime(), cal.getActualMaximum(Calendar.DAY_OF_MONTH)));
        } else if (diff == -7) {
            // 周日为下周的第一天 7 代表周六
            cal.set(Calendar.DAY_OF_WEEK, 7);
            cal.add(Calendar.DATE, 1);
            return UdfUtils.sdf.format(cal.getTime());
        } else
            throw new ParseException("error diff in getCalendarStart", 0);
    }

    public synchronized NavigableSet<String> loadFromFile(NavigableSet<String> allTradeDaySet) throws HiveException, IOException {
        if (allTradeDaySet == null || allTradeDaySet.isEmpty()) {
            try {
                URL.setURLStreamHandlerFactory(new FsUrlStreamHandlerFactory());
            } catch (Throwable e) {
                //ignore
            }

            allTradeDaySet = new TreeSet<String>();
            Configuration conf = new Configuration();
            String uri = "hdfs:///metadata/dim/tradecalender.csv";
            FSDataInputStream in = null;
            BufferedReader reader = null;
            try {
                FileSystem hdfs = FileSystem.get(URI.create(uri), conf);
                in = hdfs.open(new Path(uri));
                reader = new BufferedReader(new InputStreamReader(in));
                String line = null;
                while ((line = reader.readLine()) != null) {
                	allTradeDaySet.add(line);
                }
            } finally {
                IOUtils.closeStream(in);
            }

        }
        return allTradeDaySet;
    }

    public static Object addDoubleData(Object v1, Object v2) {
        if (v1 == null)
            return v2;
        else if (v2 == null)
            return v1;
        else
            return (Double) v1 + (Double) v2;
    }

    public static Object addData(Object v1, Object v2) {
        if (v1 == null)
            return v2;
        else if (v2 == null)
            return v1;
        LOG.debug("v1 instanceof : " + v1.getClass() + " v1 : " + v1 + " v2 : " + v2);
        if (v1 instanceof Double) {
            v1 = (Double) v1 + (Double) v2;
        } else if (v1 instanceof Long) {
            v1 = (Long) v1 + (Long) v2;
        } else if (v1 instanceof Integer) {
            v1 = (Integer) v1 + (Integer) v2;
        } else if (v1 instanceof Short) {
            v1 = (Short) v1 + (Short) v2;
        } else if (v1 instanceof IntWritable) {
            ((IntWritable) v1).set(((IntWritable) v1).get() + ((IntWritable) v2).get());
        } else if (v1 instanceof LongWritable) {
            ((LongWritable) v1).set(((LongWritable) v1).get() + ((LongWritable) v2).get());
        } else if (v1 instanceof DoubleWritable) {
            ((DoubleWritable) v1).set(((DoubleWritable) v1).get() + ((DoubleWritable) v2).get());
        } else if (v1 instanceof FloatWritable) {
            ((FloatWritable) v1).set(((FloatWritable) v1).get() + ((FloatWritable) v2).get());
        } else if (v1 instanceof HiveDecimal) {
            v1 = ((HiveDecimal) v1).multiply((HiveDecimal) v2);
        }
        return v1;
    }

    /**
     * @param dictionary
     * @return
     * @throws HiveException
     * @throws IOException
     */
    public static synchronized Map<String, List<String>> loadMeasureDict(Map<String, List<String>> dictionary) throws HiveException, IOException {
        if (dictionary == null || dictionary.size() == 0) {
            try {
                URL.setURLStreamHandlerFactory(new FsUrlStreamHandlerFactory());
            } catch (Throwable e) {
                //ignore
            }

            dictionary = new HashMap<String, List<String>>();
            Configuration conf = new Configuration();
            String uri = "hdfs://pasc/user/hive/warehouse/dim.db/uds_dictionary/000000_0";
            FSDataInputStream in = null;
            BufferedReader reader = null;
            try {
                FileSystem hdfs = FileSystem.get(URI.create(uri), conf);
                in = hdfs.open(new Path(uri));
                reader = new BufferedReader(new InputStreamReader(in));
                String line = null;
                while ((line = reader.readLine()) != null) {
                    String[] cols = line.split("\u0001");
                    if (cols.length >= 4) {
                        List<String> dictEnums = dictionary.get(cols[1]);
                        if (dictEnums == null)
                            dictEnums = new ArrayList<>();
                        dictEnums.add(cols[3]);
                        dictionary.put(cols[1], dictEnums);
                    }
                }
            } finally {
                IOUtils.closeStream(in);
            }
        }
        return dictionary;
    }

    /**
     * @param dictionary
     * @return
     * @throws HiveException
     * @throws IOException
     */
    public static synchronized Map<String, Map<String, String>> loadMeasureDictLabel(Map<String, Map<String, String>> dictionary) throws HiveException, IOException {
        if (dictionary == null || dictionary.size() == 0) {
            try {
                URL.setURLStreamHandlerFactory(new FsUrlStreamHandlerFactory());
            } catch (Throwable e) {
                //ignore
            }

            dictionary = new HashMap<String, Map<String, String>>();
            Configuration conf = new Configuration();
            String uri = "hdfs://pasc/user/hive/warehouse/dim.db/uds_dictionary/000000_0";
            FSDataInputStream in = null;
            BufferedReader reader = null;
            try {
                FileSystem hdfs = FileSystem.get(URI.create(uri), conf);
                in = hdfs.open(new Path(uri));
                reader = new BufferedReader(new InputStreamReader(in));
                String line = null;
                while ((line = reader.readLine()) != null) {
                    String[] cols = line.split("\u0001");
                    if (cols.length >= 4) {
                        Map<String, String> dictEnums = dictionary.get(cols[1]);
                        if (dictEnums == null)
                            dictEnums = new HashMap<>();
                        dictEnums.put(cols[3], cols[2]);
                        dictionary.put(cols[1], dictEnums);
                    }
                }
            } finally {
                IOUtils.closeStream(in);
            }
        }
        return dictionary;
    }

    private static Map<String, String[]> cachedDays = new HashMap<>();

    public static String[] getDays(String start, String end) throws ParseException {
        String cachedKey = start + end;
        if (cachedDays.containsKey(cachedKey))
            return cachedDays.get(cachedKey);

        List<String> dts = new LinkedList<>();
        Date startDate = sdf.parse(start);
        Date endDate = sdf.parse(end);
        while (!startDate.after(endDate)) {
            dts.add(sdf.format(startDate));
            startDate.setTime(startDate.getTime() + 24 * 60 * 60 * 1000);
        }
        String[] days = dts.toArray(new String[]{});
        cachedDays.put(cachedKey, days);
        return days;
    }

    private static String[] tradeDays = null;

    public synchronized static String[] getTradeDays() throws HiveException, IOException {
        if (tradeDays == null) {
            List<String> dts = new ArrayList<String>();
            try {
                URL.setURLStreamHandlerFactory(new FsUrlStreamHandlerFactory());
            } catch (Throwable e) {
                //ignore
            }

            Configuration conf = new Configuration();
            String uri = "hdfs:///metadata/dim/tradecalender.csv";
            FSDataInputStream in = null;
            BufferedReader reader = null;
            try {
                FileSystem hdfs = FileSystem.get(URI.create(uri), conf);
                in = hdfs.open(new Path(uri));
                reader = new BufferedReader(new InputStreamReader(in));
                String line;
                while ((line = reader.readLine()) != null) {
                    dts.add(line);
                }
            } finally {
                IOUtils.closeStream(in);
            }
            tradeDays = dts.toArray(new String[]{});
            Arrays.sort(tradeDays);
        }
        return tradeDays;
    }

    private static int floorBinarySearch(Object[] a, Object key) {
        int low = 0;
        int high = a.length - 1;

        while (high - low > 1) {
            int mid = (low + high) >>> 1;
            Comparable midVal = (Comparable) a[mid];
            int cmp = midVal.compareTo(key);
            if (cmp == 0)
                return mid;
            else if (cmp < 0)
                low = mid;
            else if (cmp > 0)
                high = mid;
        }
        return low;
    }

    private static int ceilBinarySearch(Object[] a, Object key) {
        int low = 0;
        int high = a.length - 1;

        while (high - low > 1) {
            int mid = (low + high) >>> 1;
            Comparable midVal = (Comparable) a[mid];
            int cmp = midVal.compareTo(key);
            if (cmp == 0)
                return mid;
            else if (cmp < 0)
                low = mid;
            else if (cmp > 0)
                high = mid;
        }
        return high;
    }

    public static int tradeDayIdx(String day) throws HiveException, IOException {
        tradeDays = getTradeDays();
        return Arrays.binarySearch(tradeDays, day);
    }

    public static int tradeDaysLength(String start, String end) throws HiveException, IOException {
        tradeDays = getTradeDays();

        return floorBinarySearch(tradeDays, end) - ceilBinarySearch(tradeDays, start) + 1;
    }

    public static boolean isTradeDay(String dt) throws HiveException, IOException {
        tradeDays = getTradeDays();
        return Arrays.binarySearch(tradeDays, dt) > 0;
    }

    public static String[] trimArray(String[] arr) {
        int p = 0;
        for (int i = 0; i < arr.length; i++) {
            if (!StringUtils.isBlank(arr[i])) {
                arr[p] = arr[i];
                p++;
            }
        }
        String[] newArr = new String[p];
        System.arraycopy(arr, 0, newArr, 0, p);
        return newArr;
    }

    public static BigDecimal safeAdd(BigDecimal a, BigDecimal b) {
        if (a == null)
            return b;
        else if (b == null)
            return a;
        else
            return a.add(b);
    }

    public static BigDecimal safeSubtract(BigDecimal a, BigDecimal b) {
        if (a == null)
            return b;
        else if (b == null)
            return a;
        else
            return a.subtract(b);
    }

    public static BigDecimal safeMultiply(BigDecimal a, BigDecimal b) {
        if (a == null || b == null)
            return null;
        else
            return a.multiply(b);
    }

    public static BigDecimal safeDivide(BigDecimal a, BigDecimal b) {
        if (a == null || b == null)
            return b;
        else if (b == BigDecimal.ZERO)
            return BigDecimal.ZERO;
        else
            return a.divide(b);
    }
}
