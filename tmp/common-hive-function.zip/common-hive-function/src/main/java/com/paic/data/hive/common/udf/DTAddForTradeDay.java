package com.paic.data.hive.common.udf;

import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;
import java.util.NavigableSet;
import java.util.TreeSet;

import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.hive.ql.metadata.HiveException;

import com.paic.data.hive.common.utils.UdfUtils;
import com.paic.data.hive.common.utils.date.DateUnit;

/**
 * @author shidawen768
 *
 */
@Description(name = "dt_add_for_tradeday", value = "_FUNC_(YYYYMMDD, TradeDays) - "
		+ "Returns a shifted trade dt, tradeDays must be greater than or equal to zero.")
public class DTAddForTradeDay extends UDF {
	private NavigableSet<String> allSet = new TreeSet<String>();
	private Map<String, String> existTradeDayMap = new HashMap<String, String>(); 
	

	private String ForwardTradeDay(String dt, int tradeDays) throws ParseException, HiveException, IOException {
		if (allSet == null || allSet.isEmpty()) {
			this.load();
		}
		
		String firstHighTradeDay = dt;
		while (allSet.contains(firstHighTradeDay) == false) {
			firstHighTradeDay = DateUnit.getInstance("D").shift(firstHighTradeDay, 1);
		}

		int index = 0;
		String resDate = firstHighTradeDay;
		while (index < tradeDays) {
			index++;
			resDate = allSet.higher(resDate);
		}

		String key = this.getKey(dt, tradeDays);
		this.existTradeDayMap.put(key, resDate);
		
		return resDate;
	}
	
	private synchronized void load() throws HiveException, IOException{
		NavigableSet<String> tmpSet = new UdfUtils().loadFromFile(null);
		
		this.allSet = tmpSet;
	}
	
	private String getKey(String dt, int tradeDays){
		return String.format("%s_%s", dt, tradeDays);
	}

	public String evaluate(String dt, int tradeDays) throws ParseException, HiveException, IOException {		
		if (tradeDays < 0) {
			throw new RuntimeException("tradeDays must be greater than or equal to zero, tradeDays=" + tradeDays);
		}
		
		if(StringUtils.isEmpty(dt) == true){
			return null;
		}
		
		String key = getKey(dt, tradeDays);
		if(existTradeDayMap.containsKey(key)){
			return existTradeDayMap.get(key);
		}

		return ForwardTradeDay(dt, tradeDays);
	}
}
