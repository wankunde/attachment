package com.paic.data.hive.common.udf.template.node;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.paic.data.hive.common.udf.template.TNode;
import com.paic.data.hive.common.udf.template.TPushData;
import com.paic.data.hive.common.udf.template.TUserData;




public class TListNode extends TVarNode {
	
	private final List<TNode> nodes;
	
	public TListNode() {
		this(null);
	}
	
	public TListNode(List<TNode> nodes) {
		this.nodes = nodes != null ? nodes : new ArrayList<TNode>();
	}
	
	public int size() {
		return nodes.size();
	}
	
	public void add(TNode node) {
		nodes.add(node);
	}
	
	public List<TNode> nodes() {
		return nodes;
	}
	
	@Override
	public void trim() {
		if (nodes.size() == 1) {
			nodes.get(0).trim();
		} else if (nodes.size() > 1) {
			TNode first = nodes.get(0);
			TNode last = nodes.get(nodes.size() - 1);
			if (first instanceof TTextNode) {
				((TTextNode) first).trimFirst();
			}
			if (last instanceof TTextNode) {
				((TTextNode) last).trimLast();
			}
		}
	}

	@Override
	public void params(Collection<String> params) {
		for (TNode node : nodes) {
			node.params(params);
		}
	}

	@Override
	public void toString(StringBuffer output, String channel, TUserData userData, TPushData pushData) {
		for (TNode node : nodes) {
			node.toString(output, channel, userData, pushData);
		}
	}
}
