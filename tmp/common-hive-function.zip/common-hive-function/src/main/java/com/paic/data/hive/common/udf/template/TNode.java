package com.paic.data.hive.common.udf.template;

import java.util.Collection;

public abstract class TNode {

	public abstract void params(Collection<String> params);
	
	public abstract void toString(StringBuffer output, String channel, TUserData userData, TPushData pushData);
	
	public String toString(String channel, TUserData userData, TPushData pushData) {
		StringBuffer output = new StringBuffer();
		toString(output, channel, userData, pushData);
		return output.toString();
	}
	
	public void trim() {
		
	}
}
