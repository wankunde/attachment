package com.paic.data.hive.common.udtf.otcBayesLogRecovery2;
  
import java.util.ArrayList;  
import java.util.List;  
import java.util.Arrays;  
import com.paic.data.hive.common.udtf.otcBayesLogRecovery2.TreeNode;  
  


/** 
 * 多叉树生成、遍历工具 
 *  
 * @author 
 * @version 
 */  
public class TrieTree   
{

	private TreeNode root;
	private List<TreeNode> list = new ArrayList<TreeNode>();

	public TrieTree(TreeNode root){
		this.root = root;
	}
	
	public TreeNode getRoot() {
		return this.root;
	}

	public void add(TreeNode Node, TreeNode Parent, int k) // 指明父节点
	{
		Node.setParent(Parent);
	}


	public List<List<TreeNode>> getBranch() {
		// 得到一棵树的每个完整分支，方法是 提取allowChild==true的叶子节点所在分支。
		List<List<TreeNode>> Instance = new ArrayList<List<TreeNode>>();
		List<TreeNode> leaf = new ArrayList<TreeNode>();	
		leaf = getLeaf(getRoot());
		for (int i = 0; i < leaf.size(); i++) {
			List<TreeNode> capital = new ArrayList<TreeNode>();
			TreeNode Node = leaf.get(i);
			while (Node != root) {
				capital.add(Node);
				Node = Node.getParent();
			}
			//capital.add(Node); //root index is -1
			Instance.add(capital);
		}

		return Instance;
	}

	public List<TreeNode> getLeaf(TreeNode Node) 
	{
		if (Node != null) 
		{
			if (Node.getLeftChild() == null && Node.getMidChild() == null && Node.getRightChild() == null && Node.getAllowChild() == true) 
			{
				list.add(Node);
			}
			getLeaf(Node.getRightChild());			
			getLeaf(Node.getMidChild());
			getLeaf(Node.getLeftChild());
			
		}
		return list;
	}
	
}  

