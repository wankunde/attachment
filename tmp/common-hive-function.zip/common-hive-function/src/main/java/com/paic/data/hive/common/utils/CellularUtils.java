package com.paic.data.hive.common.utils;


import java.io.PrintStream;
import java.util.Iterator;
import java.util.Set;
import org.apache.commons.lang.StringUtils;

public class CellularUtils
{
  public static void main(String[] args)
  {
    String telno = "12618758658";
    System.out.println(formatTelNoMore(telno));
  }

  public static int isCNNetNum(String telno)
  {
    Iterator it = CellularConstant.allNetTelSet.iterator();
    return CollectionUtils.isStart(it, formatTelNo(telno));
  }

  public static int isCNUnionNum(String telno) {
    Iterator it = CellularConstant.allUnionTelSet.iterator();
    return CollectionUtils.isStart(it, formatTelNo(telno));
  }

  public static int isCNMobileNum(String telno) {
    Iterator it = CellularConstant.allMobileTelSet.iterator();
    return CollectionUtils.isStart(it, formatTelNo(telno));
  }

  public static int is2GsNum(String telno)
  {
    Iterator it = CellularConstant.all2GTelSet.iterator();
    return CollectionUtils.isStart(it, formatTelNo(telno));
  }

  public static int is3GsNum(String telno) {
    Iterator it = CellularConstant.all3GTelSet.iterator();
    return CollectionUtils.isStart(it, formatTelNo(telno));
  }

  public static int is4GsNum(String telno) {
    Iterator it = CellularConstant.all4GTelSet.iterator();
    return CollectionUtils.isStart(it, formatTelNo(telno));
  }

  public static int isVGsNum(String telno) {
    Iterator it = CellularConstant.allVGTelSet.iterator();
    return CollectionUtils.isStart(it, formatTelNo(telno));
  }

  public static int isTelNum(String telno) {
    Iterator it = CellularConstant.allCNTelSet.iterator();
    return CollectionUtils.isStart(it, formatTelNo(telno));
  }

  public static String getPrefix(String telno) {
    Iterator it = CellularConstant.allCNTelSet.iterator();
    String tmp = "";

    while (it.hasNext()) {
      tmp = (String)it.next();
      if (telno.startsWith(tmp)) {
        return tmp;
      }
    }

    return null;
  }

  public static String formatTelNo(String telno)
  {
    return getCellularHelper(telno, CellularConstant.allCNTelSet.iterator());
  }

  public static String formatTelNoMore(String telno)
  {
    if ((telno == null) || ("".equals(telno.trim()))) {
      System.out.println("0");
      return null;
    }

    telno = formatTelNo(telno);

    if ((telno == null) || ("".equals(telno.trim()))) {
      System.out.println("号码不合法！");
      return null;
    }

    if (PAStringUtils.getNumCharCount(telno) < 3) {
      System.out.println("同一个手机号中不同数字的个数不能小于3个");
      return null;
    }

    if (PAStringUtils.getNumMaxCharCount(telno) > 7) {
      System.out.println("同一个手机号中某一个数字出现的最大次数不能大于7个");
      return null;
    }

    if (PAStringUtils.getNumMaxConstantCount(telno) > 5) {
      System.out.println("同一个手机号中同一个数字连续出现的次数不能大于5");
      return null;
    }

    if (PAStringUtils.getNumDescAscCount(telno) > 6) {
      System.out.println("同一个手机号中同一个数字连续递增递减出现的次数不能大于6");
      return null;
    }

    if (isPaicExcludeTelno(telno)) {
      System.out.println("此号码为平安内部指定剔除的号码！");
      return null;
    }

    return telno;
  }

  public static String getChinaMobile(String telno)
  {
    return getCellularHelper(telno, CellularConstant.allMobileTelSet.iterator());
  }

  public static String getChinaNet(String telno)
  {
    return getCellularHelper(telno, CellularConstant.allNetTelSet.iterator());
  }

  public static String getChinaUnion(String telno)
  {
    return getCellularHelper(telno, CellularConstant.allUnionTelSet.iterator());
  }

  private static String getCellularHelper(String telno, Iterator it) {
    if ((telno == null) || ("".equals(telno.trim()))) {
      return null;
    }

    telno = PAStringUtils.formatFullArabicStr(telno);

    if (telno.endsWith(".0")) {
      telno = telno.substring(0, telno.lastIndexOf(".0"));
    }

    telno = telno.replaceAll("[^0-9]", "");
    telno = telno.replaceAll("^86", "");

    if (telno.length() < 11) {
      return null;
    }

    telno = telno.substring(telno.length() - 11);

    // 删除手机号校验条件
//    && (CollectionUtils.isStart(it, telno) == 0 || telno.startsWith("17"))
    if (telno.length() == 11) {
      char n1 = telno.charAt(0);
      char n2 = telno.charAt(1);
      if(n1 == '1' && n2 >= '3' && n2 <= '9')
        return telno;
    }

    return null;
  }

  public static boolean isPaicExcludeTelno(String telno)
  {
    return CellularExcludeConstant.excludeTelSet.contains(telno);
  }

  public static int check(String telno) {
    if (StringUtils.isNotEmpty(formatTelNo(telno))) {
      return 0;
    }
    return -1;
  }
}
