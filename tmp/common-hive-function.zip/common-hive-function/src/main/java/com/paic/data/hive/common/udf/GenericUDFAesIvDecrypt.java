package com.paic.data.hive.common.udf;

import org.apache.commons.codec.binary.Base64;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.exec.UDFArgumentTypeException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDF;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorConverters;
import org.apache.hadoop.hive.serde2.objectinspector.PrimitiveObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorUtils;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.IOUtils;
import org.apache.hadoop.io.Text;

import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.security.GeneralSecurityException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

import static org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorUtils.PrimitiveGrouping.BINARY_GROUP;
import static org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorUtils.PrimitiveGrouping.STRING_GROUP;

@Description(name = "aes_iv_decrypt", value = "_FUNC_(input binary, iv string/binary, key string) - Decrypt input using AES.")
public class GenericUDFAesIvDecrypt extends GenericUDF {

    protected transient PrimitiveObjectInspector.PrimitiveCategory[] inputTypes = new PrimitiveObjectInspector.PrimitiveCategory[3];
    protected transient ObjectInspectorConverters.Converter[] converters = new ObjectInspectorConverters.Converter[3];
    protected transient boolean isStr1;
    protected transient Cipher cipher;
    protected transient Map<String, String> map;
    protected final BytesWritable output = new BytesWritable();

    @Override
    public ObjectInspector initialize(ObjectInspector[] arguments) throws UDFArgumentException {
        checkArgsSize(arguments, 3, 3);
        checkArgPrimitive(arguments, 0);
        checkArgPrimitive(arguments, 1);
        checkArgPrimitive(arguments, 2);

        checkArgGroups(arguments, 0, inputTypes, BINARY_GROUP);
        checkArgGroups(arguments, 1, inputTypes, STRING_GROUP, BINARY_GROUP);
        checkArgGroups(arguments, 2, inputTypes, STRING_GROUP);

        converters[0] = ObjectInspectorConverters.getConverter(arguments[0],
                    PrimitiveObjectInspectorFactory.writableBinaryObjectInspector);


        if (isStr1 = PrimitiveObjectInspectorUtils.getPrimitiveGrouping(inputTypes[1]) == STRING_GROUP) {
            converters[1] = ObjectInspectorConverters.getConverter(arguments[1],
                    PrimitiveObjectInspectorFactory.writableStringObjectInspector);
        } else {
            converters[1] = ObjectInspectorConverters.getConverter(arguments[1],
                    PrimitiveObjectInspectorFactory.writableBinaryObjectInspector);
        }

        converters[2] = ObjectInspectorConverters.getConverter(arguments[2],
                    PrimitiveObjectInspectorFactory.writableStringObjectInspector);

        try {
            cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        } catch (NoSuchPaddingException | NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }

        Configuration conf = new Configuration();
        URI uri = URI.create("hdfs:///metadata/dim/aesDecrypt.key");
        FSDataInputStream in = null;
        BufferedReader br = null;
        try {
            FileSystem fs = FileSystem.get(uri, conf);
            in = fs.open(new Path(uri));
            br = new BufferedReader(new InputStreamReader(in));
            String line;
            map = new HashMap<>();
            String[] kv;
            while ((line = br.readLine()) != null) {
                kv = line.split("@@");
                if (kv.length >= 2) {
                    map.put(kv[0], kv[1]);
//                    System.err.println(kv[0] + ":" + kv[1]);
                }
            }
            br.close();
            IOUtils.closeStream(in);
        } catch (IOException e) {
            IOUtils.closeStream(in);
        }


        ObjectInspector outputOI = PrimitiveObjectInspectorFactory.writableBinaryObjectInspector;
        return outputOI;
    }

    @Override
    public Object evaluate(DeferredObject[] arguments) throws HiveException {
        byte[] input;
        int inputLength;

        BytesWritable bWr = getBinaryValue(arguments, 0, converters);
        if (bWr == null) return null;
        input = bWr.getBytes();
        inputLength = bWr.getLength();
        if (input == null) return null;

        byte[] iv;
        if (isStr1) {
            Text n = getTextValue(arguments, 1, converters);
            if (n == null) return null;
            iv = n.getBytes();
        } else {
            bWr = getBinaryValue(arguments, 1, converters);
            if (bWr == null) return null;
            iv = bWr.getBytes();
        }
        if (iv == null) return null;

        byte[] key;
        Text n = getTextValue(arguments, 2, converters);
        if (n == null) return null;
        String mapKey = map.get(n.toString());
        if (mapKey != null) key = Base64.decodeBase64(mapKey); else return null;
        SecretKey secretKey = getSecretKey(key);
        if (secretKey == null) return null;

        byte[] res = aesFunction(input, inputLength, secretKey, iv);
        if (res == null) return null;
        output.set(res, 0, res.length);
        return output;
    }

    protected int getCipherMode() {
        return Cipher.DECRYPT_MODE;
    }

    @Override
    public String getDisplayString(String[] children) {
        StringBuilder sb = new StringBuilder();
        sb.append(getFuncName()).append("(");
        if (children.length > 0) {
            sb.append(children[0]);
            for (int i = 1; i<children.length; i++) {
                sb.append(", ");
                sb.append(children[i]);
            }
        }
        sb.append(")");
        return sb.toString();
    }

    @Override
    protected String getFuncName() {
        return "aes_iv_decrypt";
    }

    protected void checkArgPrimitive(ObjectInspector[] argument, int i) throws UDFArgumentTypeException {
        ObjectInspector.Category oiCat = argument[i].getCategory();
        if (oiCat != ObjectInspector.Category.PRIMITIVE) {
            throw new UDFArgumentTypeException(i, getFuncName() + " only takes primitive types as "
                    + (i + 1) + " argument, got " + oiCat);
        }
    }

    protected void checkArgGroups(ObjectInspector[] arguments, int i, PrimitiveObjectInspector.PrimitiveCategory[] inputTypes,
                                  PrimitiveObjectInspectorUtils.PrimitiveGrouping... grps) throws UDFArgumentTypeException {
        PrimitiveObjectInspector.PrimitiveCategory inputType = ((PrimitiveObjectInspector) arguments[i]).getPrimitiveCategory();
        for (PrimitiveObjectInspectorUtils.PrimitiveGrouping grp : grps) {
            if (PrimitiveObjectInspectorUtils.getPrimitiveGrouping(inputType) == grp) {
                inputTypes[i] = inputType;
                return;
            }
        }
        StringBuilder sb = new StringBuilder();
        sb.append(getFuncName());
        sb.append(" only takes ");
        sb.append(grps[0]);
        for (int j = 1; j < grps.length; j++) {
            sb.append(", ");
            sb.append(grps[j]);
        }
        sb.append(" types as ");
        sb.append(i + 1);
        sb.append(" argument, got ");
        sb.append(inputType);
        throw new UDFArgumentTypeException(i, sb.toString());
    }

    protected SecretKey getSecretKey(byte[] key) {
        return new SecretKeySpec(key, "AES");
    }

    protected byte[] aesFunction(byte[] input, int inputLength, SecretKey secretKey, byte[] iv) {
        try {
            IvParameterSpec ivp = new IvParameterSpec(iv);
            cipher.init(getCipherMode(), secretKey, ivp);
            byte[] res = cipher.doFinal(input, 0, inputLength);
            return res;
        } catch (GeneralSecurityException e) {
            return null;
        }
    }

    protected Text getTextValue(DeferredObject[] arguments, int i, ObjectInspectorConverters.Converter[] converters) throws HiveException {
        Object obj;
        if ((obj = arguments[i].get()) == null) return null;
        Object writableValue = converters[i].convert(obj);
        return (Text) writableValue;
    }

    protected BytesWritable getBinaryValue(DeferredObject[] arguments, int i, ObjectInspectorConverters.Converter[] converters) throws HiveException {
        Object obj;
        if ((obj = arguments[i].get()) == null) return null;
        Object writableValue = converters[i].convert(obj);
        return (BytesWritable) writableValue;
    }

}
