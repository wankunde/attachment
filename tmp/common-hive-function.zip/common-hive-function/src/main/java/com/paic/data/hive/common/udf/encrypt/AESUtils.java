package com.paic.data.hive.common.udf.encrypt;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class AESUtils {

//	private static String KEY_STR = "pingankey";// 密钥
//	private static String CHARSETNAME = "UTF-8";// 编码
//	private static String ALGORITHM = "AES";// 加密类型
//
//	/**
//	 * 原始加密
//	 * 
//	 * @param content
//	 *            霄1�7要加密的内容
//	 * @return
//	 */
//	private static byte[] encrypt(String content) {
//		try {
//			KeyGenerator kgen = KeyGenerator.getInstance(ALGORITHM);
//			kgen.init(128, new SecureRandom(KEY_STR.getBytes()));
//			SecretKey secretKey = kgen.generateKey();
//			byte[] enCodeFormat = secretKey.getEncoded();
//			SecretKeySpec key = new SecretKeySpec(enCodeFormat, ALGORITHM);
//			Cipher cipher = Cipher.getInstance(ALGORITHM);// 创建密码噄1�7
//			byte[] byteContent = content.getBytes(CHARSETNAME);
//			cipher.init(Cipher.ENCRYPT_MODE, key);// 初始匄1�7
//			byte[] result = cipher.doFinal(byteContent);
//			return result; // 加密
//		} catch (NoSuchAlgorithmException e) {
//			e.printStackTrace();
//		} catch (NoSuchPaddingException e) {
//			e.printStackTrace();
//		} catch (InvalidKeyException e) {
//			e.printStackTrace();
//		} catch (UnsupportedEncodingException e) {
//			e.printStackTrace();
//		} catch (IllegalBlockSizeException e) {
//			e.printStackTrace();
//		} catch (BadPaddingException e) {
//			e.printStackTrace();
//		}
//		return null;
//	}
//
//	/**
//	 * 原始解密
//	 * 
//	 * @param content
//	 *            待解密内宄1�7
//	 * @return
//	 */
//	public static String decrypt(String content) {
//		try {
//			byte[] decryptFrom = parseHexStr2Byte(content);
//			KeyGenerator kgen = KeyGenerator.getInstance(ALGORITHM);
//			kgen.init(128, new SecureRandom(KEY_STR.getBytes()));
//			SecretKey secretKey = kgen.generateKey();
//			byte[] enCodeFormat = secretKey.getEncoded();
//			SecretKeySpec key = new SecretKeySpec(enCodeFormat, ALGORITHM);
//			Cipher cipher = Cipher.getInstance(ALGORITHM);// 创建密码噄1�7
//			cipher.init(Cipher.DECRYPT_MODE, key);// 初始匄1�7
//			byte[] result = cipher.doFinal(decryptFrom);
//			return new String(result); // 加密
//		} catch (NoSuchAlgorithmException e) {
//			e.printStackTrace();
//		} catch (NoSuchPaddingException e) {
//			e.printStackTrace();
//		} catch (InvalidKeyException e) {
//			e.printStackTrace();
//		} catch (IllegalBlockSizeException e) {
//			e.printStackTrace();
//		} catch (BadPaddingException e) {
//			e.printStackTrace();
//		}
//		return null;
//	}
//
//	/**
//	 * 将二进制转换戄1�7进制
//	 * 
//	 * @param buf
//	 * @return
//	 */
//	public static String parseByte2HexStr(String content) {
//		byte[] encryptResult = encrypt(content);
//		StringBuffer sb = new StringBuffer();
//		for (int i = 0; i < encryptResult.length; i++) {
//			String hex = Integer.toHexString(encryptResult[i] & 0xFF);
//			if (hex.length() == 1) {
//				hex = '0' + hex;
//			}
//			sb.append(hex.toUpperCase());
//		}
//		return sb.toString();
//	}
//
//	/**
//	 * 射1�7进制转换为二进制
//	 * 
//	 * @param hexStr
//	 * @return
//	 */
//	private static byte[] parseHexStr2Byte(String hexStr) {
//		if (hexStr.length() < 1)
//			return null;
//		byte[] result = new byte[hexStr.length() / 2];
//		for (int i = 0; i < hexStr.length() / 2; i++) {
//			int high = Integer.parseInt(hexStr.substring(i * 2, i * 2 + 1), 16);
//			int low = Integer.parseInt(hexStr.substring(i * 2 + 1, i * 2 + 2),
//					16);
//			result[i] = (byte) (high * 16 + low);
//		}
//		return result;
//	}
//
//	public static void main(String[] args) {
//		
//
//		 System.out.println(parseByte2HexStr("Bdata1234"));
//		 System.out.println(parseByte2HexStr("Pecppa18"));
//		 System.out.println(parseByte2HexStr("12eshop34"));
//		 System.out.println(parseByte2HexStr("12eshop34"));
//		 System.out.println(parseByte2HexStr("Pecppa18"));
//		 System.out.println(parseByte2HexStr("Lasdf1234*"));
//		 System.out.println(parseByte2HexStr("change4txt"));
//		 System.out.println(parseByte2HexStr("12ESHOP34"));
//		 System.out.println(parseByte2HexStr("change4txt"));
//		 System.out.println(parseByte2HexStr("change4txt"));
//		 
//		 System.out.println(parseByte2HexStr("Paic1234"));
//		 System.out.println(parseByte2HexStr("love0629"));
//		 System.out.println(parseByte2HexStr("passwd4egis"));
//		 System.out.println(parseByte2HexStr("pubweb1234"));
//		 System.out.println(parseByte2HexStr("paic1234"));
//		String content = "Test1234";
//		// 加密 4.System.out.println("加密前：" + content);
//		String encryptResultStr = parseByte2HexStr(content);
//		System.out.println("加密后：" + encryptResultStr);
//		// 解密
//		// byte[] decryptFrom = parseHexStr2Byte(encryptResultStr);
//		String decryptResult = decrypt("9E75C98ADBBB95D7B44DA4BE3006388A");
//		System.out.println("解密后：" + new String(decryptResult));
//	}
	
	
	
	private static int KEY_LENGTH = 16;	// 指定key的字节长度，少的衄1�7�多的裁剄1�7
	private static String KEY_STR = "pingankey";// 密钥
	private static String CHARSETNAME = "UTF-8";// 编码
	private static final String KEY_ALGORITHM = "AES";
	private static final String CIPHER_ALGORITHM ="AES/ECB/PKCS5Padding"; // 指定填充方式

	private static SecretKeySpec generateKey(byte[] password) throws Exception {
		if (password.length == KEY_LENGTH) {
			return new SecretKeySpec(password, KEY_ALGORITHM);
		} else if (password.length < KEY_LENGTH) {
			byte[] pwd = new byte[KEY_LENGTH];
			for (int i = 0; i < password.length; i ++) {
				pwd[i] = password[i];
			}
			for (int i = password.length; i < KEY_LENGTH; i ++) {
				pwd[i] = 0;
			}
			return new SecretKeySpec(pwd, KEY_ALGORITHM);
		} else {
			byte[] pwd = new byte[KEY_LENGTH];
			for (int i = 0; i < KEY_LENGTH; i ++) {
				pwd[i] = password[i];
			}
			return new SecretKeySpec(pwd, KEY_ALGORITHM);
		}
	}

	public static byte[] encrypt(byte[] content, byte[] password) throws Exception {
		Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
		cipher.init(Cipher.ENCRYPT_MODE, generateKey(password));
		return cipher.doFinal(content);
	}

	public static byte[] decrypt(byte[] content, byte[] password) throws Exception {
		Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
		cipher.init(Cipher.DECRYPT_MODE, generateKey(password));
		return cipher.doFinal(content);
	}

	/**
	 * 原始加密
	 * 
	 * @param content
	 *            霄1�7要加密的内容
	 * @return
	 */
	private static byte[] encrypt(String content) {
		try {
			byte[] byteContent = content.getBytes(CHARSETNAME);
			byte[] password = KEY_STR.getBytes(CHARSETNAME);
			return encrypt(byteContent, password); // 加密
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 原始解密
	 * 
	 * @param content
	 *            待解密内宄1�7
	 * @return
	 */
	public static String decrypt(String content) {
		try {
			byte[] decryptFrom = parseHexStr2Byte(content);
			byte[] password = KEY_STR.getBytes(CHARSETNAME);
			byte[] result = decrypt(decryptFrom, password);
			return new String(result); // 加密
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 将二进制转换戄1�7进制
	 * 
	 * @param buf
	 * @return
	 */
	public static String parseByte2HexStr(String content) {
		byte[] encryptResult = encrypt(content);
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < encryptResult.length; i++) {
			String hex = Integer.toHexString(encryptResult[i] & 0xFF);
			if (hex.length() == 1) {
				hex = '0' + hex;
			}
			sb.append(hex.toUpperCase());
		}
		return sb.toString();
	}

	/**
	 * 射1�7进制转换为二进制
	 * 
	 * @param hexStr
	 * @return
	 */
	private static byte[] parseHexStr2Byte(String hexStr) {
		if (hexStr.length() < 1)
			return null;
		byte[] result = new byte[hexStr.length() / 2];
		for (int i = 0; i < hexStr.length() / 2; i++) {
			int high = Integer.parseInt(hexStr.substring(i * 2, i * 2 + 1), 16);
			int low = Integer.parseInt(hexStr.substring(i * 2 + 1, i * 2 + 2),
					16);
			result[i] = (byte) (high * 16 + low);
		}
		return result;
	}

	public static void main(String[] args) {
		System.out.println("加密后：" + parseByte2HexStr("Paic1234"));
		String decryptResult = decrypt("FE27EC30AEBB57D6DCC89C24A12860EE");
		System.out.println("解密后：" + new String(decryptResult));
	}
}
