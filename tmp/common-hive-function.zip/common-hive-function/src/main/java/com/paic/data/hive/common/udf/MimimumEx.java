package com.paic.data.hive.common.udf;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;

@Description(name = "min_ex", value = "_FUNC_(n, number... numbers) - Returns a value which is Fifth min")
public class MimimumEx extends UDF {

	private Comparator<Number> comparator = new Comparator<Number>() {

		@Override
		public int compare(Number o1, Number o2) {

			return ((Comparable) o1).compareTo(o2);
		}
	};

	public Integer evaluate(int n, Integer... parameters) {
		Number ret = this.calcuateN(n, parameters);

		return ret == null ? null : ret.intValue();
	}

	public Long evaluate(int n, Long... parameters) {
		Number ret = this.calcuateN(n, parameters);

		return ret == null ? null : ret.longValue();
	}

	public Double evaluate(int n, Double... parameters) {
		Number ret = this.calcuateN(n, parameters);

		return ret == null ? null : ret.doubleValue();
	}

	public Float evaluate(int n, Float... parameters) {
		Number ret = this.calcuateN(n, parameters);

		return ret == null ? null : ret.floatValue();
	}

	private Number calcuateN(int n, Number... parameters) {
		if (parameters == null || parameters.length == 0) {
			return null;
		}

		if (n <= 0) {
			return null;
		}

		if (parameters.length < n) {
			return null;
		}

		List<Number> list = new ArrayList<>(parameters.length);
		for (Number number : parameters) {
			if (number != null) {
				list.add(number);
			}
		}

		if (list.size() < n) {
			return null;
		}

		Collections.sort(list, comparator);

		return list.get(n - 1);
	}
}
