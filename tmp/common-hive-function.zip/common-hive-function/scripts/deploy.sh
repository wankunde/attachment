#!/usr/bin/env bash
cd ${0%/*}
hadoop dfs -put -f common-hive-function-1.0-SNAPSHOT.jar /metadata/libs/udf/common-hive-function-1.0-SNAPSHOT.jar
sudo cp common-hive-function-1.0-SNAPSHOT.jar /usr/lib/hive/lib/common-hive-function-1.0-SNAPSHOT.jar
sudo chmod 777 /usr/lib/hive/lib/common-hive-function-1.0-SNAPSHOT.jar
sudo service hive-server2 restart